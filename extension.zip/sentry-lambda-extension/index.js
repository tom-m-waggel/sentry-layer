#!/usr/bin/env node
"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// node_modules/web-streams-polyfill/dist/ponyfill.es2018.js
var require_ponyfill_es2018 = __commonJS({
  "node_modules/web-streams-polyfill/dist/ponyfill.es2018.js"(exports2, module2) {
    (function(global2, factory) {
      typeof exports2 === "object" && typeof module2 !== "undefined" ? factory(exports2) : typeof define === "function" && define.amd ? define(["exports"], factory) : (global2 = typeof globalThis !== "undefined" ? globalThis : global2 || self, factory(global2.WebStreamsPolyfill = {}));
    })(exports2, function(exports3) {
      "use strict";
      const SymbolPolyfill = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? Symbol : (description) => `Symbol(${description})`;
      function noop2() {
        return void 0;
      }
      function typeIsObject(x2) {
        return typeof x2 === "object" && x2 !== null || typeof x2 === "function";
      }
      const rethrowAssertionErrorRejection = noop2;
      function setFunctionName(fn, name) {
        try {
          Object.defineProperty(fn, "name", {
            value: name,
            configurable: true
          });
        } catch (_a) {
        }
      }
      const originalPromise = Promise;
      const originalPromiseThen = Promise.prototype.then;
      const originalPromiseReject = Promise.reject.bind(originalPromise);
      function newPromise(executor) {
        return new originalPromise(executor);
      }
      function promiseResolvedWith(value) {
        return newPromise((resolve2) => resolve2(value));
      }
      function promiseRejectedWith(reason) {
        return originalPromiseReject(reason);
      }
      function PerformPromiseThen(promise, onFulfilled, onRejected) {
        return originalPromiseThen.call(promise, onFulfilled, onRejected);
      }
      function uponPromise(promise, onFulfilled, onRejected) {
        PerformPromiseThen(PerformPromiseThen(promise, onFulfilled, onRejected), void 0, rethrowAssertionErrorRejection);
      }
      function uponFulfillment(promise, onFulfilled) {
        uponPromise(promise, onFulfilled);
      }
      function uponRejection(promise, onRejected) {
        uponPromise(promise, void 0, onRejected);
      }
      function transformPromiseWith(promise, fulfillmentHandler, rejectionHandler) {
        return PerformPromiseThen(promise, fulfillmentHandler, rejectionHandler);
      }
      function setPromiseIsHandledToTrue(promise) {
        PerformPromiseThen(promise, void 0, rethrowAssertionErrorRejection);
      }
      let _queueMicrotask = (callback) => {
        if (typeof queueMicrotask === "function") {
          _queueMicrotask = queueMicrotask;
        } else {
          const resolvedPromise = promiseResolvedWith(void 0);
          _queueMicrotask = (cb) => PerformPromiseThen(resolvedPromise, cb);
        }
        return _queueMicrotask(callback);
      };
      function reflectCall(F2, V, args) {
        if (typeof F2 !== "function") {
          throw new TypeError("Argument is not a function");
        }
        return Function.prototype.apply.call(F2, V, args);
      }
      function promiseCall(F2, V, args) {
        try {
          return promiseResolvedWith(reflectCall(F2, V, args));
        } catch (value) {
          return promiseRejectedWith(value);
        }
      }
      const QUEUE_MAX_ARRAY_SIZE = 16384;
      class SimpleQueue {
        constructor() {
          this._cursor = 0;
          this._size = 0;
          this._front = {
            _elements: [],
            _next: void 0
          };
          this._back = this._front;
          this._cursor = 0;
          this._size = 0;
        }
        get length() {
          return this._size;
        }
        // For exception safety, this method is structured in order:
        // 1. Read state
        // 2. Calculate required state mutations
        // 3. Perform state mutations
        push(element) {
          const oldBack = this._back;
          let newBack = oldBack;
          if (oldBack._elements.length === QUEUE_MAX_ARRAY_SIZE - 1) {
            newBack = {
              _elements: [],
              _next: void 0
            };
          }
          oldBack._elements.push(element);
          if (newBack !== oldBack) {
            this._back = newBack;
            oldBack._next = newBack;
          }
          ++this._size;
        }
        // Like push(), shift() follows the read -> calculate -> mutate pattern for
        // exception safety.
        shift() {
          const oldFront = this._front;
          let newFront = oldFront;
          const oldCursor = this._cursor;
          let newCursor = oldCursor + 1;
          const elements = oldFront._elements;
          const element = elements[oldCursor];
          if (newCursor === QUEUE_MAX_ARRAY_SIZE) {
            newFront = oldFront._next;
            newCursor = 0;
          }
          --this._size;
          this._cursor = newCursor;
          if (oldFront !== newFront) {
            this._front = newFront;
          }
          elements[oldCursor] = void 0;
          return element;
        }
        // The tricky thing about forEach() is that it can be called
        // re-entrantly. The queue may be mutated inside the callback. It is easy to
        // see that push() within the callback has no negative effects since the end
        // of the queue is checked for on every iteration. If shift() is called
        // repeatedly within the callback then the next iteration may return an
        // element that has been removed. In this case the callback will be called
        // with undefined values until we either "catch up" with elements that still
        // exist or reach the back of the queue.
        forEach(callback) {
          let i2 = this._cursor;
          let node = this._front;
          let elements = node._elements;
          while (i2 !== elements.length || node._next !== void 0) {
            if (i2 === elements.length) {
              node = node._next;
              elements = node._elements;
              i2 = 0;
              if (elements.length === 0) {
                break;
              }
            }
            callback(elements[i2]);
            ++i2;
          }
        }
        // Return the element that would be returned if shift() was called now,
        // without modifying the queue.
        peek() {
          const front = this._front;
          const cursor = this._cursor;
          return front._elements[cursor];
        }
      }
      const AbortSteps = SymbolPolyfill("[[AbortSteps]]");
      const ErrorSteps = SymbolPolyfill("[[ErrorSteps]]");
      const CancelSteps = SymbolPolyfill("[[CancelSteps]]");
      const PullSteps = SymbolPolyfill("[[PullSteps]]");
      const ReleaseSteps = SymbolPolyfill("[[ReleaseSteps]]");
      function ReadableStreamReaderGenericInitialize(reader, stream) {
        reader._ownerReadableStream = stream;
        stream._reader = reader;
        if (stream._state === "readable") {
          defaultReaderClosedPromiseInitialize(reader);
        } else if (stream._state === "closed") {
          defaultReaderClosedPromiseInitializeAsResolved(reader);
        } else {
          defaultReaderClosedPromiseInitializeAsRejected(reader, stream._storedError);
        }
      }
      function ReadableStreamReaderGenericCancel(reader, reason) {
        const stream = reader._ownerReadableStream;
        return ReadableStreamCancel(stream, reason);
      }
      function ReadableStreamReaderGenericRelease(reader) {
        const stream = reader._ownerReadableStream;
        if (stream._state === "readable") {
          defaultReaderClosedPromiseReject(reader, new TypeError(`Reader was released and can no longer be used to monitor the stream's closedness`));
        } else {
          defaultReaderClosedPromiseResetToRejected(reader, new TypeError(`Reader was released and can no longer be used to monitor the stream's closedness`));
        }
        stream._readableStreamController[ReleaseSteps]();
        stream._reader = void 0;
        reader._ownerReadableStream = void 0;
      }
      function readerLockException(name) {
        return new TypeError("Cannot " + name + " a stream using a released reader");
      }
      function defaultReaderClosedPromiseInitialize(reader) {
        reader._closedPromise = newPromise((resolve2, reject) => {
          reader._closedPromise_resolve = resolve2;
          reader._closedPromise_reject = reject;
        });
      }
      function defaultReaderClosedPromiseInitializeAsRejected(reader, reason) {
        defaultReaderClosedPromiseInitialize(reader);
        defaultReaderClosedPromiseReject(reader, reason);
      }
      function defaultReaderClosedPromiseInitializeAsResolved(reader) {
        defaultReaderClosedPromiseInitialize(reader);
        defaultReaderClosedPromiseResolve(reader);
      }
      function defaultReaderClosedPromiseReject(reader, reason) {
        if (reader._closedPromise_reject === void 0) {
          return;
        }
        setPromiseIsHandledToTrue(reader._closedPromise);
        reader._closedPromise_reject(reason);
        reader._closedPromise_resolve = void 0;
        reader._closedPromise_reject = void 0;
      }
      function defaultReaderClosedPromiseResetToRejected(reader, reason) {
        defaultReaderClosedPromiseInitializeAsRejected(reader, reason);
      }
      function defaultReaderClosedPromiseResolve(reader) {
        if (reader._closedPromise_resolve === void 0) {
          return;
        }
        reader._closedPromise_resolve(void 0);
        reader._closedPromise_resolve = void 0;
        reader._closedPromise_reject = void 0;
      }
      const NumberIsFinite = Number.isFinite || function(x2) {
        return typeof x2 === "number" && isFinite(x2);
      };
      const MathTrunc = Math.trunc || function(v) {
        return v < 0 ? Math.ceil(v) : Math.floor(v);
      };
      function isDictionary(x2) {
        return typeof x2 === "object" || typeof x2 === "function";
      }
      function assertDictionary(obj, context) {
        if (obj !== void 0 && !isDictionary(obj)) {
          throw new TypeError(`${context} is not an object.`);
        }
      }
      function assertFunction(x2, context) {
        if (typeof x2 !== "function") {
          throw new TypeError(`${context} is not a function.`);
        }
      }
      function isObject(x2) {
        return typeof x2 === "object" && x2 !== null || typeof x2 === "function";
      }
      function assertObject(x2, context) {
        if (!isObject(x2)) {
          throw new TypeError(`${context} is not an object.`);
        }
      }
      function assertRequiredArgument(x2, position, context) {
        if (x2 === void 0) {
          throw new TypeError(`Parameter ${position} is required in '${context}'.`);
        }
      }
      function assertRequiredField(x2, field, context) {
        if (x2 === void 0) {
          throw new TypeError(`${field} is required in '${context}'.`);
        }
      }
      function convertUnrestrictedDouble(value) {
        return Number(value);
      }
      function censorNegativeZero(x2) {
        return x2 === 0 ? 0 : x2;
      }
      function integerPart(x2) {
        return censorNegativeZero(MathTrunc(x2));
      }
      function convertUnsignedLongLongWithEnforceRange(value, context) {
        const lowerBound = 0;
        const upperBound = Number.MAX_SAFE_INTEGER;
        let x2 = Number(value);
        x2 = censorNegativeZero(x2);
        if (!NumberIsFinite(x2)) {
          throw new TypeError(`${context} is not a finite number`);
        }
        x2 = integerPart(x2);
        if (x2 < lowerBound || x2 > upperBound) {
          throw new TypeError(`${context} is outside the accepted range of ${lowerBound} to ${upperBound}, inclusive`);
        }
        if (!NumberIsFinite(x2) || x2 === 0) {
          return 0;
        }
        return x2;
      }
      function assertReadableStream(x2, context) {
        if (!IsReadableStream(x2)) {
          throw new TypeError(`${context} is not a ReadableStream.`);
        }
      }
      function AcquireReadableStreamDefaultReader(stream) {
        return new ReadableStreamDefaultReader(stream);
      }
      function ReadableStreamAddReadRequest(stream, readRequest) {
        stream._reader._readRequests.push(readRequest);
      }
      function ReadableStreamFulfillReadRequest(stream, chunk, done) {
        const reader = stream._reader;
        const readRequest = reader._readRequests.shift();
        if (done) {
          readRequest._closeSteps();
        } else {
          readRequest._chunkSteps(chunk);
        }
      }
      function ReadableStreamGetNumReadRequests(stream) {
        return stream._reader._readRequests.length;
      }
      function ReadableStreamHasDefaultReader(stream) {
        const reader = stream._reader;
        if (reader === void 0) {
          return false;
        }
        if (!IsReadableStreamDefaultReader(reader)) {
          return false;
        }
        return true;
      }
      class ReadableStreamDefaultReader {
        constructor(stream) {
          assertRequiredArgument(stream, 1, "ReadableStreamDefaultReader");
          assertReadableStream(stream, "First parameter");
          if (IsReadableStreamLocked(stream)) {
            throw new TypeError("This stream has already been locked for exclusive reading by another reader");
          }
          ReadableStreamReaderGenericInitialize(this, stream);
          this._readRequests = new SimpleQueue();
        }
        /**
         * Returns a promise that will be fulfilled when the stream becomes closed,
         * or rejected if the stream ever errors or the reader's lock is released before the stream finishes closing.
         */
        get closed() {
          if (!IsReadableStreamDefaultReader(this)) {
            return promiseRejectedWith(defaultReaderBrandCheckException("closed"));
          }
          return this._closedPromise;
        }
        /**
         * If the reader is active, behaves the same as {@link ReadableStream.cancel | stream.cancel(reason)}.
         */
        cancel(reason = void 0) {
          if (!IsReadableStreamDefaultReader(this)) {
            return promiseRejectedWith(defaultReaderBrandCheckException("cancel"));
          }
          if (this._ownerReadableStream === void 0) {
            return promiseRejectedWith(readerLockException("cancel"));
          }
          return ReadableStreamReaderGenericCancel(this, reason);
        }
        /**
         * Returns a promise that allows access to the next chunk from the stream's internal queue, if available.
         *
         * If reading a chunk causes the queue to become empty, more data will be pulled from the underlying source.
         */
        read() {
          if (!IsReadableStreamDefaultReader(this)) {
            return promiseRejectedWith(defaultReaderBrandCheckException("read"));
          }
          if (this._ownerReadableStream === void 0) {
            return promiseRejectedWith(readerLockException("read from"));
          }
          let resolvePromise;
          let rejectPromise;
          const promise = newPromise((resolve2, reject) => {
            resolvePromise = resolve2;
            rejectPromise = reject;
          });
          const readRequest = {
            _chunkSteps: (chunk) => resolvePromise({ value: chunk, done: false }),
            _closeSteps: () => resolvePromise({ value: void 0, done: true }),
            _errorSteps: (e2) => rejectPromise(e2)
          };
          ReadableStreamDefaultReaderRead(this, readRequest);
          return promise;
        }
        /**
         * Releases the reader's lock on the corresponding stream. After the lock is released, the reader is no longer active.
         * If the associated stream is errored when the lock is released, the reader will appear errored in the same way
         * from now on; otherwise, the reader will appear closed.
         *
         * A reader's lock cannot be released while it still has a pending read request, i.e., if a promise returned by
         * the reader's {@link ReadableStreamDefaultReader.read | read()} method has not yet been settled. Attempting to
         * do so will throw a `TypeError` and leave the reader locked to the stream.
         */
        releaseLock() {
          if (!IsReadableStreamDefaultReader(this)) {
            throw defaultReaderBrandCheckException("releaseLock");
          }
          if (this._ownerReadableStream === void 0) {
            return;
          }
          ReadableStreamDefaultReaderRelease(this);
        }
      }
      Object.defineProperties(ReadableStreamDefaultReader.prototype, {
        cancel: { enumerable: true },
        read: { enumerable: true },
        releaseLock: { enumerable: true },
        closed: { enumerable: true }
      });
      setFunctionName(ReadableStreamDefaultReader.prototype.cancel, "cancel");
      setFunctionName(ReadableStreamDefaultReader.prototype.read, "read");
      setFunctionName(ReadableStreamDefaultReader.prototype.releaseLock, "releaseLock");
      if (typeof SymbolPolyfill.toStringTag === "symbol") {
        Object.defineProperty(ReadableStreamDefaultReader.prototype, SymbolPolyfill.toStringTag, {
          value: "ReadableStreamDefaultReader",
          configurable: true
        });
      }
      function IsReadableStreamDefaultReader(x2) {
        if (!typeIsObject(x2)) {
          return false;
        }
        if (!Object.prototype.hasOwnProperty.call(x2, "_readRequests")) {
          return false;
        }
        return x2 instanceof ReadableStreamDefaultReader;
      }
      function ReadableStreamDefaultReaderRead(reader, readRequest) {
        const stream = reader._ownerReadableStream;
        stream._disturbed = true;
        if (stream._state === "closed") {
          readRequest._closeSteps();
        } else if (stream._state === "errored") {
          readRequest._errorSteps(stream._storedError);
        } else {
          stream._readableStreamController[PullSteps](readRequest);
        }
      }
      function ReadableStreamDefaultReaderRelease(reader) {
        ReadableStreamReaderGenericRelease(reader);
        const e2 = new TypeError("Reader was released");
        ReadableStreamDefaultReaderErrorReadRequests(reader, e2);
      }
      function ReadableStreamDefaultReaderErrorReadRequests(reader, e2) {
        const readRequests = reader._readRequests;
        reader._readRequests = new SimpleQueue();
        readRequests.forEach((readRequest) => {
          readRequest._errorSteps(e2);
        });
      }
      function defaultReaderBrandCheckException(name) {
        return new TypeError(`ReadableStreamDefaultReader.prototype.${name} can only be used on a ReadableStreamDefaultReader`);
      }
      const AsyncIteratorPrototype = Object.getPrototypeOf(Object.getPrototypeOf(async function* () {
      }).prototype);
      class ReadableStreamAsyncIteratorImpl {
        constructor(reader, preventCancel) {
          this._ongoingPromise = void 0;
          this._isFinished = false;
          this._reader = reader;
          this._preventCancel = preventCancel;
        }
        next() {
          const nextSteps = () => this._nextSteps();
          this._ongoingPromise = this._ongoingPromise ? transformPromiseWith(this._ongoingPromise, nextSteps, nextSteps) : nextSteps();
          return this._ongoingPromise;
        }
        return(value) {
          const returnSteps = () => this._returnSteps(value);
          return this._ongoingPromise ? transformPromiseWith(this._ongoingPromise, returnSteps, returnSteps) : returnSteps();
        }
        _nextSteps() {
          if (this._isFinished) {
            return Promise.resolve({ value: void 0, done: true });
          }
          const reader = this._reader;
          let resolvePromise;
          let rejectPromise;
          const promise = newPromise((resolve2, reject) => {
            resolvePromise = resolve2;
            rejectPromise = reject;
          });
          const readRequest = {
            _chunkSteps: (chunk) => {
              this._ongoingPromise = void 0;
              _queueMicrotask(() => resolvePromise({ value: chunk, done: false }));
            },
            _closeSteps: () => {
              this._ongoingPromise = void 0;
              this._isFinished = true;
              ReadableStreamReaderGenericRelease(reader);
              resolvePromise({ value: void 0, done: true });
            },
            _errorSteps: (reason) => {
              this._ongoingPromise = void 0;
              this._isFinished = true;
              ReadableStreamReaderGenericRelease(reader);
              rejectPromise(reason);
            }
          };
          ReadableStreamDefaultReaderRead(reader, readRequest);
          return promise;
        }
        _returnSteps(value) {
          if (this._isFinished) {
            return Promise.resolve({ value, done: true });
          }
          this._isFinished = true;
          const reader = this._reader;
          if (!this._preventCancel) {
            const result = ReadableStreamReaderGenericCancel(reader, value);
            ReadableStreamReaderGenericRelease(reader);
            return transformPromiseWith(result, () => ({ value, done: true }));
          }
          ReadableStreamReaderGenericRelease(reader);
          return promiseResolvedWith({ value, done: true });
        }
      }
      const ReadableStreamAsyncIteratorPrototype = {
        next() {
          if (!IsReadableStreamAsyncIterator(this)) {
            return promiseRejectedWith(streamAsyncIteratorBrandCheckException("next"));
          }
          return this._asyncIteratorImpl.next();
        },
        return(value) {
          if (!IsReadableStreamAsyncIterator(this)) {
            return promiseRejectedWith(streamAsyncIteratorBrandCheckException("return"));
          }
          return this._asyncIteratorImpl.return(value);
        }
      };
      if (AsyncIteratorPrototype !== void 0) {
        Object.setPrototypeOf(ReadableStreamAsyncIteratorPrototype, AsyncIteratorPrototype);
      }
      function AcquireReadableStreamAsyncIterator(stream, preventCancel) {
        const reader = AcquireReadableStreamDefaultReader(stream);
        const impl = new ReadableStreamAsyncIteratorImpl(reader, preventCancel);
        const iterator = Object.create(ReadableStreamAsyncIteratorPrototype);
        iterator._asyncIteratorImpl = impl;
        return iterator;
      }
      function IsReadableStreamAsyncIterator(x2) {
        if (!typeIsObject(x2)) {
          return false;
        }
        if (!Object.prototype.hasOwnProperty.call(x2, "_asyncIteratorImpl")) {
          return false;
        }
        try {
          return x2._asyncIteratorImpl instanceof ReadableStreamAsyncIteratorImpl;
        } catch (_a) {
          return false;
        }
      }
      function streamAsyncIteratorBrandCheckException(name) {
        return new TypeError(`ReadableStreamAsyncIterator.${name} can only be used on a ReadableSteamAsyncIterator`);
      }
      const NumberIsNaN = Number.isNaN || function(x2) {
        return x2 !== x2;
      };
      function CreateArrayFromList(elements) {
        return elements.slice();
      }
      function CopyDataBlockBytes(dest, destOffset, src, srcOffset, n) {
        new Uint8Array(dest).set(new Uint8Array(src, srcOffset, n), destOffset);
      }
      let TransferArrayBuffer = (O) => {
        if (typeof O.transfer === "function") {
          TransferArrayBuffer = (buffer) => buffer.transfer();
        } else if (typeof structuredClone === "function") {
          TransferArrayBuffer = (buffer) => structuredClone(buffer, { transfer: [buffer] });
        } else {
          TransferArrayBuffer = (buffer) => buffer;
        }
        return TransferArrayBuffer(O);
      };
      let IsDetachedBuffer = (O) => {
        if (typeof O.detached === "boolean") {
          IsDetachedBuffer = (buffer) => buffer.detached;
        } else {
          IsDetachedBuffer = (buffer) => buffer.byteLength === 0;
        }
        return IsDetachedBuffer(O);
      };
      function ArrayBufferSlice(buffer, begin, end) {
        if (buffer.slice) {
          return buffer.slice(begin, end);
        }
        const length = end - begin;
        const slice = new ArrayBuffer(length);
        CopyDataBlockBytes(slice, 0, buffer, begin, length);
        return slice;
      }
      function GetMethod(receiver, prop) {
        const func = receiver[prop];
        if (func === void 0 || func === null) {
          return void 0;
        }
        if (typeof func !== "function") {
          throw new TypeError(`${String(prop)} is not a function`);
        }
        return func;
      }
      function CreateAsyncFromSyncIterator(syncIteratorRecord) {
        const syncIterable = {
          [SymbolPolyfill.iterator]: () => syncIteratorRecord.iterator
        };
        const asyncIterator = async function* () {
          return yield* syncIterable;
        }();
        const nextMethod = asyncIterator.next;
        return { iterator: asyncIterator, nextMethod, done: false };
      }
      function GetIterator(obj, hint = "sync", method) {
        if (method === void 0) {
          if (hint === "async") {
            method = GetMethod(obj, SymbolPolyfill.asyncIterator);
            if (method === void 0) {
              const syncMethod = GetMethod(obj, SymbolPolyfill.iterator);
              const syncIteratorRecord = GetIterator(obj, "sync", syncMethod);
              return CreateAsyncFromSyncIterator(syncIteratorRecord);
            }
          } else {
            method = GetMethod(obj, SymbolPolyfill.iterator);
          }
        }
        if (method === void 0) {
          throw new TypeError("The object is not iterable");
        }
        const iterator = reflectCall(method, obj, []);
        if (!typeIsObject(iterator)) {
          throw new TypeError("The iterator method must return an object");
        }
        const nextMethod = iterator.next;
        return { iterator, nextMethod, done: false };
      }
      function IteratorNext(iteratorRecord) {
        const result = reflectCall(iteratorRecord.nextMethod, iteratorRecord.iterator, []);
        if (!typeIsObject(result)) {
          throw new TypeError("The iterator.next() method must return an object");
        }
        return result;
      }
      function IteratorComplete(iterResult) {
        return Boolean(iterResult.done);
      }
      function IteratorValue(iterResult) {
        return iterResult.value;
      }
      function IsNonNegativeNumber(v) {
        if (typeof v !== "number") {
          return false;
        }
        if (NumberIsNaN(v)) {
          return false;
        }
        if (v < 0) {
          return false;
        }
        return true;
      }
      function CloneAsUint8Array(O) {
        const buffer = ArrayBufferSlice(O.buffer, O.byteOffset, O.byteOffset + O.byteLength);
        return new Uint8Array(buffer);
      }
      function DequeueValue(container) {
        const pair = container._queue.shift();
        container._queueTotalSize -= pair.size;
        if (container._queueTotalSize < 0) {
          container._queueTotalSize = 0;
        }
        return pair.value;
      }
      function EnqueueValueWithSize(container, value, size) {
        if (!IsNonNegativeNumber(size) || size === Infinity) {
          throw new RangeError("Size must be a finite, non-NaN, non-negative number.");
        }
        container._queue.push({ value, size });
        container._queueTotalSize += size;
      }
      function PeekQueueValue(container) {
        const pair = container._queue.peek();
        return pair.value;
      }
      function ResetQueue(container) {
        container._queue = new SimpleQueue();
        container._queueTotalSize = 0;
      }
      function isDataViewConstructor(ctor) {
        return ctor === DataView;
      }
      function isDataView(view) {
        return isDataViewConstructor(view.constructor);
      }
      function arrayBufferViewElementSize(ctor) {
        if (isDataViewConstructor(ctor)) {
          return 1;
        }
        return ctor.BYTES_PER_ELEMENT;
      }
      class ReadableStreamBYOBRequest {
        constructor() {
          throw new TypeError("Illegal constructor");
        }
        /**
         * Returns the view for writing in to, or `null` if the BYOB request has already been responded to.
         */
        get view() {
          if (!IsReadableStreamBYOBRequest(this)) {
            throw byobRequestBrandCheckException("view");
          }
          return this._view;
        }
        respond(bytesWritten) {
          if (!IsReadableStreamBYOBRequest(this)) {
            throw byobRequestBrandCheckException("respond");
          }
          assertRequiredArgument(bytesWritten, 1, "respond");
          bytesWritten = convertUnsignedLongLongWithEnforceRange(bytesWritten, "First parameter");
          if (this._associatedReadableByteStreamController === void 0) {
            throw new TypeError("This BYOB request has been invalidated");
          }
          if (IsDetachedBuffer(this._view.buffer)) {
            throw new TypeError(`The BYOB request's buffer has been detached and so cannot be used as a response`);
          }
          ReadableByteStreamControllerRespond(this._associatedReadableByteStreamController, bytesWritten);
        }
        respondWithNewView(view) {
          if (!IsReadableStreamBYOBRequest(this)) {
            throw byobRequestBrandCheckException("respondWithNewView");
          }
          assertRequiredArgument(view, 1, "respondWithNewView");
          if (!ArrayBuffer.isView(view)) {
            throw new TypeError("You can only respond with array buffer views");
          }
          if (this._associatedReadableByteStreamController === void 0) {
            throw new TypeError("This BYOB request has been invalidated");
          }
          if (IsDetachedBuffer(view.buffer)) {
            throw new TypeError("The given view's buffer has been detached and so cannot be used as a response");
          }
          ReadableByteStreamControllerRespondWithNewView(this._associatedReadableByteStreamController, view);
        }
      }
      Object.defineProperties(ReadableStreamBYOBRequest.prototype, {
        respond: { enumerable: true },
        respondWithNewView: { enumerable: true },
        view: { enumerable: true }
      });
      setFunctionName(ReadableStreamBYOBRequest.prototype.respond, "respond");
      setFunctionName(ReadableStreamBYOBRequest.prototype.respondWithNewView, "respondWithNewView");
      if (typeof SymbolPolyfill.toStringTag === "symbol") {
        Object.defineProperty(ReadableStreamBYOBRequest.prototype, SymbolPolyfill.toStringTag, {
          value: "ReadableStreamBYOBRequest",
          configurable: true
        });
      }
      class ReadableByteStreamController {
        constructor() {
          throw new TypeError("Illegal constructor");
        }
        /**
         * Returns the current BYOB pull request, or `null` if there isn't one.
         */
        get byobRequest() {
          if (!IsReadableByteStreamController(this)) {
            throw byteStreamControllerBrandCheckException("byobRequest");
          }
          return ReadableByteStreamControllerGetBYOBRequest(this);
        }
        /**
         * Returns the desired size to fill the controlled stream's internal queue. It can be negative, if the queue is
         * over-full. An underlying byte source ought to use this information to determine when and how to apply backpressure.
         */
        get desiredSize() {
          if (!IsReadableByteStreamController(this)) {
            throw byteStreamControllerBrandCheckException("desiredSize");
          }
          return ReadableByteStreamControllerGetDesiredSize(this);
        }
        /**
         * Closes the controlled readable stream. Consumers will still be able to read any previously-enqueued chunks from
         * the stream, but once those are read, the stream will become closed.
         */
        close() {
          if (!IsReadableByteStreamController(this)) {
            throw byteStreamControllerBrandCheckException("close");
          }
          if (this._closeRequested) {
            throw new TypeError("The stream has already been closed; do not close it again!");
          }
          const state = this._controlledReadableByteStream._state;
          if (state !== "readable") {
            throw new TypeError(`The stream (in ${state} state) is not in the readable state and cannot be closed`);
          }
          ReadableByteStreamControllerClose(this);
        }
        enqueue(chunk) {
          if (!IsReadableByteStreamController(this)) {
            throw byteStreamControllerBrandCheckException("enqueue");
          }
          assertRequiredArgument(chunk, 1, "enqueue");
          if (!ArrayBuffer.isView(chunk)) {
            throw new TypeError("chunk must be an array buffer view");
          }
          if (chunk.byteLength === 0) {
            throw new TypeError("chunk must have non-zero byteLength");
          }
          if (chunk.buffer.byteLength === 0) {
            throw new TypeError(`chunk's buffer must have non-zero byteLength`);
          }
          if (this._closeRequested) {
            throw new TypeError("stream is closed or draining");
          }
          const state = this._controlledReadableByteStream._state;
          if (state !== "readable") {
            throw new TypeError(`The stream (in ${state} state) is not in the readable state and cannot be enqueued to`);
          }
          ReadableByteStreamControllerEnqueue(this, chunk);
        }
        /**
         * Errors the controlled readable stream, making all future interactions with it fail with the given error `e`.
         */
        error(e2 = void 0) {
          if (!IsReadableByteStreamController(this)) {
            throw byteStreamControllerBrandCheckException("error");
          }
          ReadableByteStreamControllerError(this, e2);
        }
        /** @internal */
        [CancelSteps](reason) {
          ReadableByteStreamControllerClearPendingPullIntos(this);
          ResetQueue(this);
          const result = this._cancelAlgorithm(reason);
          ReadableByteStreamControllerClearAlgorithms(this);
          return result;
        }
        /** @internal */
        [PullSteps](readRequest) {
          const stream = this._controlledReadableByteStream;
          if (this._queueTotalSize > 0) {
            ReadableByteStreamControllerFillReadRequestFromQueue(this, readRequest);
            return;
          }
          const autoAllocateChunkSize = this._autoAllocateChunkSize;
          if (autoAllocateChunkSize !== void 0) {
            let buffer;
            try {
              buffer = new ArrayBuffer(autoAllocateChunkSize);
            } catch (bufferE) {
              readRequest._errorSteps(bufferE);
              return;
            }
            const pullIntoDescriptor = {
              buffer,
              bufferByteLength: autoAllocateChunkSize,
              byteOffset: 0,
              byteLength: autoAllocateChunkSize,
              bytesFilled: 0,
              minimumFill: 1,
              elementSize: 1,
              viewConstructor: Uint8Array,
              readerType: "default"
            };
            this._pendingPullIntos.push(pullIntoDescriptor);
          }
          ReadableStreamAddReadRequest(stream, readRequest);
          ReadableByteStreamControllerCallPullIfNeeded(this);
        }
        /** @internal */
        [ReleaseSteps]() {
          if (this._pendingPullIntos.length > 0) {
            const firstPullInto = this._pendingPullIntos.peek();
            firstPullInto.readerType = "none";
            this._pendingPullIntos = new SimpleQueue();
            this._pendingPullIntos.push(firstPullInto);
          }
        }
      }
      Object.defineProperties(ReadableByteStreamController.prototype, {
        close: { enumerable: true },
        enqueue: { enumerable: true },
        error: { enumerable: true },
        byobRequest: { enumerable: true },
        desiredSize: { enumerable: true }
      });
      setFunctionName(ReadableByteStreamController.prototype.close, "close");
      setFunctionName(ReadableByteStreamController.prototype.enqueue, "enqueue");
      setFunctionName(ReadableByteStreamController.prototype.error, "error");
      if (typeof SymbolPolyfill.toStringTag === "symbol") {
        Object.defineProperty(ReadableByteStreamController.prototype, SymbolPolyfill.toStringTag, {
          value: "ReadableByteStreamController",
          configurable: true
        });
      }
      function IsReadableByteStreamController(x2) {
        if (!typeIsObject(x2)) {
          return false;
        }
        if (!Object.prototype.hasOwnProperty.call(x2, "_controlledReadableByteStream")) {
          return false;
        }
        return x2 instanceof ReadableByteStreamController;
      }
      function IsReadableStreamBYOBRequest(x2) {
        if (!typeIsObject(x2)) {
          return false;
        }
        if (!Object.prototype.hasOwnProperty.call(x2, "_associatedReadableByteStreamController")) {
          return false;
        }
        return x2 instanceof ReadableStreamBYOBRequest;
      }
      function ReadableByteStreamControllerCallPullIfNeeded(controller) {
        const shouldPull = ReadableByteStreamControllerShouldCallPull(controller);
        if (!shouldPull) {
          return;
        }
        if (controller._pulling) {
          controller._pullAgain = true;
          return;
        }
        controller._pulling = true;
        const pullPromise = controller._pullAlgorithm();
        uponPromise(pullPromise, () => {
          controller._pulling = false;
          if (controller._pullAgain) {
            controller._pullAgain = false;
            ReadableByteStreamControllerCallPullIfNeeded(controller);
          }
          return null;
        }, (e2) => {
          ReadableByteStreamControllerError(controller, e2);
          return null;
        });
      }
      function ReadableByteStreamControllerClearPendingPullIntos(controller) {
        ReadableByteStreamControllerInvalidateBYOBRequest(controller);
        controller._pendingPullIntos = new SimpleQueue();
      }
      function ReadableByteStreamControllerCommitPullIntoDescriptor(stream, pullIntoDescriptor) {
        let done = false;
        if (stream._state === "closed") {
          done = true;
        }
        const filledView = ReadableByteStreamControllerConvertPullIntoDescriptor(pullIntoDescriptor);
        if (pullIntoDescriptor.readerType === "default") {
          ReadableStreamFulfillReadRequest(stream, filledView, done);
        } else {
          ReadableStreamFulfillReadIntoRequest(stream, filledView, done);
        }
      }
      function ReadableByteStreamControllerConvertPullIntoDescriptor(pullIntoDescriptor) {
        const bytesFilled = pullIntoDescriptor.bytesFilled;
        const elementSize = pullIntoDescriptor.elementSize;
        return new pullIntoDescriptor.viewConstructor(pullIntoDescriptor.buffer, pullIntoDescriptor.byteOffset, bytesFilled / elementSize);
      }
      function ReadableByteStreamControllerEnqueueChunkToQueue(controller, buffer, byteOffset, byteLength) {
        controller._queue.push({ buffer, byteOffset, byteLength });
        controller._queueTotalSize += byteLength;
      }
      function ReadableByteStreamControllerEnqueueClonedChunkToQueue(controller, buffer, byteOffset, byteLength) {
        let clonedChunk;
        try {
          clonedChunk = ArrayBufferSlice(buffer, byteOffset, byteOffset + byteLength);
        } catch (cloneE) {
          ReadableByteStreamControllerError(controller, cloneE);
          throw cloneE;
        }
        ReadableByteStreamControllerEnqueueChunkToQueue(controller, clonedChunk, 0, byteLength);
      }
      function ReadableByteStreamControllerEnqueueDetachedPullIntoToQueue(controller, firstDescriptor) {
        if (firstDescriptor.bytesFilled > 0) {
          ReadableByteStreamControllerEnqueueClonedChunkToQueue(controller, firstDescriptor.buffer, firstDescriptor.byteOffset, firstDescriptor.bytesFilled);
        }
        ReadableByteStreamControllerShiftPendingPullInto(controller);
      }
      function ReadableByteStreamControllerFillPullIntoDescriptorFromQueue(controller, pullIntoDescriptor) {
        const maxBytesToCopy = Math.min(controller._queueTotalSize, pullIntoDescriptor.byteLength - pullIntoDescriptor.bytesFilled);
        const maxBytesFilled = pullIntoDescriptor.bytesFilled + maxBytesToCopy;
        let totalBytesToCopyRemaining = maxBytesToCopy;
        let ready = false;
        const remainderBytes = maxBytesFilled % pullIntoDescriptor.elementSize;
        const maxAlignedBytes = maxBytesFilled - remainderBytes;
        if (maxAlignedBytes >= pullIntoDescriptor.minimumFill) {
          totalBytesToCopyRemaining = maxAlignedBytes - pullIntoDescriptor.bytesFilled;
          ready = true;
        }
        const queue = controller._queue;
        while (totalBytesToCopyRemaining > 0) {
          const headOfQueue = queue.peek();
          const bytesToCopy = Math.min(totalBytesToCopyRemaining, headOfQueue.byteLength);
          const destStart = pullIntoDescriptor.byteOffset + pullIntoDescriptor.bytesFilled;
          CopyDataBlockBytes(pullIntoDescriptor.buffer, destStart, headOfQueue.buffer, headOfQueue.byteOffset, bytesToCopy);
          if (headOfQueue.byteLength === bytesToCopy) {
            queue.shift();
          } else {
            headOfQueue.byteOffset += bytesToCopy;
            headOfQueue.byteLength -= bytesToCopy;
          }
          controller._queueTotalSize -= bytesToCopy;
          ReadableByteStreamControllerFillHeadPullIntoDescriptor(controller, bytesToCopy, pullIntoDescriptor);
          totalBytesToCopyRemaining -= bytesToCopy;
        }
        return ready;
      }
      function ReadableByteStreamControllerFillHeadPullIntoDescriptor(controller, size, pullIntoDescriptor) {
        pullIntoDescriptor.bytesFilled += size;
      }
      function ReadableByteStreamControllerHandleQueueDrain(controller) {
        if (controller._queueTotalSize === 0 && controller._closeRequested) {
          ReadableByteStreamControllerClearAlgorithms(controller);
          ReadableStreamClose(controller._controlledReadableByteStream);
        } else {
          ReadableByteStreamControllerCallPullIfNeeded(controller);
        }
      }
      function ReadableByteStreamControllerInvalidateBYOBRequest(controller) {
        if (controller._byobRequest === null) {
          return;
        }
        controller._byobRequest._associatedReadableByteStreamController = void 0;
        controller._byobRequest._view = null;
        controller._byobRequest = null;
      }
      function ReadableByteStreamControllerProcessPullIntoDescriptorsUsingQueue(controller) {
        while (controller._pendingPullIntos.length > 0) {
          if (controller._queueTotalSize === 0) {
            return;
          }
          const pullIntoDescriptor = controller._pendingPullIntos.peek();
          if (ReadableByteStreamControllerFillPullIntoDescriptorFromQueue(controller, pullIntoDescriptor)) {
            ReadableByteStreamControllerShiftPendingPullInto(controller);
            ReadableByteStreamControllerCommitPullIntoDescriptor(controller._controlledReadableByteStream, pullIntoDescriptor);
          }
        }
      }
      function ReadableByteStreamControllerProcessReadRequestsUsingQueue(controller) {
        const reader = controller._controlledReadableByteStream._reader;
        while (reader._readRequests.length > 0) {
          if (controller._queueTotalSize === 0) {
            return;
          }
          const readRequest = reader._readRequests.shift();
          ReadableByteStreamControllerFillReadRequestFromQueue(controller, readRequest);
        }
      }
      function ReadableByteStreamControllerPullInto(controller, view, min, readIntoRequest) {
        const stream = controller._controlledReadableByteStream;
        const ctor = view.constructor;
        const elementSize = arrayBufferViewElementSize(ctor);
        const { byteOffset, byteLength } = view;
        const minimumFill = min * elementSize;
        let buffer;
        try {
          buffer = TransferArrayBuffer(view.buffer);
        } catch (e2) {
          readIntoRequest._errorSteps(e2);
          return;
        }
        const pullIntoDescriptor = {
          buffer,
          bufferByteLength: buffer.byteLength,
          byteOffset,
          byteLength,
          bytesFilled: 0,
          minimumFill,
          elementSize,
          viewConstructor: ctor,
          readerType: "byob"
        };
        if (controller._pendingPullIntos.length > 0) {
          controller._pendingPullIntos.push(pullIntoDescriptor);
          ReadableStreamAddReadIntoRequest(stream, readIntoRequest);
          return;
        }
        if (stream._state === "closed") {
          const emptyView = new ctor(pullIntoDescriptor.buffer, pullIntoDescriptor.byteOffset, 0);
          readIntoRequest._closeSteps(emptyView);
          return;
        }
        if (controller._queueTotalSize > 0) {
          if (ReadableByteStreamControllerFillPullIntoDescriptorFromQueue(controller, pullIntoDescriptor)) {
            const filledView = ReadableByteStreamControllerConvertPullIntoDescriptor(pullIntoDescriptor);
            ReadableByteStreamControllerHandleQueueDrain(controller);
            readIntoRequest._chunkSteps(filledView);
            return;
          }
          if (controller._closeRequested) {
            const e2 = new TypeError("Insufficient bytes to fill elements in the given buffer");
            ReadableByteStreamControllerError(controller, e2);
            readIntoRequest._errorSteps(e2);
            return;
          }
        }
        controller._pendingPullIntos.push(pullIntoDescriptor);
        ReadableStreamAddReadIntoRequest(stream, readIntoRequest);
        ReadableByteStreamControllerCallPullIfNeeded(controller);
      }
      function ReadableByteStreamControllerRespondInClosedState(controller, firstDescriptor) {
        if (firstDescriptor.readerType === "none") {
          ReadableByteStreamControllerShiftPendingPullInto(controller);
        }
        const stream = controller._controlledReadableByteStream;
        if (ReadableStreamHasBYOBReader(stream)) {
          while (ReadableStreamGetNumReadIntoRequests(stream) > 0) {
            const pullIntoDescriptor = ReadableByteStreamControllerShiftPendingPullInto(controller);
            ReadableByteStreamControllerCommitPullIntoDescriptor(stream, pullIntoDescriptor);
          }
        }
      }
      function ReadableByteStreamControllerRespondInReadableState(controller, bytesWritten, pullIntoDescriptor) {
        ReadableByteStreamControllerFillHeadPullIntoDescriptor(controller, bytesWritten, pullIntoDescriptor);
        if (pullIntoDescriptor.readerType === "none") {
          ReadableByteStreamControllerEnqueueDetachedPullIntoToQueue(controller, pullIntoDescriptor);
          ReadableByteStreamControllerProcessPullIntoDescriptorsUsingQueue(controller);
          return;
        }
        if (pullIntoDescriptor.bytesFilled < pullIntoDescriptor.minimumFill) {
          return;
        }
        ReadableByteStreamControllerShiftPendingPullInto(controller);
        const remainderSize = pullIntoDescriptor.bytesFilled % pullIntoDescriptor.elementSize;
        if (remainderSize > 0) {
          const end = pullIntoDescriptor.byteOffset + pullIntoDescriptor.bytesFilled;
          ReadableByteStreamControllerEnqueueClonedChunkToQueue(controller, pullIntoDescriptor.buffer, end - remainderSize, remainderSize);
        }
        pullIntoDescriptor.bytesFilled -= remainderSize;
        ReadableByteStreamControllerCommitPullIntoDescriptor(controller._controlledReadableByteStream, pullIntoDescriptor);
        ReadableByteStreamControllerProcessPullIntoDescriptorsUsingQueue(controller);
      }
      function ReadableByteStreamControllerRespondInternal(controller, bytesWritten) {
        const firstDescriptor = controller._pendingPullIntos.peek();
        ReadableByteStreamControllerInvalidateBYOBRequest(controller);
        const state = controller._controlledReadableByteStream._state;
        if (state === "closed") {
          ReadableByteStreamControllerRespondInClosedState(controller, firstDescriptor);
        } else {
          ReadableByteStreamControllerRespondInReadableState(controller, bytesWritten, firstDescriptor);
        }
        ReadableByteStreamControllerCallPullIfNeeded(controller);
      }
      function ReadableByteStreamControllerShiftPendingPullInto(controller) {
        const descriptor = controller._pendingPullIntos.shift();
        return descriptor;
      }
      function ReadableByteStreamControllerShouldCallPull(controller) {
        const stream = controller._controlledReadableByteStream;
        if (stream._state !== "readable") {
          return false;
        }
        if (controller._closeRequested) {
          return false;
        }
        if (!controller._started) {
          return false;
        }
        if (ReadableStreamHasDefaultReader(stream) && ReadableStreamGetNumReadRequests(stream) > 0) {
          return true;
        }
        if (ReadableStreamHasBYOBReader(stream) && ReadableStreamGetNumReadIntoRequests(stream) > 0) {
          return true;
        }
        const desiredSize = ReadableByteStreamControllerGetDesiredSize(controller);
        if (desiredSize > 0) {
          return true;
        }
        return false;
      }
      function ReadableByteStreamControllerClearAlgorithms(controller) {
        controller._pullAlgorithm = void 0;
        controller._cancelAlgorithm = void 0;
      }
      function ReadableByteStreamControllerClose(controller) {
        const stream = controller._controlledReadableByteStream;
        if (controller._closeRequested || stream._state !== "readable") {
          return;
        }
        if (controller._queueTotalSize > 0) {
          controller._closeRequested = true;
          return;
        }
        if (controller._pendingPullIntos.length > 0) {
          const firstPendingPullInto = controller._pendingPullIntos.peek();
          if (firstPendingPullInto.bytesFilled % firstPendingPullInto.elementSize !== 0) {
            const e2 = new TypeError("Insufficient bytes to fill elements in the given buffer");
            ReadableByteStreamControllerError(controller, e2);
            throw e2;
          }
        }
        ReadableByteStreamControllerClearAlgorithms(controller);
        ReadableStreamClose(stream);
      }
      function ReadableByteStreamControllerEnqueue(controller, chunk) {
        const stream = controller._controlledReadableByteStream;
        if (controller._closeRequested || stream._state !== "readable") {
          return;
        }
        const { buffer, byteOffset, byteLength } = chunk;
        if (IsDetachedBuffer(buffer)) {
          throw new TypeError("chunk's buffer is detached and so cannot be enqueued");
        }
        const transferredBuffer = TransferArrayBuffer(buffer);
        if (controller._pendingPullIntos.length > 0) {
          const firstPendingPullInto = controller._pendingPullIntos.peek();
          if (IsDetachedBuffer(firstPendingPullInto.buffer)) {
            throw new TypeError("The BYOB request's buffer has been detached and so cannot be filled with an enqueued chunk");
          }
          ReadableByteStreamControllerInvalidateBYOBRequest(controller);
          firstPendingPullInto.buffer = TransferArrayBuffer(firstPendingPullInto.buffer);
          if (firstPendingPullInto.readerType === "none") {
            ReadableByteStreamControllerEnqueueDetachedPullIntoToQueue(controller, firstPendingPullInto);
          }
        }
        if (ReadableStreamHasDefaultReader(stream)) {
          ReadableByteStreamControllerProcessReadRequestsUsingQueue(controller);
          if (ReadableStreamGetNumReadRequests(stream) === 0) {
            ReadableByteStreamControllerEnqueueChunkToQueue(controller, transferredBuffer, byteOffset, byteLength);
          } else {
            if (controller._pendingPullIntos.length > 0) {
              ReadableByteStreamControllerShiftPendingPullInto(controller);
            }
            const transferredView = new Uint8Array(transferredBuffer, byteOffset, byteLength);
            ReadableStreamFulfillReadRequest(stream, transferredView, false);
          }
        } else if (ReadableStreamHasBYOBReader(stream)) {
          ReadableByteStreamControllerEnqueueChunkToQueue(controller, transferredBuffer, byteOffset, byteLength);
          ReadableByteStreamControllerProcessPullIntoDescriptorsUsingQueue(controller);
        } else {
          ReadableByteStreamControllerEnqueueChunkToQueue(controller, transferredBuffer, byteOffset, byteLength);
        }
        ReadableByteStreamControllerCallPullIfNeeded(controller);
      }
      function ReadableByteStreamControllerError(controller, e2) {
        const stream = controller._controlledReadableByteStream;
        if (stream._state !== "readable") {
          return;
        }
        ReadableByteStreamControllerClearPendingPullIntos(controller);
        ResetQueue(controller);
        ReadableByteStreamControllerClearAlgorithms(controller);
        ReadableStreamError(stream, e2);
      }
      function ReadableByteStreamControllerFillReadRequestFromQueue(controller, readRequest) {
        const entry = controller._queue.shift();
        controller._queueTotalSize -= entry.byteLength;
        ReadableByteStreamControllerHandleQueueDrain(controller);
        const view = new Uint8Array(entry.buffer, entry.byteOffset, entry.byteLength);
        readRequest._chunkSteps(view);
      }
      function ReadableByteStreamControllerGetBYOBRequest(controller) {
        if (controller._byobRequest === null && controller._pendingPullIntos.length > 0) {
          const firstDescriptor = controller._pendingPullIntos.peek();
          const view = new Uint8Array(firstDescriptor.buffer, firstDescriptor.byteOffset + firstDescriptor.bytesFilled, firstDescriptor.byteLength - firstDescriptor.bytesFilled);
          const byobRequest = Object.create(ReadableStreamBYOBRequest.prototype);
          SetUpReadableStreamBYOBRequest(byobRequest, controller, view);
          controller._byobRequest = byobRequest;
        }
        return controller._byobRequest;
      }
      function ReadableByteStreamControllerGetDesiredSize(controller) {
        const state = controller._controlledReadableByteStream._state;
        if (state === "errored") {
          return null;
        }
        if (state === "closed") {
          return 0;
        }
        return controller._strategyHWM - controller._queueTotalSize;
      }
      function ReadableByteStreamControllerRespond(controller, bytesWritten) {
        const firstDescriptor = controller._pendingPullIntos.peek();
        const state = controller._controlledReadableByteStream._state;
        if (state === "closed") {
          if (bytesWritten !== 0) {
            throw new TypeError("bytesWritten must be 0 when calling respond() on a closed stream");
          }
        } else {
          if (bytesWritten === 0) {
            throw new TypeError("bytesWritten must be greater than 0 when calling respond() on a readable stream");
          }
          if (firstDescriptor.bytesFilled + bytesWritten > firstDescriptor.byteLength) {
            throw new RangeError("bytesWritten out of range");
          }
        }
        firstDescriptor.buffer = TransferArrayBuffer(firstDescriptor.buffer);
        ReadableByteStreamControllerRespondInternal(controller, bytesWritten);
      }
      function ReadableByteStreamControllerRespondWithNewView(controller, view) {
        const firstDescriptor = controller._pendingPullIntos.peek();
        const state = controller._controlledReadableByteStream._state;
        if (state === "closed") {
          if (view.byteLength !== 0) {
            throw new TypeError("The view's length must be 0 when calling respondWithNewView() on a closed stream");
          }
        } else {
          if (view.byteLength === 0) {
            throw new TypeError("The view's length must be greater than 0 when calling respondWithNewView() on a readable stream");
          }
        }
        if (firstDescriptor.byteOffset + firstDescriptor.bytesFilled !== view.byteOffset) {
          throw new RangeError("The region specified by view does not match byobRequest");
        }
        if (firstDescriptor.bufferByteLength !== view.buffer.byteLength) {
          throw new RangeError("The buffer of view has different capacity than byobRequest");
        }
        if (firstDescriptor.bytesFilled + view.byteLength > firstDescriptor.byteLength) {
          throw new RangeError("The region specified by view is larger than byobRequest");
        }
        const viewByteLength = view.byteLength;
        firstDescriptor.buffer = TransferArrayBuffer(view.buffer);
        ReadableByteStreamControllerRespondInternal(controller, viewByteLength);
      }
      function SetUpReadableByteStreamController(stream, controller, startAlgorithm, pullAlgorithm, cancelAlgorithm, highWaterMark, autoAllocateChunkSize) {
        controller._controlledReadableByteStream = stream;
        controller._pullAgain = false;
        controller._pulling = false;
        controller._byobRequest = null;
        controller._queue = controller._queueTotalSize = void 0;
        ResetQueue(controller);
        controller._closeRequested = false;
        controller._started = false;
        controller._strategyHWM = highWaterMark;
        controller._pullAlgorithm = pullAlgorithm;
        controller._cancelAlgorithm = cancelAlgorithm;
        controller._autoAllocateChunkSize = autoAllocateChunkSize;
        controller._pendingPullIntos = new SimpleQueue();
        stream._readableStreamController = controller;
        const startResult = startAlgorithm();
        uponPromise(promiseResolvedWith(startResult), () => {
          controller._started = true;
          ReadableByteStreamControllerCallPullIfNeeded(controller);
          return null;
        }, (r2) => {
          ReadableByteStreamControllerError(controller, r2);
          return null;
        });
      }
      function SetUpReadableByteStreamControllerFromUnderlyingSource(stream, underlyingByteSource, highWaterMark) {
        const controller = Object.create(ReadableByteStreamController.prototype);
        let startAlgorithm;
        let pullAlgorithm;
        let cancelAlgorithm;
        if (underlyingByteSource.start !== void 0) {
          startAlgorithm = () => underlyingByteSource.start(controller);
        } else {
          startAlgorithm = () => void 0;
        }
        if (underlyingByteSource.pull !== void 0) {
          pullAlgorithm = () => underlyingByteSource.pull(controller);
        } else {
          pullAlgorithm = () => promiseResolvedWith(void 0);
        }
        if (underlyingByteSource.cancel !== void 0) {
          cancelAlgorithm = (reason) => underlyingByteSource.cancel(reason);
        } else {
          cancelAlgorithm = () => promiseResolvedWith(void 0);
        }
        const autoAllocateChunkSize = underlyingByteSource.autoAllocateChunkSize;
        if (autoAllocateChunkSize === 0) {
          throw new TypeError("autoAllocateChunkSize must be greater than 0");
        }
        SetUpReadableByteStreamController(stream, controller, startAlgorithm, pullAlgorithm, cancelAlgorithm, highWaterMark, autoAllocateChunkSize);
      }
      function SetUpReadableStreamBYOBRequest(request, controller, view) {
        request._associatedReadableByteStreamController = controller;
        request._view = view;
      }
      function byobRequestBrandCheckException(name) {
        return new TypeError(`ReadableStreamBYOBRequest.prototype.${name} can only be used on a ReadableStreamBYOBRequest`);
      }
      function byteStreamControllerBrandCheckException(name) {
        return new TypeError(`ReadableByteStreamController.prototype.${name} can only be used on a ReadableByteStreamController`);
      }
      function convertReaderOptions(options, context) {
        assertDictionary(options, context);
        const mode = options === null || options === void 0 ? void 0 : options.mode;
        return {
          mode: mode === void 0 ? void 0 : convertReadableStreamReaderMode(mode, `${context} has member 'mode' that`)
        };
      }
      function convertReadableStreamReaderMode(mode, context) {
        mode = `${mode}`;
        if (mode !== "byob") {
          throw new TypeError(`${context} '${mode}' is not a valid enumeration value for ReadableStreamReaderMode`);
        }
        return mode;
      }
      function convertByobReadOptions(options, context) {
        var _a;
        assertDictionary(options, context);
        const min = (_a = options === null || options === void 0 ? void 0 : options.min) !== null && _a !== void 0 ? _a : 1;
        return {
          min: convertUnsignedLongLongWithEnforceRange(min, `${context} has member 'min' that`)
        };
      }
      function AcquireReadableStreamBYOBReader(stream) {
        return new ReadableStreamBYOBReader(stream);
      }
      function ReadableStreamAddReadIntoRequest(stream, readIntoRequest) {
        stream._reader._readIntoRequests.push(readIntoRequest);
      }
      function ReadableStreamFulfillReadIntoRequest(stream, chunk, done) {
        const reader = stream._reader;
        const readIntoRequest = reader._readIntoRequests.shift();
        if (done) {
          readIntoRequest._closeSteps(chunk);
        } else {
          readIntoRequest._chunkSteps(chunk);
        }
      }
      function ReadableStreamGetNumReadIntoRequests(stream) {
        return stream._reader._readIntoRequests.length;
      }
      function ReadableStreamHasBYOBReader(stream) {
        const reader = stream._reader;
        if (reader === void 0) {
          return false;
        }
        if (!IsReadableStreamBYOBReader(reader)) {
          return false;
        }
        return true;
      }
      class ReadableStreamBYOBReader {
        constructor(stream) {
          assertRequiredArgument(stream, 1, "ReadableStreamBYOBReader");
          assertReadableStream(stream, "First parameter");
          if (IsReadableStreamLocked(stream)) {
            throw new TypeError("This stream has already been locked for exclusive reading by another reader");
          }
          if (!IsReadableByteStreamController(stream._readableStreamController)) {
            throw new TypeError("Cannot construct a ReadableStreamBYOBReader for a stream not constructed with a byte source");
          }
          ReadableStreamReaderGenericInitialize(this, stream);
          this._readIntoRequests = new SimpleQueue();
        }
        /**
         * Returns a promise that will be fulfilled when the stream becomes closed, or rejected if the stream ever errors or
         * the reader's lock is released before the stream finishes closing.
         */
        get closed() {
          if (!IsReadableStreamBYOBReader(this)) {
            return promiseRejectedWith(byobReaderBrandCheckException("closed"));
          }
          return this._closedPromise;
        }
        /**
         * If the reader is active, behaves the same as {@link ReadableStream.cancel | stream.cancel(reason)}.
         */
        cancel(reason = void 0) {
          if (!IsReadableStreamBYOBReader(this)) {
            return promiseRejectedWith(byobReaderBrandCheckException("cancel"));
          }
          if (this._ownerReadableStream === void 0) {
            return promiseRejectedWith(readerLockException("cancel"));
          }
          return ReadableStreamReaderGenericCancel(this, reason);
        }
        read(view, rawOptions = {}) {
          if (!IsReadableStreamBYOBReader(this)) {
            return promiseRejectedWith(byobReaderBrandCheckException("read"));
          }
          if (!ArrayBuffer.isView(view)) {
            return promiseRejectedWith(new TypeError("view must be an array buffer view"));
          }
          if (view.byteLength === 0) {
            return promiseRejectedWith(new TypeError("view must have non-zero byteLength"));
          }
          if (view.buffer.byteLength === 0) {
            return promiseRejectedWith(new TypeError(`view's buffer must have non-zero byteLength`));
          }
          if (IsDetachedBuffer(view.buffer)) {
            return promiseRejectedWith(new TypeError("view's buffer has been detached"));
          }
          let options;
          try {
            options = convertByobReadOptions(rawOptions, "options");
          } catch (e2) {
            return promiseRejectedWith(e2);
          }
          const min = options.min;
          if (min === 0) {
            return promiseRejectedWith(new TypeError("options.min must be greater than 0"));
          }
          if (!isDataView(view)) {
            if (min > view.length) {
              return promiseRejectedWith(new RangeError("options.min must be less than or equal to view's length"));
            }
          } else if (min > view.byteLength) {
            return promiseRejectedWith(new RangeError("options.min must be less than or equal to view's byteLength"));
          }
          if (this._ownerReadableStream === void 0) {
            return promiseRejectedWith(readerLockException("read from"));
          }
          let resolvePromise;
          let rejectPromise;
          const promise = newPromise((resolve2, reject) => {
            resolvePromise = resolve2;
            rejectPromise = reject;
          });
          const readIntoRequest = {
            _chunkSteps: (chunk) => resolvePromise({ value: chunk, done: false }),
            _closeSteps: (chunk) => resolvePromise({ value: chunk, done: true }),
            _errorSteps: (e2) => rejectPromise(e2)
          };
          ReadableStreamBYOBReaderRead(this, view, min, readIntoRequest);
          return promise;
        }
        /**
         * Releases the reader's lock on the corresponding stream. After the lock is released, the reader is no longer active.
         * If the associated stream is errored when the lock is released, the reader will appear errored in the same way
         * from now on; otherwise, the reader will appear closed.
         *
         * A reader's lock cannot be released while it still has a pending read request, i.e., if a promise returned by
         * the reader's {@link ReadableStreamBYOBReader.read | read()} method has not yet been settled. Attempting to
         * do so will throw a `TypeError` and leave the reader locked to the stream.
         */
        releaseLock() {
          if (!IsReadableStreamBYOBReader(this)) {
            throw byobReaderBrandCheckException("releaseLock");
          }
          if (this._ownerReadableStream === void 0) {
            return;
          }
          ReadableStreamBYOBReaderRelease(this);
        }
      }
      Object.defineProperties(ReadableStreamBYOBReader.prototype, {
        cancel: { enumerable: true },
        read: { enumerable: true },
        releaseLock: { enumerable: true },
        closed: { enumerable: true }
      });
      setFunctionName(ReadableStreamBYOBReader.prototype.cancel, "cancel");
      setFunctionName(ReadableStreamBYOBReader.prototype.read, "read");
      setFunctionName(ReadableStreamBYOBReader.prototype.releaseLock, "releaseLock");
      if (typeof SymbolPolyfill.toStringTag === "symbol") {
        Object.defineProperty(ReadableStreamBYOBReader.prototype, SymbolPolyfill.toStringTag, {
          value: "ReadableStreamBYOBReader",
          configurable: true
        });
      }
      function IsReadableStreamBYOBReader(x2) {
        if (!typeIsObject(x2)) {
          return false;
        }
        if (!Object.prototype.hasOwnProperty.call(x2, "_readIntoRequests")) {
          return false;
        }
        return x2 instanceof ReadableStreamBYOBReader;
      }
      function ReadableStreamBYOBReaderRead(reader, view, min, readIntoRequest) {
        const stream = reader._ownerReadableStream;
        stream._disturbed = true;
        if (stream._state === "errored") {
          readIntoRequest._errorSteps(stream._storedError);
        } else {
          ReadableByteStreamControllerPullInto(stream._readableStreamController, view, min, readIntoRequest);
        }
      }
      function ReadableStreamBYOBReaderRelease(reader) {
        ReadableStreamReaderGenericRelease(reader);
        const e2 = new TypeError("Reader was released");
        ReadableStreamBYOBReaderErrorReadIntoRequests(reader, e2);
      }
      function ReadableStreamBYOBReaderErrorReadIntoRequests(reader, e2) {
        const readIntoRequests = reader._readIntoRequests;
        reader._readIntoRequests = new SimpleQueue();
        readIntoRequests.forEach((readIntoRequest) => {
          readIntoRequest._errorSteps(e2);
        });
      }
      function byobReaderBrandCheckException(name) {
        return new TypeError(`ReadableStreamBYOBReader.prototype.${name} can only be used on a ReadableStreamBYOBReader`);
      }
      function ExtractHighWaterMark(strategy, defaultHWM) {
        const { highWaterMark } = strategy;
        if (highWaterMark === void 0) {
          return defaultHWM;
        }
        if (NumberIsNaN(highWaterMark) || highWaterMark < 0) {
          throw new RangeError("Invalid highWaterMark");
        }
        return highWaterMark;
      }
      function ExtractSizeAlgorithm(strategy) {
        const { size } = strategy;
        if (!size) {
          return () => 1;
        }
        return size;
      }
      function convertQueuingStrategy(init, context) {
        assertDictionary(init, context);
        const highWaterMark = init === null || init === void 0 ? void 0 : init.highWaterMark;
        const size = init === null || init === void 0 ? void 0 : init.size;
        return {
          highWaterMark: highWaterMark === void 0 ? void 0 : convertUnrestrictedDouble(highWaterMark),
          size: size === void 0 ? void 0 : convertQueuingStrategySize(size, `${context} has member 'size' that`)
        };
      }
      function convertQueuingStrategySize(fn, context) {
        assertFunction(fn, context);
        return (chunk) => convertUnrestrictedDouble(fn(chunk));
      }
      function convertUnderlyingSink(original, context) {
        assertDictionary(original, context);
        const abort = original === null || original === void 0 ? void 0 : original.abort;
        const close2 = original === null || original === void 0 ? void 0 : original.close;
        const start = original === null || original === void 0 ? void 0 : original.start;
        const type = original === null || original === void 0 ? void 0 : original.type;
        const write = original === null || original === void 0 ? void 0 : original.write;
        return {
          abort: abort === void 0 ? void 0 : convertUnderlyingSinkAbortCallback(abort, original, `${context} has member 'abort' that`),
          close: close2 === void 0 ? void 0 : convertUnderlyingSinkCloseCallback(close2, original, `${context} has member 'close' that`),
          start: start === void 0 ? void 0 : convertUnderlyingSinkStartCallback(start, original, `${context} has member 'start' that`),
          write: write === void 0 ? void 0 : convertUnderlyingSinkWriteCallback(write, original, `${context} has member 'write' that`),
          type
        };
      }
      function convertUnderlyingSinkAbortCallback(fn, original, context) {
        assertFunction(fn, context);
        return (reason) => promiseCall(fn, original, [reason]);
      }
      function convertUnderlyingSinkCloseCallback(fn, original, context) {
        assertFunction(fn, context);
        return () => promiseCall(fn, original, []);
      }
      function convertUnderlyingSinkStartCallback(fn, original, context) {
        assertFunction(fn, context);
        return (controller) => reflectCall(fn, original, [controller]);
      }
      function convertUnderlyingSinkWriteCallback(fn, original, context) {
        assertFunction(fn, context);
        return (chunk, controller) => promiseCall(fn, original, [chunk, controller]);
      }
      function assertWritableStream(x2, context) {
        if (!IsWritableStream(x2)) {
          throw new TypeError(`${context} is not a WritableStream.`);
        }
      }
      function isAbortSignal2(value) {
        if (typeof value !== "object" || value === null) {
          return false;
        }
        try {
          return typeof value.aborted === "boolean";
        } catch (_a) {
          return false;
        }
      }
      const supportsAbortController = typeof AbortController === "function";
      function createAbortController() {
        if (supportsAbortController) {
          return new AbortController();
        }
        return void 0;
      }
      class WritableStream {
        constructor(rawUnderlyingSink = {}, rawStrategy = {}) {
          if (rawUnderlyingSink === void 0) {
            rawUnderlyingSink = null;
          } else {
            assertObject(rawUnderlyingSink, "First parameter");
          }
          const strategy = convertQueuingStrategy(rawStrategy, "Second parameter");
          const underlyingSink = convertUnderlyingSink(rawUnderlyingSink, "First parameter");
          InitializeWritableStream(this);
          const type = underlyingSink.type;
          if (type !== void 0) {
            throw new RangeError("Invalid type is specified");
          }
          const sizeAlgorithm = ExtractSizeAlgorithm(strategy);
          const highWaterMark = ExtractHighWaterMark(strategy, 1);
          SetUpWritableStreamDefaultControllerFromUnderlyingSink(this, underlyingSink, highWaterMark, sizeAlgorithm);
        }
        /**
         * Returns whether or not the writable stream is locked to a writer.
         */
        get locked() {
          if (!IsWritableStream(this)) {
            throw streamBrandCheckException$2("locked");
          }
          return IsWritableStreamLocked(this);
        }
        /**
         * Aborts the stream, signaling that the producer can no longer successfully write to the stream and it is to be
         * immediately moved to an errored state, with any queued-up writes discarded. This will also execute any abort
         * mechanism of the underlying sink.
         *
         * The returned promise will fulfill if the stream shuts down successfully, or reject if the underlying sink signaled
         * that there was an error doing so. Additionally, it will reject with a `TypeError` (without attempting to cancel
         * the stream) if the stream is currently locked.
         */
        abort(reason = void 0) {
          if (!IsWritableStream(this)) {
            return promiseRejectedWith(streamBrandCheckException$2("abort"));
          }
          if (IsWritableStreamLocked(this)) {
            return promiseRejectedWith(new TypeError("Cannot abort a stream that already has a writer"));
          }
          return WritableStreamAbort(this, reason);
        }
        /**
         * Closes the stream. The underlying sink will finish processing any previously-written chunks, before invoking its
         * close behavior. During this time any further attempts to write will fail (without erroring the stream).
         *
         * The method returns a promise that will fulfill if all remaining chunks are successfully written and the stream
         * successfully closes, or rejects if an error is encountered during this process. Additionally, it will reject with
         * a `TypeError` (without attempting to cancel the stream) if the stream is currently locked.
         */
        close() {
          if (!IsWritableStream(this)) {
            return promiseRejectedWith(streamBrandCheckException$2("close"));
          }
          if (IsWritableStreamLocked(this)) {
            return promiseRejectedWith(new TypeError("Cannot close a stream that already has a writer"));
          }
          if (WritableStreamCloseQueuedOrInFlight(this)) {
            return promiseRejectedWith(new TypeError("Cannot close an already-closing stream"));
          }
          return WritableStreamClose(this);
        }
        /**
         * Creates a {@link WritableStreamDefaultWriter | writer} and locks the stream to the new writer. While the stream
         * is locked, no other writer can be acquired until this one is released.
         *
         * This functionality is especially useful for creating abstractions that desire the ability to write to a stream
         * without interruption or interleaving. By getting a writer for the stream, you can ensure nobody else can write at
         * the same time, which would cause the resulting written data to be unpredictable and probably useless.
         */
        getWriter() {
          if (!IsWritableStream(this)) {
            throw streamBrandCheckException$2("getWriter");
          }
          return AcquireWritableStreamDefaultWriter(this);
        }
      }
      Object.defineProperties(WritableStream.prototype, {
        abort: { enumerable: true },
        close: { enumerable: true },
        getWriter: { enumerable: true },
        locked: { enumerable: true }
      });
      setFunctionName(WritableStream.prototype.abort, "abort");
      setFunctionName(WritableStream.prototype.close, "close");
      setFunctionName(WritableStream.prototype.getWriter, "getWriter");
      if (typeof SymbolPolyfill.toStringTag === "symbol") {
        Object.defineProperty(WritableStream.prototype, SymbolPolyfill.toStringTag, {
          value: "WritableStream",
          configurable: true
        });
      }
      function AcquireWritableStreamDefaultWriter(stream) {
        return new WritableStreamDefaultWriter(stream);
      }
      function CreateWritableStream(startAlgorithm, writeAlgorithm, closeAlgorithm, abortAlgorithm, highWaterMark = 1, sizeAlgorithm = () => 1) {
        const stream = Object.create(WritableStream.prototype);
        InitializeWritableStream(stream);
        const controller = Object.create(WritableStreamDefaultController.prototype);
        SetUpWritableStreamDefaultController(stream, controller, startAlgorithm, writeAlgorithm, closeAlgorithm, abortAlgorithm, highWaterMark, sizeAlgorithm);
        return stream;
      }
      function InitializeWritableStream(stream) {
        stream._state = "writable";
        stream._storedError = void 0;
        stream._writer = void 0;
        stream._writableStreamController = void 0;
        stream._writeRequests = new SimpleQueue();
        stream._inFlightWriteRequest = void 0;
        stream._closeRequest = void 0;
        stream._inFlightCloseRequest = void 0;
        stream._pendingAbortRequest = void 0;
        stream._backpressure = false;
      }
      function IsWritableStream(x2) {
        if (!typeIsObject(x2)) {
          return false;
        }
        if (!Object.prototype.hasOwnProperty.call(x2, "_writableStreamController")) {
          return false;
        }
        return x2 instanceof WritableStream;
      }
      function IsWritableStreamLocked(stream) {
        if (stream._writer === void 0) {
          return false;
        }
        return true;
      }
      function WritableStreamAbort(stream, reason) {
        var _a;
        if (stream._state === "closed" || stream._state === "errored") {
          return promiseResolvedWith(void 0);
        }
        stream._writableStreamController._abortReason = reason;
        (_a = stream._writableStreamController._abortController) === null || _a === void 0 ? void 0 : _a.abort(reason);
        const state = stream._state;
        if (state === "closed" || state === "errored") {
          return promiseResolvedWith(void 0);
        }
        if (stream._pendingAbortRequest !== void 0) {
          return stream._pendingAbortRequest._promise;
        }
        let wasAlreadyErroring = false;
        if (state === "erroring") {
          wasAlreadyErroring = true;
          reason = void 0;
        }
        const promise = newPromise((resolve2, reject) => {
          stream._pendingAbortRequest = {
            _promise: void 0,
            _resolve: resolve2,
            _reject: reject,
            _reason: reason,
            _wasAlreadyErroring: wasAlreadyErroring
          };
        });
        stream._pendingAbortRequest._promise = promise;
        if (!wasAlreadyErroring) {
          WritableStreamStartErroring(stream, reason);
        }
        return promise;
      }
      function WritableStreamClose(stream) {
        const state = stream._state;
        if (state === "closed" || state === "errored") {
          return promiseRejectedWith(new TypeError(`The stream (in ${state} state) is not in the writable state and cannot be closed`));
        }
        const promise = newPromise((resolve2, reject) => {
          const closeRequest = {
            _resolve: resolve2,
            _reject: reject
          };
          stream._closeRequest = closeRequest;
        });
        const writer = stream._writer;
        if (writer !== void 0 && stream._backpressure && state === "writable") {
          defaultWriterReadyPromiseResolve(writer);
        }
        WritableStreamDefaultControllerClose(stream._writableStreamController);
        return promise;
      }
      function WritableStreamAddWriteRequest(stream) {
        const promise = newPromise((resolve2, reject) => {
          const writeRequest = {
            _resolve: resolve2,
            _reject: reject
          };
          stream._writeRequests.push(writeRequest);
        });
        return promise;
      }
      function WritableStreamDealWithRejection(stream, error) {
        const state = stream._state;
        if (state === "writable") {
          WritableStreamStartErroring(stream, error);
          return;
        }
        WritableStreamFinishErroring(stream);
      }
      function WritableStreamStartErroring(stream, reason) {
        const controller = stream._writableStreamController;
        stream._state = "erroring";
        stream._storedError = reason;
        const writer = stream._writer;
        if (writer !== void 0) {
          WritableStreamDefaultWriterEnsureReadyPromiseRejected(writer, reason);
        }
        if (!WritableStreamHasOperationMarkedInFlight(stream) && controller._started) {
          WritableStreamFinishErroring(stream);
        }
      }
      function WritableStreamFinishErroring(stream) {
        stream._state = "errored";
        stream._writableStreamController[ErrorSteps]();
        const storedError = stream._storedError;
        stream._writeRequests.forEach((writeRequest) => {
          writeRequest._reject(storedError);
        });
        stream._writeRequests = new SimpleQueue();
        if (stream._pendingAbortRequest === void 0) {
          WritableStreamRejectCloseAndClosedPromiseIfNeeded(stream);
          return;
        }
        const abortRequest = stream._pendingAbortRequest;
        stream._pendingAbortRequest = void 0;
        if (abortRequest._wasAlreadyErroring) {
          abortRequest._reject(storedError);
          WritableStreamRejectCloseAndClosedPromiseIfNeeded(stream);
          return;
        }
        const promise = stream._writableStreamController[AbortSteps](abortRequest._reason);
        uponPromise(promise, () => {
          abortRequest._resolve();
          WritableStreamRejectCloseAndClosedPromiseIfNeeded(stream);
          return null;
        }, (reason) => {
          abortRequest._reject(reason);
          WritableStreamRejectCloseAndClosedPromiseIfNeeded(stream);
          return null;
        });
      }
      function WritableStreamFinishInFlightWrite(stream) {
        stream._inFlightWriteRequest._resolve(void 0);
        stream._inFlightWriteRequest = void 0;
      }
      function WritableStreamFinishInFlightWriteWithError(stream, error) {
        stream._inFlightWriteRequest._reject(error);
        stream._inFlightWriteRequest = void 0;
        WritableStreamDealWithRejection(stream, error);
      }
      function WritableStreamFinishInFlightClose(stream) {
        stream._inFlightCloseRequest._resolve(void 0);
        stream._inFlightCloseRequest = void 0;
        const state = stream._state;
        if (state === "erroring") {
          stream._storedError = void 0;
          if (stream._pendingAbortRequest !== void 0) {
            stream._pendingAbortRequest._resolve();
            stream._pendingAbortRequest = void 0;
          }
        }
        stream._state = "closed";
        const writer = stream._writer;
        if (writer !== void 0) {
          defaultWriterClosedPromiseResolve(writer);
        }
      }
      function WritableStreamFinishInFlightCloseWithError(stream, error) {
        stream._inFlightCloseRequest._reject(error);
        stream._inFlightCloseRequest = void 0;
        if (stream._pendingAbortRequest !== void 0) {
          stream._pendingAbortRequest._reject(error);
          stream._pendingAbortRequest = void 0;
        }
        WritableStreamDealWithRejection(stream, error);
      }
      function WritableStreamCloseQueuedOrInFlight(stream) {
        if (stream._closeRequest === void 0 && stream._inFlightCloseRequest === void 0) {
          return false;
        }
        return true;
      }
      function WritableStreamHasOperationMarkedInFlight(stream) {
        if (stream._inFlightWriteRequest === void 0 && stream._inFlightCloseRequest === void 0) {
          return false;
        }
        return true;
      }
      function WritableStreamMarkCloseRequestInFlight(stream) {
        stream._inFlightCloseRequest = stream._closeRequest;
        stream._closeRequest = void 0;
      }
      function WritableStreamMarkFirstWriteRequestInFlight(stream) {
        stream._inFlightWriteRequest = stream._writeRequests.shift();
      }
      function WritableStreamRejectCloseAndClosedPromiseIfNeeded(stream) {
        if (stream._closeRequest !== void 0) {
          stream._closeRequest._reject(stream._storedError);
          stream._closeRequest = void 0;
        }
        const writer = stream._writer;
        if (writer !== void 0) {
          defaultWriterClosedPromiseReject(writer, stream._storedError);
        }
      }
      function WritableStreamUpdateBackpressure(stream, backpressure) {
        const writer = stream._writer;
        if (writer !== void 0 && backpressure !== stream._backpressure) {
          if (backpressure) {
            defaultWriterReadyPromiseReset(writer);
          } else {
            defaultWriterReadyPromiseResolve(writer);
          }
        }
        stream._backpressure = backpressure;
      }
      class WritableStreamDefaultWriter {
        constructor(stream) {
          assertRequiredArgument(stream, 1, "WritableStreamDefaultWriter");
          assertWritableStream(stream, "First parameter");
          if (IsWritableStreamLocked(stream)) {
            throw new TypeError("This stream has already been locked for exclusive writing by another writer");
          }
          this._ownerWritableStream = stream;
          stream._writer = this;
          const state = stream._state;
          if (state === "writable") {
            if (!WritableStreamCloseQueuedOrInFlight(stream) && stream._backpressure) {
              defaultWriterReadyPromiseInitialize(this);
            } else {
              defaultWriterReadyPromiseInitializeAsResolved(this);
            }
            defaultWriterClosedPromiseInitialize(this);
          } else if (state === "erroring") {
            defaultWriterReadyPromiseInitializeAsRejected(this, stream._storedError);
            defaultWriterClosedPromiseInitialize(this);
          } else if (state === "closed") {
            defaultWriterReadyPromiseInitializeAsResolved(this);
            defaultWriterClosedPromiseInitializeAsResolved(this);
          } else {
            const storedError = stream._storedError;
            defaultWriterReadyPromiseInitializeAsRejected(this, storedError);
            defaultWriterClosedPromiseInitializeAsRejected(this, storedError);
          }
        }
        /**
         * Returns a promise that will be fulfilled when the stream becomes closed, or rejected if the stream ever errors or
         * the writer’s lock is released before the stream finishes closing.
         */
        get closed() {
          if (!IsWritableStreamDefaultWriter(this)) {
            return promiseRejectedWith(defaultWriterBrandCheckException("closed"));
          }
          return this._closedPromise;
        }
        /**
         * Returns the desired size to fill the stream’s internal queue. It can be negative, if the queue is over-full.
         * A producer can use this information to determine the right amount of data to write.
         *
         * It will be `null` if the stream cannot be successfully written to (due to either being errored, or having an abort
         * queued up). It will return zero if the stream is closed. And the getter will throw an exception if invoked when
         * the writer’s lock is released.
         */
        get desiredSize() {
          if (!IsWritableStreamDefaultWriter(this)) {
            throw defaultWriterBrandCheckException("desiredSize");
          }
          if (this._ownerWritableStream === void 0) {
            throw defaultWriterLockException("desiredSize");
          }
          return WritableStreamDefaultWriterGetDesiredSize(this);
        }
        /**
         * Returns a promise that will be fulfilled when the desired size to fill the stream’s internal queue transitions
         * from non-positive to positive, signaling that it is no longer applying backpressure. Once the desired size dips
         * back to zero or below, the getter will return a new promise that stays pending until the next transition.
         *
         * If the stream becomes errored or aborted, or the writer’s lock is released, the returned promise will become
         * rejected.
         */
        get ready() {
          if (!IsWritableStreamDefaultWriter(this)) {
            return promiseRejectedWith(defaultWriterBrandCheckException("ready"));
          }
          return this._readyPromise;
        }
        /**
         * If the reader is active, behaves the same as {@link WritableStream.abort | stream.abort(reason)}.
         */
        abort(reason = void 0) {
          if (!IsWritableStreamDefaultWriter(this)) {
            return promiseRejectedWith(defaultWriterBrandCheckException("abort"));
          }
          if (this._ownerWritableStream === void 0) {
            return promiseRejectedWith(defaultWriterLockException("abort"));
          }
          return WritableStreamDefaultWriterAbort(this, reason);
        }
        /**
         * If the reader is active, behaves the same as {@link WritableStream.close | stream.close()}.
         */
        close() {
          if (!IsWritableStreamDefaultWriter(this)) {
            return promiseRejectedWith(defaultWriterBrandCheckException("close"));
          }
          const stream = this._ownerWritableStream;
          if (stream === void 0) {
            return promiseRejectedWith(defaultWriterLockException("close"));
          }
          if (WritableStreamCloseQueuedOrInFlight(stream)) {
            return promiseRejectedWith(new TypeError("Cannot close an already-closing stream"));
          }
          return WritableStreamDefaultWriterClose(this);
        }
        /**
         * Releases the writer’s lock on the corresponding stream. After the lock is released, the writer is no longer active.
         * If the associated stream is errored when the lock is released, the writer will appear errored in the same way from
         * now on; otherwise, the writer will appear closed.
         *
         * Note that the lock can still be released even if some ongoing writes have not yet finished (i.e. even if the
         * promises returned from previous calls to {@link WritableStreamDefaultWriter.write | write()} have not yet settled).
         * It’s not necessary to hold the lock on the writer for the duration of the write; the lock instead simply prevents
         * other producers from writing in an interleaved manner.
         */
        releaseLock() {
          if (!IsWritableStreamDefaultWriter(this)) {
            throw defaultWriterBrandCheckException("releaseLock");
          }
          const stream = this._ownerWritableStream;
          if (stream === void 0) {
            return;
          }
          WritableStreamDefaultWriterRelease(this);
        }
        write(chunk = void 0) {
          if (!IsWritableStreamDefaultWriter(this)) {
            return promiseRejectedWith(defaultWriterBrandCheckException("write"));
          }
          if (this._ownerWritableStream === void 0) {
            return promiseRejectedWith(defaultWriterLockException("write to"));
          }
          return WritableStreamDefaultWriterWrite(this, chunk);
        }
      }
      Object.defineProperties(WritableStreamDefaultWriter.prototype, {
        abort: { enumerable: true },
        close: { enumerable: true },
        releaseLock: { enumerable: true },
        write: { enumerable: true },
        closed: { enumerable: true },
        desiredSize: { enumerable: true },
        ready: { enumerable: true }
      });
      setFunctionName(WritableStreamDefaultWriter.prototype.abort, "abort");
      setFunctionName(WritableStreamDefaultWriter.prototype.close, "close");
      setFunctionName(WritableStreamDefaultWriter.prototype.releaseLock, "releaseLock");
      setFunctionName(WritableStreamDefaultWriter.prototype.write, "write");
      if (typeof SymbolPolyfill.toStringTag === "symbol") {
        Object.defineProperty(WritableStreamDefaultWriter.prototype, SymbolPolyfill.toStringTag, {
          value: "WritableStreamDefaultWriter",
          configurable: true
        });
      }
      function IsWritableStreamDefaultWriter(x2) {
        if (!typeIsObject(x2)) {
          return false;
        }
        if (!Object.prototype.hasOwnProperty.call(x2, "_ownerWritableStream")) {
          return false;
        }
        return x2 instanceof WritableStreamDefaultWriter;
      }
      function WritableStreamDefaultWriterAbort(writer, reason) {
        const stream = writer._ownerWritableStream;
        return WritableStreamAbort(stream, reason);
      }
      function WritableStreamDefaultWriterClose(writer) {
        const stream = writer._ownerWritableStream;
        return WritableStreamClose(stream);
      }
      function WritableStreamDefaultWriterCloseWithErrorPropagation(writer) {
        const stream = writer._ownerWritableStream;
        const state = stream._state;
        if (WritableStreamCloseQueuedOrInFlight(stream) || state === "closed") {
          return promiseResolvedWith(void 0);
        }
        if (state === "errored") {
          return promiseRejectedWith(stream._storedError);
        }
        return WritableStreamDefaultWriterClose(writer);
      }
      function WritableStreamDefaultWriterEnsureClosedPromiseRejected(writer, error) {
        if (writer._closedPromiseState === "pending") {
          defaultWriterClosedPromiseReject(writer, error);
        } else {
          defaultWriterClosedPromiseResetToRejected(writer, error);
        }
      }
      function WritableStreamDefaultWriterEnsureReadyPromiseRejected(writer, error) {
        if (writer._readyPromiseState === "pending") {
          defaultWriterReadyPromiseReject(writer, error);
        } else {
          defaultWriterReadyPromiseResetToRejected(writer, error);
        }
      }
      function WritableStreamDefaultWriterGetDesiredSize(writer) {
        const stream = writer._ownerWritableStream;
        const state = stream._state;
        if (state === "errored" || state === "erroring") {
          return null;
        }
        if (state === "closed") {
          return 0;
        }
        return WritableStreamDefaultControllerGetDesiredSize(stream._writableStreamController);
      }
      function WritableStreamDefaultWriterRelease(writer) {
        const stream = writer._ownerWritableStream;
        const releasedError = new TypeError(`Writer was released and can no longer be used to monitor the stream's closedness`);
        WritableStreamDefaultWriterEnsureReadyPromiseRejected(writer, releasedError);
        WritableStreamDefaultWriterEnsureClosedPromiseRejected(writer, releasedError);
        stream._writer = void 0;
        writer._ownerWritableStream = void 0;
      }
      function WritableStreamDefaultWriterWrite(writer, chunk) {
        const stream = writer._ownerWritableStream;
        const controller = stream._writableStreamController;
        const chunkSize = WritableStreamDefaultControllerGetChunkSize(controller, chunk);
        if (stream !== writer._ownerWritableStream) {
          return promiseRejectedWith(defaultWriterLockException("write to"));
        }
        const state = stream._state;
        if (state === "errored") {
          return promiseRejectedWith(stream._storedError);
        }
        if (WritableStreamCloseQueuedOrInFlight(stream) || state === "closed") {
          return promiseRejectedWith(new TypeError("The stream is closing or closed and cannot be written to"));
        }
        if (state === "erroring") {
          return promiseRejectedWith(stream._storedError);
        }
        const promise = WritableStreamAddWriteRequest(stream);
        WritableStreamDefaultControllerWrite(controller, chunk, chunkSize);
        return promise;
      }
      const closeSentinel = {};
      class WritableStreamDefaultController {
        constructor() {
          throw new TypeError("Illegal constructor");
        }
        /**
         * The reason which was passed to `WritableStream.abort(reason)` when the stream was aborted.
         *
         * @deprecated
         *  This property has been removed from the specification, see https://github.com/whatwg/streams/pull/1177.
         *  Use {@link WritableStreamDefaultController.signal}'s `reason` instead.
         */
        get abortReason() {
          if (!IsWritableStreamDefaultController(this)) {
            throw defaultControllerBrandCheckException$2("abortReason");
          }
          return this._abortReason;
        }
        /**
         * An `AbortSignal` that can be used to abort the pending write or close operation when the stream is aborted.
         */
        get signal() {
          if (!IsWritableStreamDefaultController(this)) {
            throw defaultControllerBrandCheckException$2("signal");
          }
          if (this._abortController === void 0) {
            throw new TypeError("WritableStreamDefaultController.prototype.signal is not supported");
          }
          return this._abortController.signal;
        }
        /**
         * Closes the controlled writable stream, making all future interactions with it fail with the given error `e`.
         *
         * This method is rarely used, since usually it suffices to return a rejected promise from one of the underlying
         * sink's methods. However, it can be useful for suddenly shutting down a stream in response to an event outside the
         * normal lifecycle of interactions with the underlying sink.
         */
        error(e2 = void 0) {
          if (!IsWritableStreamDefaultController(this)) {
            throw defaultControllerBrandCheckException$2("error");
          }
          const state = this._controlledWritableStream._state;
          if (state !== "writable") {
            return;
          }
          WritableStreamDefaultControllerError(this, e2);
        }
        /** @internal */
        [AbortSteps](reason) {
          const result = this._abortAlgorithm(reason);
          WritableStreamDefaultControllerClearAlgorithms(this);
          return result;
        }
        /** @internal */
        [ErrorSteps]() {
          ResetQueue(this);
        }
      }
      Object.defineProperties(WritableStreamDefaultController.prototype, {
        abortReason: { enumerable: true },
        signal: { enumerable: true },
        error: { enumerable: true }
      });
      if (typeof SymbolPolyfill.toStringTag === "symbol") {
        Object.defineProperty(WritableStreamDefaultController.prototype, SymbolPolyfill.toStringTag, {
          value: "WritableStreamDefaultController",
          configurable: true
        });
      }
      function IsWritableStreamDefaultController(x2) {
        if (!typeIsObject(x2)) {
          return false;
        }
        if (!Object.prototype.hasOwnProperty.call(x2, "_controlledWritableStream")) {
          return false;
        }
        return x2 instanceof WritableStreamDefaultController;
      }
      function SetUpWritableStreamDefaultController(stream, controller, startAlgorithm, writeAlgorithm, closeAlgorithm, abortAlgorithm, highWaterMark, sizeAlgorithm) {
        controller._controlledWritableStream = stream;
        stream._writableStreamController = controller;
        controller._queue = void 0;
        controller._queueTotalSize = void 0;
        ResetQueue(controller);
        controller._abortReason = void 0;
        controller._abortController = createAbortController();
        controller._started = false;
        controller._strategySizeAlgorithm = sizeAlgorithm;
        controller._strategyHWM = highWaterMark;
        controller._writeAlgorithm = writeAlgorithm;
        controller._closeAlgorithm = closeAlgorithm;
        controller._abortAlgorithm = abortAlgorithm;
        const backpressure = WritableStreamDefaultControllerGetBackpressure(controller);
        WritableStreamUpdateBackpressure(stream, backpressure);
        const startResult = startAlgorithm();
        const startPromise = promiseResolvedWith(startResult);
        uponPromise(startPromise, () => {
          controller._started = true;
          WritableStreamDefaultControllerAdvanceQueueIfNeeded(controller);
          return null;
        }, (r2) => {
          controller._started = true;
          WritableStreamDealWithRejection(stream, r2);
          return null;
        });
      }
      function SetUpWritableStreamDefaultControllerFromUnderlyingSink(stream, underlyingSink, highWaterMark, sizeAlgorithm) {
        const controller = Object.create(WritableStreamDefaultController.prototype);
        let startAlgorithm;
        let writeAlgorithm;
        let closeAlgorithm;
        let abortAlgorithm;
        if (underlyingSink.start !== void 0) {
          startAlgorithm = () => underlyingSink.start(controller);
        } else {
          startAlgorithm = () => void 0;
        }
        if (underlyingSink.write !== void 0) {
          writeAlgorithm = (chunk) => underlyingSink.write(chunk, controller);
        } else {
          writeAlgorithm = () => promiseResolvedWith(void 0);
        }
        if (underlyingSink.close !== void 0) {
          closeAlgorithm = () => underlyingSink.close();
        } else {
          closeAlgorithm = () => promiseResolvedWith(void 0);
        }
        if (underlyingSink.abort !== void 0) {
          abortAlgorithm = (reason) => underlyingSink.abort(reason);
        } else {
          abortAlgorithm = () => promiseResolvedWith(void 0);
        }
        SetUpWritableStreamDefaultController(stream, controller, startAlgorithm, writeAlgorithm, closeAlgorithm, abortAlgorithm, highWaterMark, sizeAlgorithm);
      }
      function WritableStreamDefaultControllerClearAlgorithms(controller) {
        controller._writeAlgorithm = void 0;
        controller._closeAlgorithm = void 0;
        controller._abortAlgorithm = void 0;
        controller._strategySizeAlgorithm = void 0;
      }
      function WritableStreamDefaultControllerClose(controller) {
        EnqueueValueWithSize(controller, closeSentinel, 0);
        WritableStreamDefaultControllerAdvanceQueueIfNeeded(controller);
      }
      function WritableStreamDefaultControllerGetChunkSize(controller, chunk) {
        try {
          return controller._strategySizeAlgorithm(chunk);
        } catch (chunkSizeE) {
          WritableStreamDefaultControllerErrorIfNeeded(controller, chunkSizeE);
          return 1;
        }
      }
      function WritableStreamDefaultControllerGetDesiredSize(controller) {
        return controller._strategyHWM - controller._queueTotalSize;
      }
      function WritableStreamDefaultControllerWrite(controller, chunk, chunkSize) {
        try {
          EnqueueValueWithSize(controller, chunk, chunkSize);
        } catch (enqueueE) {
          WritableStreamDefaultControllerErrorIfNeeded(controller, enqueueE);
          return;
        }
        const stream = controller._controlledWritableStream;
        if (!WritableStreamCloseQueuedOrInFlight(stream) && stream._state === "writable") {
          const backpressure = WritableStreamDefaultControllerGetBackpressure(controller);
          WritableStreamUpdateBackpressure(stream, backpressure);
        }
        WritableStreamDefaultControllerAdvanceQueueIfNeeded(controller);
      }
      function WritableStreamDefaultControllerAdvanceQueueIfNeeded(controller) {
        const stream = controller._controlledWritableStream;
        if (!controller._started) {
          return;
        }
        if (stream._inFlightWriteRequest !== void 0) {
          return;
        }
        const state = stream._state;
        if (state === "erroring") {
          WritableStreamFinishErroring(stream);
          return;
        }
        if (controller._queue.length === 0) {
          return;
        }
        const value = PeekQueueValue(controller);
        if (value === closeSentinel) {
          WritableStreamDefaultControllerProcessClose(controller);
        } else {
          WritableStreamDefaultControllerProcessWrite(controller, value);
        }
      }
      function WritableStreamDefaultControllerErrorIfNeeded(controller, error) {
        if (controller._controlledWritableStream._state === "writable") {
          WritableStreamDefaultControllerError(controller, error);
        }
      }
      function WritableStreamDefaultControllerProcessClose(controller) {
        const stream = controller._controlledWritableStream;
        WritableStreamMarkCloseRequestInFlight(stream);
        DequeueValue(controller);
        const sinkClosePromise = controller._closeAlgorithm();
        WritableStreamDefaultControllerClearAlgorithms(controller);
        uponPromise(sinkClosePromise, () => {
          WritableStreamFinishInFlightClose(stream);
          return null;
        }, (reason) => {
          WritableStreamFinishInFlightCloseWithError(stream, reason);
          return null;
        });
      }
      function WritableStreamDefaultControllerProcessWrite(controller, chunk) {
        const stream = controller._controlledWritableStream;
        WritableStreamMarkFirstWriteRequestInFlight(stream);
        const sinkWritePromise = controller._writeAlgorithm(chunk);
        uponPromise(sinkWritePromise, () => {
          WritableStreamFinishInFlightWrite(stream);
          const state = stream._state;
          DequeueValue(controller);
          if (!WritableStreamCloseQueuedOrInFlight(stream) && state === "writable") {
            const backpressure = WritableStreamDefaultControllerGetBackpressure(controller);
            WritableStreamUpdateBackpressure(stream, backpressure);
          }
          WritableStreamDefaultControllerAdvanceQueueIfNeeded(controller);
          return null;
        }, (reason) => {
          if (stream._state === "writable") {
            WritableStreamDefaultControllerClearAlgorithms(controller);
          }
          WritableStreamFinishInFlightWriteWithError(stream, reason);
          return null;
        });
      }
      function WritableStreamDefaultControllerGetBackpressure(controller) {
        const desiredSize = WritableStreamDefaultControllerGetDesiredSize(controller);
        return desiredSize <= 0;
      }
      function WritableStreamDefaultControllerError(controller, error) {
        const stream = controller._controlledWritableStream;
        WritableStreamDefaultControllerClearAlgorithms(controller);
        WritableStreamStartErroring(stream, error);
      }
      function streamBrandCheckException$2(name) {
        return new TypeError(`WritableStream.prototype.${name} can only be used on a WritableStream`);
      }
      function defaultControllerBrandCheckException$2(name) {
        return new TypeError(`WritableStreamDefaultController.prototype.${name} can only be used on a WritableStreamDefaultController`);
      }
      function defaultWriterBrandCheckException(name) {
        return new TypeError(`WritableStreamDefaultWriter.prototype.${name} can only be used on a WritableStreamDefaultWriter`);
      }
      function defaultWriterLockException(name) {
        return new TypeError("Cannot " + name + " a stream using a released writer");
      }
      function defaultWriterClosedPromiseInitialize(writer) {
        writer._closedPromise = newPromise((resolve2, reject) => {
          writer._closedPromise_resolve = resolve2;
          writer._closedPromise_reject = reject;
          writer._closedPromiseState = "pending";
        });
      }
      function defaultWriterClosedPromiseInitializeAsRejected(writer, reason) {
        defaultWriterClosedPromiseInitialize(writer);
        defaultWriterClosedPromiseReject(writer, reason);
      }
      function defaultWriterClosedPromiseInitializeAsResolved(writer) {
        defaultWriterClosedPromiseInitialize(writer);
        defaultWriterClosedPromiseResolve(writer);
      }
      function defaultWriterClosedPromiseReject(writer, reason) {
        if (writer._closedPromise_reject === void 0) {
          return;
        }
        setPromiseIsHandledToTrue(writer._closedPromise);
        writer._closedPromise_reject(reason);
        writer._closedPromise_resolve = void 0;
        writer._closedPromise_reject = void 0;
        writer._closedPromiseState = "rejected";
      }
      function defaultWriterClosedPromiseResetToRejected(writer, reason) {
        defaultWriterClosedPromiseInitializeAsRejected(writer, reason);
      }
      function defaultWriterClosedPromiseResolve(writer) {
        if (writer._closedPromise_resolve === void 0) {
          return;
        }
        writer._closedPromise_resolve(void 0);
        writer._closedPromise_resolve = void 0;
        writer._closedPromise_reject = void 0;
        writer._closedPromiseState = "resolved";
      }
      function defaultWriterReadyPromiseInitialize(writer) {
        writer._readyPromise = newPromise((resolve2, reject) => {
          writer._readyPromise_resolve = resolve2;
          writer._readyPromise_reject = reject;
        });
        writer._readyPromiseState = "pending";
      }
      function defaultWriterReadyPromiseInitializeAsRejected(writer, reason) {
        defaultWriterReadyPromiseInitialize(writer);
        defaultWriterReadyPromiseReject(writer, reason);
      }
      function defaultWriterReadyPromiseInitializeAsResolved(writer) {
        defaultWriterReadyPromiseInitialize(writer);
        defaultWriterReadyPromiseResolve(writer);
      }
      function defaultWriterReadyPromiseReject(writer, reason) {
        if (writer._readyPromise_reject === void 0) {
          return;
        }
        setPromiseIsHandledToTrue(writer._readyPromise);
        writer._readyPromise_reject(reason);
        writer._readyPromise_resolve = void 0;
        writer._readyPromise_reject = void 0;
        writer._readyPromiseState = "rejected";
      }
      function defaultWriterReadyPromiseReset(writer) {
        defaultWriterReadyPromiseInitialize(writer);
      }
      function defaultWriterReadyPromiseResetToRejected(writer, reason) {
        defaultWriterReadyPromiseInitializeAsRejected(writer, reason);
      }
      function defaultWriterReadyPromiseResolve(writer) {
        if (writer._readyPromise_resolve === void 0) {
          return;
        }
        writer._readyPromise_resolve(void 0);
        writer._readyPromise_resolve = void 0;
        writer._readyPromise_reject = void 0;
        writer._readyPromiseState = "fulfilled";
      }
      function getGlobals() {
        if (typeof globalThis !== "undefined") {
          return globalThis;
        } else if (typeof self !== "undefined") {
          return self;
        } else if (typeof global !== "undefined") {
          return global;
        }
        return void 0;
      }
      const globals = getGlobals();
      function isDOMExceptionConstructor(ctor) {
        if (!(typeof ctor === "function" || typeof ctor === "object")) {
          return false;
        }
        if (ctor.name !== "DOMException") {
          return false;
        }
        try {
          new ctor();
          return true;
        } catch (_a) {
          return false;
        }
      }
      function getFromGlobal() {
        const ctor = globals === null || globals === void 0 ? void 0 : globals.DOMException;
        return isDOMExceptionConstructor(ctor) ? ctor : void 0;
      }
      function createPolyfill() {
        const ctor = function DOMException3(message, name) {
          this.message = message || "";
          this.name = name || "Error";
          if (Error.captureStackTrace) {
            Error.captureStackTrace(this, this.constructor);
          }
        };
        setFunctionName(ctor, "DOMException");
        ctor.prototype = Object.create(Error.prototype);
        Object.defineProperty(ctor.prototype, "constructor", { value: ctor, writable: true, configurable: true });
        return ctor;
      }
      const DOMException2 = getFromGlobal() || createPolyfill();
      function ReadableStreamPipeTo(source, dest, preventClose, preventAbort, preventCancel, signal) {
        const reader = AcquireReadableStreamDefaultReader(source);
        const writer = AcquireWritableStreamDefaultWriter(dest);
        source._disturbed = true;
        let shuttingDown = false;
        let currentWrite = promiseResolvedWith(void 0);
        return newPromise((resolve2, reject) => {
          let abortAlgorithm;
          if (signal !== void 0) {
            abortAlgorithm = () => {
              const error = signal.reason !== void 0 ? signal.reason : new DOMException2("Aborted", "AbortError");
              const actions = [];
              if (!preventAbort) {
                actions.push(() => {
                  if (dest._state === "writable") {
                    return WritableStreamAbort(dest, error);
                  }
                  return promiseResolvedWith(void 0);
                });
              }
              if (!preventCancel) {
                actions.push(() => {
                  if (source._state === "readable") {
                    return ReadableStreamCancel(source, error);
                  }
                  return promiseResolvedWith(void 0);
                });
              }
              shutdownWithAction(() => Promise.all(actions.map((action) => action())), true, error);
            };
            if (signal.aborted) {
              abortAlgorithm();
              return;
            }
            signal.addEventListener("abort", abortAlgorithm);
          }
          function pipeLoop() {
            return newPromise((resolveLoop, rejectLoop) => {
              function next(done) {
                if (done) {
                  resolveLoop();
                } else {
                  PerformPromiseThen(pipeStep(), next, rejectLoop);
                }
              }
              next(false);
            });
          }
          function pipeStep() {
            if (shuttingDown) {
              return promiseResolvedWith(true);
            }
            return PerformPromiseThen(writer._readyPromise, () => {
              return newPromise((resolveRead, rejectRead) => {
                ReadableStreamDefaultReaderRead(reader, {
                  _chunkSteps: (chunk) => {
                    currentWrite = PerformPromiseThen(WritableStreamDefaultWriterWrite(writer, chunk), void 0, noop2);
                    resolveRead(false);
                  },
                  _closeSteps: () => resolveRead(true),
                  _errorSteps: rejectRead
                });
              });
            });
          }
          isOrBecomesErrored(source, reader._closedPromise, (storedError) => {
            if (!preventAbort) {
              shutdownWithAction(() => WritableStreamAbort(dest, storedError), true, storedError);
            } else {
              shutdown(true, storedError);
            }
            return null;
          });
          isOrBecomesErrored(dest, writer._closedPromise, (storedError) => {
            if (!preventCancel) {
              shutdownWithAction(() => ReadableStreamCancel(source, storedError), true, storedError);
            } else {
              shutdown(true, storedError);
            }
            return null;
          });
          isOrBecomesClosed(source, reader._closedPromise, () => {
            if (!preventClose) {
              shutdownWithAction(() => WritableStreamDefaultWriterCloseWithErrorPropagation(writer));
            } else {
              shutdown();
            }
            return null;
          });
          if (WritableStreamCloseQueuedOrInFlight(dest) || dest._state === "closed") {
            const destClosed = new TypeError("the destination writable stream closed before all data could be piped to it");
            if (!preventCancel) {
              shutdownWithAction(() => ReadableStreamCancel(source, destClosed), true, destClosed);
            } else {
              shutdown(true, destClosed);
            }
          }
          setPromiseIsHandledToTrue(pipeLoop());
          function waitForWritesToFinish() {
            const oldCurrentWrite = currentWrite;
            return PerformPromiseThen(currentWrite, () => oldCurrentWrite !== currentWrite ? waitForWritesToFinish() : void 0);
          }
          function isOrBecomesErrored(stream, promise, action) {
            if (stream._state === "errored") {
              action(stream._storedError);
            } else {
              uponRejection(promise, action);
            }
          }
          function isOrBecomesClosed(stream, promise, action) {
            if (stream._state === "closed") {
              action();
            } else {
              uponFulfillment(promise, action);
            }
          }
          function shutdownWithAction(action, originalIsError, originalError) {
            if (shuttingDown) {
              return;
            }
            shuttingDown = true;
            if (dest._state === "writable" && !WritableStreamCloseQueuedOrInFlight(dest)) {
              uponFulfillment(waitForWritesToFinish(), doTheRest);
            } else {
              doTheRest();
            }
            function doTheRest() {
              uponPromise(action(), () => finalize(originalIsError, originalError), (newError) => finalize(true, newError));
              return null;
            }
          }
          function shutdown(isError2, error) {
            if (shuttingDown) {
              return;
            }
            shuttingDown = true;
            if (dest._state === "writable" && !WritableStreamCloseQueuedOrInFlight(dest)) {
              uponFulfillment(waitForWritesToFinish(), () => finalize(isError2, error));
            } else {
              finalize(isError2, error);
            }
          }
          function finalize(isError2, error) {
            WritableStreamDefaultWriterRelease(writer);
            ReadableStreamReaderGenericRelease(reader);
            if (signal !== void 0) {
              signal.removeEventListener("abort", abortAlgorithm);
            }
            if (isError2) {
              reject(error);
            } else {
              resolve2(void 0);
            }
            return null;
          }
        });
      }
      class ReadableStreamDefaultController {
        constructor() {
          throw new TypeError("Illegal constructor");
        }
        /**
         * Returns the desired size to fill the controlled stream's internal queue. It can be negative, if the queue is
         * over-full. An underlying source ought to use this information to determine when and how to apply backpressure.
         */
        get desiredSize() {
          if (!IsReadableStreamDefaultController(this)) {
            throw defaultControllerBrandCheckException$1("desiredSize");
          }
          return ReadableStreamDefaultControllerGetDesiredSize(this);
        }
        /**
         * Closes the controlled readable stream. Consumers will still be able to read any previously-enqueued chunks from
         * the stream, but once those are read, the stream will become closed.
         */
        close() {
          if (!IsReadableStreamDefaultController(this)) {
            throw defaultControllerBrandCheckException$1("close");
          }
          if (!ReadableStreamDefaultControllerCanCloseOrEnqueue(this)) {
            throw new TypeError("The stream is not in a state that permits close");
          }
          ReadableStreamDefaultControllerClose(this);
        }
        enqueue(chunk = void 0) {
          if (!IsReadableStreamDefaultController(this)) {
            throw defaultControllerBrandCheckException$1("enqueue");
          }
          if (!ReadableStreamDefaultControllerCanCloseOrEnqueue(this)) {
            throw new TypeError("The stream is not in a state that permits enqueue");
          }
          return ReadableStreamDefaultControllerEnqueue(this, chunk);
        }
        /**
         * Errors the controlled readable stream, making all future interactions with it fail with the given error `e`.
         */
        error(e2 = void 0) {
          if (!IsReadableStreamDefaultController(this)) {
            throw defaultControllerBrandCheckException$1("error");
          }
          ReadableStreamDefaultControllerError(this, e2);
        }
        /** @internal */
        [CancelSteps](reason) {
          ResetQueue(this);
          const result = this._cancelAlgorithm(reason);
          ReadableStreamDefaultControllerClearAlgorithms(this);
          return result;
        }
        /** @internal */
        [PullSteps](readRequest) {
          const stream = this._controlledReadableStream;
          if (this._queue.length > 0) {
            const chunk = DequeueValue(this);
            if (this._closeRequested && this._queue.length === 0) {
              ReadableStreamDefaultControllerClearAlgorithms(this);
              ReadableStreamClose(stream);
            } else {
              ReadableStreamDefaultControllerCallPullIfNeeded(this);
            }
            readRequest._chunkSteps(chunk);
          } else {
            ReadableStreamAddReadRequest(stream, readRequest);
            ReadableStreamDefaultControllerCallPullIfNeeded(this);
          }
        }
        /** @internal */
        [ReleaseSteps]() {
        }
      }
      Object.defineProperties(ReadableStreamDefaultController.prototype, {
        close: { enumerable: true },
        enqueue: { enumerable: true },
        error: { enumerable: true },
        desiredSize: { enumerable: true }
      });
      setFunctionName(ReadableStreamDefaultController.prototype.close, "close");
      setFunctionName(ReadableStreamDefaultController.prototype.enqueue, "enqueue");
      setFunctionName(ReadableStreamDefaultController.prototype.error, "error");
      if (typeof SymbolPolyfill.toStringTag === "symbol") {
        Object.defineProperty(ReadableStreamDefaultController.prototype, SymbolPolyfill.toStringTag, {
          value: "ReadableStreamDefaultController",
          configurable: true
        });
      }
      function IsReadableStreamDefaultController(x2) {
        if (!typeIsObject(x2)) {
          return false;
        }
        if (!Object.prototype.hasOwnProperty.call(x2, "_controlledReadableStream")) {
          return false;
        }
        return x2 instanceof ReadableStreamDefaultController;
      }
      function ReadableStreamDefaultControllerCallPullIfNeeded(controller) {
        const shouldPull = ReadableStreamDefaultControllerShouldCallPull(controller);
        if (!shouldPull) {
          return;
        }
        if (controller._pulling) {
          controller._pullAgain = true;
          return;
        }
        controller._pulling = true;
        const pullPromise = controller._pullAlgorithm();
        uponPromise(pullPromise, () => {
          controller._pulling = false;
          if (controller._pullAgain) {
            controller._pullAgain = false;
            ReadableStreamDefaultControllerCallPullIfNeeded(controller);
          }
          return null;
        }, (e2) => {
          ReadableStreamDefaultControllerError(controller, e2);
          return null;
        });
      }
      function ReadableStreamDefaultControllerShouldCallPull(controller) {
        const stream = controller._controlledReadableStream;
        if (!ReadableStreamDefaultControllerCanCloseOrEnqueue(controller)) {
          return false;
        }
        if (!controller._started) {
          return false;
        }
        if (IsReadableStreamLocked(stream) && ReadableStreamGetNumReadRequests(stream) > 0) {
          return true;
        }
        const desiredSize = ReadableStreamDefaultControllerGetDesiredSize(controller);
        if (desiredSize > 0) {
          return true;
        }
        return false;
      }
      function ReadableStreamDefaultControllerClearAlgorithms(controller) {
        controller._pullAlgorithm = void 0;
        controller._cancelAlgorithm = void 0;
        controller._strategySizeAlgorithm = void 0;
      }
      function ReadableStreamDefaultControllerClose(controller) {
        if (!ReadableStreamDefaultControllerCanCloseOrEnqueue(controller)) {
          return;
        }
        const stream = controller._controlledReadableStream;
        controller._closeRequested = true;
        if (controller._queue.length === 0) {
          ReadableStreamDefaultControllerClearAlgorithms(controller);
          ReadableStreamClose(stream);
        }
      }
      function ReadableStreamDefaultControllerEnqueue(controller, chunk) {
        if (!ReadableStreamDefaultControllerCanCloseOrEnqueue(controller)) {
          return;
        }
        const stream = controller._controlledReadableStream;
        if (IsReadableStreamLocked(stream) && ReadableStreamGetNumReadRequests(stream) > 0) {
          ReadableStreamFulfillReadRequest(stream, chunk, false);
        } else {
          let chunkSize;
          try {
            chunkSize = controller._strategySizeAlgorithm(chunk);
          } catch (chunkSizeE) {
            ReadableStreamDefaultControllerError(controller, chunkSizeE);
            throw chunkSizeE;
          }
          try {
            EnqueueValueWithSize(controller, chunk, chunkSize);
          } catch (enqueueE) {
            ReadableStreamDefaultControllerError(controller, enqueueE);
            throw enqueueE;
          }
        }
        ReadableStreamDefaultControllerCallPullIfNeeded(controller);
      }
      function ReadableStreamDefaultControllerError(controller, e2) {
        const stream = controller._controlledReadableStream;
        if (stream._state !== "readable") {
          return;
        }
        ResetQueue(controller);
        ReadableStreamDefaultControllerClearAlgorithms(controller);
        ReadableStreamError(stream, e2);
      }
      function ReadableStreamDefaultControllerGetDesiredSize(controller) {
        const state = controller._controlledReadableStream._state;
        if (state === "errored") {
          return null;
        }
        if (state === "closed") {
          return 0;
        }
        return controller._strategyHWM - controller._queueTotalSize;
      }
      function ReadableStreamDefaultControllerHasBackpressure(controller) {
        if (ReadableStreamDefaultControllerShouldCallPull(controller)) {
          return false;
        }
        return true;
      }
      function ReadableStreamDefaultControllerCanCloseOrEnqueue(controller) {
        const state = controller._controlledReadableStream._state;
        if (!controller._closeRequested && state === "readable") {
          return true;
        }
        return false;
      }
      function SetUpReadableStreamDefaultController(stream, controller, startAlgorithm, pullAlgorithm, cancelAlgorithm, highWaterMark, sizeAlgorithm) {
        controller._controlledReadableStream = stream;
        controller._queue = void 0;
        controller._queueTotalSize = void 0;
        ResetQueue(controller);
        controller._started = false;
        controller._closeRequested = false;
        controller._pullAgain = false;
        controller._pulling = false;
        controller._strategySizeAlgorithm = sizeAlgorithm;
        controller._strategyHWM = highWaterMark;
        controller._pullAlgorithm = pullAlgorithm;
        controller._cancelAlgorithm = cancelAlgorithm;
        stream._readableStreamController = controller;
        const startResult = startAlgorithm();
        uponPromise(promiseResolvedWith(startResult), () => {
          controller._started = true;
          ReadableStreamDefaultControllerCallPullIfNeeded(controller);
          return null;
        }, (r2) => {
          ReadableStreamDefaultControllerError(controller, r2);
          return null;
        });
      }
      function SetUpReadableStreamDefaultControllerFromUnderlyingSource(stream, underlyingSource, highWaterMark, sizeAlgorithm) {
        const controller = Object.create(ReadableStreamDefaultController.prototype);
        let startAlgorithm;
        let pullAlgorithm;
        let cancelAlgorithm;
        if (underlyingSource.start !== void 0) {
          startAlgorithm = () => underlyingSource.start(controller);
        } else {
          startAlgorithm = () => void 0;
        }
        if (underlyingSource.pull !== void 0) {
          pullAlgorithm = () => underlyingSource.pull(controller);
        } else {
          pullAlgorithm = () => promiseResolvedWith(void 0);
        }
        if (underlyingSource.cancel !== void 0) {
          cancelAlgorithm = (reason) => underlyingSource.cancel(reason);
        } else {
          cancelAlgorithm = () => promiseResolvedWith(void 0);
        }
        SetUpReadableStreamDefaultController(stream, controller, startAlgorithm, pullAlgorithm, cancelAlgorithm, highWaterMark, sizeAlgorithm);
      }
      function defaultControllerBrandCheckException$1(name) {
        return new TypeError(`ReadableStreamDefaultController.prototype.${name} can only be used on a ReadableStreamDefaultController`);
      }
      function ReadableStreamTee(stream, cloneForBranch2) {
        if (IsReadableByteStreamController(stream._readableStreamController)) {
          return ReadableByteStreamTee(stream);
        }
        return ReadableStreamDefaultTee(stream);
      }
      function ReadableStreamDefaultTee(stream, cloneForBranch2) {
        const reader = AcquireReadableStreamDefaultReader(stream);
        let reading = false;
        let readAgain = false;
        let canceled1 = false;
        let canceled2 = false;
        let reason1;
        let reason2;
        let branch1;
        let branch2;
        let resolveCancelPromise;
        const cancelPromise = newPromise((resolve2) => {
          resolveCancelPromise = resolve2;
        });
        function pullAlgorithm() {
          if (reading) {
            readAgain = true;
            return promiseResolvedWith(void 0);
          }
          reading = true;
          const readRequest = {
            _chunkSteps: (chunk) => {
              _queueMicrotask(() => {
                readAgain = false;
                const chunk1 = chunk;
                const chunk2 = chunk;
                if (!canceled1) {
                  ReadableStreamDefaultControllerEnqueue(branch1._readableStreamController, chunk1);
                }
                if (!canceled2) {
                  ReadableStreamDefaultControllerEnqueue(branch2._readableStreamController, chunk2);
                }
                reading = false;
                if (readAgain) {
                  pullAlgorithm();
                }
              });
            },
            _closeSteps: () => {
              reading = false;
              if (!canceled1) {
                ReadableStreamDefaultControllerClose(branch1._readableStreamController);
              }
              if (!canceled2) {
                ReadableStreamDefaultControllerClose(branch2._readableStreamController);
              }
              if (!canceled1 || !canceled2) {
                resolveCancelPromise(void 0);
              }
            },
            _errorSteps: () => {
              reading = false;
            }
          };
          ReadableStreamDefaultReaderRead(reader, readRequest);
          return promiseResolvedWith(void 0);
        }
        function cancel1Algorithm(reason) {
          canceled1 = true;
          reason1 = reason;
          if (canceled2) {
            const compositeReason = CreateArrayFromList([reason1, reason2]);
            const cancelResult = ReadableStreamCancel(stream, compositeReason);
            resolveCancelPromise(cancelResult);
          }
          return cancelPromise;
        }
        function cancel2Algorithm(reason) {
          canceled2 = true;
          reason2 = reason;
          if (canceled1) {
            const compositeReason = CreateArrayFromList([reason1, reason2]);
            const cancelResult = ReadableStreamCancel(stream, compositeReason);
            resolveCancelPromise(cancelResult);
          }
          return cancelPromise;
        }
        function startAlgorithm() {
        }
        branch1 = CreateReadableStream(startAlgorithm, pullAlgorithm, cancel1Algorithm);
        branch2 = CreateReadableStream(startAlgorithm, pullAlgorithm, cancel2Algorithm);
        uponRejection(reader._closedPromise, (r2) => {
          ReadableStreamDefaultControllerError(branch1._readableStreamController, r2);
          ReadableStreamDefaultControllerError(branch2._readableStreamController, r2);
          if (!canceled1 || !canceled2) {
            resolveCancelPromise(void 0);
          }
          return null;
        });
        return [branch1, branch2];
      }
      function ReadableByteStreamTee(stream) {
        let reader = AcquireReadableStreamDefaultReader(stream);
        let reading = false;
        let readAgainForBranch1 = false;
        let readAgainForBranch2 = false;
        let canceled1 = false;
        let canceled2 = false;
        let reason1;
        let reason2;
        let branch1;
        let branch2;
        let resolveCancelPromise;
        const cancelPromise = newPromise((resolve2) => {
          resolveCancelPromise = resolve2;
        });
        function forwardReaderError(thisReader) {
          uponRejection(thisReader._closedPromise, (r2) => {
            if (thisReader !== reader) {
              return null;
            }
            ReadableByteStreamControllerError(branch1._readableStreamController, r2);
            ReadableByteStreamControllerError(branch2._readableStreamController, r2);
            if (!canceled1 || !canceled2) {
              resolveCancelPromise(void 0);
            }
            return null;
          });
        }
        function pullWithDefaultReader() {
          if (IsReadableStreamBYOBReader(reader)) {
            ReadableStreamReaderGenericRelease(reader);
            reader = AcquireReadableStreamDefaultReader(stream);
            forwardReaderError(reader);
          }
          const readRequest = {
            _chunkSteps: (chunk) => {
              _queueMicrotask(() => {
                readAgainForBranch1 = false;
                readAgainForBranch2 = false;
                const chunk1 = chunk;
                let chunk2 = chunk;
                if (!canceled1 && !canceled2) {
                  try {
                    chunk2 = CloneAsUint8Array(chunk);
                  } catch (cloneE) {
                    ReadableByteStreamControllerError(branch1._readableStreamController, cloneE);
                    ReadableByteStreamControllerError(branch2._readableStreamController, cloneE);
                    resolveCancelPromise(ReadableStreamCancel(stream, cloneE));
                    return;
                  }
                }
                if (!canceled1) {
                  ReadableByteStreamControllerEnqueue(branch1._readableStreamController, chunk1);
                }
                if (!canceled2) {
                  ReadableByteStreamControllerEnqueue(branch2._readableStreamController, chunk2);
                }
                reading = false;
                if (readAgainForBranch1) {
                  pull1Algorithm();
                } else if (readAgainForBranch2) {
                  pull2Algorithm();
                }
              });
            },
            _closeSteps: () => {
              reading = false;
              if (!canceled1) {
                ReadableByteStreamControllerClose(branch1._readableStreamController);
              }
              if (!canceled2) {
                ReadableByteStreamControllerClose(branch2._readableStreamController);
              }
              if (branch1._readableStreamController._pendingPullIntos.length > 0) {
                ReadableByteStreamControllerRespond(branch1._readableStreamController, 0);
              }
              if (branch2._readableStreamController._pendingPullIntos.length > 0) {
                ReadableByteStreamControllerRespond(branch2._readableStreamController, 0);
              }
              if (!canceled1 || !canceled2) {
                resolveCancelPromise(void 0);
              }
            },
            _errorSteps: () => {
              reading = false;
            }
          };
          ReadableStreamDefaultReaderRead(reader, readRequest);
        }
        function pullWithBYOBReader(view, forBranch2) {
          if (IsReadableStreamDefaultReader(reader)) {
            ReadableStreamReaderGenericRelease(reader);
            reader = AcquireReadableStreamBYOBReader(stream);
            forwardReaderError(reader);
          }
          const byobBranch = forBranch2 ? branch2 : branch1;
          const otherBranch = forBranch2 ? branch1 : branch2;
          const readIntoRequest = {
            _chunkSteps: (chunk) => {
              _queueMicrotask(() => {
                readAgainForBranch1 = false;
                readAgainForBranch2 = false;
                const byobCanceled = forBranch2 ? canceled2 : canceled1;
                const otherCanceled = forBranch2 ? canceled1 : canceled2;
                if (!otherCanceled) {
                  let clonedChunk;
                  try {
                    clonedChunk = CloneAsUint8Array(chunk);
                  } catch (cloneE) {
                    ReadableByteStreamControllerError(byobBranch._readableStreamController, cloneE);
                    ReadableByteStreamControllerError(otherBranch._readableStreamController, cloneE);
                    resolveCancelPromise(ReadableStreamCancel(stream, cloneE));
                    return;
                  }
                  if (!byobCanceled) {
                    ReadableByteStreamControllerRespondWithNewView(byobBranch._readableStreamController, chunk);
                  }
                  ReadableByteStreamControllerEnqueue(otherBranch._readableStreamController, clonedChunk);
                } else if (!byobCanceled) {
                  ReadableByteStreamControllerRespondWithNewView(byobBranch._readableStreamController, chunk);
                }
                reading = false;
                if (readAgainForBranch1) {
                  pull1Algorithm();
                } else if (readAgainForBranch2) {
                  pull2Algorithm();
                }
              });
            },
            _closeSteps: (chunk) => {
              reading = false;
              const byobCanceled = forBranch2 ? canceled2 : canceled1;
              const otherCanceled = forBranch2 ? canceled1 : canceled2;
              if (!byobCanceled) {
                ReadableByteStreamControllerClose(byobBranch._readableStreamController);
              }
              if (!otherCanceled) {
                ReadableByteStreamControllerClose(otherBranch._readableStreamController);
              }
              if (chunk !== void 0) {
                if (!byobCanceled) {
                  ReadableByteStreamControllerRespondWithNewView(byobBranch._readableStreamController, chunk);
                }
                if (!otherCanceled && otherBranch._readableStreamController._pendingPullIntos.length > 0) {
                  ReadableByteStreamControllerRespond(otherBranch._readableStreamController, 0);
                }
              }
              if (!byobCanceled || !otherCanceled) {
                resolveCancelPromise(void 0);
              }
            },
            _errorSteps: () => {
              reading = false;
            }
          };
          ReadableStreamBYOBReaderRead(reader, view, 1, readIntoRequest);
        }
        function pull1Algorithm() {
          if (reading) {
            readAgainForBranch1 = true;
            return promiseResolvedWith(void 0);
          }
          reading = true;
          const byobRequest = ReadableByteStreamControllerGetBYOBRequest(branch1._readableStreamController);
          if (byobRequest === null) {
            pullWithDefaultReader();
          } else {
            pullWithBYOBReader(byobRequest._view, false);
          }
          return promiseResolvedWith(void 0);
        }
        function pull2Algorithm() {
          if (reading) {
            readAgainForBranch2 = true;
            return promiseResolvedWith(void 0);
          }
          reading = true;
          const byobRequest = ReadableByteStreamControllerGetBYOBRequest(branch2._readableStreamController);
          if (byobRequest === null) {
            pullWithDefaultReader();
          } else {
            pullWithBYOBReader(byobRequest._view, true);
          }
          return promiseResolvedWith(void 0);
        }
        function cancel1Algorithm(reason) {
          canceled1 = true;
          reason1 = reason;
          if (canceled2) {
            const compositeReason = CreateArrayFromList([reason1, reason2]);
            const cancelResult = ReadableStreamCancel(stream, compositeReason);
            resolveCancelPromise(cancelResult);
          }
          return cancelPromise;
        }
        function cancel2Algorithm(reason) {
          canceled2 = true;
          reason2 = reason;
          if (canceled1) {
            const compositeReason = CreateArrayFromList([reason1, reason2]);
            const cancelResult = ReadableStreamCancel(stream, compositeReason);
            resolveCancelPromise(cancelResult);
          }
          return cancelPromise;
        }
        function startAlgorithm() {
          return;
        }
        branch1 = CreateReadableByteStream(startAlgorithm, pull1Algorithm, cancel1Algorithm);
        branch2 = CreateReadableByteStream(startAlgorithm, pull2Algorithm, cancel2Algorithm);
        forwardReaderError(reader);
        return [branch1, branch2];
      }
      function isReadableStreamLike(stream) {
        return typeIsObject(stream) && typeof stream.getReader !== "undefined";
      }
      function ReadableStreamFrom(source) {
        if (isReadableStreamLike(source)) {
          return ReadableStreamFromDefaultReader(source.getReader());
        }
        return ReadableStreamFromIterable(source);
      }
      function ReadableStreamFromIterable(asyncIterable) {
        let stream;
        const iteratorRecord = GetIterator(asyncIterable, "async");
        const startAlgorithm = noop2;
        function pullAlgorithm() {
          let nextResult;
          try {
            nextResult = IteratorNext(iteratorRecord);
          } catch (e2) {
            return promiseRejectedWith(e2);
          }
          const nextPromise = promiseResolvedWith(nextResult);
          return transformPromiseWith(nextPromise, (iterResult) => {
            if (!typeIsObject(iterResult)) {
              throw new TypeError("The promise returned by the iterator.next() method must fulfill with an object");
            }
            const done = IteratorComplete(iterResult);
            if (done) {
              ReadableStreamDefaultControllerClose(stream._readableStreamController);
            } else {
              const value = IteratorValue(iterResult);
              ReadableStreamDefaultControllerEnqueue(stream._readableStreamController, value);
            }
          });
        }
        function cancelAlgorithm(reason) {
          const iterator = iteratorRecord.iterator;
          let returnMethod;
          try {
            returnMethod = GetMethod(iterator, "return");
          } catch (e2) {
            return promiseRejectedWith(e2);
          }
          if (returnMethod === void 0) {
            return promiseResolvedWith(void 0);
          }
          let returnResult;
          try {
            returnResult = reflectCall(returnMethod, iterator, [reason]);
          } catch (e2) {
            return promiseRejectedWith(e2);
          }
          const returnPromise = promiseResolvedWith(returnResult);
          return transformPromiseWith(returnPromise, (iterResult) => {
            if (!typeIsObject(iterResult)) {
              throw new TypeError("The promise returned by the iterator.return() method must fulfill with an object");
            }
            return void 0;
          });
        }
        stream = CreateReadableStream(startAlgorithm, pullAlgorithm, cancelAlgorithm, 0);
        return stream;
      }
      function ReadableStreamFromDefaultReader(reader) {
        let stream;
        const startAlgorithm = noop2;
        function pullAlgorithm() {
          let readPromise;
          try {
            readPromise = reader.read();
          } catch (e2) {
            return promiseRejectedWith(e2);
          }
          return transformPromiseWith(readPromise, (readResult) => {
            if (!typeIsObject(readResult)) {
              throw new TypeError("The promise returned by the reader.read() method must fulfill with an object");
            }
            if (readResult.done) {
              ReadableStreamDefaultControllerClose(stream._readableStreamController);
            } else {
              const value = readResult.value;
              ReadableStreamDefaultControllerEnqueue(stream._readableStreamController, value);
            }
          });
        }
        function cancelAlgorithm(reason) {
          try {
            return promiseResolvedWith(reader.cancel(reason));
          } catch (e2) {
            return promiseRejectedWith(e2);
          }
        }
        stream = CreateReadableStream(startAlgorithm, pullAlgorithm, cancelAlgorithm, 0);
        return stream;
      }
      function convertUnderlyingDefaultOrByteSource(source, context) {
        assertDictionary(source, context);
        const original = source;
        const autoAllocateChunkSize = original === null || original === void 0 ? void 0 : original.autoAllocateChunkSize;
        const cancel = original === null || original === void 0 ? void 0 : original.cancel;
        const pull = original === null || original === void 0 ? void 0 : original.pull;
        const start = original === null || original === void 0 ? void 0 : original.start;
        const type = original === null || original === void 0 ? void 0 : original.type;
        return {
          autoAllocateChunkSize: autoAllocateChunkSize === void 0 ? void 0 : convertUnsignedLongLongWithEnforceRange(autoAllocateChunkSize, `${context} has member 'autoAllocateChunkSize' that`),
          cancel: cancel === void 0 ? void 0 : convertUnderlyingSourceCancelCallback(cancel, original, `${context} has member 'cancel' that`),
          pull: pull === void 0 ? void 0 : convertUnderlyingSourcePullCallback(pull, original, `${context} has member 'pull' that`),
          start: start === void 0 ? void 0 : convertUnderlyingSourceStartCallback(start, original, `${context} has member 'start' that`),
          type: type === void 0 ? void 0 : convertReadableStreamType(type, `${context} has member 'type' that`)
        };
      }
      function convertUnderlyingSourceCancelCallback(fn, original, context) {
        assertFunction(fn, context);
        return (reason) => promiseCall(fn, original, [reason]);
      }
      function convertUnderlyingSourcePullCallback(fn, original, context) {
        assertFunction(fn, context);
        return (controller) => promiseCall(fn, original, [controller]);
      }
      function convertUnderlyingSourceStartCallback(fn, original, context) {
        assertFunction(fn, context);
        return (controller) => reflectCall(fn, original, [controller]);
      }
      function convertReadableStreamType(type, context) {
        type = `${type}`;
        if (type !== "bytes") {
          throw new TypeError(`${context} '${type}' is not a valid enumeration value for ReadableStreamType`);
        }
        return type;
      }
      function convertIteratorOptions(options, context) {
        assertDictionary(options, context);
        const preventCancel = options === null || options === void 0 ? void 0 : options.preventCancel;
        return { preventCancel: Boolean(preventCancel) };
      }
      function convertPipeOptions(options, context) {
        assertDictionary(options, context);
        const preventAbort = options === null || options === void 0 ? void 0 : options.preventAbort;
        const preventCancel = options === null || options === void 0 ? void 0 : options.preventCancel;
        const preventClose = options === null || options === void 0 ? void 0 : options.preventClose;
        const signal = options === null || options === void 0 ? void 0 : options.signal;
        if (signal !== void 0) {
          assertAbortSignal(signal, `${context} has member 'signal' that`);
        }
        return {
          preventAbort: Boolean(preventAbort),
          preventCancel: Boolean(preventCancel),
          preventClose: Boolean(preventClose),
          signal
        };
      }
      function assertAbortSignal(signal, context) {
        if (!isAbortSignal2(signal)) {
          throw new TypeError(`${context} is not an AbortSignal.`);
        }
      }
      function convertReadableWritablePair(pair, context) {
        assertDictionary(pair, context);
        const readable = pair === null || pair === void 0 ? void 0 : pair.readable;
        assertRequiredField(readable, "readable", "ReadableWritablePair");
        assertReadableStream(readable, `${context} has member 'readable' that`);
        const writable = pair === null || pair === void 0 ? void 0 : pair.writable;
        assertRequiredField(writable, "writable", "ReadableWritablePair");
        assertWritableStream(writable, `${context} has member 'writable' that`);
        return { readable, writable };
      }
      class ReadableStream2 {
        constructor(rawUnderlyingSource = {}, rawStrategy = {}) {
          if (rawUnderlyingSource === void 0) {
            rawUnderlyingSource = null;
          } else {
            assertObject(rawUnderlyingSource, "First parameter");
          }
          const strategy = convertQueuingStrategy(rawStrategy, "Second parameter");
          const underlyingSource = convertUnderlyingDefaultOrByteSource(rawUnderlyingSource, "First parameter");
          InitializeReadableStream(this);
          if (underlyingSource.type === "bytes") {
            if (strategy.size !== void 0) {
              throw new RangeError("The strategy for a byte stream cannot have a size function");
            }
            const highWaterMark = ExtractHighWaterMark(strategy, 0);
            SetUpReadableByteStreamControllerFromUnderlyingSource(this, underlyingSource, highWaterMark);
          } else {
            const sizeAlgorithm = ExtractSizeAlgorithm(strategy);
            const highWaterMark = ExtractHighWaterMark(strategy, 1);
            SetUpReadableStreamDefaultControllerFromUnderlyingSource(this, underlyingSource, highWaterMark, sizeAlgorithm);
          }
        }
        /**
         * Whether or not the readable stream is locked to a {@link ReadableStreamDefaultReader | reader}.
         */
        get locked() {
          if (!IsReadableStream(this)) {
            throw streamBrandCheckException$1("locked");
          }
          return IsReadableStreamLocked(this);
        }
        /**
         * Cancels the stream, signaling a loss of interest in the stream by a consumer.
         *
         * The supplied `reason` argument will be given to the underlying source's {@link UnderlyingSource.cancel | cancel()}
         * method, which might or might not use it.
         */
        cancel(reason = void 0) {
          if (!IsReadableStream(this)) {
            return promiseRejectedWith(streamBrandCheckException$1("cancel"));
          }
          if (IsReadableStreamLocked(this)) {
            return promiseRejectedWith(new TypeError("Cannot cancel a stream that already has a reader"));
          }
          return ReadableStreamCancel(this, reason);
        }
        getReader(rawOptions = void 0) {
          if (!IsReadableStream(this)) {
            throw streamBrandCheckException$1("getReader");
          }
          const options = convertReaderOptions(rawOptions, "First parameter");
          if (options.mode === void 0) {
            return AcquireReadableStreamDefaultReader(this);
          }
          return AcquireReadableStreamBYOBReader(this);
        }
        pipeThrough(rawTransform, rawOptions = {}) {
          if (!IsReadableStream(this)) {
            throw streamBrandCheckException$1("pipeThrough");
          }
          assertRequiredArgument(rawTransform, 1, "pipeThrough");
          const transform = convertReadableWritablePair(rawTransform, "First parameter");
          const options = convertPipeOptions(rawOptions, "Second parameter");
          if (IsReadableStreamLocked(this)) {
            throw new TypeError("ReadableStream.prototype.pipeThrough cannot be used on a locked ReadableStream");
          }
          if (IsWritableStreamLocked(transform.writable)) {
            throw new TypeError("ReadableStream.prototype.pipeThrough cannot be used on a locked WritableStream");
          }
          const promise = ReadableStreamPipeTo(this, transform.writable, options.preventClose, options.preventAbort, options.preventCancel, options.signal);
          setPromiseIsHandledToTrue(promise);
          return transform.readable;
        }
        pipeTo(destination, rawOptions = {}) {
          if (!IsReadableStream(this)) {
            return promiseRejectedWith(streamBrandCheckException$1("pipeTo"));
          }
          if (destination === void 0) {
            return promiseRejectedWith(`Parameter 1 is required in 'pipeTo'.`);
          }
          if (!IsWritableStream(destination)) {
            return promiseRejectedWith(new TypeError(`ReadableStream.prototype.pipeTo's first argument must be a WritableStream`));
          }
          let options;
          try {
            options = convertPipeOptions(rawOptions, "Second parameter");
          } catch (e2) {
            return promiseRejectedWith(e2);
          }
          if (IsReadableStreamLocked(this)) {
            return promiseRejectedWith(new TypeError("ReadableStream.prototype.pipeTo cannot be used on a locked ReadableStream"));
          }
          if (IsWritableStreamLocked(destination)) {
            return promiseRejectedWith(new TypeError("ReadableStream.prototype.pipeTo cannot be used on a locked WritableStream"));
          }
          return ReadableStreamPipeTo(this, destination, options.preventClose, options.preventAbort, options.preventCancel, options.signal);
        }
        /**
         * Tees this readable stream, returning a two-element array containing the two resulting branches as
         * new {@link ReadableStream} instances.
         *
         * Teeing a stream will lock it, preventing any other consumer from acquiring a reader.
         * To cancel the stream, cancel both of the resulting branches; a composite cancellation reason will then be
         * propagated to the stream's underlying source.
         *
         * Note that the chunks seen in each branch will be the same object. If the chunks are not immutable,
         * this could allow interference between the two branches.
         */
        tee() {
          if (!IsReadableStream(this)) {
            throw streamBrandCheckException$1("tee");
          }
          const branches = ReadableStreamTee(this);
          return CreateArrayFromList(branches);
        }
        values(rawOptions = void 0) {
          if (!IsReadableStream(this)) {
            throw streamBrandCheckException$1("values");
          }
          const options = convertIteratorOptions(rawOptions, "First parameter");
          return AcquireReadableStreamAsyncIterator(this, options.preventCancel);
        }
        /**
         * Creates a new ReadableStream wrapping the provided iterable or async iterable.
         *
         * This can be used to adapt various kinds of objects into a readable stream,
         * such as an array, an async generator, or a Node.js readable stream.
         */
        static from(asyncIterable) {
          return ReadableStreamFrom(asyncIterable);
        }
      }
      Object.defineProperties(ReadableStream2, {
        from: { enumerable: true }
      });
      Object.defineProperties(ReadableStream2.prototype, {
        cancel: { enumerable: true },
        getReader: { enumerable: true },
        pipeThrough: { enumerable: true },
        pipeTo: { enumerable: true },
        tee: { enumerable: true },
        values: { enumerable: true },
        locked: { enumerable: true }
      });
      setFunctionName(ReadableStream2.from, "from");
      setFunctionName(ReadableStream2.prototype.cancel, "cancel");
      setFunctionName(ReadableStream2.prototype.getReader, "getReader");
      setFunctionName(ReadableStream2.prototype.pipeThrough, "pipeThrough");
      setFunctionName(ReadableStream2.prototype.pipeTo, "pipeTo");
      setFunctionName(ReadableStream2.prototype.tee, "tee");
      setFunctionName(ReadableStream2.prototype.values, "values");
      if (typeof SymbolPolyfill.toStringTag === "symbol") {
        Object.defineProperty(ReadableStream2.prototype, SymbolPolyfill.toStringTag, {
          value: "ReadableStream",
          configurable: true
        });
      }
      if (typeof SymbolPolyfill.asyncIterator === "symbol") {
        Object.defineProperty(ReadableStream2.prototype, SymbolPolyfill.asyncIterator, {
          value: ReadableStream2.prototype.values,
          writable: true,
          configurable: true
        });
      }
      function CreateReadableStream(startAlgorithm, pullAlgorithm, cancelAlgorithm, highWaterMark = 1, sizeAlgorithm = () => 1) {
        const stream = Object.create(ReadableStream2.prototype);
        InitializeReadableStream(stream);
        const controller = Object.create(ReadableStreamDefaultController.prototype);
        SetUpReadableStreamDefaultController(stream, controller, startAlgorithm, pullAlgorithm, cancelAlgorithm, highWaterMark, sizeAlgorithm);
        return stream;
      }
      function CreateReadableByteStream(startAlgorithm, pullAlgorithm, cancelAlgorithm) {
        const stream = Object.create(ReadableStream2.prototype);
        InitializeReadableStream(stream);
        const controller = Object.create(ReadableByteStreamController.prototype);
        SetUpReadableByteStreamController(stream, controller, startAlgorithm, pullAlgorithm, cancelAlgorithm, 0, void 0);
        return stream;
      }
      function InitializeReadableStream(stream) {
        stream._state = "readable";
        stream._reader = void 0;
        stream._storedError = void 0;
        stream._disturbed = false;
      }
      function IsReadableStream(x2) {
        if (!typeIsObject(x2)) {
          return false;
        }
        if (!Object.prototype.hasOwnProperty.call(x2, "_readableStreamController")) {
          return false;
        }
        return x2 instanceof ReadableStream2;
      }
      function IsReadableStreamLocked(stream) {
        if (stream._reader === void 0) {
          return false;
        }
        return true;
      }
      function ReadableStreamCancel(stream, reason) {
        stream._disturbed = true;
        if (stream._state === "closed") {
          return promiseResolvedWith(void 0);
        }
        if (stream._state === "errored") {
          return promiseRejectedWith(stream._storedError);
        }
        ReadableStreamClose(stream);
        const reader = stream._reader;
        if (reader !== void 0 && IsReadableStreamBYOBReader(reader)) {
          const readIntoRequests = reader._readIntoRequests;
          reader._readIntoRequests = new SimpleQueue();
          readIntoRequests.forEach((readIntoRequest) => {
            readIntoRequest._closeSteps(void 0);
          });
        }
        const sourceCancelPromise = stream._readableStreamController[CancelSteps](reason);
        return transformPromiseWith(sourceCancelPromise, noop2);
      }
      function ReadableStreamClose(stream) {
        stream._state = "closed";
        const reader = stream._reader;
        if (reader === void 0) {
          return;
        }
        defaultReaderClosedPromiseResolve(reader);
        if (IsReadableStreamDefaultReader(reader)) {
          const readRequests = reader._readRequests;
          reader._readRequests = new SimpleQueue();
          readRequests.forEach((readRequest) => {
            readRequest._closeSteps();
          });
        }
      }
      function ReadableStreamError(stream, e2) {
        stream._state = "errored";
        stream._storedError = e2;
        const reader = stream._reader;
        if (reader === void 0) {
          return;
        }
        defaultReaderClosedPromiseReject(reader, e2);
        if (IsReadableStreamDefaultReader(reader)) {
          ReadableStreamDefaultReaderErrorReadRequests(reader, e2);
        } else {
          ReadableStreamBYOBReaderErrorReadIntoRequests(reader, e2);
        }
      }
      function streamBrandCheckException$1(name) {
        return new TypeError(`ReadableStream.prototype.${name} can only be used on a ReadableStream`);
      }
      function convertQueuingStrategyInit(init, context) {
        assertDictionary(init, context);
        const highWaterMark = init === null || init === void 0 ? void 0 : init.highWaterMark;
        assertRequiredField(highWaterMark, "highWaterMark", "QueuingStrategyInit");
        return {
          highWaterMark: convertUnrestrictedDouble(highWaterMark)
        };
      }
      const byteLengthSizeFunction = (chunk) => {
        return chunk.byteLength;
      };
      setFunctionName(byteLengthSizeFunction, "size");
      class ByteLengthQueuingStrategy {
        constructor(options) {
          assertRequiredArgument(options, 1, "ByteLengthQueuingStrategy");
          options = convertQueuingStrategyInit(options, "First parameter");
          this._byteLengthQueuingStrategyHighWaterMark = options.highWaterMark;
        }
        /**
         * Returns the high water mark provided to the constructor.
         */
        get highWaterMark() {
          if (!IsByteLengthQueuingStrategy(this)) {
            throw byteLengthBrandCheckException("highWaterMark");
          }
          return this._byteLengthQueuingStrategyHighWaterMark;
        }
        /**
         * Measures the size of `chunk` by returning the value of its `byteLength` property.
         */
        get size() {
          if (!IsByteLengthQueuingStrategy(this)) {
            throw byteLengthBrandCheckException("size");
          }
          return byteLengthSizeFunction;
        }
      }
      Object.defineProperties(ByteLengthQueuingStrategy.prototype, {
        highWaterMark: { enumerable: true },
        size: { enumerable: true }
      });
      if (typeof SymbolPolyfill.toStringTag === "symbol") {
        Object.defineProperty(ByteLengthQueuingStrategy.prototype, SymbolPolyfill.toStringTag, {
          value: "ByteLengthQueuingStrategy",
          configurable: true
        });
      }
      function byteLengthBrandCheckException(name) {
        return new TypeError(`ByteLengthQueuingStrategy.prototype.${name} can only be used on a ByteLengthQueuingStrategy`);
      }
      function IsByteLengthQueuingStrategy(x2) {
        if (!typeIsObject(x2)) {
          return false;
        }
        if (!Object.prototype.hasOwnProperty.call(x2, "_byteLengthQueuingStrategyHighWaterMark")) {
          return false;
        }
        return x2 instanceof ByteLengthQueuingStrategy;
      }
      const countSizeFunction = () => {
        return 1;
      };
      setFunctionName(countSizeFunction, "size");
      class CountQueuingStrategy {
        constructor(options) {
          assertRequiredArgument(options, 1, "CountQueuingStrategy");
          options = convertQueuingStrategyInit(options, "First parameter");
          this._countQueuingStrategyHighWaterMark = options.highWaterMark;
        }
        /**
         * Returns the high water mark provided to the constructor.
         */
        get highWaterMark() {
          if (!IsCountQueuingStrategy(this)) {
            throw countBrandCheckException("highWaterMark");
          }
          return this._countQueuingStrategyHighWaterMark;
        }
        /**
         * Measures the size of `chunk` by always returning 1.
         * This ensures that the total queue size is a count of the number of chunks in the queue.
         */
        get size() {
          if (!IsCountQueuingStrategy(this)) {
            throw countBrandCheckException("size");
          }
          return countSizeFunction;
        }
      }
      Object.defineProperties(CountQueuingStrategy.prototype, {
        highWaterMark: { enumerable: true },
        size: { enumerable: true }
      });
      if (typeof SymbolPolyfill.toStringTag === "symbol") {
        Object.defineProperty(CountQueuingStrategy.prototype, SymbolPolyfill.toStringTag, {
          value: "CountQueuingStrategy",
          configurable: true
        });
      }
      function countBrandCheckException(name) {
        return new TypeError(`CountQueuingStrategy.prototype.${name} can only be used on a CountQueuingStrategy`);
      }
      function IsCountQueuingStrategy(x2) {
        if (!typeIsObject(x2)) {
          return false;
        }
        if (!Object.prototype.hasOwnProperty.call(x2, "_countQueuingStrategyHighWaterMark")) {
          return false;
        }
        return x2 instanceof CountQueuingStrategy;
      }
      function convertTransformer(original, context) {
        assertDictionary(original, context);
        const cancel = original === null || original === void 0 ? void 0 : original.cancel;
        const flush2 = original === null || original === void 0 ? void 0 : original.flush;
        const readableType = original === null || original === void 0 ? void 0 : original.readableType;
        const start = original === null || original === void 0 ? void 0 : original.start;
        const transform = original === null || original === void 0 ? void 0 : original.transform;
        const writableType = original === null || original === void 0 ? void 0 : original.writableType;
        return {
          cancel: cancel === void 0 ? void 0 : convertTransformerCancelCallback(cancel, original, `${context} has member 'cancel' that`),
          flush: flush2 === void 0 ? void 0 : convertTransformerFlushCallback(flush2, original, `${context} has member 'flush' that`),
          readableType,
          start: start === void 0 ? void 0 : convertTransformerStartCallback(start, original, `${context} has member 'start' that`),
          transform: transform === void 0 ? void 0 : convertTransformerTransformCallback(transform, original, `${context} has member 'transform' that`),
          writableType
        };
      }
      function convertTransformerFlushCallback(fn, original, context) {
        assertFunction(fn, context);
        return (controller) => promiseCall(fn, original, [controller]);
      }
      function convertTransformerStartCallback(fn, original, context) {
        assertFunction(fn, context);
        return (controller) => reflectCall(fn, original, [controller]);
      }
      function convertTransformerTransformCallback(fn, original, context) {
        assertFunction(fn, context);
        return (chunk, controller) => promiseCall(fn, original, [chunk, controller]);
      }
      function convertTransformerCancelCallback(fn, original, context) {
        assertFunction(fn, context);
        return (reason) => promiseCall(fn, original, [reason]);
      }
      class TransformStream {
        constructor(rawTransformer = {}, rawWritableStrategy = {}, rawReadableStrategy = {}) {
          if (rawTransformer === void 0) {
            rawTransformer = null;
          }
          const writableStrategy = convertQueuingStrategy(rawWritableStrategy, "Second parameter");
          const readableStrategy = convertQueuingStrategy(rawReadableStrategy, "Third parameter");
          const transformer = convertTransformer(rawTransformer, "First parameter");
          if (transformer.readableType !== void 0) {
            throw new RangeError("Invalid readableType specified");
          }
          if (transformer.writableType !== void 0) {
            throw new RangeError("Invalid writableType specified");
          }
          const readableHighWaterMark = ExtractHighWaterMark(readableStrategy, 0);
          const readableSizeAlgorithm = ExtractSizeAlgorithm(readableStrategy);
          const writableHighWaterMark = ExtractHighWaterMark(writableStrategy, 1);
          const writableSizeAlgorithm = ExtractSizeAlgorithm(writableStrategy);
          let startPromise_resolve;
          const startPromise = newPromise((resolve2) => {
            startPromise_resolve = resolve2;
          });
          InitializeTransformStream(this, startPromise, writableHighWaterMark, writableSizeAlgorithm, readableHighWaterMark, readableSizeAlgorithm);
          SetUpTransformStreamDefaultControllerFromTransformer(this, transformer);
          if (transformer.start !== void 0) {
            startPromise_resolve(transformer.start(this._transformStreamController));
          } else {
            startPromise_resolve(void 0);
          }
        }
        /**
         * The readable side of the transform stream.
         */
        get readable() {
          if (!IsTransformStream(this)) {
            throw streamBrandCheckException("readable");
          }
          return this._readable;
        }
        /**
         * The writable side of the transform stream.
         */
        get writable() {
          if (!IsTransformStream(this)) {
            throw streamBrandCheckException("writable");
          }
          return this._writable;
        }
      }
      Object.defineProperties(TransformStream.prototype, {
        readable: { enumerable: true },
        writable: { enumerable: true }
      });
      if (typeof SymbolPolyfill.toStringTag === "symbol") {
        Object.defineProperty(TransformStream.prototype, SymbolPolyfill.toStringTag, {
          value: "TransformStream",
          configurable: true
        });
      }
      function InitializeTransformStream(stream, startPromise, writableHighWaterMark, writableSizeAlgorithm, readableHighWaterMark, readableSizeAlgorithm) {
        function startAlgorithm() {
          return startPromise;
        }
        function writeAlgorithm(chunk) {
          return TransformStreamDefaultSinkWriteAlgorithm(stream, chunk);
        }
        function abortAlgorithm(reason) {
          return TransformStreamDefaultSinkAbortAlgorithm(stream, reason);
        }
        function closeAlgorithm() {
          return TransformStreamDefaultSinkCloseAlgorithm(stream);
        }
        stream._writable = CreateWritableStream(startAlgorithm, writeAlgorithm, closeAlgorithm, abortAlgorithm, writableHighWaterMark, writableSizeAlgorithm);
        function pullAlgorithm() {
          return TransformStreamDefaultSourcePullAlgorithm(stream);
        }
        function cancelAlgorithm(reason) {
          return TransformStreamDefaultSourceCancelAlgorithm(stream, reason);
        }
        stream._readable = CreateReadableStream(startAlgorithm, pullAlgorithm, cancelAlgorithm, readableHighWaterMark, readableSizeAlgorithm);
        stream._backpressure = void 0;
        stream._backpressureChangePromise = void 0;
        stream._backpressureChangePromise_resolve = void 0;
        TransformStreamSetBackpressure(stream, true);
        stream._transformStreamController = void 0;
      }
      function IsTransformStream(x2) {
        if (!typeIsObject(x2)) {
          return false;
        }
        if (!Object.prototype.hasOwnProperty.call(x2, "_transformStreamController")) {
          return false;
        }
        return x2 instanceof TransformStream;
      }
      function TransformStreamError(stream, e2) {
        ReadableStreamDefaultControllerError(stream._readable._readableStreamController, e2);
        TransformStreamErrorWritableAndUnblockWrite(stream, e2);
      }
      function TransformStreamErrorWritableAndUnblockWrite(stream, e2) {
        TransformStreamDefaultControllerClearAlgorithms(stream._transformStreamController);
        WritableStreamDefaultControllerErrorIfNeeded(stream._writable._writableStreamController, e2);
        TransformStreamUnblockWrite(stream);
      }
      function TransformStreamUnblockWrite(stream) {
        if (stream._backpressure) {
          TransformStreamSetBackpressure(stream, false);
        }
      }
      function TransformStreamSetBackpressure(stream, backpressure) {
        if (stream._backpressureChangePromise !== void 0) {
          stream._backpressureChangePromise_resolve();
        }
        stream._backpressureChangePromise = newPromise((resolve2) => {
          stream._backpressureChangePromise_resolve = resolve2;
        });
        stream._backpressure = backpressure;
      }
      class TransformStreamDefaultController {
        constructor() {
          throw new TypeError("Illegal constructor");
        }
        /**
         * Returns the desired size to fill the readable side’s internal queue. It can be negative, if the queue is over-full.
         */
        get desiredSize() {
          if (!IsTransformStreamDefaultController(this)) {
            throw defaultControllerBrandCheckException("desiredSize");
          }
          const readableController = this._controlledTransformStream._readable._readableStreamController;
          return ReadableStreamDefaultControllerGetDesiredSize(readableController);
        }
        enqueue(chunk = void 0) {
          if (!IsTransformStreamDefaultController(this)) {
            throw defaultControllerBrandCheckException("enqueue");
          }
          TransformStreamDefaultControllerEnqueue(this, chunk);
        }
        /**
         * Errors both the readable side and the writable side of the controlled transform stream, making all future
         * interactions with it fail with the given error `e`. Any chunks queued for transformation will be discarded.
         */
        error(reason = void 0) {
          if (!IsTransformStreamDefaultController(this)) {
            throw defaultControllerBrandCheckException("error");
          }
          TransformStreamDefaultControllerError(this, reason);
        }
        /**
         * Closes the readable side and errors the writable side of the controlled transform stream. This is useful when the
         * transformer only needs to consume a portion of the chunks written to the writable side.
         */
        terminate() {
          if (!IsTransformStreamDefaultController(this)) {
            throw defaultControllerBrandCheckException("terminate");
          }
          TransformStreamDefaultControllerTerminate(this);
        }
      }
      Object.defineProperties(TransformStreamDefaultController.prototype, {
        enqueue: { enumerable: true },
        error: { enumerable: true },
        terminate: { enumerable: true },
        desiredSize: { enumerable: true }
      });
      setFunctionName(TransformStreamDefaultController.prototype.enqueue, "enqueue");
      setFunctionName(TransformStreamDefaultController.prototype.error, "error");
      setFunctionName(TransformStreamDefaultController.prototype.terminate, "terminate");
      if (typeof SymbolPolyfill.toStringTag === "symbol") {
        Object.defineProperty(TransformStreamDefaultController.prototype, SymbolPolyfill.toStringTag, {
          value: "TransformStreamDefaultController",
          configurable: true
        });
      }
      function IsTransformStreamDefaultController(x2) {
        if (!typeIsObject(x2)) {
          return false;
        }
        if (!Object.prototype.hasOwnProperty.call(x2, "_controlledTransformStream")) {
          return false;
        }
        return x2 instanceof TransformStreamDefaultController;
      }
      function SetUpTransformStreamDefaultController(stream, controller, transformAlgorithm, flushAlgorithm, cancelAlgorithm) {
        controller._controlledTransformStream = stream;
        stream._transformStreamController = controller;
        controller._transformAlgorithm = transformAlgorithm;
        controller._flushAlgorithm = flushAlgorithm;
        controller._cancelAlgorithm = cancelAlgorithm;
        controller._finishPromise = void 0;
        controller._finishPromise_resolve = void 0;
        controller._finishPromise_reject = void 0;
      }
      function SetUpTransformStreamDefaultControllerFromTransformer(stream, transformer) {
        const controller = Object.create(TransformStreamDefaultController.prototype);
        let transformAlgorithm;
        let flushAlgorithm;
        let cancelAlgorithm;
        if (transformer.transform !== void 0) {
          transformAlgorithm = (chunk) => transformer.transform(chunk, controller);
        } else {
          transformAlgorithm = (chunk) => {
            try {
              TransformStreamDefaultControllerEnqueue(controller, chunk);
              return promiseResolvedWith(void 0);
            } catch (transformResultE) {
              return promiseRejectedWith(transformResultE);
            }
          };
        }
        if (transformer.flush !== void 0) {
          flushAlgorithm = () => transformer.flush(controller);
        } else {
          flushAlgorithm = () => promiseResolvedWith(void 0);
        }
        if (transformer.cancel !== void 0) {
          cancelAlgorithm = (reason) => transformer.cancel(reason);
        } else {
          cancelAlgorithm = () => promiseResolvedWith(void 0);
        }
        SetUpTransformStreamDefaultController(stream, controller, transformAlgorithm, flushAlgorithm, cancelAlgorithm);
      }
      function TransformStreamDefaultControllerClearAlgorithms(controller) {
        controller._transformAlgorithm = void 0;
        controller._flushAlgorithm = void 0;
        controller._cancelAlgorithm = void 0;
      }
      function TransformStreamDefaultControllerEnqueue(controller, chunk) {
        const stream = controller._controlledTransformStream;
        const readableController = stream._readable._readableStreamController;
        if (!ReadableStreamDefaultControllerCanCloseOrEnqueue(readableController)) {
          throw new TypeError("Readable side is not in a state that permits enqueue");
        }
        try {
          ReadableStreamDefaultControllerEnqueue(readableController, chunk);
        } catch (e2) {
          TransformStreamErrorWritableAndUnblockWrite(stream, e2);
          throw stream._readable._storedError;
        }
        const backpressure = ReadableStreamDefaultControllerHasBackpressure(readableController);
        if (backpressure !== stream._backpressure) {
          TransformStreamSetBackpressure(stream, true);
        }
      }
      function TransformStreamDefaultControllerError(controller, e2) {
        TransformStreamError(controller._controlledTransformStream, e2);
      }
      function TransformStreamDefaultControllerPerformTransform(controller, chunk) {
        const transformPromise = controller._transformAlgorithm(chunk);
        return transformPromiseWith(transformPromise, void 0, (r2) => {
          TransformStreamError(controller._controlledTransformStream, r2);
          throw r2;
        });
      }
      function TransformStreamDefaultControllerTerminate(controller) {
        const stream = controller._controlledTransformStream;
        const readableController = stream._readable._readableStreamController;
        ReadableStreamDefaultControllerClose(readableController);
        const error = new TypeError("TransformStream terminated");
        TransformStreamErrorWritableAndUnblockWrite(stream, error);
      }
      function TransformStreamDefaultSinkWriteAlgorithm(stream, chunk) {
        const controller = stream._transformStreamController;
        if (stream._backpressure) {
          const backpressureChangePromise = stream._backpressureChangePromise;
          return transformPromiseWith(backpressureChangePromise, () => {
            const writable = stream._writable;
            const state = writable._state;
            if (state === "erroring") {
              throw writable._storedError;
            }
            return TransformStreamDefaultControllerPerformTransform(controller, chunk);
          });
        }
        return TransformStreamDefaultControllerPerformTransform(controller, chunk);
      }
      function TransformStreamDefaultSinkAbortAlgorithm(stream, reason) {
        const controller = stream._transformStreamController;
        if (controller._finishPromise !== void 0) {
          return controller._finishPromise;
        }
        const readable = stream._readable;
        controller._finishPromise = newPromise((resolve2, reject) => {
          controller._finishPromise_resolve = resolve2;
          controller._finishPromise_reject = reject;
        });
        const cancelPromise = controller._cancelAlgorithm(reason);
        TransformStreamDefaultControllerClearAlgorithms(controller);
        uponPromise(cancelPromise, () => {
          if (readable._state === "errored") {
            defaultControllerFinishPromiseReject(controller, readable._storedError);
          } else {
            ReadableStreamDefaultControllerError(readable._readableStreamController, reason);
            defaultControllerFinishPromiseResolve(controller);
          }
          return null;
        }, (r2) => {
          ReadableStreamDefaultControllerError(readable._readableStreamController, r2);
          defaultControllerFinishPromiseReject(controller, r2);
          return null;
        });
        return controller._finishPromise;
      }
      function TransformStreamDefaultSinkCloseAlgorithm(stream) {
        const controller = stream._transformStreamController;
        if (controller._finishPromise !== void 0) {
          return controller._finishPromise;
        }
        const readable = stream._readable;
        controller._finishPromise = newPromise((resolve2, reject) => {
          controller._finishPromise_resolve = resolve2;
          controller._finishPromise_reject = reject;
        });
        const flushPromise = controller._flushAlgorithm();
        TransformStreamDefaultControllerClearAlgorithms(controller);
        uponPromise(flushPromise, () => {
          if (readable._state === "errored") {
            defaultControllerFinishPromiseReject(controller, readable._storedError);
          } else {
            ReadableStreamDefaultControllerClose(readable._readableStreamController);
            defaultControllerFinishPromiseResolve(controller);
          }
          return null;
        }, (r2) => {
          ReadableStreamDefaultControllerError(readable._readableStreamController, r2);
          defaultControllerFinishPromiseReject(controller, r2);
          return null;
        });
        return controller._finishPromise;
      }
      function TransformStreamDefaultSourcePullAlgorithm(stream) {
        TransformStreamSetBackpressure(stream, false);
        return stream._backpressureChangePromise;
      }
      function TransformStreamDefaultSourceCancelAlgorithm(stream, reason) {
        const controller = stream._transformStreamController;
        if (controller._finishPromise !== void 0) {
          return controller._finishPromise;
        }
        const writable = stream._writable;
        controller._finishPromise = newPromise((resolve2, reject) => {
          controller._finishPromise_resolve = resolve2;
          controller._finishPromise_reject = reject;
        });
        const cancelPromise = controller._cancelAlgorithm(reason);
        TransformStreamDefaultControllerClearAlgorithms(controller);
        uponPromise(cancelPromise, () => {
          if (writable._state === "errored") {
            defaultControllerFinishPromiseReject(controller, writable._storedError);
          } else {
            WritableStreamDefaultControllerErrorIfNeeded(writable._writableStreamController, reason);
            TransformStreamUnblockWrite(stream);
            defaultControllerFinishPromiseResolve(controller);
          }
          return null;
        }, (r2) => {
          WritableStreamDefaultControllerErrorIfNeeded(writable._writableStreamController, r2);
          TransformStreamUnblockWrite(stream);
          defaultControllerFinishPromiseReject(controller, r2);
          return null;
        });
        return controller._finishPromise;
      }
      function defaultControllerBrandCheckException(name) {
        return new TypeError(`TransformStreamDefaultController.prototype.${name} can only be used on a TransformStreamDefaultController`);
      }
      function defaultControllerFinishPromiseResolve(controller) {
        if (controller._finishPromise_resolve === void 0) {
          return;
        }
        controller._finishPromise_resolve();
        controller._finishPromise_resolve = void 0;
        controller._finishPromise_reject = void 0;
      }
      function defaultControllerFinishPromiseReject(controller, reason) {
        if (controller._finishPromise_reject === void 0) {
          return;
        }
        setPromiseIsHandledToTrue(controller._finishPromise);
        controller._finishPromise_reject(reason);
        controller._finishPromise_resolve = void 0;
        controller._finishPromise_reject = void 0;
      }
      function streamBrandCheckException(name) {
        return new TypeError(`TransformStream.prototype.${name} can only be used on a TransformStream`);
      }
      exports3.ByteLengthQueuingStrategy = ByteLengthQueuingStrategy;
      exports3.CountQueuingStrategy = CountQueuingStrategy;
      exports3.ReadableByteStreamController = ReadableByteStreamController;
      exports3.ReadableStream = ReadableStream2;
      exports3.ReadableStreamBYOBReader = ReadableStreamBYOBReader;
      exports3.ReadableStreamBYOBRequest = ReadableStreamBYOBRequest;
      exports3.ReadableStreamDefaultController = ReadableStreamDefaultController;
      exports3.ReadableStreamDefaultReader = ReadableStreamDefaultReader;
      exports3.TransformStream = TransformStream;
      exports3.TransformStreamDefaultController = TransformStreamDefaultController;
      exports3.WritableStream = WritableStream;
      exports3.WritableStreamDefaultController = WritableStreamDefaultController;
      exports3.WritableStreamDefaultWriter = WritableStreamDefaultWriter;
    });
  }
});

// node_modules/fetch-blob/streams.cjs
var require_streams = __commonJS({
  "node_modules/fetch-blob/streams.cjs"() {
    var POOL_SIZE2 = 65536;
    if (!globalThis.ReadableStream) {
      try {
        const process2 = require("node:process");
        const { emitWarning } = process2;
        try {
          process2.emitWarning = () => {
          };
          Object.assign(globalThis, require("node:stream/web"));
          process2.emitWarning = emitWarning;
        } catch (error) {
          process2.emitWarning = emitWarning;
          throw error;
        }
      } catch (error) {
        Object.assign(globalThis, require_ponyfill_es2018());
      }
    }
    try {
      const { Blob: Blob3 } = require("buffer");
      if (Blob3 && !Blob3.prototype.stream) {
        Blob3.prototype.stream = function name(params) {
          let position = 0;
          const blob = this;
          return new ReadableStream({
            type: "bytes",
            async pull(ctrl) {
              const chunk = blob.slice(position, Math.min(blob.size, position + POOL_SIZE2));
              const buffer = await chunk.arrayBuffer();
              position += buffer.byteLength;
              ctrl.enqueue(new Uint8Array(buffer));
              if (position === blob.size) {
                ctrl.close();
              }
            }
          });
        };
      }
    } catch (error) {
    }
  }
});

// node_modules/fetch-blob/index.js
async function* toIterator(parts, clone2 = true) {
  for (const part of parts) {
    if ("stream" in part) {
      yield* (
        /** @type {AsyncIterableIterator<Uint8Array>} */
        part.stream()
      );
    } else if (ArrayBuffer.isView(part)) {
      if (clone2) {
        let position = part.byteOffset;
        const end = part.byteOffset + part.byteLength;
        while (position !== end) {
          const size = Math.min(end - position, POOL_SIZE);
          const chunk = part.buffer.slice(position, position + size);
          position += chunk.byteLength;
          yield new Uint8Array(chunk);
        }
      } else {
        yield part;
      }
    } else {
      let position = 0, b = (
        /** @type {Blob} */
        part
      );
      while (position !== b.size) {
        const chunk = b.slice(position, Math.min(b.size, position + POOL_SIZE));
        const buffer = await chunk.arrayBuffer();
        position += buffer.byteLength;
        yield new Uint8Array(buffer);
      }
    }
  }
}
var import_streams, POOL_SIZE, _Blob, Blob2, fetch_blob_default;
var init_fetch_blob = __esm({
  "node_modules/fetch-blob/index.js"() {
    import_streams = __toESM(require_streams(), 1);
    POOL_SIZE = 65536;
    _Blob = class Blob {
      /** @type {Array.<(Blob|Uint8Array)>} */
      #parts = [];
      #type = "";
      #size = 0;
      #endings = "transparent";
      /**
       * The Blob() constructor returns a new Blob object. The content
       * of the blob consists of the concatenation of the values given
       * in the parameter array.
       *
       * @param {*} blobParts
       * @param {{ type?: string, endings?: string }} [options]
       */
      constructor(blobParts = [], options = {}) {
        if (typeof blobParts !== "object" || blobParts === null) {
          throw new TypeError("Failed to construct 'Blob': The provided value cannot be converted to a sequence.");
        }
        if (typeof blobParts[Symbol.iterator] !== "function") {
          throw new TypeError("Failed to construct 'Blob': The object must have a callable @@iterator property.");
        }
        if (typeof options !== "object" && typeof options !== "function") {
          throw new TypeError("Failed to construct 'Blob': parameter 2 cannot convert to dictionary.");
        }
        if (options === null)
          options = {};
        const encoder = new TextEncoder();
        for (const element of blobParts) {
          let part;
          if (ArrayBuffer.isView(element)) {
            part = new Uint8Array(element.buffer.slice(element.byteOffset, element.byteOffset + element.byteLength));
          } else if (element instanceof ArrayBuffer) {
            part = new Uint8Array(element.slice(0));
          } else if (element instanceof Blob) {
            part = element;
          } else {
            part = encoder.encode(`${element}`);
          }
          this.#size += ArrayBuffer.isView(part) ? part.byteLength : part.size;
          this.#parts.push(part);
        }
        this.#endings = `${options.endings === void 0 ? "transparent" : options.endings}`;
        const type = options.type === void 0 ? "" : String(options.type);
        this.#type = /^[\x20-\x7E]*$/.test(type) ? type : "";
      }
      /**
       * The Blob interface's size property returns the
       * size of the Blob in bytes.
       */
      get size() {
        return this.#size;
      }
      /**
       * The type property of a Blob object returns the MIME type of the file.
       */
      get type() {
        return this.#type;
      }
      /**
       * The text() method in the Blob interface returns a Promise
       * that resolves with a string containing the contents of
       * the blob, interpreted as UTF-8.
       *
       * @return {Promise<string>}
       */
      async text() {
        const decoder = new TextDecoder();
        let str = "";
        for await (const part of toIterator(this.#parts, false)) {
          str += decoder.decode(part, { stream: true });
        }
        str += decoder.decode();
        return str;
      }
      /**
       * The arrayBuffer() method in the Blob interface returns a
       * Promise that resolves with the contents of the blob as
       * binary data contained in an ArrayBuffer.
       *
       * @return {Promise<ArrayBuffer>}
       */
      async arrayBuffer() {
        const data = new Uint8Array(this.size);
        let offset = 0;
        for await (const chunk of toIterator(this.#parts, false)) {
          data.set(chunk, offset);
          offset += chunk.length;
        }
        return data.buffer;
      }
      stream() {
        const it = toIterator(this.#parts, true);
        return new globalThis.ReadableStream({
          // @ts-ignore
          type: "bytes",
          async pull(ctrl) {
            const chunk = await it.next();
            chunk.done ? ctrl.close() : ctrl.enqueue(chunk.value);
          },
          async cancel() {
            await it.return();
          }
        });
      }
      /**
       * The Blob interface's slice() method creates and returns a
       * new Blob object which contains data from a subset of the
       * blob on which it's called.
       *
       * @param {number} [start]
       * @param {number} [end]
       * @param {string} [type]
       */
      slice(start = 0, end = this.size, type = "") {
        const { size } = this;
        let relativeStart = start < 0 ? Math.max(size + start, 0) : Math.min(start, size);
        let relativeEnd = end < 0 ? Math.max(size + end, 0) : Math.min(end, size);
        const span = Math.max(relativeEnd - relativeStart, 0);
        const parts = this.#parts;
        const blobParts = [];
        let added = 0;
        for (const part of parts) {
          if (added >= span) {
            break;
          }
          const size2 = ArrayBuffer.isView(part) ? part.byteLength : part.size;
          if (relativeStart && size2 <= relativeStart) {
            relativeStart -= size2;
            relativeEnd -= size2;
          } else {
            let chunk;
            if (ArrayBuffer.isView(part)) {
              chunk = part.subarray(relativeStart, Math.min(size2, relativeEnd));
              added += chunk.byteLength;
            } else {
              chunk = part.slice(relativeStart, Math.min(size2, relativeEnd));
              added += chunk.size;
            }
            relativeEnd -= size2;
            blobParts.push(chunk);
            relativeStart = 0;
          }
        }
        const blob = new Blob([], { type: String(type).toLowerCase() });
        blob.#size = span;
        blob.#parts = blobParts;
        return blob;
      }
      get [Symbol.toStringTag]() {
        return "Blob";
      }
      static [Symbol.hasInstance](object) {
        return object && typeof object === "object" && typeof object.constructor === "function" && (typeof object.stream === "function" || typeof object.arrayBuffer === "function") && /^(Blob|File)$/.test(object[Symbol.toStringTag]);
      }
    };
    Object.defineProperties(_Blob.prototype, {
      size: { enumerable: true },
      type: { enumerable: true },
      slice: { enumerable: true }
    });
    Blob2 = _Blob;
    fetch_blob_default = Blob2;
  }
});

// node_modules/fetch-blob/file.js
var _File, File2, file_default;
var init_file = __esm({
  "node_modules/fetch-blob/file.js"() {
    init_fetch_blob();
    _File = class File extends fetch_blob_default {
      #lastModified = 0;
      #name = "";
      /**
       * @param {*[]} fileBits
       * @param {string} fileName
       * @param {{lastModified?: number, type?: string}} options
       */
      // @ts-ignore
      constructor(fileBits, fileName, options = {}) {
        if (arguments.length < 2) {
          throw new TypeError(`Failed to construct 'File': 2 arguments required, but only ${arguments.length} present.`);
        }
        super(fileBits, options);
        if (options === null)
          options = {};
        const lastModified = options.lastModified === void 0 ? Date.now() : Number(options.lastModified);
        if (!Number.isNaN(lastModified)) {
          this.#lastModified = lastModified;
        }
        this.#name = String(fileName);
      }
      get name() {
        return this.#name;
      }
      get lastModified() {
        return this.#lastModified;
      }
      get [Symbol.toStringTag]() {
        return "File";
      }
      static [Symbol.hasInstance](object) {
        return !!object && object instanceof fetch_blob_default && /^(File)$/.test(object[Symbol.toStringTag]);
      }
    };
    File2 = _File;
    file_default = File2;
  }
});

// node_modules/formdata-polyfill/esm.min.js
function formDataToBlob(F2, B = fetch_blob_default) {
  var b = `${r()}${r()}`.replace(/\./g, "").slice(-28).padStart(32, "-"), c = [], p = `--${b}\r
Content-Disposition: form-data; name="`;
  F2.forEach((v, n) => typeof v == "string" ? c.push(p + e(n) + `"\r
\r
${v.replace(/\r(?!\n)|(?<!\r)\n/g, "\r\n")}\r
`) : c.push(p + e(n) + `"; filename="${e(v.name, 1)}"\r
Content-Type: ${v.type || "application/octet-stream"}\r
\r
`, v, "\r\n"));
  c.push(`--${b}--`);
  return new B(c, { type: "multipart/form-data; boundary=" + b });
}
var t, i, h, r, m, f, e, x, FormData;
var init_esm_min = __esm({
  "node_modules/formdata-polyfill/esm.min.js"() {
    init_fetch_blob();
    init_file();
    ({ toStringTag: t, iterator: i, hasInstance: h } = Symbol);
    r = Math.random;
    m = "append,set,get,getAll,delete,keys,values,entries,forEach,constructor".split(",");
    f = (a, b, c) => (a += "", /^(Blob|File)$/.test(b && b[t]) ? [(c = c !== void 0 ? c + "" : b[t] == "File" ? b.name : "blob", a), b.name !== c || b[t] == "blob" ? new file_default([b], c, b) : b] : [a, b + ""]);
    e = (c, f3) => (f3 ? c : c.replace(/\r?\n|\r/g, "\r\n")).replace(/\n/g, "%0A").replace(/\r/g, "%0D").replace(/"/g, "%22");
    x = (n, a, e2) => {
      if (a.length < e2) {
        throw new TypeError(`Failed to execute '${n}' on 'FormData': ${e2} arguments required, but only ${a.length} present.`);
      }
    };
    FormData = class FormData2 {
      #d = [];
      constructor(...a) {
        if (a.length)
          throw new TypeError(`Failed to construct 'FormData': parameter 1 is not of type 'HTMLFormElement'.`);
      }
      get [t]() {
        return "FormData";
      }
      [i]() {
        return this.entries();
      }
      static [h](o) {
        return o && typeof o === "object" && o[t] === "FormData" && !m.some((m2) => typeof o[m2] != "function");
      }
      append(...a) {
        x("append", arguments, 2);
        this.#d.push(f(...a));
      }
      delete(a) {
        x("delete", arguments, 1);
        a += "";
        this.#d = this.#d.filter(([b]) => b !== a);
      }
      get(a) {
        x("get", arguments, 1);
        a += "";
        for (var b = this.#d, l = b.length, c = 0; c < l; c++)
          if (b[c][0] === a)
            return b[c][1];
        return null;
      }
      getAll(a, b) {
        x("getAll", arguments, 1);
        b = [];
        a += "";
        this.#d.forEach((c) => c[0] === a && b.push(c[1]));
        return b;
      }
      has(a) {
        x("has", arguments, 1);
        a += "";
        return this.#d.some((b) => b[0] === a);
      }
      forEach(a, b) {
        x("forEach", arguments, 1);
        for (var [c, d] of this)
          a.call(b, d, c, this);
      }
      set(...a) {
        x("set", arguments, 2);
        var b = [], c = true;
        a = f(...a);
        this.#d.forEach((d) => {
          d[0] === a[0] ? c && (c = !b.push(a)) : b.push(d);
        });
        c && b.push(a);
        this.#d = b;
      }
      *entries() {
        yield* this.#d;
      }
      *keys() {
        for (var [a] of this)
          yield a;
      }
      *values() {
        for (var [, a] of this)
          yield a;
      }
    };
  }
});

// node_modules/node-domexception/index.js
var require_node_domexception = __commonJS({
  "node_modules/node-domexception/index.js"(exports2, module2) {
    if (!globalThis.DOMException) {
      try {
        const { MessageChannel } = require("worker_threads"), port = new MessageChannel().port1, ab = new ArrayBuffer();
        port.postMessage(ab, [ab, ab]);
      } catch (err) {
        err.constructor.name === "DOMException" && (globalThis.DOMException = err.constructor);
      }
    }
    module2.exports = globalThis.DOMException;
  }
});

// node_modules/fetch-blob/from.js
var import_node_fs, import_node_domexception, stat;
var init_from = __esm({
  "node_modules/fetch-blob/from.js"() {
    import_node_fs = require("node:fs");
    import_node_domexception = __toESM(require_node_domexception(), 1);
    init_file();
    init_fetch_blob();
    ({ stat } = import_node_fs.promises);
  }
});

// node_modules/node-fetch/src/utils/multipart-parser.js
var multipart_parser_exports = {};
__export(multipart_parser_exports, {
  toFormData: () => toFormData
});
function _fileName(headerValue) {
  const m2 = headerValue.match(/\bfilename=("(.*?)"|([^()<>@,;:\\"/[\]?={}\s\t]+))($|;\s)/i);
  if (!m2) {
    return;
  }
  const match = m2[2] || m2[3] || "";
  let filename = match.slice(match.lastIndexOf("\\") + 1);
  filename = filename.replace(/%22/g, '"');
  filename = filename.replace(/&#(\d{4});/g, (m3, code) => {
    return String.fromCharCode(code);
  });
  return filename;
}
async function toFormData(Body2, ct) {
  if (!/multipart/i.test(ct)) {
    throw new TypeError("Failed to fetch");
  }
  const m2 = ct.match(/boundary=(?:"([^"]+)"|([^;]+))/i);
  if (!m2) {
    throw new TypeError("no or bad content-type header, no multipart boundary");
  }
  const parser = new MultipartParser(m2[1] || m2[2]);
  let headerField;
  let headerValue;
  let entryValue;
  let entryName;
  let contentType;
  let filename;
  const entryChunks = [];
  const formData = new FormData();
  const onPartData = (ui8a) => {
    entryValue += decoder.decode(ui8a, { stream: true });
  };
  const appendToFile = (ui8a) => {
    entryChunks.push(ui8a);
  };
  const appendFileToFormData = () => {
    const file = new file_default(entryChunks, filename, { type: contentType });
    formData.append(entryName, file);
  };
  const appendEntryToFormData = () => {
    formData.append(entryName, entryValue);
  };
  const decoder = new TextDecoder("utf-8");
  decoder.decode();
  parser.onPartBegin = function() {
    parser.onPartData = onPartData;
    parser.onPartEnd = appendEntryToFormData;
    headerField = "";
    headerValue = "";
    entryValue = "";
    entryName = "";
    contentType = "";
    filename = null;
    entryChunks.length = 0;
  };
  parser.onHeaderField = function(ui8a) {
    headerField += decoder.decode(ui8a, { stream: true });
  };
  parser.onHeaderValue = function(ui8a) {
    headerValue += decoder.decode(ui8a, { stream: true });
  };
  parser.onHeaderEnd = function() {
    headerValue += decoder.decode();
    headerField = headerField.toLowerCase();
    if (headerField === "content-disposition") {
      const m3 = headerValue.match(/\bname=("([^"]*)"|([^()<>@,;:\\"/[\]?={}\s\t]+))/i);
      if (m3) {
        entryName = m3[2] || m3[3] || "";
      }
      filename = _fileName(headerValue);
      if (filename) {
        parser.onPartData = appendToFile;
        parser.onPartEnd = appendFileToFormData;
      }
    } else if (headerField === "content-type") {
      contentType = headerValue;
    }
    headerValue = "";
    headerField = "";
  };
  for await (const chunk of Body2) {
    parser.write(chunk);
  }
  parser.end();
  return formData;
}
var s, S, f2, F, LF, CR, SPACE, HYPHEN, COLON, A, Z, lower, noop, MultipartParser;
var init_multipart_parser = __esm({
  "node_modules/node-fetch/src/utils/multipart-parser.js"() {
    init_from();
    init_esm_min();
    s = 0;
    S = {
      START_BOUNDARY: s++,
      HEADER_FIELD_START: s++,
      HEADER_FIELD: s++,
      HEADER_VALUE_START: s++,
      HEADER_VALUE: s++,
      HEADER_VALUE_ALMOST_DONE: s++,
      HEADERS_ALMOST_DONE: s++,
      PART_DATA_START: s++,
      PART_DATA: s++,
      END: s++
    };
    f2 = 1;
    F = {
      PART_BOUNDARY: f2,
      LAST_BOUNDARY: f2 *= 2
    };
    LF = 10;
    CR = 13;
    SPACE = 32;
    HYPHEN = 45;
    COLON = 58;
    A = 97;
    Z = 122;
    lower = (c) => c | 32;
    noop = () => {
    };
    MultipartParser = class {
      /**
       * @param {string} boundary
       */
      constructor(boundary) {
        this.index = 0;
        this.flags = 0;
        this.onHeaderEnd = noop;
        this.onHeaderField = noop;
        this.onHeadersEnd = noop;
        this.onHeaderValue = noop;
        this.onPartBegin = noop;
        this.onPartData = noop;
        this.onPartEnd = noop;
        this.boundaryChars = {};
        boundary = "\r\n--" + boundary;
        const ui8a = new Uint8Array(boundary.length);
        for (let i2 = 0; i2 < boundary.length; i2++) {
          ui8a[i2] = boundary.charCodeAt(i2);
          this.boundaryChars[ui8a[i2]] = true;
        }
        this.boundary = ui8a;
        this.lookbehind = new Uint8Array(this.boundary.length + 8);
        this.state = S.START_BOUNDARY;
      }
      /**
       * @param {Uint8Array} data
       */
      write(data) {
        let i2 = 0;
        const length_ = data.length;
        let previousIndex = this.index;
        let { lookbehind, boundary, boundaryChars, index, state, flags } = this;
        const boundaryLength = this.boundary.length;
        const boundaryEnd = boundaryLength - 1;
        const bufferLength = data.length;
        let c;
        let cl;
        const mark = (name) => {
          this[name + "Mark"] = i2;
        };
        const clear = (name) => {
          delete this[name + "Mark"];
        };
        const callback = (callbackSymbol, start, end, ui8a) => {
          if (start === void 0 || start !== end) {
            this[callbackSymbol](ui8a && ui8a.subarray(start, end));
          }
        };
        const dataCallback = (name, clear2) => {
          const markSymbol = name + "Mark";
          if (!(markSymbol in this)) {
            return;
          }
          if (clear2) {
            callback(name, this[markSymbol], i2, data);
            delete this[markSymbol];
          } else {
            callback(name, this[markSymbol], data.length, data);
            this[markSymbol] = 0;
          }
        };
        for (i2 = 0; i2 < length_; i2++) {
          c = data[i2];
          switch (state) {
            case S.START_BOUNDARY:
              if (index === boundary.length - 2) {
                if (c === HYPHEN) {
                  flags |= F.LAST_BOUNDARY;
                } else if (c !== CR) {
                  return;
                }
                index++;
                break;
              } else if (index - 1 === boundary.length - 2) {
                if (flags & F.LAST_BOUNDARY && c === HYPHEN) {
                  state = S.END;
                  flags = 0;
                } else if (!(flags & F.LAST_BOUNDARY) && c === LF) {
                  index = 0;
                  callback("onPartBegin");
                  state = S.HEADER_FIELD_START;
                } else {
                  return;
                }
                break;
              }
              if (c !== boundary[index + 2]) {
                index = -2;
              }
              if (c === boundary[index + 2]) {
                index++;
              }
              break;
            case S.HEADER_FIELD_START:
              state = S.HEADER_FIELD;
              mark("onHeaderField");
              index = 0;
            case S.HEADER_FIELD:
              if (c === CR) {
                clear("onHeaderField");
                state = S.HEADERS_ALMOST_DONE;
                break;
              }
              index++;
              if (c === HYPHEN) {
                break;
              }
              if (c === COLON) {
                if (index === 1) {
                  return;
                }
                dataCallback("onHeaderField", true);
                state = S.HEADER_VALUE_START;
                break;
              }
              cl = lower(c);
              if (cl < A || cl > Z) {
                return;
              }
              break;
            case S.HEADER_VALUE_START:
              if (c === SPACE) {
                break;
              }
              mark("onHeaderValue");
              state = S.HEADER_VALUE;
            case S.HEADER_VALUE:
              if (c === CR) {
                dataCallback("onHeaderValue", true);
                callback("onHeaderEnd");
                state = S.HEADER_VALUE_ALMOST_DONE;
              }
              break;
            case S.HEADER_VALUE_ALMOST_DONE:
              if (c !== LF) {
                return;
              }
              state = S.HEADER_FIELD_START;
              break;
            case S.HEADERS_ALMOST_DONE:
              if (c !== LF) {
                return;
              }
              callback("onHeadersEnd");
              state = S.PART_DATA_START;
              break;
            case S.PART_DATA_START:
              state = S.PART_DATA;
              mark("onPartData");
            case S.PART_DATA:
              previousIndex = index;
              if (index === 0) {
                i2 += boundaryEnd;
                while (i2 < bufferLength && !(data[i2] in boundaryChars)) {
                  i2 += boundaryLength;
                }
                i2 -= boundaryEnd;
                c = data[i2];
              }
              if (index < boundary.length) {
                if (boundary[index] === c) {
                  if (index === 0) {
                    dataCallback("onPartData", true);
                  }
                  index++;
                } else {
                  index = 0;
                }
              } else if (index === boundary.length) {
                index++;
                if (c === CR) {
                  flags |= F.PART_BOUNDARY;
                } else if (c === HYPHEN) {
                  flags |= F.LAST_BOUNDARY;
                } else {
                  index = 0;
                }
              } else if (index - 1 === boundary.length) {
                if (flags & F.PART_BOUNDARY) {
                  index = 0;
                  if (c === LF) {
                    flags &= ~F.PART_BOUNDARY;
                    callback("onPartEnd");
                    callback("onPartBegin");
                    state = S.HEADER_FIELD_START;
                    break;
                  }
                } else if (flags & F.LAST_BOUNDARY) {
                  if (c === HYPHEN) {
                    callback("onPartEnd");
                    state = S.END;
                    flags = 0;
                  } else {
                    index = 0;
                  }
                } else {
                  index = 0;
                }
              }
              if (index > 0) {
                lookbehind[index - 1] = c;
              } else if (previousIndex > 0) {
                const _lookbehind = new Uint8Array(lookbehind.buffer, lookbehind.byteOffset, lookbehind.byteLength);
                callback("onPartData", 0, previousIndex, _lookbehind);
                previousIndex = 0;
                mark("onPartData");
                i2--;
              }
              break;
            case S.END:
              break;
            default:
              throw new Error(`Unexpected state entered: ${state}`);
          }
        }
        dataCallback("onHeaderField");
        dataCallback("onHeaderValue");
        dataCallback("onPartData");
        this.index = index;
        this.state = state;
        this.flags = flags;
      }
      end() {
        if (this.state === S.HEADER_FIELD_START && this.index === 0 || this.state === S.PART_DATA && this.index === this.boundary.length) {
          this.onPartEnd();
        } else if (this.state !== S.END) {
          throw new Error("MultipartParser.end(): stream ended unexpectedly");
        }
      }
    };
  }
});

// node_modules/node-fetch/src/index.js
var import_node_http2 = __toESM(require("node:http"), 1);
var import_node_https = __toESM(require("node:https"), 1);
var import_node_zlib = __toESM(require("node:zlib"), 1);
var import_node_stream2 = __toESM(require("node:stream"), 1);
var import_node_buffer2 = require("node:buffer");

// node_modules/data-uri-to-buffer/dist/index.js
function dataUriToBuffer(uri) {
  if (!/^data:/i.test(uri)) {
    throw new TypeError('`uri` does not appear to be a Data URI (must begin with "data:")');
  }
  uri = uri.replace(/\r?\n/g, "");
  const firstComma = uri.indexOf(",");
  if (firstComma === -1 || firstComma <= 4) {
    throw new TypeError("malformed data: URI");
  }
  const meta = uri.substring(5, firstComma).split(";");
  let charset = "";
  let base64 = false;
  const type = meta[0] || "text/plain";
  let typeFull = type;
  for (let i2 = 1; i2 < meta.length; i2++) {
    if (meta[i2] === "base64") {
      base64 = true;
    } else if (meta[i2]) {
      typeFull += `;${meta[i2]}`;
      if (meta[i2].indexOf("charset=") === 0) {
        charset = meta[i2].substring(8);
      }
    }
  }
  if (!meta[0] && !charset.length) {
    typeFull += ";charset=US-ASCII";
    charset = "US-ASCII";
  }
  const encoding = base64 ? "base64" : "ascii";
  const data = unescape(uri.substring(firstComma + 1));
  const buffer = Buffer.from(data, encoding);
  buffer.type = type;
  buffer.typeFull = typeFull;
  buffer.charset = charset;
  return buffer;
}
var dist_default = dataUriToBuffer;

// node_modules/node-fetch/src/body.js
var import_node_stream = __toESM(require("node:stream"), 1);
var import_node_util = require("node:util");
var import_node_buffer = require("node:buffer");
init_fetch_blob();
init_esm_min();

// node_modules/node-fetch/src/errors/base.js
var FetchBaseError = class extends Error {
  constructor(message, type) {
    super(message);
    Error.captureStackTrace(this, this.constructor);
    this.type = type;
  }
  get name() {
    return this.constructor.name;
  }
  get [Symbol.toStringTag]() {
    return this.constructor.name;
  }
};

// node_modules/node-fetch/src/errors/fetch-error.js
var FetchError = class extends FetchBaseError {
  /**
   * @param  {string} message -      Error message for human
   * @param  {string} [type] -        Error type for machine
   * @param  {SystemError} [systemError] - For Node.js system error
   */
  constructor(message, type, systemError) {
    super(message, type);
    if (systemError) {
      this.code = this.errno = systemError.code;
      this.erroredSysCall = systemError.syscall;
    }
  }
};

// node_modules/node-fetch/src/utils/is.js
var NAME = Symbol.toStringTag;
var isURLSearchParameters = (object) => {
  return typeof object === "object" && typeof object.append === "function" && typeof object.delete === "function" && typeof object.get === "function" && typeof object.getAll === "function" && typeof object.has === "function" && typeof object.set === "function" && typeof object.sort === "function" && object[NAME] === "URLSearchParams";
};
var isBlob = (object) => {
  return object && typeof object === "object" && typeof object.arrayBuffer === "function" && typeof object.type === "string" && typeof object.stream === "function" && typeof object.constructor === "function" && /^(Blob|File)$/.test(object[NAME]);
};
var isAbortSignal = (object) => {
  return typeof object === "object" && (object[NAME] === "AbortSignal" || object[NAME] === "EventTarget");
};
var isDomainOrSubdomain = (destination, original) => {
  const orig = new URL(original).hostname;
  const dest = new URL(destination).hostname;
  return orig === dest || orig.endsWith(`.${dest}`);
};
var isSameProtocol = (destination, original) => {
  const orig = new URL(original).protocol;
  const dest = new URL(destination).protocol;
  return orig === dest;
};

// node_modules/node-fetch/src/body.js
var pipeline = (0, import_node_util.promisify)(import_node_stream.default.pipeline);
var INTERNALS = Symbol("Body internals");
var Body = class {
  constructor(body, {
    size = 0
  } = {}) {
    let boundary = null;
    if (body === null) {
      body = null;
    } else if (isURLSearchParameters(body)) {
      body = import_node_buffer.Buffer.from(body.toString());
    } else if (isBlob(body)) {
    } else if (import_node_buffer.Buffer.isBuffer(body)) {
    } else if (import_node_util.types.isAnyArrayBuffer(body)) {
      body = import_node_buffer.Buffer.from(body);
    } else if (ArrayBuffer.isView(body)) {
      body = import_node_buffer.Buffer.from(body.buffer, body.byteOffset, body.byteLength);
    } else if (body instanceof import_node_stream.default) {
    } else if (body instanceof FormData) {
      body = formDataToBlob(body);
      boundary = body.type.split("=")[1];
    } else {
      body = import_node_buffer.Buffer.from(String(body));
    }
    let stream = body;
    if (import_node_buffer.Buffer.isBuffer(body)) {
      stream = import_node_stream.default.Readable.from(body);
    } else if (isBlob(body)) {
      stream = import_node_stream.default.Readable.from(body.stream());
    }
    this[INTERNALS] = {
      body,
      stream,
      boundary,
      disturbed: false,
      error: null
    };
    this.size = size;
    if (body instanceof import_node_stream.default) {
      body.on("error", (error_) => {
        const error = error_ instanceof FetchBaseError ? error_ : new FetchError(`Invalid response body while trying to fetch ${this.url}: ${error_.message}`, "system", error_);
        this[INTERNALS].error = error;
      });
    }
  }
  get body() {
    return this[INTERNALS].stream;
  }
  get bodyUsed() {
    return this[INTERNALS].disturbed;
  }
  /**
   * Decode response as ArrayBuffer
   *
   * @return  Promise
   */
  async arrayBuffer() {
    const { buffer, byteOffset, byteLength } = await consumeBody(this);
    return buffer.slice(byteOffset, byteOffset + byteLength);
  }
  async formData() {
    const ct = this.headers.get("content-type");
    if (ct.startsWith("application/x-www-form-urlencoded")) {
      const formData = new FormData();
      const parameters = new URLSearchParams(await this.text());
      for (const [name, value] of parameters) {
        formData.append(name, value);
      }
      return formData;
    }
    const { toFormData: toFormData2 } = await Promise.resolve().then(() => (init_multipart_parser(), multipart_parser_exports));
    return toFormData2(this.body, ct);
  }
  /**
   * Return raw response as Blob
   *
   * @return Promise
   */
  async blob() {
    const ct = this.headers && this.headers.get("content-type") || this[INTERNALS].body && this[INTERNALS].body.type || "";
    const buf = await this.arrayBuffer();
    return new fetch_blob_default([buf], {
      type: ct
    });
  }
  /**
   * Decode response as json
   *
   * @return  Promise
   */
  async json() {
    const text = await this.text();
    return JSON.parse(text);
  }
  /**
   * Decode response as text
   *
   * @return  Promise
   */
  async text() {
    const buffer = await consumeBody(this);
    return new TextDecoder().decode(buffer);
  }
  /**
   * Decode response as buffer (non-spec api)
   *
   * @return  Promise
   */
  buffer() {
    return consumeBody(this);
  }
};
Body.prototype.buffer = (0, import_node_util.deprecate)(Body.prototype.buffer, "Please use 'response.arrayBuffer()' instead of 'response.buffer()'", "node-fetch#buffer");
Object.defineProperties(Body.prototype, {
  body: { enumerable: true },
  bodyUsed: { enumerable: true },
  arrayBuffer: { enumerable: true },
  blob: { enumerable: true },
  json: { enumerable: true },
  text: { enumerable: true },
  data: { get: (0, import_node_util.deprecate)(
    () => {
    },
    "data doesn't exist, use json(), text(), arrayBuffer(), or body instead",
    "https://github.com/node-fetch/node-fetch/issues/1000 (response)"
  ) }
});
async function consumeBody(data) {
  if (data[INTERNALS].disturbed) {
    throw new TypeError(`body used already for: ${data.url}`);
  }
  data[INTERNALS].disturbed = true;
  if (data[INTERNALS].error) {
    throw data[INTERNALS].error;
  }
  const { body } = data;
  if (body === null) {
    return import_node_buffer.Buffer.alloc(0);
  }
  if (!(body instanceof import_node_stream.default)) {
    return import_node_buffer.Buffer.alloc(0);
  }
  const accum = [];
  let accumBytes = 0;
  try {
    for await (const chunk of body) {
      if (data.size > 0 && accumBytes + chunk.length > data.size) {
        const error = new FetchError(`content size at ${data.url} over limit: ${data.size}`, "max-size");
        body.destroy(error);
        throw error;
      }
      accumBytes += chunk.length;
      accum.push(chunk);
    }
  } catch (error) {
    const error_ = error instanceof FetchBaseError ? error : new FetchError(`Invalid response body while trying to fetch ${data.url}: ${error.message}`, "system", error);
    throw error_;
  }
  if (body.readableEnded === true || body._readableState.ended === true) {
    try {
      if (accum.every((c) => typeof c === "string")) {
        return import_node_buffer.Buffer.from(accum.join(""));
      }
      return import_node_buffer.Buffer.concat(accum, accumBytes);
    } catch (error) {
      throw new FetchError(`Could not create Buffer from response body for ${data.url}: ${error.message}`, "system", error);
    }
  } else {
    throw new FetchError(`Premature close of server response while trying to fetch ${data.url}`);
  }
}
var clone = (instance, highWaterMark) => {
  let p1;
  let p2;
  let { body } = instance[INTERNALS];
  if (instance.bodyUsed) {
    throw new Error("cannot clone body after it is used");
  }
  if (body instanceof import_node_stream.default && typeof body.getBoundary !== "function") {
    p1 = new import_node_stream.PassThrough({ highWaterMark });
    p2 = new import_node_stream.PassThrough({ highWaterMark });
    body.pipe(p1);
    body.pipe(p2);
    instance[INTERNALS].stream = p1;
    body = p2;
  }
  return body;
};
var getNonSpecFormDataBoundary = (0, import_node_util.deprecate)(
  (body) => body.getBoundary(),
  "form-data doesn't follow the spec and requires special treatment. Use alternative package",
  "https://github.com/node-fetch/node-fetch/issues/1167"
);
var extractContentType = (body, request) => {
  if (body === null) {
    return null;
  }
  if (typeof body === "string") {
    return "text/plain;charset=UTF-8";
  }
  if (isURLSearchParameters(body)) {
    return "application/x-www-form-urlencoded;charset=UTF-8";
  }
  if (isBlob(body)) {
    return body.type || null;
  }
  if (import_node_buffer.Buffer.isBuffer(body) || import_node_util.types.isAnyArrayBuffer(body) || ArrayBuffer.isView(body)) {
    return null;
  }
  if (body instanceof FormData) {
    return `multipart/form-data; boundary=${request[INTERNALS].boundary}`;
  }
  if (body && typeof body.getBoundary === "function") {
    return `multipart/form-data;boundary=${getNonSpecFormDataBoundary(body)}`;
  }
  if (body instanceof import_node_stream.default) {
    return null;
  }
  return "text/plain;charset=UTF-8";
};
var getTotalBytes = (request) => {
  const { body } = request[INTERNALS];
  if (body === null) {
    return 0;
  }
  if (isBlob(body)) {
    return body.size;
  }
  if (import_node_buffer.Buffer.isBuffer(body)) {
    return body.length;
  }
  if (body && typeof body.getLengthSync === "function") {
    return body.hasKnownLength && body.hasKnownLength() ? body.getLengthSync() : null;
  }
  return null;
};
var writeToStream = async (dest, { body }) => {
  if (body === null) {
    dest.end();
  } else {
    await pipeline(body, dest);
  }
};

// node_modules/node-fetch/src/headers.js
var import_node_util2 = require("node:util");
var import_node_http = __toESM(require("node:http"), 1);
var validateHeaderName = typeof import_node_http.default.validateHeaderName === "function" ? import_node_http.default.validateHeaderName : (name) => {
  if (!/^[\^`\-\w!#$%&'*+.|~]+$/.test(name)) {
    const error = new TypeError(`Header name must be a valid HTTP token [${name}]`);
    Object.defineProperty(error, "code", { value: "ERR_INVALID_HTTP_TOKEN" });
    throw error;
  }
};
var validateHeaderValue = typeof import_node_http.default.validateHeaderValue === "function" ? import_node_http.default.validateHeaderValue : (name, value) => {
  if (/[^\t\u0020-\u007E\u0080-\u00FF]/.test(value)) {
    const error = new TypeError(`Invalid character in header content ["${name}"]`);
    Object.defineProperty(error, "code", { value: "ERR_INVALID_CHAR" });
    throw error;
  }
};
var Headers = class _Headers extends URLSearchParams {
  /**
   * Headers class
   *
   * @constructor
   * @param {HeadersInit} [init] - Response headers
   */
  constructor(init) {
    let result = [];
    if (init instanceof _Headers) {
      const raw = init.raw();
      for (const [name, values] of Object.entries(raw)) {
        result.push(...values.map((value) => [name, value]));
      }
    } else if (init == null) {
    } else if (typeof init === "object" && !import_node_util2.types.isBoxedPrimitive(init)) {
      const method = init[Symbol.iterator];
      if (method == null) {
        result.push(...Object.entries(init));
      } else {
        if (typeof method !== "function") {
          throw new TypeError("Header pairs must be iterable");
        }
        result = [...init].map((pair) => {
          if (typeof pair !== "object" || import_node_util2.types.isBoxedPrimitive(pair)) {
            throw new TypeError("Each header pair must be an iterable object");
          }
          return [...pair];
        }).map((pair) => {
          if (pair.length !== 2) {
            throw new TypeError("Each header pair must be a name/value tuple");
          }
          return [...pair];
        });
      }
    } else {
      throw new TypeError("Failed to construct 'Headers': The provided value is not of type '(sequence<sequence<ByteString>> or record<ByteString, ByteString>)");
    }
    result = result.length > 0 ? result.map(([name, value]) => {
      validateHeaderName(name);
      validateHeaderValue(name, String(value));
      return [String(name).toLowerCase(), String(value)];
    }) : void 0;
    super(result);
    return new Proxy(this, {
      get(target, p, receiver) {
        switch (p) {
          case "append":
          case "set":
            return (name, value) => {
              validateHeaderName(name);
              validateHeaderValue(name, String(value));
              return URLSearchParams.prototype[p].call(
                target,
                String(name).toLowerCase(),
                String(value)
              );
            };
          case "delete":
          case "has":
          case "getAll":
            return (name) => {
              validateHeaderName(name);
              return URLSearchParams.prototype[p].call(
                target,
                String(name).toLowerCase()
              );
            };
          case "keys":
            return () => {
              target.sort();
              return new Set(URLSearchParams.prototype.keys.call(target)).keys();
            };
          default:
            return Reflect.get(target, p, receiver);
        }
      }
    });
  }
  get [Symbol.toStringTag]() {
    return this.constructor.name;
  }
  toString() {
    return Object.prototype.toString.call(this);
  }
  get(name) {
    const values = this.getAll(name);
    if (values.length === 0) {
      return null;
    }
    let value = values.join(", ");
    if (/^content-encoding$/i.test(name)) {
      value = value.toLowerCase();
    }
    return value;
  }
  forEach(callback, thisArg = void 0) {
    for (const name of this.keys()) {
      Reflect.apply(callback, thisArg, [this.get(name), name, this]);
    }
  }
  *values() {
    for (const name of this.keys()) {
      yield this.get(name);
    }
  }
  /**
   * @type {() => IterableIterator<[string, string]>}
   */
  *entries() {
    for (const name of this.keys()) {
      yield [name, this.get(name)];
    }
  }
  [Symbol.iterator]() {
    return this.entries();
  }
  /**
   * Node-fetch non-spec method
   * returning all headers and their values as array
   * @returns {Record<string, string[]>}
   */
  raw() {
    return [...this.keys()].reduce((result, key) => {
      result[key] = this.getAll(key);
      return result;
    }, {});
  }
  /**
   * For better console.log(headers) and also to convert Headers into Node.js Request compatible format
   */
  [Symbol.for("nodejs.util.inspect.custom")]() {
    return [...this.keys()].reduce((result, key) => {
      const values = this.getAll(key);
      if (key === "host") {
        result[key] = values[0];
      } else {
        result[key] = values.length > 1 ? values : values[0];
      }
      return result;
    }, {});
  }
};
Object.defineProperties(
  Headers.prototype,
  ["get", "entries", "forEach", "values"].reduce((result, property) => {
    result[property] = { enumerable: true };
    return result;
  }, {})
);
function fromRawHeaders(headers = []) {
  return new Headers(
    headers.reduce((result, value, index, array) => {
      if (index % 2 === 0) {
        result.push(array.slice(index, index + 2));
      }
      return result;
    }, []).filter(([name, value]) => {
      try {
        validateHeaderName(name);
        validateHeaderValue(name, String(value));
        return true;
      } catch {
        return false;
      }
    })
  );
}

// node_modules/node-fetch/src/utils/is-redirect.js
var redirectStatus = /* @__PURE__ */ new Set([301, 302, 303, 307, 308]);
var isRedirect = (code) => {
  return redirectStatus.has(code);
};

// node_modules/node-fetch/src/response.js
var INTERNALS2 = Symbol("Response internals");
var Response = class _Response extends Body {
  constructor(body = null, options = {}) {
    super(body, options);
    const status = options.status != null ? options.status : 200;
    const headers = new Headers(options.headers);
    if (body !== null && !headers.has("Content-Type")) {
      const contentType = extractContentType(body, this);
      if (contentType) {
        headers.append("Content-Type", contentType);
      }
    }
    this[INTERNALS2] = {
      type: "default",
      url: options.url,
      status,
      statusText: options.statusText || "",
      headers,
      counter: options.counter,
      highWaterMark: options.highWaterMark
    };
  }
  get type() {
    return this[INTERNALS2].type;
  }
  get url() {
    return this[INTERNALS2].url || "";
  }
  get status() {
    return this[INTERNALS2].status;
  }
  /**
   * Convenience property representing if the request ended normally
   */
  get ok() {
    return this[INTERNALS2].status >= 200 && this[INTERNALS2].status < 300;
  }
  get redirected() {
    return this[INTERNALS2].counter > 0;
  }
  get statusText() {
    return this[INTERNALS2].statusText;
  }
  get headers() {
    return this[INTERNALS2].headers;
  }
  get highWaterMark() {
    return this[INTERNALS2].highWaterMark;
  }
  /**
   * Clone this response
   *
   * @return  Response
   */
  clone() {
    return new _Response(clone(this, this.highWaterMark), {
      type: this.type,
      url: this.url,
      status: this.status,
      statusText: this.statusText,
      headers: this.headers,
      ok: this.ok,
      redirected: this.redirected,
      size: this.size,
      highWaterMark: this.highWaterMark
    });
  }
  /**
   * @param {string} url    The URL that the new response is to originate from.
   * @param {number} status An optional status code for the response (e.g., 302.)
   * @returns {Response}    A Response object.
   */
  static redirect(url, status = 302) {
    if (!isRedirect(status)) {
      throw new RangeError('Failed to execute "redirect" on "response": Invalid status code');
    }
    return new _Response(null, {
      headers: {
        location: new URL(url).toString()
      },
      status
    });
  }
  static error() {
    const response = new _Response(null, { status: 0, statusText: "" });
    response[INTERNALS2].type = "error";
    return response;
  }
  static json(data = void 0, init = {}) {
    const body = JSON.stringify(data);
    if (body === void 0) {
      throw new TypeError("data is not JSON serializable");
    }
    const headers = new Headers(init && init.headers);
    if (!headers.has("content-type")) {
      headers.set("content-type", "application/json");
    }
    return new _Response(body, {
      ...init,
      headers
    });
  }
  get [Symbol.toStringTag]() {
    return "Response";
  }
};
Object.defineProperties(Response.prototype, {
  type: { enumerable: true },
  url: { enumerable: true },
  status: { enumerable: true },
  ok: { enumerable: true },
  redirected: { enumerable: true },
  statusText: { enumerable: true },
  headers: { enumerable: true },
  clone: { enumerable: true }
});

// node_modules/node-fetch/src/request.js
var import_node_url = require("node:url");
var import_node_util3 = require("node:util");

// node_modules/node-fetch/src/utils/get-search.js
var getSearch = (parsedURL) => {
  if (parsedURL.search) {
    return parsedURL.search;
  }
  const lastOffset = parsedURL.href.length - 1;
  const hash = parsedURL.hash || (parsedURL.href[lastOffset] === "#" ? "#" : "");
  return parsedURL.href[lastOffset - hash.length] === "?" ? "?" : "";
};

// node_modules/node-fetch/src/utils/referrer.js
var import_node_net = require("node:net");
function stripURLForUseAsAReferrer(url, originOnly = false) {
  if (url == null) {
    return "no-referrer";
  }
  url = new URL(url);
  if (/^(about|blob|data):$/.test(url.protocol)) {
    return "no-referrer";
  }
  url.username = "";
  url.password = "";
  url.hash = "";
  if (originOnly) {
    url.pathname = "";
    url.search = "";
  }
  return url;
}
var ReferrerPolicy = /* @__PURE__ */ new Set([
  "",
  "no-referrer",
  "no-referrer-when-downgrade",
  "same-origin",
  "origin",
  "strict-origin",
  "origin-when-cross-origin",
  "strict-origin-when-cross-origin",
  "unsafe-url"
]);
var DEFAULT_REFERRER_POLICY = "strict-origin-when-cross-origin";
function validateReferrerPolicy(referrerPolicy) {
  if (!ReferrerPolicy.has(referrerPolicy)) {
    throw new TypeError(`Invalid referrerPolicy: ${referrerPolicy}`);
  }
  return referrerPolicy;
}
function isOriginPotentiallyTrustworthy(url) {
  if (/^(http|ws)s:$/.test(url.protocol)) {
    return true;
  }
  const hostIp = url.host.replace(/(^\[)|(]$)/g, "");
  const hostIPVersion = (0, import_node_net.isIP)(hostIp);
  if (hostIPVersion === 4 && /^127\./.test(hostIp)) {
    return true;
  }
  if (hostIPVersion === 6 && /^(((0+:){7})|(::(0+:){0,6}))0*1$/.test(hostIp)) {
    return true;
  }
  if (url.host === "localhost" || url.host.endsWith(".localhost")) {
    return false;
  }
  if (url.protocol === "file:") {
    return true;
  }
  return false;
}
function isUrlPotentiallyTrustworthy(url) {
  if (/^about:(blank|srcdoc)$/.test(url)) {
    return true;
  }
  if (url.protocol === "data:") {
    return true;
  }
  if (/^(blob|filesystem):$/.test(url.protocol)) {
    return true;
  }
  return isOriginPotentiallyTrustworthy(url);
}
function determineRequestsReferrer(request, { referrerURLCallback, referrerOriginCallback } = {}) {
  if (request.referrer === "no-referrer" || request.referrerPolicy === "") {
    return null;
  }
  const policy = request.referrerPolicy;
  if (request.referrer === "about:client") {
    return "no-referrer";
  }
  const referrerSource = request.referrer;
  let referrerURL = stripURLForUseAsAReferrer(referrerSource);
  let referrerOrigin = stripURLForUseAsAReferrer(referrerSource, true);
  if (referrerURL.toString().length > 4096) {
    referrerURL = referrerOrigin;
  }
  if (referrerURLCallback) {
    referrerURL = referrerURLCallback(referrerURL);
  }
  if (referrerOriginCallback) {
    referrerOrigin = referrerOriginCallback(referrerOrigin);
  }
  const currentURL = new URL(request.url);
  switch (policy) {
    case "no-referrer":
      return "no-referrer";
    case "origin":
      return referrerOrigin;
    case "unsafe-url":
      return referrerURL;
    case "strict-origin":
      if (isUrlPotentiallyTrustworthy(referrerURL) && !isUrlPotentiallyTrustworthy(currentURL)) {
        return "no-referrer";
      }
      return referrerOrigin.toString();
    case "strict-origin-when-cross-origin":
      if (referrerURL.origin === currentURL.origin) {
        return referrerURL;
      }
      if (isUrlPotentiallyTrustworthy(referrerURL) && !isUrlPotentiallyTrustworthy(currentURL)) {
        return "no-referrer";
      }
      return referrerOrigin;
    case "same-origin":
      if (referrerURL.origin === currentURL.origin) {
        return referrerURL;
      }
      return "no-referrer";
    case "origin-when-cross-origin":
      if (referrerURL.origin === currentURL.origin) {
        return referrerURL;
      }
      return referrerOrigin;
    case "no-referrer-when-downgrade":
      if (isUrlPotentiallyTrustworthy(referrerURL) && !isUrlPotentiallyTrustworthy(currentURL)) {
        return "no-referrer";
      }
      return referrerURL;
    default:
      throw new TypeError(`Invalid referrerPolicy: ${policy}`);
  }
}
function parseReferrerPolicyFromHeader(headers) {
  const policyTokens = (headers.get("referrer-policy") || "").split(/[,\s]+/);
  let policy = "";
  for (const token of policyTokens) {
    if (token && ReferrerPolicy.has(token)) {
      policy = token;
    }
  }
  return policy;
}

// node_modules/node-fetch/src/request.js
var INTERNALS3 = Symbol("Request internals");
var isRequest = (object) => {
  return typeof object === "object" && typeof object[INTERNALS3] === "object";
};
var doBadDataWarn = (0, import_node_util3.deprecate)(
  () => {
  },
  ".data is not a valid RequestInit property, use .body instead",
  "https://github.com/node-fetch/node-fetch/issues/1000 (request)"
);
var Request = class _Request extends Body {
  constructor(input, init = {}) {
    let parsedURL;
    if (isRequest(input)) {
      parsedURL = new URL(input.url);
    } else {
      parsedURL = new URL(input);
      input = {};
    }
    if (parsedURL.username !== "" || parsedURL.password !== "") {
      throw new TypeError(`${parsedURL} is an url with embedded credentials.`);
    }
    let method = init.method || input.method || "GET";
    if (/^(delete|get|head|options|post|put)$/i.test(method)) {
      method = method.toUpperCase();
    }
    if (!isRequest(init) && "data" in init) {
      doBadDataWarn();
    }
    if ((init.body != null || isRequest(input) && input.body !== null) && (method === "GET" || method === "HEAD")) {
      throw new TypeError("Request with GET/HEAD method cannot have body");
    }
    const inputBody = init.body ? init.body : isRequest(input) && input.body !== null ? clone(input) : null;
    super(inputBody, {
      size: init.size || input.size || 0
    });
    const headers = new Headers(init.headers || input.headers || {});
    if (inputBody !== null && !headers.has("Content-Type")) {
      const contentType = extractContentType(inputBody, this);
      if (contentType) {
        headers.set("Content-Type", contentType);
      }
    }
    let signal = isRequest(input) ? input.signal : null;
    if ("signal" in init) {
      signal = init.signal;
    }
    if (signal != null && !isAbortSignal(signal)) {
      throw new TypeError("Expected signal to be an instanceof AbortSignal or EventTarget");
    }
    let referrer = init.referrer == null ? input.referrer : init.referrer;
    if (referrer === "") {
      referrer = "no-referrer";
    } else if (referrer) {
      const parsedReferrer = new URL(referrer);
      referrer = /^about:(\/\/)?client$/.test(parsedReferrer) ? "client" : parsedReferrer;
    } else {
      referrer = void 0;
    }
    this[INTERNALS3] = {
      method,
      redirect: init.redirect || input.redirect || "follow",
      headers,
      parsedURL,
      signal,
      referrer
    };
    this.follow = init.follow === void 0 ? input.follow === void 0 ? 20 : input.follow : init.follow;
    this.compress = init.compress === void 0 ? input.compress === void 0 ? true : input.compress : init.compress;
    this.counter = init.counter || input.counter || 0;
    this.agent = init.agent || input.agent;
    this.highWaterMark = init.highWaterMark || input.highWaterMark || 16384;
    this.insecureHTTPParser = init.insecureHTTPParser || input.insecureHTTPParser || false;
    this.referrerPolicy = init.referrerPolicy || input.referrerPolicy || "";
  }
  /** @returns {string} */
  get method() {
    return this[INTERNALS3].method;
  }
  /** @returns {string} */
  get url() {
    return (0, import_node_url.format)(this[INTERNALS3].parsedURL);
  }
  /** @returns {Headers} */
  get headers() {
    return this[INTERNALS3].headers;
  }
  get redirect() {
    return this[INTERNALS3].redirect;
  }
  /** @returns {AbortSignal} */
  get signal() {
    return this[INTERNALS3].signal;
  }
  // https://fetch.spec.whatwg.org/#dom-request-referrer
  get referrer() {
    if (this[INTERNALS3].referrer === "no-referrer") {
      return "";
    }
    if (this[INTERNALS3].referrer === "client") {
      return "about:client";
    }
    if (this[INTERNALS3].referrer) {
      return this[INTERNALS3].referrer.toString();
    }
    return void 0;
  }
  get referrerPolicy() {
    return this[INTERNALS3].referrerPolicy;
  }
  set referrerPolicy(referrerPolicy) {
    this[INTERNALS3].referrerPolicy = validateReferrerPolicy(referrerPolicy);
  }
  /**
   * Clone this request
   *
   * @return  Request
   */
  clone() {
    return new _Request(this);
  }
  get [Symbol.toStringTag]() {
    return "Request";
  }
};
Object.defineProperties(Request.prototype, {
  method: { enumerable: true },
  url: { enumerable: true },
  headers: { enumerable: true },
  redirect: { enumerable: true },
  clone: { enumerable: true },
  signal: { enumerable: true },
  referrer: { enumerable: true },
  referrerPolicy: { enumerable: true }
});
var getNodeRequestOptions = (request) => {
  const { parsedURL } = request[INTERNALS3];
  const headers = new Headers(request[INTERNALS3].headers);
  if (!headers.has("Accept")) {
    headers.set("Accept", "*/*");
  }
  let contentLengthValue = null;
  if (request.body === null && /^(post|put)$/i.test(request.method)) {
    contentLengthValue = "0";
  }
  if (request.body !== null) {
    const totalBytes = getTotalBytes(request);
    if (typeof totalBytes === "number" && !Number.isNaN(totalBytes)) {
      contentLengthValue = String(totalBytes);
    }
  }
  if (contentLengthValue) {
    headers.set("Content-Length", contentLengthValue);
  }
  if (request.referrerPolicy === "") {
    request.referrerPolicy = DEFAULT_REFERRER_POLICY;
  }
  if (request.referrer && request.referrer !== "no-referrer") {
    request[INTERNALS3].referrer = determineRequestsReferrer(request);
  } else {
    request[INTERNALS3].referrer = "no-referrer";
  }
  if (request[INTERNALS3].referrer instanceof URL) {
    headers.set("Referer", request.referrer);
  }
  if (!headers.has("User-Agent")) {
    headers.set("User-Agent", "node-fetch");
  }
  if (request.compress && !headers.has("Accept-Encoding")) {
    headers.set("Accept-Encoding", "gzip, deflate, br");
  }
  let { agent } = request;
  if (typeof agent === "function") {
    agent = agent(parsedURL);
  }
  const search = getSearch(parsedURL);
  const options = {
    // Overwrite search to retain trailing ? (issue #776)
    path: parsedURL.pathname + search,
    // The following options are not expressed in the URL
    method: request.method,
    headers: headers[Symbol.for("nodejs.util.inspect.custom")](),
    insecureHTTPParser: request.insecureHTTPParser,
    agent
  };
  return {
    /** @type {URL} */
    parsedURL,
    options
  };
};

// node_modules/node-fetch/src/errors/abort-error.js
var AbortError = class extends FetchBaseError {
  constructor(message, type = "aborted") {
    super(message, type);
  }
};

// node_modules/node-fetch/src/index.js
init_esm_min();
init_from();
var supportedSchemas = /* @__PURE__ */ new Set(["data:", "http:", "https:"]);
async function fetch(url, options_) {
  return new Promise((resolve2, reject) => {
    const request = new Request(url, options_);
    const { parsedURL, options } = getNodeRequestOptions(request);
    if (!supportedSchemas.has(parsedURL.protocol)) {
      throw new TypeError(`node-fetch cannot load ${url}. URL scheme "${parsedURL.protocol.replace(/:$/, "")}" is not supported.`);
    }
    if (parsedURL.protocol === "data:") {
      const data = dist_default(request.url);
      const response2 = new Response(data, { headers: { "Content-Type": data.typeFull } });
      resolve2(response2);
      return;
    }
    const send = (parsedURL.protocol === "https:" ? import_node_https.default : import_node_http2.default).request;
    const { signal } = request;
    let response = null;
    const abort = () => {
      const error = new AbortError("The operation was aborted.");
      reject(error);
      if (request.body && request.body instanceof import_node_stream2.default.Readable) {
        request.body.destroy(error);
      }
      if (!response || !response.body) {
        return;
      }
      response.body.emit("error", error);
    };
    if (signal && signal.aborted) {
      abort();
      return;
    }
    const abortAndFinalize = () => {
      abort();
      finalize();
    };
    const request_ = send(parsedURL.toString(), options);
    if (signal) {
      signal.addEventListener("abort", abortAndFinalize);
    }
    const finalize = () => {
      request_.abort();
      if (signal) {
        signal.removeEventListener("abort", abortAndFinalize);
      }
    };
    request_.on("error", (error) => {
      reject(new FetchError(`request to ${request.url} failed, reason: ${error.message}`, "system", error));
      finalize();
    });
    fixResponseChunkedTransferBadEnding(request_, (error) => {
      if (response && response.body) {
        response.body.destroy(error);
      }
    });
    if (process.version < "v14") {
      request_.on("socket", (s2) => {
        let endedWithEventsCount;
        s2.prependListener("end", () => {
          endedWithEventsCount = s2._eventsCount;
        });
        s2.prependListener("close", (hadError) => {
          if (response && endedWithEventsCount < s2._eventsCount && !hadError) {
            const error = new Error("Premature close");
            error.code = "ERR_STREAM_PREMATURE_CLOSE";
            response.body.emit("error", error);
          }
        });
      });
    }
    request_.on("response", (response_) => {
      request_.setTimeout(0);
      const headers = fromRawHeaders(response_.rawHeaders);
      if (isRedirect(response_.statusCode)) {
        const location = headers.get("Location");
        let locationURL = null;
        try {
          locationURL = location === null ? null : new URL(location, request.url);
        } catch {
          if (request.redirect !== "manual") {
            reject(new FetchError(`uri requested responds with an invalid redirect URL: ${location}`, "invalid-redirect"));
            finalize();
            return;
          }
        }
        switch (request.redirect) {
          case "error":
            reject(new FetchError(`uri requested responds with a redirect, redirect mode is set to error: ${request.url}`, "no-redirect"));
            finalize();
            return;
          case "manual":
            break;
          case "follow": {
            if (locationURL === null) {
              break;
            }
            if (request.counter >= request.follow) {
              reject(new FetchError(`maximum redirect reached at: ${request.url}`, "max-redirect"));
              finalize();
              return;
            }
            const requestOptions = {
              headers: new Headers(request.headers),
              follow: request.follow,
              counter: request.counter + 1,
              agent: request.agent,
              compress: request.compress,
              method: request.method,
              body: clone(request),
              signal: request.signal,
              size: request.size,
              referrer: request.referrer,
              referrerPolicy: request.referrerPolicy
            };
            if (!isDomainOrSubdomain(request.url, locationURL) || !isSameProtocol(request.url, locationURL)) {
              for (const name of ["authorization", "www-authenticate", "cookie", "cookie2"]) {
                requestOptions.headers.delete(name);
              }
            }
            if (response_.statusCode !== 303 && request.body && options_.body instanceof import_node_stream2.default.Readable) {
              reject(new FetchError("Cannot follow redirect with body being a readable stream", "unsupported-redirect"));
              finalize();
              return;
            }
            if (response_.statusCode === 303 || (response_.statusCode === 301 || response_.statusCode === 302) && request.method === "POST") {
              requestOptions.method = "GET";
              requestOptions.body = void 0;
              requestOptions.headers.delete("content-length");
            }
            const responseReferrerPolicy = parseReferrerPolicyFromHeader(headers);
            if (responseReferrerPolicy) {
              requestOptions.referrerPolicy = responseReferrerPolicy;
            }
            resolve2(fetch(new Request(locationURL, requestOptions)));
            finalize();
            return;
          }
          default:
            return reject(new TypeError(`Redirect option '${request.redirect}' is not a valid value of RequestRedirect`));
        }
      }
      if (signal) {
        response_.once("end", () => {
          signal.removeEventListener("abort", abortAndFinalize);
        });
      }
      let body = (0, import_node_stream2.pipeline)(response_, new import_node_stream2.PassThrough(), (error) => {
        if (error) {
          reject(error);
        }
      });
      if (process.version < "v12.10") {
        response_.on("aborted", abortAndFinalize);
      }
      const responseOptions = {
        url: request.url,
        status: response_.statusCode,
        statusText: response_.statusMessage,
        headers,
        size: request.size,
        counter: request.counter,
        highWaterMark: request.highWaterMark
      };
      const codings = headers.get("Content-Encoding");
      if (!request.compress || request.method === "HEAD" || codings === null || response_.statusCode === 204 || response_.statusCode === 304) {
        response = new Response(body, responseOptions);
        resolve2(response);
        return;
      }
      const zlibOptions = {
        flush: import_node_zlib.default.Z_SYNC_FLUSH,
        finishFlush: import_node_zlib.default.Z_SYNC_FLUSH
      };
      if (codings === "gzip" || codings === "x-gzip") {
        body = (0, import_node_stream2.pipeline)(body, import_node_zlib.default.createGunzip(zlibOptions), (error) => {
          if (error) {
            reject(error);
          }
        });
        response = new Response(body, responseOptions);
        resolve2(response);
        return;
      }
      if (codings === "deflate" || codings === "x-deflate") {
        const raw = (0, import_node_stream2.pipeline)(response_, new import_node_stream2.PassThrough(), (error) => {
          if (error) {
            reject(error);
          }
        });
        raw.once("data", (chunk) => {
          if ((chunk[0] & 15) === 8) {
            body = (0, import_node_stream2.pipeline)(body, import_node_zlib.default.createInflate(), (error) => {
              if (error) {
                reject(error);
              }
            });
          } else {
            body = (0, import_node_stream2.pipeline)(body, import_node_zlib.default.createInflateRaw(), (error) => {
              if (error) {
                reject(error);
              }
            });
          }
          response = new Response(body, responseOptions);
          resolve2(response);
        });
        raw.once("end", () => {
          if (!response) {
            response = new Response(body, responseOptions);
            resolve2(response);
          }
        });
        return;
      }
      if (codings === "br") {
        body = (0, import_node_stream2.pipeline)(body, import_node_zlib.default.createBrotliDecompress(), (error) => {
          if (error) {
            reject(error);
          }
        });
        response = new Response(body, responseOptions);
        resolve2(response);
        return;
      }
      response = new Response(body, responseOptions);
      resolve2(response);
    });
    writeToStream(request_, request).catch(reject);
  });
}
function fixResponseChunkedTransferBadEnding(request, errorCallback) {
  const LAST_CHUNK = import_node_buffer2.Buffer.from("0\r\n\r\n");
  let isChunkedTransfer = false;
  let properLastChunkReceived = false;
  let previousChunk;
  request.on("response", (response) => {
    const { headers } = response;
    isChunkedTransfer = headers["transfer-encoding"] === "chunked" && !headers["content-length"];
  });
  request.on("socket", (socket) => {
    const onSocketClose = () => {
      if (isChunkedTransfer && !properLastChunkReceived) {
        const error = new Error("Premature close");
        error.code = "ERR_STREAM_PREMATURE_CLOSE";
        errorCallback(error);
      }
    };
    const onData = (buf) => {
      properLastChunkReceived = import_node_buffer2.Buffer.compare(buf.slice(-5), LAST_CHUNK) === 0;
      if (!properLastChunkReceived && previousChunk) {
        properLastChunkReceived = import_node_buffer2.Buffer.compare(previousChunk.slice(-3), LAST_CHUNK.slice(0, 3)) === 0 && import_node_buffer2.Buffer.compare(buf.slice(-2), LAST_CHUNK.slice(3)) === 0;
      }
      previousChunk = buf;
    };
    socket.prependListener("close", onSocketClose);
    socket.on("data", onData);
    request.on("close", () => {
      socket.removeListener("close", onSocketClose);
      socket.removeListener("data", onData);
    });
  });
}

// node_modules/lambda-extension-service/dist/index.js
var import_events = require("events");
var import_http = require("http");
var EventTypes = {
  Invoke: "INVOKE",
  Shutdown: "SHUTDOWN"
  // Shutdown event is not supported for internal extensions
};
var TelemetryEventTypes = {
  Platform: "platform",
  Function: "function",
  Extension: "extension"
};
var EXTENSION_URL = `http://${process.env.AWS_LAMBDA_RUNTIME_API}/2020-01-01/extension`;
var TELEMETRY_URL = `http://${process.env.AWS_LAMBDA_RUNTIME_API}/2022-07-01/telemetry`;
var telemetryEvent = "telemetry-event";
var telemetryServerHostname = "sandbox.localdomain";
var defaultConfig = {
  extensionName: "MyExtension",
  telemetryServerPort: 4242
};
var ExtensionAPIService = class {
  extensionId;
  telemetryEventEmitter = new import_events.EventEmitter();
  telemetryServer;
  config;
  constructor(config = {}) {
    this.config = {
      ...defaultConfig,
      ...config
    };
  }
  register = async (events = [EventTypes.Invoke, EventTypes.Shutdown]) => {
    const response = await fetch(`${EXTENSION_URL}/register`, {
      method: "POST",
      headers: {
        "Lambda-Extension-Name": this.config.extensionName
      },
      body: JSON.stringify({
        events
      })
    });
    if (response.status !== 200) {
      console.error(await response.json());
      throw new Error(
        `Unexpected register response status code: ${response.status}`
      );
    }
    this.extensionId = response.headers.get("lambda-extension-identifier") ?? void 0;
    if (!this.extensionId) {
      throw new Error("Unexpected register response: extension id not found");
    }
    return this.extensionId;
  };
  next = async () => {
    if (!this.extensionId) {
      throw new Error("Extension ID not set, please register first");
    }
    const response = await fetch(`${EXTENSION_URL}/event/next`, {
      method: "GET",
      headers: {
        "Lambda-Extension-Identifier": this.extensionId
      }
    });
    if (response.status !== 200) {
      console.error(await response.json());
      throw new Error(
        `Unexpected next response status code: ${response.status}`
      );
    }
    return response.json();
  };
  registerTelemetry = async (events = [
    TelemetryEventTypes.Function,
    TelemetryEventTypes.Platform,
    TelemetryEventTypes.Extension
  ]) => {
    if (!this.extensionId) {
      throw new Error("Extension ID not set, please register first");
    }
    this.telemetryServer = (0, import_http.createServer)((request, response2) => {
      if (request.method !== "POST")
        throw new Error("Unexpected request method");
      let body = "";
      request.on("data", (data) => {
        body += data;
      });
      request.on("end", () => {
        response2.writeHead(200, {});
        response2.end("OK");
        const data = JSON.parse(body);
        for (const event of data) {
          this.telemetryEventEmitter.emit(telemetryEvent, event);
        }
      });
    }).listen(this.config.telemetryServerPort, telemetryServerHostname).on("error", (err) => {
      console.error("Server error: ", err);
    });
    const response = await fetch(TELEMETRY_URL, {
      method: "PUT",
      headers: {
        "Lambda-Extension-Identifier": this.extensionId
      },
      body: JSON.stringify({
        destination: {
          protocol: "HTTP",
          URI: `http://${telemetryServerHostname}:${this.config.telemetryServerPort}`
        },
        types: events,
        buffering: { timeoutMs: 25, maxBytes: 262144, maxItems: 1e3 },
        schemaVersion: "2022-07-01"
      })
    });
    if (response.status !== 200) {
      console.error(await response.json());
      throw new Error(
        `Unexpected telemetry register response status code: ${response.status}`
      );
    }
    return response.json();
  };
  onTelemetryEvent = (callback) => {
    this.telemetryEventEmitter.on(telemetryEvent, callback);
  };
};

// src/logAggregator.ts
var BEFORE_INIT = "BEFORE_INIT";
var LogAggregator = class {
  constructor() {
    this.logMap = {};
  }
  addLog(log2, requestId = BEFORE_INIT) {
    if (!(requestId in this.logMap)) {
      this.logMap[requestId] = [];
    }
    this.logMap[requestId].push(log2);
  }
  getLogs(requestId) {
    const logs = this.logMap[requestId];
    if (logs === void 0) {
      return [];
    }
    return logs;
  }
  deleteLogs(requestId) {
    delete this.logMap[requestId];
  }
};

// src/logServer.ts
var import_node_http3 = require("node:http");
var listenForLog = (onLogReceived, { port } = { port: 4e3 }) => {
  const server = (0, import_node_http3.createServer)((request, response) => {
    if (request.method == "POST") {
      let body = "";
      request.on("data", function(data) {
        body += data;
      });
      request.on("end", function() {
        response.writeHead(200, {});
        response.end("OK");
        try {
          onLogReceived(JSON.parse(body));
        } catch (e2) {
          console.error("[Sentry Lambda Exension] Failed to parse logs", e2);
        }
      });
    }
  });
  server.keepAliveTimeout = 0;
  server.listen(port, "sandbox");
  console.info(`[Sentry Lambda Exension] Listening for logs at http://sandbox:${port}`);
};

// src/lambdaContext.ts
var LambdaContext = class {
  constructor() {
    this.context = void 0;
  }
  updateContext(event) {
    if (event.eventType === EventTypes.Invoke) {
      this.context = {
        requestId: event.requestId,
        invokedFunctionArn: event.invokedFunctionArn,
        invokedAt: (/* @__PURE__ */ new Date()).toISOString()
      };
    } else {
      this.context = void 0;
    }
  }
  getContext() {
    return this.context;
  }
  getRequestId() {
    return this.context?.requestId;
  }
};

// node_modules/@sentry/utils/esm/is.js
var objectToString = Object.prototype.toString;
function isError(wat) {
  switch (objectToString.call(wat)) {
    case "[object Error]":
    case "[object Exception]":
    case "[object DOMException]":
      return true;
    default:
      return isInstanceOf(wat, Error);
  }
}
function isBuiltin(wat, className) {
  return objectToString.call(wat) === `[object ${className}]`;
}
function isString(wat) {
  return isBuiltin(wat, "String");
}
function isPlainObject(wat) {
  return isBuiltin(wat, "Object");
}
function isEvent(wat) {
  return typeof Event !== "undefined" && isInstanceOf(wat, Event);
}
function isElement(wat) {
  return typeof Element !== "undefined" && isInstanceOf(wat, Element);
}
function isRegExp(wat) {
  return isBuiltin(wat, "RegExp");
}
function isThenable(wat) {
  return Boolean(wat && wat.then && typeof wat.then === "function");
}
function isSyntheticEvent(wat) {
  return isPlainObject(wat) && "nativeEvent" in wat && "preventDefault" in wat && "stopPropagation" in wat;
}
function isNaN2(wat) {
  return typeof wat === "number" && wat !== wat;
}
function isInstanceOf(wat, base) {
  try {
    return wat instanceof base;
  } catch (_e) {
    return false;
  }
}
function isVueViewModel(wat) {
  return !!(typeof wat === "object" && wat !== null && (wat.__isVue || wat._isVue));
}

// node_modules/@sentry/utils/esm/string.js
function truncate(str, max = 0) {
  if (typeof str !== "string" || max === 0) {
    return str;
  }
  return str.length <= max ? str : `${str.slice(0, max)}...`;
}
function snipLine(line, colno) {
  let newLine = line;
  const lineLength = newLine.length;
  if (lineLength <= 150) {
    return newLine;
  }
  if (colno > lineLength) {
    colno = lineLength;
  }
  let start = Math.max(colno - 60, 0);
  if (start < 5) {
    start = 0;
  }
  let end = Math.min(start + 140, lineLength);
  if (end > lineLength - 5) {
    end = lineLength;
  }
  if (end === lineLength) {
    start = Math.max(end - 140, 0);
  }
  newLine = newLine.slice(start, end);
  if (start > 0) {
    newLine = `'{snip} ${newLine}`;
  }
  if (end < lineLength) {
    newLine += " {snip}";
  }
  return newLine;
}
function isMatchingPattern(value, pattern, requireExactStringMatch = false) {
  if (!isString(value)) {
    return false;
  }
  if (isRegExp(pattern)) {
    return pattern.test(value);
  }
  if (isString(pattern)) {
    return requireExactStringMatch ? value === pattern : value.includes(pattern);
  }
  return false;
}
function stringMatchesSomePattern(testString, patterns = [], requireExactStringMatch = false) {
  return patterns.some((pattern) => isMatchingPattern(testString, pattern, requireExactStringMatch));
}

// node_modules/@sentry/utils/esm/aggregate-errors.js
function applyAggregateErrorsToEvent(exceptionFromErrorImplementation, parser, maxValueLimit = 250, key, limit, event, hint) {
  if (!event.exception || !event.exception.values || !hint || !isInstanceOf(hint.originalException, Error)) {
    return;
  }
  const originalException = event.exception.values.length > 0 ? event.exception.values[event.exception.values.length - 1] : void 0;
  if (originalException) {
    event.exception.values = truncateAggregateExceptions(
      aggregateExceptionsFromError(
        exceptionFromErrorImplementation,
        parser,
        limit,
        hint.originalException,
        key,
        event.exception.values,
        originalException,
        0
      ),
      maxValueLimit
    );
  }
}
function aggregateExceptionsFromError(exceptionFromErrorImplementation, parser, limit, error, key, prevExceptions, exception, exceptionId) {
  if (prevExceptions.length >= limit + 1) {
    return prevExceptions;
  }
  let newExceptions = [...prevExceptions];
  if (isInstanceOf(error[key], Error)) {
    applyExceptionGroupFieldsForParentException(exception, exceptionId);
    const newException = exceptionFromErrorImplementation(parser, error[key]);
    const newExceptionId = newExceptions.length;
    applyExceptionGroupFieldsForChildException(newException, key, newExceptionId, exceptionId);
    newExceptions = aggregateExceptionsFromError(
      exceptionFromErrorImplementation,
      parser,
      limit,
      error[key],
      key,
      [newException, ...newExceptions],
      newException,
      newExceptionId
    );
  }
  if (Array.isArray(error.errors)) {
    error.errors.forEach((childError, i2) => {
      if (isInstanceOf(childError, Error)) {
        applyExceptionGroupFieldsForParentException(exception, exceptionId);
        const newException = exceptionFromErrorImplementation(parser, childError);
        const newExceptionId = newExceptions.length;
        applyExceptionGroupFieldsForChildException(newException, `errors[${i2}]`, newExceptionId, exceptionId);
        newExceptions = aggregateExceptionsFromError(
          exceptionFromErrorImplementation,
          parser,
          limit,
          childError,
          key,
          [newException, ...newExceptions],
          newException,
          newExceptionId
        );
      }
    });
  }
  return newExceptions;
}
function applyExceptionGroupFieldsForParentException(exception, exceptionId) {
  exception.mechanism = exception.mechanism || { type: "generic", handled: true };
  exception.mechanism = {
    ...exception.mechanism,
    is_exception_group: true,
    exception_id: exceptionId
  };
}
function applyExceptionGroupFieldsForChildException(exception, source, exceptionId, parentId) {
  exception.mechanism = exception.mechanism || { type: "generic", handled: true };
  exception.mechanism = {
    ...exception.mechanism,
    type: "chained",
    source,
    exception_id: exceptionId,
    parent_id: parentId
  };
}
function truncateAggregateExceptions(exceptions, maxValueLength) {
  return exceptions.map((exception) => {
    if (exception.value) {
      exception.value = truncate(exception.value, maxValueLength);
    }
    return exception;
  });
}

// node_modules/@sentry/utils/esm/worldwide.js
function isGlobalObj(obj) {
  return obj && obj.Math == Math ? obj : void 0;
}
var GLOBAL_OBJ = typeof globalThis == "object" && isGlobalObj(globalThis) || // eslint-disable-next-line no-restricted-globals
typeof window == "object" && isGlobalObj(window) || typeof self == "object" && isGlobalObj(self) || typeof global == "object" && isGlobalObj(global) || /* @__PURE__ */ function() {
  return this;
}() || {};
function getGlobalObject() {
  return GLOBAL_OBJ;
}
function getGlobalSingleton(name, creator, obj) {
  const gbl = obj || GLOBAL_OBJ;
  const __SENTRY__ = gbl.__SENTRY__ = gbl.__SENTRY__ || {};
  const singleton = __SENTRY__[name] || (__SENTRY__[name] = creator());
  return singleton;
}

// node_modules/@sentry/utils/esm/browser.js
var WINDOW = getGlobalObject();
var DEFAULT_MAX_STRING_LENGTH = 80;
function htmlTreeAsString(elem, options = {}) {
  if (!elem) {
    return "<unknown>";
  }
  try {
    let currentElem = elem;
    const MAX_TRAVERSE_HEIGHT = 5;
    const out = [];
    let height = 0;
    let len = 0;
    const separator = " > ";
    const sepLength = separator.length;
    let nextStr;
    const keyAttrs = Array.isArray(options) ? options : options.keyAttrs;
    const maxStringLength = !Array.isArray(options) && options.maxStringLength || DEFAULT_MAX_STRING_LENGTH;
    while (currentElem && height++ < MAX_TRAVERSE_HEIGHT) {
      nextStr = _htmlElementAsString(currentElem, keyAttrs);
      if (nextStr === "html" || height > 1 && len + out.length * sepLength + nextStr.length >= maxStringLength) {
        break;
      }
      out.push(nextStr);
      len += nextStr.length;
      currentElem = currentElem.parentNode;
    }
    return out.reverse().join(separator);
  } catch (_oO) {
    return "<unknown>";
  }
}
function _htmlElementAsString(el, keyAttrs) {
  const elem = el;
  const out = [];
  let className;
  let classes;
  let key;
  let attr;
  let i2;
  if (!elem || !elem.tagName) {
    return "";
  }
  if (WINDOW.HTMLElement) {
    if (elem instanceof HTMLElement && elem.dataset && elem.dataset["sentryComponent"]) {
      return elem.dataset["sentryComponent"];
    }
  }
  out.push(elem.tagName.toLowerCase());
  const keyAttrPairs = keyAttrs && keyAttrs.length ? keyAttrs.filter((keyAttr) => elem.getAttribute(keyAttr)).map((keyAttr) => [keyAttr, elem.getAttribute(keyAttr)]) : null;
  if (keyAttrPairs && keyAttrPairs.length) {
    keyAttrPairs.forEach((keyAttrPair) => {
      out.push(`[${keyAttrPair[0]}="${keyAttrPair[1]}"]`);
    });
  } else {
    if (elem.id) {
      out.push(`#${elem.id}`);
    }
    className = elem.className;
    if (className && isString(className)) {
      classes = className.split(/\s+/);
      for (i2 = 0; i2 < classes.length; i2++) {
        out.push(`.${classes[i2]}`);
      }
    }
  }
  const allowedAttrs = ["aria-label", "type", "name", "title", "alt"];
  for (i2 = 0; i2 < allowedAttrs.length; i2++) {
    key = allowedAttrs[i2];
    attr = elem.getAttribute(key);
    if (attr) {
      out.push(`[${key}="${attr}"]`);
    }
  }
  return out.join("");
}

// node_modules/@sentry/utils/esm/debug-build.js
var DEBUG_BUILD = typeof __SENTRY_DEBUG__ === "undefined" || __SENTRY_DEBUG__;

// node_modules/@sentry/utils/esm/logger.js
var PREFIX = "Sentry Logger ";
var CONSOLE_LEVELS = [
  "debug",
  "info",
  "warn",
  "error",
  "log",
  "assert",
  "trace"
];
var originalConsoleMethods = {};
function consoleSandbox(callback) {
  if (!("console" in GLOBAL_OBJ)) {
    return callback();
  }
  const console2 = GLOBAL_OBJ.console;
  const wrappedFuncs = {};
  const wrappedLevels = Object.keys(originalConsoleMethods);
  wrappedLevels.forEach((level) => {
    const originalConsoleMethod = originalConsoleMethods[level];
    wrappedFuncs[level] = console2[level];
    console2[level] = originalConsoleMethod;
  });
  try {
    return callback();
  } finally {
    wrappedLevels.forEach((level) => {
      console2[level] = wrappedFuncs[level];
    });
  }
}
function makeLogger() {
  let enabled = false;
  const logger2 = {
    enable: () => {
      enabled = true;
    },
    disable: () => {
      enabled = false;
    },
    isEnabled: () => enabled
  };
  if (DEBUG_BUILD) {
    CONSOLE_LEVELS.forEach((name) => {
      logger2[name] = (...args) => {
        if (enabled) {
          consoleSandbox(() => {
            GLOBAL_OBJ.console[name](`${PREFIX}[${name}]:`, ...args);
          });
        }
      };
    });
  } else {
    CONSOLE_LEVELS.forEach((name) => {
      logger2[name] = () => void 0;
    });
  }
  return logger2;
}
var logger = makeLogger();

// node_modules/@sentry/utils/esm/error.js
var SentryError = class extends Error {
  /** Display name of this error instance. */
  constructor(message, logLevel = "warn") {
    super(message);
    this.message = message;
    this.name = new.target.prototype.constructor.name;
    Object.setPrototypeOf(this, new.target.prototype);
    this.logLevel = logLevel;
  }
};

// node_modules/@sentry/utils/esm/object.js
function fill(source, name, replacementFactory) {
  if (!(name in source)) {
    return;
  }
  const original = source[name];
  const wrapped = replacementFactory(original);
  if (typeof wrapped === "function") {
    markFunctionWrapped(wrapped, original);
  }
  source[name] = wrapped;
}
function addNonEnumerableProperty(obj, name, value) {
  try {
    Object.defineProperty(obj, name, {
      // enumerable: false, // the default, so we can save on bundle size by not explicitly setting it
      value,
      writable: true,
      configurable: true
    });
  } catch (o_O) {
    DEBUG_BUILD && logger.log(`Failed to add non-enumerable property "${name}" to object`, obj);
  }
}
function markFunctionWrapped(wrapped, original) {
  try {
    const proto = original.prototype || {};
    wrapped.prototype = original.prototype = proto;
    addNonEnumerableProperty(wrapped, "__sentry_original__", original);
  } catch (o_O) {
  }
}
function getOriginalFunction(func) {
  return func.__sentry_original__;
}
function convertToPlainObject(value) {
  if (isError(value)) {
    return {
      message: value.message,
      name: value.name,
      stack: value.stack,
      ...getOwnProperties(value)
    };
  } else if (isEvent(value)) {
    const newObj = {
      type: value.type,
      target: serializeEventTarget(value.target),
      currentTarget: serializeEventTarget(value.currentTarget),
      ...getOwnProperties(value)
    };
    if (typeof CustomEvent !== "undefined" && isInstanceOf(value, CustomEvent)) {
      newObj.detail = value.detail;
    }
    return newObj;
  } else {
    return value;
  }
}
function serializeEventTarget(target) {
  try {
    return isElement(target) ? htmlTreeAsString(target) : Object.prototype.toString.call(target);
  } catch (_oO) {
    return "<unknown>";
  }
}
function getOwnProperties(obj) {
  if (typeof obj === "object" && obj !== null) {
    const extractedProps = {};
    for (const property in obj) {
      if (Object.prototype.hasOwnProperty.call(obj, property)) {
        extractedProps[property] = obj[property];
      }
    }
    return extractedProps;
  } else {
    return {};
  }
}
function dropUndefinedKeys(inputValue) {
  const memoizationMap = /* @__PURE__ */ new Map();
  return _dropUndefinedKeys(inputValue, memoizationMap);
}
function _dropUndefinedKeys(inputValue, memoizationMap) {
  if (isPojo(inputValue)) {
    const memoVal = memoizationMap.get(inputValue);
    if (memoVal !== void 0) {
      return memoVal;
    }
    const returnValue = {};
    memoizationMap.set(inputValue, returnValue);
    for (const key of Object.keys(inputValue)) {
      if (typeof inputValue[key] !== "undefined") {
        returnValue[key] = _dropUndefinedKeys(inputValue[key], memoizationMap);
      }
    }
    return returnValue;
  }
  if (Array.isArray(inputValue)) {
    const memoVal = memoizationMap.get(inputValue);
    if (memoVal !== void 0) {
      return memoVal;
    }
    const returnValue = [];
    memoizationMap.set(inputValue, returnValue);
    inputValue.forEach((item) => {
      returnValue.push(_dropUndefinedKeys(item, memoizationMap));
    });
    return returnValue;
  }
  return inputValue;
}
function isPojo(input) {
  if (!isPlainObject(input)) {
    return false;
  }
  try {
    const name = Object.getPrototypeOf(input).constructor.name;
    return !name || name === "Object";
  } catch (e2) {
    return true;
  }
}

// node_modules/@sentry/utils/esm/stacktrace.js
var defaultFunctionName = "<anonymous>";
function getFunctionName(fn) {
  try {
    if (!fn || typeof fn !== "function") {
      return defaultFunctionName;
    }
    return fn.name || defaultFunctionName;
  } catch (e2) {
    return defaultFunctionName;
  }
}

// node_modules/@sentry/utils/esm/instrument/_handlers.js
var handlers = {};
var instrumented = {};
function addHandler(type, handler) {
  handlers[type] = handlers[type] || [];
  handlers[type].push(handler);
}
function maybeInstrument(type, instrumentFn) {
  if (!instrumented[type]) {
    instrumentFn();
    instrumented[type] = true;
  }
}
function triggerHandlers(type, data) {
  const typeHandlers = type && handlers[type];
  if (!typeHandlers) {
    return;
  }
  for (const handler of typeHandlers) {
    try {
      handler(data);
    } catch (e2) {
      DEBUG_BUILD && logger.error(
        `Error while triggering instrumentation handler.
Type: ${type}
Name: ${getFunctionName(handler)}
Error:`,
        e2
      );
    }
  }
}

// node_modules/@sentry/utils/esm/instrument/console.js
function addConsoleInstrumentationHandler(handler) {
  const type = "console";
  addHandler(type, handler);
  maybeInstrument(type, instrumentConsole);
}
function instrumentConsole() {
  if (!("console" in GLOBAL_OBJ)) {
    return;
  }
  CONSOLE_LEVELS.forEach(function(level) {
    if (!(level in GLOBAL_OBJ.console)) {
      return;
    }
    fill(GLOBAL_OBJ.console, level, function(originalConsoleMethod) {
      originalConsoleMethods[level] = originalConsoleMethod;
      return function(...args) {
        const handlerData = { args, level };
        triggerHandlers("console", handlerData);
        const log2 = originalConsoleMethods[level];
        log2 && log2.apply(GLOBAL_OBJ.console, args);
      };
    });
  });
}

// node_modules/@sentry/utils/esm/misc.js
function uuid4() {
  const gbl = GLOBAL_OBJ;
  const crypto = gbl.crypto || gbl.msCrypto;
  let getRandomByte = () => Math.random() * 16;
  try {
    if (crypto && crypto.randomUUID) {
      return crypto.randomUUID().replace(/-/g, "");
    }
    if (crypto && crypto.getRandomValues) {
      getRandomByte = () => {
        const typedArray = new Uint8Array(1);
        crypto.getRandomValues(typedArray);
        return typedArray[0];
      };
    }
  } catch (_) {
  }
  return ("10000000100040008000" + 1e11).replace(
    /[018]/g,
    (c) => (
      // eslint-disable-next-line no-bitwise
      (c ^ (getRandomByte() & 15) >> c / 4).toString(16)
    )
  );
}
function getFirstException(event) {
  return event.exception && event.exception.values ? event.exception.values[0] : void 0;
}
function getEventDescription(event) {
  const { message, event_id: eventId } = event;
  if (message) {
    return message;
  }
  const firstException = getFirstException(event);
  if (firstException) {
    if (firstException.type && firstException.value) {
      return `${firstException.type}: ${firstException.value}`;
    }
    return firstException.type || firstException.value || eventId || "<unknown>";
  }
  return eventId || "<unknown>";
}
var SEMVER_REGEXP = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-((?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*)(?:\.(?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*))*))?(?:\+([0-9a-zA-Z-]+(?:\.[0-9a-zA-Z-]+)*))?$/;
function parseSemver(input) {
  const match = input.match(SEMVER_REGEXP) || [];
  const major = parseInt(match[1], 10);
  const minor = parseInt(match[2], 10);
  const patch = parseInt(match[3], 10);
  return {
    buildmetadata: match[5],
    major: isNaN(major) ? void 0 : major,
    minor: isNaN(minor) ? void 0 : minor,
    patch: isNaN(patch) ? void 0 : patch,
    prerelease: match[4]
  };
}
function addContextToFrame(lines, frame, linesOfContext = 5) {
  if (frame.lineno === void 0) {
    return;
  }
  const maxLines = lines.length;
  const sourceLine = Math.max(Math.min(maxLines - 1, frame.lineno - 1), 0);
  frame.pre_context = lines.slice(Math.max(0, sourceLine - linesOfContext), sourceLine).map((line) => snipLine(line, 0));
  frame.context_line = snipLine(lines[Math.min(maxLines - 1, sourceLine)], frame.colno || 0);
  frame.post_context = lines.slice(Math.min(sourceLine + 1, maxLines), sourceLine + 1 + linesOfContext).map((line) => snipLine(line, 0));
}
function arrayify(maybeArray) {
  return Array.isArray(maybeArray) ? maybeArray : [maybeArray];
}

// node_modules/@sentry/utils/esm/node.js
function dynamicRequire(mod, request) {
  return mod.require(request);
}
function loadModule(moduleName) {
  let mod;
  try {
    mod = dynamicRequire(module, moduleName);
  } catch (e2) {
  }
  try {
    const { cwd } = dynamicRequire(module, "process");
    mod = dynamicRequire(module, `${cwd()}/node_modules/${moduleName}`);
  } catch (e2) {
  }
  return mod;
}

// node_modules/@sentry/utils/esm/memo.js
function memoBuilder() {
  const hasWeakSet = typeof WeakSet === "function";
  const inner = hasWeakSet ? /* @__PURE__ */ new WeakSet() : [];
  function memoize(obj) {
    if (hasWeakSet) {
      if (inner.has(obj)) {
        return true;
      }
      inner.add(obj);
      return false;
    }
    for (let i2 = 0; i2 < inner.length; i2++) {
      const value = inner[i2];
      if (value === obj) {
        return true;
      }
    }
    inner.push(obj);
    return false;
  }
  function unmemoize(obj) {
    if (hasWeakSet) {
      inner.delete(obj);
    } else {
      for (let i2 = 0; i2 < inner.length; i2++) {
        if (inner[i2] === obj) {
          inner.splice(i2, 1);
          break;
        }
      }
    }
  }
  return [memoize, unmemoize];
}

// node_modules/@sentry/utils/esm/normalize.js
function normalize(input, depth = 100, maxProperties = Infinity) {
  try {
    return visit("", input, depth, maxProperties);
  } catch (err) {
    return { ERROR: `**non-serializable** (${err})` };
  }
}
function visit(key, value, depth = Infinity, maxProperties = Infinity, memo = memoBuilder()) {
  const [memoize, unmemoize] = memo;
  if (value == null || // this matches null and undefined -> eqeq not eqeqeq
  ["number", "boolean", "string"].includes(typeof value) && !isNaN2(value)) {
    return value;
  }
  const stringified = stringifyValue(key, value);
  if (!stringified.startsWith("[object ")) {
    return stringified;
  }
  if (value["__sentry_skip_normalization__"]) {
    return value;
  }
  const remainingDepth = typeof value["__sentry_override_normalization_depth__"] === "number" ? value["__sentry_override_normalization_depth__"] : depth;
  if (remainingDepth === 0) {
    return stringified.replace("object ", "");
  }
  if (memoize(value)) {
    return "[Circular ~]";
  }
  const valueWithToJSON = value;
  if (valueWithToJSON && typeof valueWithToJSON.toJSON === "function") {
    try {
      const jsonValue = valueWithToJSON.toJSON();
      return visit("", jsonValue, remainingDepth - 1, maxProperties, memo);
    } catch (err) {
    }
  }
  const normalized = Array.isArray(value) ? [] : {};
  let numAdded = 0;
  const visitable = convertToPlainObject(value);
  for (const visitKey in visitable) {
    if (!Object.prototype.hasOwnProperty.call(visitable, visitKey)) {
      continue;
    }
    if (numAdded >= maxProperties) {
      normalized[visitKey] = "[MaxProperties ~]";
      break;
    }
    const visitValue = visitable[visitKey];
    normalized[visitKey] = visit(visitKey, visitValue, remainingDepth - 1, maxProperties, memo);
    numAdded++;
  }
  unmemoize(value);
  return normalized;
}
function stringifyValue(key, value) {
  try {
    if (key === "domain" && value && typeof value === "object" && value._events) {
      return "[Domain]";
    }
    if (key === "domainEmitter") {
      return "[DomainEmitter]";
    }
    if (typeof global !== "undefined" && value === global) {
      return "[Global]";
    }
    if (typeof window !== "undefined" && value === window) {
      return "[Window]";
    }
    if (typeof document !== "undefined" && value === document) {
      return "[Document]";
    }
    if (isVueViewModel(value)) {
      return "[VueViewModel]";
    }
    if (isSyntheticEvent(value)) {
      return "[SyntheticEvent]";
    }
    if (typeof value === "number" && value !== value) {
      return "[NaN]";
    }
    if (typeof value === "function") {
      return `[Function: ${getFunctionName(value)}]`;
    }
    if (typeof value === "symbol") {
      return `[${String(value)}]`;
    }
    if (typeof value === "bigint") {
      return `[BigInt: ${String(value)}]`;
    }
    const objName = getConstructorName(value);
    if (/^HTML(\w*)Element$/.test(objName)) {
      return `[HTMLElement: ${objName}]`;
    }
    return `[object ${objName}]`;
  } catch (err) {
    return `**non-serializable** (${err})`;
  }
}
function getConstructorName(value) {
  const prototype = Object.getPrototypeOf(value);
  return prototype ? prototype.constructor.name : "null prototype";
}

// node_modules/@sentry/utils/esm/path.js
var splitPathRe = /^(\S+:\\|\/?)([\s\S]*?)((?:\.{1,2}|[^/\\]+?|)(\.[^./\\]*|))(?:[/\\]*)$/;
function splitPath(filename) {
  const truncated = filename.length > 1024 ? `<truncated>${filename.slice(-1024)}` : filename;
  const parts = splitPathRe.exec(truncated);
  return parts ? parts.slice(1) : [];
}
function dirname(path) {
  const result = splitPath(path);
  const root = result[0];
  let dir = result[1];
  if (!root && !dir) {
    return ".";
  }
  if (dir) {
    dir = dir.slice(0, dir.length - 1);
  }
  return root + dir;
}

// node_modules/@sentry/utils/esm/syncpromise.js
var States;
(function(States2) {
  const PENDING = 0;
  States2[States2["PENDING"] = PENDING] = "PENDING";
  const RESOLVED = 1;
  States2[States2["RESOLVED"] = RESOLVED] = "RESOLVED";
  const REJECTED = 2;
  States2[States2["REJECTED"] = REJECTED] = "REJECTED";
})(States || (States = {}));
function resolvedSyncPromise(value) {
  return new SyncPromise((resolve2) => {
    resolve2(value);
  });
}
function rejectedSyncPromise(reason) {
  return new SyncPromise((_, reject) => {
    reject(reason);
  });
}
var SyncPromise = class _SyncPromise {
  constructor(executor) {
    _SyncPromise.prototype.__init.call(this);
    _SyncPromise.prototype.__init2.call(this);
    _SyncPromise.prototype.__init3.call(this);
    _SyncPromise.prototype.__init4.call(this);
    this._state = States.PENDING;
    this._handlers = [];
    try {
      executor(this._resolve, this._reject);
    } catch (e2) {
      this._reject(e2);
    }
  }
  /** JSDoc */
  then(onfulfilled, onrejected) {
    return new _SyncPromise((resolve2, reject) => {
      this._handlers.push([
        false,
        (result) => {
          if (!onfulfilled) {
            resolve2(result);
          } else {
            try {
              resolve2(onfulfilled(result));
            } catch (e2) {
              reject(e2);
            }
          }
        },
        (reason) => {
          if (!onrejected) {
            reject(reason);
          } else {
            try {
              resolve2(onrejected(reason));
            } catch (e2) {
              reject(e2);
            }
          }
        }
      ]);
      this._executeHandlers();
    });
  }
  /** JSDoc */
  catch(onrejected) {
    return this.then((val) => val, onrejected);
  }
  /** JSDoc */
  finally(onfinally) {
    return new _SyncPromise((resolve2, reject) => {
      let val;
      let isRejected;
      return this.then(
        (value) => {
          isRejected = false;
          val = value;
          if (onfinally) {
            onfinally();
          }
        },
        (reason) => {
          isRejected = true;
          val = reason;
          if (onfinally) {
            onfinally();
          }
        }
      ).then(() => {
        if (isRejected) {
          reject(val);
          return;
        }
        resolve2(val);
      });
    });
  }
  /** JSDoc */
  __init() {
    this._resolve = (value) => {
      this._setResult(States.RESOLVED, value);
    };
  }
  /** JSDoc */
  __init2() {
    this._reject = (reason) => {
      this._setResult(States.REJECTED, reason);
    };
  }
  /** JSDoc */
  __init3() {
    this._setResult = (state, value) => {
      if (this._state !== States.PENDING) {
        return;
      }
      if (isThenable(value)) {
        void value.then(this._resolve, this._reject);
        return;
      }
      this._state = state;
      this._value = value;
      this._executeHandlers();
    };
  }
  /** JSDoc */
  __init4() {
    this._executeHandlers = () => {
      if (this._state === States.PENDING) {
        return;
      }
      const cachedHandlers = this._handlers.slice();
      this._handlers = [];
      cachedHandlers.forEach((handler) => {
        if (handler[0]) {
          return;
        }
        if (this._state === States.RESOLVED) {
          handler[1](this._value);
        }
        if (this._state === States.REJECTED) {
          handler[2](this._value);
        }
        handler[0] = true;
      });
    };
  }
};

// node_modules/@sentry/utils/esm/promisebuffer.js
function makePromiseBuffer(limit) {
  const buffer = [];
  function isReady() {
    return limit === void 0 || buffer.length < limit;
  }
  function remove(task) {
    return buffer.splice(buffer.indexOf(task), 1)[0];
  }
  function add(taskProducer) {
    if (!isReady()) {
      return rejectedSyncPromise(new SentryError("Not adding Promise because buffer limit was reached."));
    }
    const task = taskProducer();
    if (buffer.indexOf(task) === -1) {
      buffer.push(task);
    }
    void task.then(() => remove(task)).then(
      null,
      () => remove(task).then(null, () => {
      })
    );
    return task;
  }
  function drain(timeout) {
    return new SyncPromise((resolve2, reject) => {
      let counter = buffer.length;
      if (!counter) {
        return resolve2(true);
      }
      const capturedSetTimeout = setTimeout(() => {
        if (timeout && timeout > 0) {
          resolve2(false);
        }
      }, timeout);
      buffer.forEach((item) => {
        void resolvedSyncPromise(item).then(() => {
          if (!--counter) {
            clearTimeout(capturedSetTimeout);
            resolve2(true);
          }
        }, reject);
      });
    });
  }
  return {
    $: buffer,
    add,
    drain
  };
}

// node_modules/@sentry/utils/esm/cookie.js
function parseCookie(str) {
  const obj = {};
  let index = 0;
  while (index < str.length) {
    const eqIdx = str.indexOf("=", index);
    if (eqIdx === -1) {
      break;
    }
    let endIdx = str.indexOf(";", index);
    if (endIdx === -1) {
      endIdx = str.length;
    } else if (endIdx < eqIdx) {
      index = str.lastIndexOf(";", eqIdx - 1) + 1;
      continue;
    }
    const key = str.slice(index, eqIdx).trim();
    if (void 0 === obj[key]) {
      let val = str.slice(eqIdx + 1, endIdx).trim();
      if (val.charCodeAt(0) === 34) {
        val = val.slice(1, -1);
      }
      try {
        obj[key] = val.indexOf("%") !== -1 ? decodeURIComponent(val) : val;
      } catch (e2) {
        obj[key] = val;
      }
    }
    index = endIdx + 1;
  }
  return obj;
}

// node_modules/@sentry/utils/esm/url.js
function parseUrl(url) {
  if (!url) {
    return {};
  }
  const match = url.match(/^(([^:/?#]+):)?(\/\/([^/?#]*))?([^?#]*)(\?([^#]*))?(#(.*))?$/);
  if (!match) {
    return {};
  }
  const query = match[6] || "";
  const fragment = match[8] || "";
  return {
    host: match[4],
    path: match[5],
    protocol: match[2],
    search: query,
    hash: fragment,
    relative: match[5] + query + fragment
    // everything minus origin
  };
}
function stripUrlQueryAndFragment(urlPath) {
  return urlPath.split(/[\?#]/, 1)[0];
}
function getNumberOfUrlSegments(url) {
  return url.split(/\\?\//).filter((s2) => s2.length > 0 && s2 !== ",").length;
}
function getSanitizedUrlString(url) {
  const { protocol, host, path } = url;
  const filteredHost = host && host.replace(/^.*@/, "[filtered]:[filtered]@").replace(/(:80)$/, "").replace(/(:443)$/, "") || "";
  return `${protocol ? `${protocol}://` : ""}${filteredHost}${path}`;
}

// node_modules/@sentry/utils/esm/requestdata.js
var DEFAULT_INCLUDES = {
  ip: false,
  request: true,
  transaction: true,
  user: true
};
var DEFAULT_REQUEST_INCLUDES = ["cookies", "data", "headers", "method", "query_string", "url"];
var DEFAULT_USER_INCLUDES = ["id", "username", "email"];
function extractPathForTransaction(req, options = {}) {
  const method = req.method && req.method.toUpperCase();
  let path = "";
  let source = "url";
  if (options.customRoute || req.route) {
    path = options.customRoute || `${req.baseUrl || ""}${req.route && req.route.path}`;
    source = "route";
  } else if (req.originalUrl || req.url) {
    path = stripUrlQueryAndFragment(req.originalUrl || req.url || "");
  }
  let name = "";
  if (options.method && method) {
    name += method;
  }
  if (options.method && options.path) {
    name += " ";
  }
  if (options.path && path) {
    name += path;
  }
  return [name, source];
}
function extractTransaction(req, type) {
  switch (type) {
    case "path": {
      return extractPathForTransaction(req, { path: true })[0];
    }
    case "handler": {
      return req.route && req.route.stack && req.route.stack[0] && req.route.stack[0].name || "<anonymous>";
    }
    case "methodPath":
    default: {
      const customRoute = req._reconstructedRoute ? req._reconstructedRoute : void 0;
      return extractPathForTransaction(req, { path: true, method: true, customRoute })[0];
    }
  }
}
function extractUserData(user, keys) {
  const extractedUser = {};
  const attributes = Array.isArray(keys) ? keys : DEFAULT_USER_INCLUDES;
  attributes.forEach((key) => {
    if (user && key in user) {
      extractedUser[key] = user[key];
    }
  });
  return extractedUser;
}
function extractRequestData(req, options) {
  const { include = DEFAULT_REQUEST_INCLUDES, deps } = options || {};
  const requestData = {};
  const headers = req.headers || {};
  const method = req.method;
  const host = headers.host || req.hostname || req.host || "<no host>";
  const protocol = req.protocol === "https" || req.socket && req.socket.encrypted ? "https" : "http";
  const originalUrl = req.originalUrl || req.url || "";
  const absoluteUrl = originalUrl.startsWith(protocol) ? originalUrl : `${protocol}://${host}${originalUrl}`;
  include.forEach((key) => {
    switch (key) {
      case "headers": {
        requestData.headers = headers;
        if (!include.includes("cookies")) {
          delete requestData.headers.cookie;
        }
        break;
      }
      case "method": {
        requestData.method = method;
        break;
      }
      case "url": {
        requestData.url = absoluteUrl;
        break;
      }
      case "cookies": {
        requestData.cookies = // TODO (v8 / #5257): We're only sending the empty object for backwards compatibility, so the last bit can
        // come off in v8
        req.cookies || headers.cookie && parseCookie(headers.cookie) || {};
        break;
      }
      case "query_string": {
        requestData.query_string = extractQueryParams(req, deps);
        break;
      }
      case "data": {
        if (method === "GET" || method === "HEAD") {
          break;
        }
        if (req.body !== void 0) {
          requestData.data = isString(req.body) ? req.body : JSON.stringify(normalize(req.body));
        }
        break;
      }
      default: {
        if ({}.hasOwnProperty.call(req, key)) {
          requestData[key] = req[key];
        }
      }
    }
  });
  return requestData;
}
function addRequestDataToEvent(event, req, options) {
  const include = {
    ...DEFAULT_INCLUDES,
    ...options && options.include
  };
  if (include.request) {
    const extractedRequestData = Array.isArray(include.request) ? extractRequestData(req, { include: include.request, deps: options && options.deps }) : extractRequestData(req, { deps: options && options.deps });
    event.request = {
      ...event.request,
      ...extractedRequestData
    };
  }
  if (include.user) {
    const extractedUser = req.user && isPlainObject(req.user) ? extractUserData(req.user, include.user) : {};
    if (Object.keys(extractedUser).length) {
      event.user = {
        ...event.user,
        ...extractedUser
      };
    }
  }
  if (include.ip) {
    const ip = req.ip || req.socket && req.socket.remoteAddress;
    if (ip) {
      event.user = {
        ...event.user,
        ip_address: ip
      };
    }
  }
  if (include.transaction && !event.transaction) {
    event.transaction = extractTransaction(req, include.transaction);
  }
  return event;
}
function extractQueryParams(req, deps) {
  let originalUrl = req.originalUrl || req.url || "";
  if (!originalUrl) {
    return;
  }
  if (originalUrl.startsWith("/")) {
    originalUrl = `http://dogs.are.great${originalUrl}`;
  }
  try {
    return req.query || typeof URL !== "undefined" && new URL(originalUrl).search.slice(1) || // In Node 8, `URL` isn't in the global scope, so we have to use the built-in module from Node
    deps && deps.url && deps.url.parse(originalUrl).query || void 0;
  } catch (e2) {
    return void 0;
  }
}

// node_modules/@sentry/utils/esm/severity.js
var validSeverityLevels = ["fatal", "error", "warning", "log", "info", "debug"];
function severityLevelFromString(level) {
  return level === "warn" ? "warning" : validSeverityLevels.includes(level) ? level : "log";
}

// node_modules/@sentry/utils/esm/time.js
var ONE_SECOND_IN_MS = 1e3;
function dateTimestampInSeconds() {
  return Date.now() / ONE_SECOND_IN_MS;
}
function createUnixTimestampInSecondsFunc() {
  const { performance } = GLOBAL_OBJ;
  if (!performance || !performance.now) {
    return dateTimestampInSeconds;
  }
  const approxStartingTimeOrigin = Date.now() - performance.now();
  const timeOrigin = performance.timeOrigin == void 0 ? approxStartingTimeOrigin : performance.timeOrigin;
  return () => {
    return (timeOrigin + performance.now()) / ONE_SECOND_IN_MS;
  };
}
var timestampInSeconds = createUnixTimestampInSecondsFunc();
var _browserPerformanceTimeOriginMode;
var browserPerformanceTimeOrigin = (() => {
  const { performance } = GLOBAL_OBJ;
  if (!performance || !performance.now) {
    _browserPerformanceTimeOriginMode = "none";
    return void 0;
  }
  const threshold = 3600 * 1e3;
  const performanceNow = performance.now();
  const dateNow = Date.now();
  const timeOriginDelta = performance.timeOrigin ? Math.abs(performance.timeOrigin + performanceNow - dateNow) : threshold;
  const timeOriginIsReliable = timeOriginDelta < threshold;
  const navigationStart = performance.timing && performance.timing.navigationStart;
  const hasNavigationStart = typeof navigationStart === "number";
  const navigationStartDelta = hasNavigationStart ? Math.abs(navigationStart + performanceNow - dateNow) : threshold;
  const navigationStartIsReliable = navigationStartDelta < threshold;
  if (timeOriginIsReliable || navigationStartIsReliable) {
    if (timeOriginDelta <= navigationStartDelta) {
      _browserPerformanceTimeOriginMode = "timeOrigin";
      return performance.timeOrigin;
    } else {
      _browserPerformanceTimeOriginMode = "navigationStart";
      return navigationStart;
    }
  }
  _browserPerformanceTimeOriginMode = "dateNow";
  return dateNow;
})();

// node_modules/@sentry/utils/esm/baggage.js
var SENTRY_BAGGAGE_KEY_PREFIX = "sentry-";
var SENTRY_BAGGAGE_KEY_PREFIX_REGEX = /^sentry-/;
var MAX_BAGGAGE_STRING_LENGTH = 8192;
function baggageHeaderToDynamicSamplingContext(baggageHeader) {
  if (!isString(baggageHeader) && !Array.isArray(baggageHeader)) {
    return void 0;
  }
  let baggageObject = {};
  if (Array.isArray(baggageHeader)) {
    baggageObject = baggageHeader.reduce((acc, curr) => {
      const currBaggageObject = baggageHeaderToObject(curr);
      for (const key of Object.keys(currBaggageObject)) {
        acc[key] = currBaggageObject[key];
      }
      return acc;
    }, {});
  } else {
    if (!baggageHeader) {
      return void 0;
    }
    baggageObject = baggageHeaderToObject(baggageHeader);
  }
  const dynamicSamplingContext = Object.entries(baggageObject).reduce((acc, [key, value]) => {
    if (key.match(SENTRY_BAGGAGE_KEY_PREFIX_REGEX)) {
      const nonPrefixedKey = key.slice(SENTRY_BAGGAGE_KEY_PREFIX.length);
      acc[nonPrefixedKey] = value;
    }
    return acc;
  }, {});
  if (Object.keys(dynamicSamplingContext).length > 0) {
    return dynamicSamplingContext;
  } else {
    return void 0;
  }
}
function dynamicSamplingContextToSentryBaggageHeader(dynamicSamplingContext) {
  if (!dynamicSamplingContext) {
    return void 0;
  }
  const sentryPrefixedDSC = Object.entries(dynamicSamplingContext).reduce(
    (acc, [dscKey, dscValue]) => {
      if (dscValue) {
        acc[`${SENTRY_BAGGAGE_KEY_PREFIX}${dscKey}`] = dscValue;
      }
      return acc;
    },
    {}
  );
  return objectToBaggageHeader(sentryPrefixedDSC);
}
function baggageHeaderToObject(baggageHeader) {
  return baggageHeader.split(",").map((baggageEntry) => baggageEntry.split("=").map((keyOrValue) => decodeURIComponent(keyOrValue.trim()))).reduce((acc, [key, value]) => {
    acc[key] = value;
    return acc;
  }, {});
}
function objectToBaggageHeader(object) {
  if (Object.keys(object).length === 0) {
    return void 0;
  }
  return Object.entries(object).reduce((baggageHeader, [objectKey, objectValue], currentIndex) => {
    const baggageEntry = `${encodeURIComponent(objectKey)}=${encodeURIComponent(objectValue)}`;
    const newBaggageHeader = currentIndex === 0 ? baggageEntry : `${baggageHeader},${baggageEntry}`;
    if (newBaggageHeader.length > MAX_BAGGAGE_STRING_LENGTH) {
      DEBUG_BUILD && logger.warn(
        `Not adding key: ${objectKey} with val: ${objectValue} to baggage header due to exceeding baggage size limits.`
      );
      return baggageHeader;
    } else {
      return newBaggageHeader;
    }
  }, "");
}

// node_modules/@sentry/utils/esm/tracing.js
var TRACEPARENT_REGEXP = new RegExp(
  "^[ \\t]*([0-9a-f]{32})?-?([0-9a-f]{16})?-?([01])?[ \\t]*$"
  // whitespace
);
function extractTraceparentData(traceparent) {
  if (!traceparent) {
    return void 0;
  }
  const matches = traceparent.match(TRACEPARENT_REGEXP);
  if (!matches) {
    return void 0;
  }
  let parentSampled;
  if (matches[3] === "1") {
    parentSampled = true;
  } else if (matches[3] === "0") {
    parentSampled = false;
  }
  return {
    traceId: matches[1],
    parentSampled,
    parentSpanId: matches[2]
  };
}
function tracingContextFromHeaders(sentryTrace, baggage) {
  const traceparentData = extractTraceparentData(sentryTrace);
  const dynamicSamplingContext = baggageHeaderToDynamicSamplingContext(baggage);
  const { traceId, parentSpanId, parentSampled } = traceparentData || {};
  if (!traceparentData) {
    return {
      traceparentData,
      dynamicSamplingContext: void 0,
      propagationContext: {
        traceId: traceId || uuid4(),
        spanId: uuid4().substring(16)
      }
    };
  } else {
    return {
      traceparentData,
      dynamicSamplingContext: dynamicSamplingContext || {},
      // If we have traceparent data but no DSC it means we are not head of trace and we must freeze it
      propagationContext: {
        traceId: traceId || uuid4(),
        parentSpanId: parentSpanId || uuid4().substring(16),
        spanId: uuid4().substring(16),
        sampled: parentSampled,
        dsc: dynamicSamplingContext || {}
        // If we have traceparent data but no DSC it means we are not head of trace and we must freeze it
      }
    };
  }
}
function generateSentryTraceHeader(traceId = uuid4(), spanId = uuid4().substring(16), sampled) {
  let sampledString = "";
  if (sampled !== void 0) {
    sampledString = sampled ? "-1" : "-0";
  }
  return `${traceId}-${spanId}${sampledString}`;
}

// node_modules/@sentry/utils/esm/envelope.js
function createEnvelope(headers, items = []) {
  return [headers, items];
}
function forEachEnvelopeItem(envelope, callback) {
  const envelopeItems = envelope[1];
  for (const envelopeItem of envelopeItems) {
    const envelopeItemType = envelopeItem[0].type;
    const result = callback(envelopeItem, envelopeItemType);
    if (result) {
      return true;
    }
  }
  return false;
}
function encodeUTF8(input, textEncoder) {
  const utf8 = textEncoder || new TextEncoder();
  return utf8.encode(input);
}
function serializeEnvelope(envelope, textEncoder) {
  const [envHeaders, items] = envelope;
  let parts = JSON.stringify(envHeaders);
  function append(next) {
    if (typeof parts === "string") {
      parts = typeof next === "string" ? parts + next : [encodeUTF8(parts, textEncoder), next];
    } else {
      parts.push(typeof next === "string" ? encodeUTF8(next, textEncoder) : next);
    }
  }
  for (const item of items) {
    const [itemHeaders, payload] = item;
    append(`
${JSON.stringify(itemHeaders)}
`);
    if (typeof payload === "string" || payload instanceof Uint8Array) {
      append(payload);
    } else {
      let stringifiedPayload;
      try {
        stringifiedPayload = JSON.stringify(payload);
      } catch (e2) {
        stringifiedPayload = JSON.stringify(normalize(payload));
      }
      append(stringifiedPayload);
    }
  }
  return typeof parts === "string" ? parts : concatBuffers(parts);
}
function concatBuffers(buffers) {
  const totalLength = buffers.reduce((acc, buf) => acc + buf.length, 0);
  const merged = new Uint8Array(totalLength);
  let offset = 0;
  for (const buffer of buffers) {
    merged.set(buffer, offset);
    offset += buffer.length;
  }
  return merged;
}
var ITEM_TYPE_TO_DATA_CATEGORY_MAP = {
  session: "session",
  sessions: "session",
  attachment: "attachment",
  transaction: "transaction",
  event: "error",
  client_report: "internal",
  user_report: "default",
  profile: "profile",
  replay_event: "replay",
  replay_recording: "replay",
  check_in: "monitor",
  feedback: "feedback",
  // TODO: This is a temporary workaround until we have a proper data category for metrics
  statsd: "unknown"
};
function envelopeItemTypeToDataCategory(type) {
  return ITEM_TYPE_TO_DATA_CATEGORY_MAP[type];
}

// node_modules/@sentry/utils/esm/ratelimit.js
var DEFAULT_RETRY_AFTER = 60 * 1e3;
function parseRetryAfterHeader(header, now = Date.now()) {
  const headerDelay = parseInt(`${header}`, 10);
  if (!isNaN(headerDelay)) {
    return headerDelay * 1e3;
  }
  const headerDate = Date.parse(`${header}`);
  if (!isNaN(headerDate)) {
    return headerDate - now;
  }
  return DEFAULT_RETRY_AFTER;
}
function disabledUntil(limits, category) {
  return limits[category] || limits.all || 0;
}
function isRateLimited(limits, category, now = Date.now()) {
  return disabledUntil(limits, category) > now;
}
function updateRateLimits(limits, { statusCode, headers }, now = Date.now()) {
  const updatedRateLimits = {
    ...limits
  };
  const rateLimitHeader = headers && headers["x-sentry-rate-limits"];
  const retryAfterHeader = headers && headers["retry-after"];
  if (rateLimitHeader) {
    for (const limit of rateLimitHeader.trim().split(",")) {
      const [retryAfter, categories] = limit.split(":", 2);
      const headerDelay = parseInt(retryAfter, 10);
      const delay = (!isNaN(headerDelay) ? headerDelay : 60) * 1e3;
      if (!categories) {
        updatedRateLimits.all = now + delay;
      } else {
        for (const category of categories.split(";")) {
          updatedRateLimits[category] = now + delay;
        }
      }
    }
  } else if (retryAfterHeader) {
    updatedRateLimits.all = now + parseRetryAfterHeader(retryAfterHeader, now);
  } else if (statusCode === 429) {
    updatedRateLimits.all = now + 60 * 1e3;
  }
  return updatedRateLimits;
}

// node_modules/@sentry/utils/esm/eventbuilder.js
function parseStackFrames(stackParser, error) {
  return stackParser(error.stack || "", 1);
}
function exceptionFromError(stackParser, error) {
  const exception = {
    type: error.name || error.constructor.name,
    value: error.message
  };
  const frames = parseStackFrames(stackParser, error);
  if (frames.length) {
    exception.stacktrace = { frames };
  }
  return exception;
}

// node_modules/@sentry/utils/esm/lru.js
var LRUMap = class {
  constructor(_maxSize) {
    this._maxSize = _maxSize;
    this._cache = /* @__PURE__ */ new Map();
  }
  /** Get the current size of the cache */
  get size() {
    return this._cache.size;
  }
  /** Get an entry or undefined if it was not in the cache. Re-inserts to update the recently used order */
  get(key) {
    const value = this._cache.get(key);
    if (value === void 0) {
      return void 0;
    }
    this._cache.delete(key);
    this._cache.set(key, value);
    return value;
  }
  /** Insert an entry and evict an older entry if we've reached maxSize */
  set(key, value) {
    if (this._cache.size >= this._maxSize) {
      this._cache.delete(this._cache.keys().next().value);
    }
    this._cache.set(key, value);
  }
  /** Remove an entry and return the entry if it was in the cache */
  remove(key) {
    const value = this._cache.get(key);
    if (value) {
      this._cache.delete(key);
    }
    return value;
  }
  /** Clear all entries */
  clear() {
    this._cache.clear();
  }
  /** Get all the keys */
  keys() {
    return Array.from(this._cache.keys());
  }
  /** Get all the values */
  values() {
    const values = [];
    this._cache.forEach((value) => values.push(value));
    return values;
  }
};

// node_modules/@sentry/utils/esm/buildPolyfills/_nullishCoalesce.js
function _nullishCoalesce(lhs, rhsFn) {
  return lhs != null ? lhs : rhsFn();
}

// node_modules/@sentry/utils/esm/buildPolyfills/_optionalChain.js
function _optionalChain(ops) {
  let lastAccessLHS = void 0;
  let value = ops[0];
  let i2 = 1;
  while (i2 < ops.length) {
    const op = ops[i2];
    const fn = ops[i2 + 1];
    i2 += 2;
    if ((op === "optionalAccess" || op === "optionalCall") && value == null) {
      return;
    }
    if (op === "access" || op === "optionalAccess") {
      lastAccessLHS = value;
      value = fn(value);
    } else if (op === "call" || op === "optionalCall") {
      value = fn((...args) => value.call(lastAccessLHS, ...args));
      lastAccessLHS = void 0;
    }
  }
  return value;
}

// node_modules/@sentry/utils/esm/buildPolyfills/_optionalChainDelete.js
function _optionalChainDelete(ops) {
  const result = _optionalChain(ops);
  return result == null ? true : result;
}

// node_modules/@sentry/core/esm/debug-build.js
var DEBUG_BUILD2 = typeof __SENTRY_DEBUG__ === "undefined" || __SENTRY_DEBUG__;

// node_modules/@sentry/core/esm/constants.js
var DEFAULT_ENVIRONMENT = "production";

// node_modules/@sentry/core/esm/eventProcessors.js
function getGlobalEventProcessors() {
  return getGlobalSingleton("globalEventProcessors", () => []);
}
function notifyEventProcessors(processors, event, hint, index = 0) {
  return new SyncPromise((resolve2, reject) => {
    const processor = processors[index];
    if (event === null || typeof processor !== "function") {
      resolve2(event);
    } else {
      const result = processor({ ...event }, hint);
      DEBUG_BUILD2 && processor.id && result === null && logger.log(`Event processor "${processor.id}" dropped event`);
      if (isThenable(result)) {
        void result.then((final) => notifyEventProcessors(processors, final, hint, index + 1).then(resolve2)).then(null, reject);
      } else {
        void notifyEventProcessors(processors, result, hint, index + 1).then(resolve2).then(null, reject);
      }
    }
  });
}

// node_modules/@sentry/core/esm/session.js
function makeSession(context) {
  const startingTime = timestampInSeconds();
  const session = {
    sid: uuid4(),
    init: true,
    timestamp: startingTime,
    started: startingTime,
    duration: 0,
    status: "ok",
    errors: 0,
    ignoreDuration: false,
    toJSON: () => sessionToJSON(session)
  };
  if (context) {
    updateSession(session, context);
  }
  return session;
}
function updateSession(session, context = {}) {
  if (context.user) {
    if (!session.ipAddress && context.user.ip_address) {
      session.ipAddress = context.user.ip_address;
    }
    if (!session.did && !context.did) {
      session.did = context.user.id || context.user.email || context.user.username;
    }
  }
  session.timestamp = context.timestamp || timestampInSeconds();
  if (context.abnormal_mechanism) {
    session.abnormal_mechanism = context.abnormal_mechanism;
  }
  if (context.ignoreDuration) {
    session.ignoreDuration = context.ignoreDuration;
  }
  if (context.sid) {
    session.sid = context.sid.length === 32 ? context.sid : uuid4();
  }
  if (context.init !== void 0) {
    session.init = context.init;
  }
  if (!session.did && context.did) {
    session.did = `${context.did}`;
  }
  if (typeof context.started === "number") {
    session.started = context.started;
  }
  if (session.ignoreDuration) {
    session.duration = void 0;
  } else if (typeof context.duration === "number") {
    session.duration = context.duration;
  } else {
    const duration = session.timestamp - session.started;
    session.duration = duration >= 0 ? duration : 0;
  }
  if (context.release) {
    session.release = context.release;
  }
  if (context.environment) {
    session.environment = context.environment;
  }
  if (!session.ipAddress && context.ipAddress) {
    session.ipAddress = context.ipAddress;
  }
  if (!session.userAgent && context.userAgent) {
    session.userAgent = context.userAgent;
  }
  if (typeof context.errors === "number") {
    session.errors = context.errors;
  }
  if (context.status) {
    session.status = context.status;
  }
}
function closeSession(session, status) {
  let context = {};
  if (status) {
    context = { status };
  } else if (session.status === "ok") {
    context = { status: "exited" };
  }
  updateSession(session, context);
}
function sessionToJSON(session) {
  return dropUndefinedKeys({
    sid: `${session.sid}`,
    init: session.init,
    // Make sure that sec is converted to ms for date constructor
    started: new Date(session.started * 1e3).toISOString(),
    timestamp: new Date(session.timestamp * 1e3).toISOString(),
    status: session.status,
    errors: session.errors,
    did: typeof session.did === "number" || typeof session.did === "string" ? `${session.did}` : void 0,
    duration: session.duration,
    abnormal_mechanism: session.abnormal_mechanism,
    attrs: {
      release: session.release,
      environment: session.environment,
      ip_address: session.ipAddress,
      user_agent: session.userAgent
    }
  });
}

// node_modules/@sentry/core/esm/utils/spanUtils.js
var TRACE_FLAG_SAMPLED = 1;
function spanToTraceContext(span) {
  const { spanId: span_id, traceId: trace_id } = span.spanContext();
  const { data, op, parent_span_id, status, tags, origin } = spanToJSON(span);
  return dropUndefinedKeys({
    data,
    op,
    parent_span_id,
    span_id,
    status,
    tags,
    trace_id,
    origin
  });
}
function spanToTraceHeader(span) {
  const { traceId, spanId } = span.spanContext();
  const sampled = spanIsSampled(span);
  return generateSentryTraceHeader(traceId, spanId, sampled);
}
function spanTimeInputToSeconds(input) {
  if (typeof input === "number") {
    return ensureTimestampInSeconds(input);
  }
  if (Array.isArray(input)) {
    return input[0] + input[1] / 1e9;
  }
  if (input instanceof Date) {
    return ensureTimestampInSeconds(input.getTime());
  }
  return timestampInSeconds();
}
function ensureTimestampInSeconds(timestamp) {
  const isMs = timestamp > 9999999999;
  return isMs ? timestamp / 1e3 : timestamp;
}
function spanToJSON(span) {
  if (spanIsSpanClass(span)) {
    return span.getSpanJSON();
  }
  if (typeof span.toJSON === "function") {
    return span.toJSON();
  }
  return {};
}
function spanIsSpanClass(span) {
  return typeof span.getSpanJSON === "function";
}
function spanIsSampled(span) {
  const { traceFlags } = span.spanContext();
  return Boolean(traceFlags & TRACE_FLAG_SAMPLED);
}

// node_modules/@sentry/core/esm/utils/prepareEvent.js
function parseEventHintOrCaptureContext(hint) {
  if (!hint) {
    return void 0;
  }
  if (hintIsScopeOrFunction(hint)) {
    return { captureContext: hint };
  }
  if (hintIsScopeContext(hint)) {
    return {
      captureContext: hint
    };
  }
  return hint;
}
function hintIsScopeOrFunction(hint) {
  return hint instanceof Scope || typeof hint === "function";
}
var captureContextKeys = [
  "user",
  "level",
  "extra",
  "contexts",
  "tags",
  "fingerprint",
  "requestSession",
  "propagationContext"
];
function hintIsScopeContext(hint) {
  return Object.keys(hint).some((key) => captureContextKeys.includes(key));
}

// node_modules/@sentry/core/esm/exports.js
function captureException(exception, hint) {
  return getCurrentHub().captureException(exception, parseEventHintOrCaptureContext(hint));
}
function addBreadcrumb(breadcrumb, hint) {
  getCurrentHub().addBreadcrumb(breadcrumb, hint);
}
function withScope(...rest) {
  const hub = getCurrentHub();
  if (rest.length === 2) {
    const [scope, callback] = rest;
    if (!scope) {
      return hub.withScope(callback);
    }
    return hub.withScope(() => {
      hub.getStackTop().scope = scope;
      return callback(scope);
    });
  }
  return hub.withScope(rest[0]);
}
function startTransaction(context, customSamplingContext) {
  return getCurrentHub().startTransaction({ ...context }, customSamplingContext);
}
function getClient() {
  return getCurrentHub().getClient();
}
function getCurrentScope() {
  return getCurrentHub().getScope();
}

// node_modules/@sentry/core/esm/utils/getRootSpan.js
function getRootSpan(span) {
  return span.transaction;
}

// node_modules/@sentry/core/esm/tracing/dynamicSamplingContext.js
function getDynamicSamplingContextFromClient(trace_id, client, scope) {
  const options = client.getOptions();
  const { publicKey: public_key } = client.getDsn() || {};
  const { segment: user_segment } = scope && scope.getUser() || {};
  const dsc = dropUndefinedKeys({
    environment: options.environment || DEFAULT_ENVIRONMENT,
    release: options.release,
    user_segment,
    public_key,
    trace_id
  });
  client.emit && client.emit("createDsc", dsc);
  return dsc;
}
function getDynamicSamplingContextFromSpan(span) {
  const client = getClient();
  if (!client) {
    return {};
  }
  const dsc = getDynamicSamplingContextFromClient(spanToJSON(span).trace_id || "", client, getCurrentScope());
  const txn = getRootSpan(span);
  if (!txn) {
    return dsc;
  }
  const v7FrozenDsc = txn && txn._frozenDynamicSamplingContext;
  if (v7FrozenDsc) {
    return v7FrozenDsc;
  }
  const { sampleRate: maybeSampleRate, source } = txn.metadata;
  if (maybeSampleRate != null) {
    dsc.sample_rate = `${maybeSampleRate}`;
  }
  const jsonSpan = spanToJSON(txn);
  if (source && source !== "url") {
    dsc.transaction = jsonSpan.description;
  }
  dsc.sampled = String(spanIsSampled(txn));
  client.emit && client.emit("createDsc", dsc);
  return dsc;
}

// node_modules/@sentry/core/esm/utils/applyScopeDataToEvent.js
function applyScopeDataToEvent(event, data) {
  const { fingerprint, span, breadcrumbs, sdkProcessingMetadata } = data;
  applyDataToEvent(event, data);
  if (span) {
    applySpanToEvent(event, span);
  }
  applyFingerprintToEvent(event, fingerprint);
  applyBreadcrumbsToEvent(event, breadcrumbs);
  applySdkMetadataToEvent(event, sdkProcessingMetadata);
}
function applyDataToEvent(event, data) {
  const {
    extra,
    tags,
    user,
    contexts,
    level,
    // eslint-disable-next-line deprecation/deprecation
    transactionName
  } = data;
  const cleanedExtra = dropUndefinedKeys(extra);
  if (cleanedExtra && Object.keys(cleanedExtra).length) {
    event.extra = { ...cleanedExtra, ...event.extra };
  }
  const cleanedTags = dropUndefinedKeys(tags);
  if (cleanedTags && Object.keys(cleanedTags).length) {
    event.tags = { ...cleanedTags, ...event.tags };
  }
  const cleanedUser = dropUndefinedKeys(user);
  if (cleanedUser && Object.keys(cleanedUser).length) {
    event.user = { ...cleanedUser, ...event.user };
  }
  const cleanedContexts = dropUndefinedKeys(contexts);
  if (cleanedContexts && Object.keys(cleanedContexts).length) {
    event.contexts = { ...cleanedContexts, ...event.contexts };
  }
  if (level) {
    event.level = level;
  }
  if (transactionName) {
    event.transaction = transactionName;
  }
}
function applyBreadcrumbsToEvent(event, breadcrumbs) {
  const mergedBreadcrumbs = [...event.breadcrumbs || [], ...breadcrumbs];
  event.breadcrumbs = mergedBreadcrumbs.length ? mergedBreadcrumbs : void 0;
}
function applySdkMetadataToEvent(event, sdkProcessingMetadata) {
  event.sdkProcessingMetadata = {
    ...event.sdkProcessingMetadata,
    ...sdkProcessingMetadata
  };
}
function applySpanToEvent(event, span) {
  event.contexts = { trace: spanToTraceContext(span), ...event.contexts };
  const rootSpan = getRootSpan(span);
  if (rootSpan) {
    event.sdkProcessingMetadata = {
      dynamicSamplingContext: getDynamicSamplingContextFromSpan(span),
      ...event.sdkProcessingMetadata
    };
    const transactionName = spanToJSON(rootSpan).description;
    if (transactionName) {
      event.tags = { transaction: transactionName, ...event.tags };
    }
  }
}
function applyFingerprintToEvent(event, fingerprint) {
  event.fingerprint = event.fingerprint ? arrayify(event.fingerprint) : [];
  if (fingerprint) {
    event.fingerprint = event.fingerprint.concat(fingerprint);
  }
  if (event.fingerprint && !event.fingerprint.length) {
    delete event.fingerprint;
  }
}

// node_modules/@sentry/core/esm/scope.js
var DEFAULT_MAX_BREADCRUMBS = 100;
var Scope = class _Scope {
  /** Flag if notifying is happening. */
  /** Callback for client to receive scope changes. */
  /** Callback list that will be called after {@link applyToEvent}. */
  /** Array of breadcrumbs. */
  /** User */
  /** Tags */
  /** Extra */
  /** Contexts */
  /** Attachments */
  /** Propagation Context for distributed tracing */
  /**
   * A place to stash data which is needed at some point in the SDK's event processing pipeline but which shouldn't get
   * sent to Sentry
   */
  /** Fingerprint */
  /** Severity */
  // eslint-disable-next-line deprecation/deprecation
  /**
   * Transaction Name
   */
  /** Span */
  /** Session */
  /** Request Mode Session Status */
  /** The client on this scope */
  // NOTE: Any field which gets added here should get added not only to the constructor but also to the `clone` method.
  constructor() {
    this._notifyingListeners = false;
    this._scopeListeners = [];
    this._eventProcessors = [];
    this._breadcrumbs = [];
    this._attachments = [];
    this._user = {};
    this._tags = {};
    this._extra = {};
    this._contexts = {};
    this._sdkProcessingMetadata = {};
    this._propagationContext = generatePropagationContext();
  }
  /**
   * Inherit values from the parent scope.
   * @deprecated Use `scope.clone()` and `new Scope()` instead.
   */
  static clone(scope) {
    return scope ? scope.clone() : new _Scope();
  }
  /**
   * Clone this scope instance.
   */
  clone() {
    const newScope = new _Scope();
    newScope._breadcrumbs = [...this._breadcrumbs];
    newScope._tags = { ...this._tags };
    newScope._extra = { ...this._extra };
    newScope._contexts = { ...this._contexts };
    newScope._user = this._user;
    newScope._level = this._level;
    newScope._span = this._span;
    newScope._session = this._session;
    newScope._transactionName = this._transactionName;
    newScope._fingerprint = this._fingerprint;
    newScope._eventProcessors = [...this._eventProcessors];
    newScope._requestSession = this._requestSession;
    newScope._attachments = [...this._attachments];
    newScope._sdkProcessingMetadata = { ...this._sdkProcessingMetadata };
    newScope._propagationContext = { ...this._propagationContext };
    newScope._client = this._client;
    return newScope;
  }
  /** Update the client on the scope. */
  setClient(client) {
    this._client = client;
  }
  /**
   * Get the client assigned to this scope.
   *
   * It is generally recommended to use the global function `Sentry.getClient()` instead, unless you know what you are doing.
   */
  getClient() {
    return this._client;
  }
  /**
   * Add internal on change listener. Used for sub SDKs that need to store the scope.
   * @hidden
   */
  addScopeListener(callback) {
    this._scopeListeners.push(callback);
  }
  /**
   * @inheritDoc
   */
  addEventProcessor(callback) {
    this._eventProcessors.push(callback);
    return this;
  }
  /**
   * @inheritDoc
   */
  setUser(user) {
    this._user = user || {
      email: void 0,
      id: void 0,
      ip_address: void 0,
      segment: void 0,
      username: void 0
    };
    if (this._session) {
      updateSession(this._session, { user });
    }
    this._notifyScopeListeners();
    return this;
  }
  /**
   * @inheritDoc
   */
  getUser() {
    return this._user;
  }
  /**
   * @inheritDoc
   */
  getRequestSession() {
    return this._requestSession;
  }
  /**
   * @inheritDoc
   */
  setRequestSession(requestSession) {
    this._requestSession = requestSession;
    return this;
  }
  /**
   * @inheritDoc
   */
  setTags(tags) {
    this._tags = {
      ...this._tags,
      ...tags
    };
    this._notifyScopeListeners();
    return this;
  }
  /**
   * @inheritDoc
   */
  setTag(key, value) {
    this._tags = { ...this._tags, [key]: value };
    this._notifyScopeListeners();
    return this;
  }
  /**
   * @inheritDoc
   */
  setExtras(extras) {
    this._extra = {
      ...this._extra,
      ...extras
    };
    this._notifyScopeListeners();
    return this;
  }
  /**
   * @inheritDoc
   */
  setExtra(key, extra) {
    this._extra = { ...this._extra, [key]: extra };
    this._notifyScopeListeners();
    return this;
  }
  /**
   * @inheritDoc
   */
  setFingerprint(fingerprint) {
    this._fingerprint = fingerprint;
    this._notifyScopeListeners();
    return this;
  }
  /**
   * @inheritDoc
   */
  setLevel(level) {
    this._level = level;
    this._notifyScopeListeners();
    return this;
  }
  /**
   * Sets the transaction name on the scope for future events.
   * @deprecated Use extra or tags instead.
   */
  setTransactionName(name) {
    this._transactionName = name;
    this._notifyScopeListeners();
    return this;
  }
  /**
   * @inheritDoc
   */
  setContext(key, context) {
    if (context === null) {
      delete this._contexts[key];
    } else {
      this._contexts[key] = context;
    }
    this._notifyScopeListeners();
    return this;
  }
  /**
   * Sets the Span on the scope.
   * @param span Span
   * @deprecated Instead of setting a span on a scope, use `startSpan()`/`startSpanManual()` instead.
   */
  setSpan(span) {
    this._span = span;
    this._notifyScopeListeners();
    return this;
  }
  /**
   * Returns the `Span` if there is one.
   * @deprecated Use `getActiveSpan()` instead.
   */
  getSpan() {
    return this._span;
  }
  /**
   * Returns the `Transaction` attached to the scope (if there is one).
   * @deprecated You should not rely on the transaction, but just use `startSpan()` APIs instead.
   */
  getTransaction() {
    const span = this._span;
    return span && span.transaction;
  }
  /**
   * @inheritDoc
   */
  setSession(session) {
    if (!session) {
      delete this._session;
    } else {
      this._session = session;
    }
    this._notifyScopeListeners();
    return this;
  }
  /**
   * @inheritDoc
   */
  getSession() {
    return this._session;
  }
  /**
   * @inheritDoc
   */
  update(captureContext) {
    if (!captureContext) {
      return this;
    }
    if (typeof captureContext === "function") {
      const updatedScope = captureContext(this);
      return updatedScope instanceof _Scope ? updatedScope : this;
    }
    if (captureContext instanceof _Scope) {
      this._tags = { ...this._tags, ...captureContext._tags };
      this._extra = { ...this._extra, ...captureContext._extra };
      this._contexts = { ...this._contexts, ...captureContext._contexts };
      if (captureContext._user && Object.keys(captureContext._user).length) {
        this._user = captureContext._user;
      }
      if (captureContext._level) {
        this._level = captureContext._level;
      }
      if (captureContext._fingerprint) {
        this._fingerprint = captureContext._fingerprint;
      }
      if (captureContext._requestSession) {
        this._requestSession = captureContext._requestSession;
      }
      if (captureContext._propagationContext) {
        this._propagationContext = captureContext._propagationContext;
      }
    } else if (isPlainObject(captureContext)) {
      captureContext = captureContext;
      this._tags = { ...this._tags, ...captureContext.tags };
      this._extra = { ...this._extra, ...captureContext.extra };
      this._contexts = { ...this._contexts, ...captureContext.contexts };
      if (captureContext.user) {
        this._user = captureContext.user;
      }
      if (captureContext.level) {
        this._level = captureContext.level;
      }
      if (captureContext.fingerprint) {
        this._fingerprint = captureContext.fingerprint;
      }
      if (captureContext.requestSession) {
        this._requestSession = captureContext.requestSession;
      }
      if (captureContext.propagationContext) {
        this._propagationContext = captureContext.propagationContext;
      }
    }
    return this;
  }
  /**
   * @inheritDoc
   */
  clear() {
    this._breadcrumbs = [];
    this._tags = {};
    this._extra = {};
    this._user = {};
    this._contexts = {};
    this._level = void 0;
    this._transactionName = void 0;
    this._fingerprint = void 0;
    this._requestSession = void 0;
    this._span = void 0;
    this._session = void 0;
    this._notifyScopeListeners();
    this._attachments = [];
    this._propagationContext = generatePropagationContext();
    return this;
  }
  /**
   * @inheritDoc
   */
  addBreadcrumb(breadcrumb, maxBreadcrumbs) {
    const maxCrumbs = typeof maxBreadcrumbs === "number" ? maxBreadcrumbs : DEFAULT_MAX_BREADCRUMBS;
    if (maxCrumbs <= 0) {
      return this;
    }
    const mergedBreadcrumb = {
      timestamp: dateTimestampInSeconds(),
      ...breadcrumb
    };
    const breadcrumbs = this._breadcrumbs;
    breadcrumbs.push(mergedBreadcrumb);
    this._breadcrumbs = breadcrumbs.length > maxCrumbs ? breadcrumbs.slice(-maxCrumbs) : breadcrumbs;
    this._notifyScopeListeners();
    return this;
  }
  /**
   * @inheritDoc
   */
  getLastBreadcrumb() {
    return this._breadcrumbs[this._breadcrumbs.length - 1];
  }
  /**
   * @inheritDoc
   */
  clearBreadcrumbs() {
    this._breadcrumbs = [];
    this._notifyScopeListeners();
    return this;
  }
  /**
   * @inheritDoc
   */
  addAttachment(attachment) {
    this._attachments.push(attachment);
    return this;
  }
  /**
   * @inheritDoc
   * @deprecated Use `getScopeData()` instead.
   */
  getAttachments() {
    const data = this.getScopeData();
    return data.attachments;
  }
  /**
   * @inheritDoc
   */
  clearAttachments() {
    this._attachments = [];
    return this;
  }
  /** @inheritDoc */
  getScopeData() {
    const {
      _breadcrumbs,
      _attachments,
      _contexts,
      _tags,
      _extra,
      _user,
      _level,
      _fingerprint,
      _eventProcessors,
      _propagationContext,
      _sdkProcessingMetadata,
      _transactionName,
      _span
    } = this;
    return {
      breadcrumbs: _breadcrumbs,
      attachments: _attachments,
      contexts: _contexts,
      tags: _tags,
      extra: _extra,
      user: _user,
      level: _level,
      fingerprint: _fingerprint || [],
      eventProcessors: _eventProcessors,
      propagationContext: _propagationContext,
      sdkProcessingMetadata: _sdkProcessingMetadata,
      transactionName: _transactionName,
      span: _span
    };
  }
  /**
   * Applies data from the scope to the event and runs all event processors on it.
   *
   * @param event Event
   * @param hint Object containing additional information about the original exception, for use by the event processors.
   * @hidden
   * @deprecated Use `applyScopeDataToEvent()` directly
   */
  applyToEvent(event, hint = {}, additionalEventProcessors = []) {
    applyScopeDataToEvent(event, this.getScopeData());
    const eventProcessors = [
      ...additionalEventProcessors,
      // eslint-disable-next-line deprecation/deprecation
      ...getGlobalEventProcessors(),
      ...this._eventProcessors
    ];
    return notifyEventProcessors(eventProcessors, event, hint);
  }
  /**
   * Add data which will be accessible during event processing but won't get sent to Sentry
   */
  setSDKProcessingMetadata(newData) {
    this._sdkProcessingMetadata = { ...this._sdkProcessingMetadata, ...newData };
    return this;
  }
  /**
   * @inheritDoc
   */
  setPropagationContext(context) {
    this._propagationContext = context;
    return this;
  }
  /**
   * @inheritDoc
   */
  getPropagationContext() {
    return this._propagationContext;
  }
  /**
   * Capture an exception for this scope.
   *
   * @param exception The exception to capture.
   * @param hint Optinal additional data to attach to the Sentry event.
   * @returns the id of the captured Sentry event.
   */
  captureException(exception, hint) {
    const eventId = hint && hint.event_id ? hint.event_id : uuid4();
    if (!this._client) {
      logger.warn("No client configured on scope - will not capture exception!");
      return eventId;
    }
    const syntheticException = new Error("Sentry syntheticException");
    this._client.captureException(
      exception,
      {
        originalException: exception,
        syntheticException,
        ...hint,
        event_id: eventId
      },
      this
    );
    return eventId;
  }
  /**
   * Capture a message for this scope.
   *
   * @param message The message to capture.
   * @param level An optional severity level to report the message with.
   * @param hint Optional additional data to attach to the Sentry event.
   * @returns the id of the captured message.
   */
  captureMessage(message, level, hint) {
    const eventId = hint && hint.event_id ? hint.event_id : uuid4();
    if (!this._client) {
      logger.warn("No client configured on scope - will not capture message!");
      return eventId;
    }
    const syntheticException = new Error(message);
    this._client.captureMessage(
      message,
      level,
      {
        originalException: message,
        syntheticException,
        ...hint,
        event_id: eventId
      },
      this
    );
    return eventId;
  }
  /**
   * Captures a manually created event for this scope and sends it to Sentry.
   *
   * @param exception The event to capture.
   * @param hint Optional additional data to attach to the Sentry event.
   * @returns the id of the captured event.
   */
  captureEvent(event, hint) {
    const eventId = hint && hint.event_id ? hint.event_id : uuid4();
    if (!this._client) {
      logger.warn("No client configured on scope - will not capture event!");
      return eventId;
    }
    this._client.captureEvent(event, { ...hint, event_id: eventId }, this);
    return eventId;
  }
  /**
   * This will be called on every set call.
   */
  _notifyScopeListeners() {
    if (!this._notifyingListeners) {
      this._notifyingListeners = true;
      this._scopeListeners.forEach((callback) => {
        callback(this);
      });
      this._notifyingListeners = false;
    }
  }
};
function generatePropagationContext() {
  return {
    traceId: uuid4(),
    spanId: uuid4().substring(16)
  };
}

// node_modules/@sentry/core/esm/version.js
var SDK_VERSION = "7.100.1";

// node_modules/@sentry/core/esm/hub.js
var API_VERSION = parseFloat(SDK_VERSION);
var DEFAULT_BREADCRUMBS = 100;
var Hub = class {
  /** Is a {@link Layer}[] containing the client and scope */
  /** Contains the last event id of a captured event.  */
  /**
   * Creates a new instance of the hub, will push one {@link Layer} into the
   * internal stack on creation.
   *
   * @param client bound to the hub.
   * @param scope bound to the hub.
   * @param version number, higher number means higher priority.
   */
  constructor(client, scope, isolationScope, _version = API_VERSION) {
    this._version = _version;
    let assignedScope;
    if (!scope) {
      assignedScope = new Scope();
      assignedScope.setClient(client);
    } else {
      assignedScope = scope;
    }
    let assignedIsolationScope;
    if (!isolationScope) {
      assignedIsolationScope = new Scope();
      assignedIsolationScope.setClient(client);
    } else {
      assignedIsolationScope = isolationScope;
    }
    this._stack = [{ scope: assignedScope }];
    if (client) {
      this.bindClient(client);
    }
    this._isolationScope = assignedIsolationScope;
  }
  /**
   * Checks if this hub's version is older than the given version.
   *
   * @param version A version number to compare to.
   * @return True if the given version is newer; otherwise false.
   *
   * @deprecated This will be removed in v8.
   */
  isOlderThan(version) {
    return this._version < version;
  }
  /**
   * This binds the given client to the current scope.
   * @param client An SDK client (client) instance.
   *
   * @deprecated Use `initAndBind()` directly, or `setCurrentClient()` and/or `client.init()` instead.
   */
  bindClient(client) {
    const top = this.getStackTop();
    top.client = client;
    top.scope.setClient(client);
    if (client && client.setupIntegrations) {
      client.setupIntegrations();
    }
  }
  /**
   * @inheritDoc
   *
   * @deprecated Use `withScope` instead.
   */
  pushScope() {
    const scope = this.getScope().clone();
    this.getStack().push({
      // eslint-disable-next-line deprecation/deprecation
      client: this.getClient(),
      scope
    });
    return scope;
  }
  /**
   * @inheritDoc
   *
   * @deprecated Use `withScope` instead.
   */
  popScope() {
    if (this.getStack().length <= 1)
      return false;
    return !!this.getStack().pop();
  }
  /**
   * @inheritDoc
   *
   * @deprecated Use `Sentry.withScope()` instead.
   */
  withScope(callback) {
    const scope = this.pushScope();
    let maybePromiseResult;
    try {
      maybePromiseResult = callback(scope);
    } catch (e2) {
      this.popScope();
      throw e2;
    }
    if (isThenable(maybePromiseResult)) {
      return maybePromiseResult.then(
        (res) => {
          this.popScope();
          return res;
        },
        (e2) => {
          this.popScope();
          throw e2;
        }
      );
    }
    this.popScope();
    return maybePromiseResult;
  }
  /**
   * @inheritDoc
   *
   * @deprecated Use `Sentry.getClient()` instead.
   */
  getClient() {
    return this.getStackTop().client;
  }
  /**
   * Returns the scope of the top stack.
   *
   * @deprecated Use `Sentry.getCurrentScope()` instead.
   */
  getScope() {
    return this.getStackTop().scope;
  }
  /**
   * @deprecated Use `Sentry.getIsolationScope()` instead.
   */
  getIsolationScope() {
    return this._isolationScope;
  }
  /**
   * Returns the scope stack for domains or the process.
   * @deprecated This will be removed in v8.
   */
  getStack() {
    return this._stack;
  }
  /**
   * Returns the topmost scope layer in the order domain > local > process.
   * @deprecated This will be removed in v8.
   */
  getStackTop() {
    return this._stack[this._stack.length - 1];
  }
  /**
   * @inheritDoc
   *
   * @deprecated Use `Sentry.captureException()` instead.
   */
  captureException(exception, hint) {
    const eventId = this._lastEventId = hint && hint.event_id ? hint.event_id : uuid4();
    const syntheticException = new Error("Sentry syntheticException");
    this.getScope().captureException(exception, {
      originalException: exception,
      syntheticException,
      ...hint,
      event_id: eventId
    });
    return eventId;
  }
  /**
   * @inheritDoc
   *
   * @deprecated Use  `Sentry.captureMessage()` instead.
   */
  captureMessage(message, level, hint) {
    const eventId = this._lastEventId = hint && hint.event_id ? hint.event_id : uuid4();
    const syntheticException = new Error(message);
    this.getScope().captureMessage(message, level, {
      originalException: message,
      syntheticException,
      ...hint,
      event_id: eventId
    });
    return eventId;
  }
  /**
   * @inheritDoc
   *
   * @deprecated Use `Sentry.captureEvent()` instead.
   */
  captureEvent(event, hint) {
    const eventId = hint && hint.event_id ? hint.event_id : uuid4();
    if (!event.type) {
      this._lastEventId = eventId;
    }
    this.getScope().captureEvent(event, { ...hint, event_id: eventId });
    return eventId;
  }
  /**
   * @inheritDoc
   *
   * @deprecated This will be removed in v8.
   */
  lastEventId() {
    return this._lastEventId;
  }
  /**
   * @inheritDoc
   *
   * @deprecated Use `Sentry.addBreadcrumb()` instead.
   */
  addBreadcrumb(breadcrumb, hint) {
    const { scope, client } = this.getStackTop();
    if (!client)
      return;
    const { beforeBreadcrumb = null, maxBreadcrumbs = DEFAULT_BREADCRUMBS } = client.getOptions && client.getOptions() || {};
    if (maxBreadcrumbs <= 0)
      return;
    const timestamp = dateTimestampInSeconds();
    const mergedBreadcrumb = { timestamp, ...breadcrumb };
    const finalBreadcrumb = beforeBreadcrumb ? consoleSandbox(() => beforeBreadcrumb(mergedBreadcrumb, hint)) : mergedBreadcrumb;
    if (finalBreadcrumb === null)
      return;
    if (client.emit) {
      client.emit("beforeAddBreadcrumb", finalBreadcrumb, hint);
    }
    scope.addBreadcrumb(finalBreadcrumb, maxBreadcrumbs);
  }
  /**
   * @inheritDoc
   * @deprecated Use `Sentry.setUser()` instead.
   */
  setUser(user) {
    this.getScope().setUser(user);
    this.getIsolationScope().setUser(user);
  }
  /**
   * @inheritDoc
   * @deprecated Use `Sentry.setTags()` instead.
   */
  setTags(tags) {
    this.getScope().setTags(tags);
    this.getIsolationScope().setTags(tags);
  }
  /**
   * @inheritDoc
   * @deprecated Use `Sentry.setExtras()` instead.
   */
  setExtras(extras) {
    this.getScope().setExtras(extras);
    this.getIsolationScope().setExtras(extras);
  }
  /**
   * @inheritDoc
   * @deprecated Use `Sentry.setTag()` instead.
   */
  setTag(key, value) {
    this.getScope().setTag(key, value);
    this.getIsolationScope().setTag(key, value);
  }
  /**
   * @inheritDoc
   * @deprecated Use `Sentry.setExtra()` instead.
   */
  setExtra(key, extra) {
    this.getScope().setExtra(key, extra);
    this.getIsolationScope().setExtra(key, extra);
  }
  /**
   * @inheritDoc
   * @deprecated Use `Sentry.setContext()` instead.
   */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  setContext(name, context) {
    this.getScope().setContext(name, context);
    this.getIsolationScope().setContext(name, context);
  }
  /**
   * @inheritDoc
   *
   * @deprecated Use `getScope()` directly.
   */
  configureScope(callback) {
    const { scope, client } = this.getStackTop();
    if (client) {
      callback(scope);
    }
  }
  /**
   * @inheritDoc
   */
  run(callback) {
    const oldHub = makeMain(this);
    try {
      callback(this);
    } finally {
      makeMain(oldHub);
    }
  }
  /**
   * @inheritDoc
   * @deprecated Use `Sentry.getClient().getIntegrationByName()` instead.
   */
  getIntegration(integration) {
    const client = this.getClient();
    if (!client)
      return null;
    try {
      return client.getIntegration(integration);
    } catch (_oO) {
      DEBUG_BUILD2 && logger.warn(`Cannot retrieve integration ${integration.id} from the current Hub`);
      return null;
    }
  }
  /**
   * Starts a new `Transaction` and returns it. This is the entry point to manual tracing instrumentation.
   *
   * A tree structure can be built by adding child spans to the transaction, and child spans to other spans. To start a
   * new child span within the transaction or any span, call the respective `.startChild()` method.
   *
   * Every child span must be finished before the transaction is finished, otherwise the unfinished spans are discarded.
   *
   * The transaction must be finished with a call to its `.end()` method, at which point the transaction with all its
   * finished child spans will be sent to Sentry.
   *
   * @param context Properties of the new `Transaction`.
   * @param customSamplingContext Information given to the transaction sampling function (along with context-dependent
   * default values). See {@link Options.tracesSampler}.
   *
   * @returns The transaction which was just started
   *
   * @deprecated Use `startSpan()`, `startSpanManual()` or `startInactiveSpan()` instead.
   */
  startTransaction(context, customSamplingContext) {
    const result = this._callExtensionMethod("startTransaction", context, customSamplingContext);
    if (DEBUG_BUILD2 && !result) {
      const client = this.getClient();
      if (!client) {
        logger.warn(
          "Tracing extension 'startTransaction' is missing. You should 'init' the SDK before calling 'startTransaction'"
        );
      } else {
        logger.warn(`Tracing extension 'startTransaction' has not been added. Call 'addTracingExtensions' before calling 'init':
Sentry.addTracingExtensions();
Sentry.init({...});
`);
      }
    }
    return result;
  }
  /**
   * @inheritDoc
   * @deprecated Use `spanToTraceHeader()` instead.
   */
  traceHeaders() {
    return this._callExtensionMethod("traceHeaders");
  }
  /**
   * @inheritDoc
   *
   * @deprecated Use top level `captureSession` instead.
   */
  captureSession(endSession2 = false) {
    if (endSession2) {
      return this.endSession();
    }
    this._sendSessionUpdate();
  }
  /**
   * @inheritDoc
   * @deprecated Use top level `endSession` instead.
   */
  endSession() {
    const layer = this.getStackTop();
    const scope = layer.scope;
    const session = scope.getSession();
    if (session) {
      closeSession(session);
    }
    this._sendSessionUpdate();
    scope.setSession();
  }
  /**
   * @inheritDoc
   * @deprecated Use top level `startSession` instead.
   */
  startSession(context) {
    const { scope, client } = this.getStackTop();
    const { release: release2, environment = DEFAULT_ENVIRONMENT } = client && client.getOptions() || {};
    const { userAgent } = GLOBAL_OBJ.navigator || {};
    const session = makeSession({
      release: release2,
      environment,
      user: scope.getUser(),
      ...userAgent && { userAgent },
      ...context
    });
    const currentSession = scope.getSession && scope.getSession();
    if (currentSession && currentSession.status === "ok") {
      updateSession(currentSession, { status: "exited" });
    }
    this.endSession();
    scope.setSession(session);
    return session;
  }
  /**
   * Returns if default PII should be sent to Sentry and propagated in ourgoing requests
   * when Tracing is used.
   *
   * @deprecated Use top-level `getClient().getOptions().sendDefaultPii` instead. This function
   * only unnecessarily increased API surface but only wrapped accessing the option.
   */
  shouldSendDefaultPii() {
    const client = this.getClient();
    const options = client && client.getOptions();
    return Boolean(options && options.sendDefaultPii);
  }
  /**
   * Sends the current Session on the scope
   */
  _sendSessionUpdate() {
    const { scope, client } = this.getStackTop();
    const session = scope.getSession();
    if (session && client && client.captureSession) {
      client.captureSession(session);
    }
  }
  /**
   * Calls global extension method and binding current instance to the function call
   */
  // @ts-expect-error Function lacks ending return statement and return type does not include 'undefined'. ts(2366)
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  _callExtensionMethod(method, ...args) {
    const carrier = getMainCarrier();
    const sentry = carrier.__SENTRY__;
    if (sentry && sentry.extensions && typeof sentry.extensions[method] === "function") {
      return sentry.extensions[method].apply(this, args);
    }
    DEBUG_BUILD2 && logger.warn(`Extension method ${method} couldn't be found, doing nothing.`);
  }
};
function getMainCarrier() {
  GLOBAL_OBJ.__SENTRY__ = GLOBAL_OBJ.__SENTRY__ || {
    extensions: {},
    hub: void 0
  };
  return GLOBAL_OBJ;
}
function makeMain(hub) {
  const registry = getMainCarrier();
  const oldHub = getHubFromCarrier(registry);
  setHubOnCarrier(registry, hub);
  return oldHub;
}
function getCurrentHub() {
  const registry = getMainCarrier();
  if (registry.__SENTRY__ && registry.__SENTRY__.acs) {
    const hub = registry.__SENTRY__.acs.getCurrentHub();
    if (hub) {
      return hub;
    }
  }
  return getGlobalHub(registry);
}
function getIsolationScope() {
  return getCurrentHub().getIsolationScope();
}
function getGlobalHub(registry = getMainCarrier()) {
  if (!hasHubOnCarrier(registry) || // eslint-disable-next-line deprecation/deprecation
  getHubFromCarrier(registry).isOlderThan(API_VERSION)) {
    setHubOnCarrier(registry, new Hub());
  }
  return getHubFromCarrier(registry);
}
function runWithAsyncContext(callback, options = {}) {
  const registry = getMainCarrier();
  if (registry.__SENTRY__ && registry.__SENTRY__.acs) {
    return registry.__SENTRY__.acs.runWithAsyncContext(callback, options);
  }
  return callback();
}
function hasHubOnCarrier(carrier) {
  return !!(carrier && carrier.__SENTRY__ && carrier.__SENTRY__.hub);
}
function getHubFromCarrier(carrier) {
  return getGlobalSingleton("hub", () => new Hub(), carrier);
}
function setHubOnCarrier(carrier, hub) {
  if (!carrier)
    return false;
  const __SENTRY__ = carrier.__SENTRY__ = carrier.__SENTRY__ || {};
  __SENTRY__.hub = hub;
  return true;
}

// node_modules/@sentry/core/esm/tracing/utils.js
function getActiveTransaction(maybeHub) {
  const hub = maybeHub || getCurrentHub();
  const scope = hub.getScope();
  return scope.getTransaction();
}

// node_modules/@sentry/core/esm/semanticAttributes.js
var SEMANTIC_ATTRIBUTE_SENTRY_SOURCE = "sentry.source";
var SEMANTIC_ATTRIBUTE_SENTRY_ORIGIN = "sentry.origin";

// node_modules/@sentry/core/esm/tracing/spanstatus.js
var SpanStatus;
(function(SpanStatus2) {
  const Ok = "ok";
  SpanStatus2["Ok"] = Ok;
  const DeadlineExceeded = "deadline_exceeded";
  SpanStatus2["DeadlineExceeded"] = DeadlineExceeded;
  const Unauthenticated = "unauthenticated";
  SpanStatus2["Unauthenticated"] = Unauthenticated;
  const PermissionDenied = "permission_denied";
  SpanStatus2["PermissionDenied"] = PermissionDenied;
  const NotFound = "not_found";
  SpanStatus2["NotFound"] = NotFound;
  const ResourceExhausted = "resource_exhausted";
  SpanStatus2["ResourceExhausted"] = ResourceExhausted;
  const InvalidArgument = "invalid_argument";
  SpanStatus2["InvalidArgument"] = InvalidArgument;
  const Unimplemented = "unimplemented";
  SpanStatus2["Unimplemented"] = Unimplemented;
  const Unavailable = "unavailable";
  SpanStatus2["Unavailable"] = Unavailable;
  const InternalError = "internal_error";
  SpanStatus2["InternalError"] = InternalError;
  const UnknownError = "unknown_error";
  SpanStatus2["UnknownError"] = UnknownError;
  const Cancelled = "cancelled";
  SpanStatus2["Cancelled"] = Cancelled;
  const AlreadyExists = "already_exists";
  SpanStatus2["AlreadyExists"] = AlreadyExists;
  const FailedPrecondition = "failed_precondition";
  SpanStatus2["FailedPrecondition"] = FailedPrecondition;
  const Aborted = "aborted";
  SpanStatus2["Aborted"] = Aborted;
  const OutOfRange = "out_of_range";
  SpanStatus2["OutOfRange"] = OutOfRange;
  const DataLoss = "data_loss";
  SpanStatus2["DataLoss"] = DataLoss;
})(SpanStatus || (SpanStatus = {}));
function getSpanStatusFromHttpCode(httpStatus) {
  if (httpStatus < 400 && httpStatus >= 100) {
    return "ok";
  }
  if (httpStatus >= 400 && httpStatus < 500) {
    switch (httpStatus) {
      case 401:
        return "unauthenticated";
      case 403:
        return "permission_denied";
      case 404:
        return "not_found";
      case 409:
        return "already_exists";
      case 413:
        return "failed_precondition";
      case 429:
        return "resource_exhausted";
      default:
        return "invalid_argument";
    }
  }
  if (httpStatus >= 500 && httpStatus < 600) {
    switch (httpStatus) {
      case 501:
        return "unimplemented";
      case 503:
        return "unavailable";
      case 504:
        return "deadline_exceeded";
      default:
        return "internal_error";
    }
  }
  return "unknown_error";
}
function setHttpStatus(span, httpStatus) {
  span.setTag("http.status_code", String(httpStatus));
  span.setData("http.response.status_code", httpStatus);
  const spanStatus = getSpanStatusFromHttpCode(httpStatus);
  if (spanStatus !== "unknown_error") {
    span.setStatus(spanStatus);
  }
}

// node_modules/@sentry/core/esm/utils/handleCallbackErrors.js
function handleCallbackErrors(fn, onError, onFinally = () => {
}) {
  let maybePromiseResult;
  try {
    maybePromiseResult = fn();
  } catch (e2) {
    onError(e2);
    onFinally();
    throw e2;
  }
  return maybeHandlePromiseRejection(maybePromiseResult, onError, onFinally);
}
function maybeHandlePromiseRejection(value, onError, onFinally) {
  if (isThenable(value)) {
    return value.then(
      (res) => {
        onFinally();
        return res;
      },
      (e2) => {
        onError(e2);
        onFinally();
        throw e2;
      }
    );
  }
  onFinally();
  return value;
}

// node_modules/@sentry/core/esm/utils/hasTracingEnabled.js
function hasTracingEnabled(maybeOptions) {
  if (typeof __SENTRY_TRACING__ === "boolean" && !__SENTRY_TRACING__) {
    return false;
  }
  const client = getClient();
  const options = maybeOptions || client && client.getOptions();
  return !!options && (options.enableTracing || "tracesSampleRate" in options || "tracesSampler" in options);
}

// node_modules/@sentry/core/esm/tracing/trace.js
function startSpan(context, callback) {
  const ctx = normalizeContext(context);
  return runWithAsyncContext(() => {
    return withScope(context.scope, (scope) => {
      const hub = getCurrentHub();
      const parentSpan = scope.getSpan();
      const shouldSkipSpan = context.onlyIfParent && !parentSpan;
      const activeSpan = shouldSkipSpan ? void 0 : createChildSpanOrTransaction(hub, parentSpan, ctx);
      scope.setSpan(activeSpan);
      return handleCallbackErrors(
        () => callback(activeSpan),
        () => {
          if (activeSpan) {
            const { status } = spanToJSON(activeSpan);
            if (!status || status === "ok") {
              activeSpan.setStatus("internal_error");
            }
          }
        },
        () => activeSpan && activeSpan.end()
      );
    });
  });
}
function getActiveSpan() {
  return getCurrentScope().getSpan();
}
var continueTrace = ({
  sentryTrace,
  baggage
}, callback) => {
  const currentScope = getCurrentScope();
  const { traceparentData, dynamicSamplingContext, propagationContext } = tracingContextFromHeaders(
    sentryTrace,
    baggage
  );
  currentScope.setPropagationContext(propagationContext);
  if (DEBUG_BUILD2 && traceparentData) {
    logger.log(`[Tracing] Continuing trace ${traceparentData.traceId}.`);
  }
  const transactionContext = {
    ...traceparentData,
    metadata: dropUndefinedKeys({
      dynamicSamplingContext
    })
  };
  if (!callback) {
    return transactionContext;
  }
  return runWithAsyncContext(() => {
    return callback(transactionContext);
  });
};
function createChildSpanOrTransaction(hub, parentSpan, ctx) {
  if (!hasTracingEnabled()) {
    return void 0;
  }
  const isolationScope = getIsolationScope();
  const scope = getCurrentScope();
  let span;
  if (parentSpan) {
    span = parentSpan.startChild(ctx);
  } else {
    const { traceId, dsc, parentSpanId, sampled } = {
      ...isolationScope.getPropagationContext(),
      ...scope.getPropagationContext()
    };
    span = hub.startTransaction({
      traceId,
      parentSpanId,
      parentSampled: sampled,
      ...ctx,
      metadata: {
        dynamicSamplingContext: dsc,
        // eslint-disable-next-line deprecation/deprecation
        ...ctx.metadata
      }
    });
  }
  setCapturedScopesOnSpan(span, scope, isolationScope);
  return span;
}
function normalizeContext(context) {
  if (context.startTime) {
    const ctx = { ...context };
    ctx.startTimestamp = spanTimeInputToSeconds(context.startTime);
    delete ctx.startTime;
    return ctx;
  }
  return context;
}
var SCOPE_ON_START_SPAN_FIELD = "_sentryScope";
var ISOLATION_SCOPE_ON_START_SPAN_FIELD = "_sentryIsolationScope";
function setCapturedScopesOnSpan(span, scope, isolationScope) {
  if (span) {
    addNonEnumerableProperty(span, ISOLATION_SCOPE_ON_START_SPAN_FIELD, isolationScope);
    addNonEnumerableProperty(span, SCOPE_ON_START_SPAN_FIELD, scope);
  }
}

// node_modules/@sentry/core/esm/integration.js
function convertIntegrationFnToClass(name, fn) {
  return Object.assign(
    function ConvertedIntegration(...args) {
      return fn(...args);
    },
    { id: name }
  );
}
function defineIntegration(fn) {
  return fn;
}

// node_modules/@sentry/core/esm/transports/base.js
var DEFAULT_TRANSPORT_BUFFER_SIZE = 30;
function createTransport(options, makeRequest, buffer = makePromiseBuffer(
  options.bufferSize || DEFAULT_TRANSPORT_BUFFER_SIZE
)) {
  let rateLimits = {};
  const flush2 = (timeout) => buffer.drain(timeout);
  function send(envelope) {
    const filteredEnvelopeItems = [];
    forEachEnvelopeItem(envelope, (item, type) => {
      const envelopeItemDataCategory = envelopeItemTypeToDataCategory(type);
      if (isRateLimited(rateLimits, envelopeItemDataCategory)) {
        const event = getEventForEnvelopeItem(item, type);
        options.recordDroppedEvent("ratelimit_backoff", envelopeItemDataCategory, event);
      } else {
        filteredEnvelopeItems.push(item);
      }
    });
    if (filteredEnvelopeItems.length === 0) {
      return resolvedSyncPromise();
    }
    const filteredEnvelope = createEnvelope(envelope[0], filteredEnvelopeItems);
    const recordEnvelopeLoss = (reason) => {
      forEachEnvelopeItem(filteredEnvelope, (item, type) => {
        const event = getEventForEnvelopeItem(item, type);
        options.recordDroppedEvent(reason, envelopeItemTypeToDataCategory(type), event);
      });
    };
    const requestTask = () => makeRequest({ body: serializeEnvelope(filteredEnvelope, options.textEncoder) }).then(
      (response) => {
        if (response.statusCode !== void 0 && (response.statusCode < 200 || response.statusCode >= 300)) {
          DEBUG_BUILD2 && logger.warn(`Sentry responded with status code ${response.statusCode} to sent event.`);
        }
        rateLimits = updateRateLimits(rateLimits, response);
        return response;
      },
      (error) => {
        recordEnvelopeLoss("network_error");
        throw error;
      }
    );
    return buffer.add(requestTask).then(
      (result) => result,
      (error) => {
        if (error instanceof SentryError) {
          DEBUG_BUILD2 && logger.error("Skipped sending event because buffer is full.");
          recordEnvelopeLoss("queue_overflow");
          return resolvedSyncPromise();
        } else {
          throw error;
        }
      }
    );
  }
  send.__sentry__baseTransport__ = true;
  return {
    send,
    flush: flush2
  };
}
function getEventForEnvelopeItem(item, type) {
  if (type !== "event" && type !== "transaction") {
    return void 0;
  }
  return Array.isArray(item) ? item[1] : void 0;
}

// node_modules/@sentry/core/esm/utils/isSentryRequestUrl.js
function isSentryRequestUrl(url, hubOrClient) {
  const client = hubOrClient && isHub(hubOrClient) ? (
    // eslint-disable-next-line deprecation/deprecation
    hubOrClient.getClient()
  ) : hubOrClient;
  const dsn = client && client.getDsn();
  const tunnel = client && client.getOptions().tunnel;
  return checkDsn(url, dsn) || checkTunnel(url, tunnel);
}
function checkTunnel(url, tunnel) {
  if (!tunnel) {
    return false;
  }
  return removeTrailingSlash(url) === removeTrailingSlash(tunnel);
}
function checkDsn(url, dsn) {
  return dsn ? url.includes(dsn.host) : false;
}
function removeTrailingSlash(str) {
  return str[str.length - 1] === "/" ? str.slice(0, -1) : str;
}
function isHub(hubOrClient) {
  return hubOrClient.getClient !== void 0;
}

// node_modules/@sentry/core/esm/integrations/requestdata.js
var DEFAULT_OPTIONS = {
  include: {
    cookies: true,
    data: true,
    headers: true,
    ip: false,
    query_string: true,
    url: true,
    user: {
      id: true,
      username: true,
      email: true
    }
  },
  transactionNamingScheme: "methodPath"
};
var INTEGRATION_NAME = "RequestData";
var _requestDataIntegration = (options = {}) => {
  const _addRequestData = addRequestDataToEvent;
  const _options = {
    ...DEFAULT_OPTIONS,
    ...options,
    include: {
      // @ts-expect-error It's mad because `method` isn't a known `include` key. (It's only here and not set by default in
      // `addRequestDataToEvent` for legacy reasons. TODO (v8): Change that.)
      method: true,
      ...DEFAULT_OPTIONS.include,
      ...options.include,
      user: options.include && typeof options.include.user === "boolean" ? options.include.user : {
        ...DEFAULT_OPTIONS.include.user,
        // Unclear why TS still thinks `options.include.user` could be a boolean at this point
        ...(options.include || {}).user
      }
    }
  };
  return {
    name: INTEGRATION_NAME,
    // TODO v8: Remove this
    setupOnce() {
    },
    // eslint-disable-line @typescript-eslint/no-empty-function
    processEvent(event, _hint, client) {
      const { transactionNamingScheme } = _options;
      const { sdkProcessingMetadata = {} } = event;
      const req = sdkProcessingMetadata.request;
      if (!req) {
        return event;
      }
      const addRequestDataOptions = sdkProcessingMetadata.requestDataOptionsFromExpressHandler || sdkProcessingMetadata.requestDataOptionsFromGCPWrapper || convertReqDataIntegrationOptsToAddReqDataOpts(_options);
      const processedEvent = _addRequestData(event, req, addRequestDataOptions);
      if (event.type === "transaction" || transactionNamingScheme === "handler") {
        return processedEvent;
      }
      const reqWithTransaction = req;
      const transaction = reqWithTransaction._sentryTransaction;
      if (transaction) {
        const name = spanToJSON(transaction).description || "";
        const shouldIncludeMethodInTransactionName = getSDKName(client) === "sentry.javascript.nextjs" ? name.startsWith("/api") : transactionNamingScheme !== "path";
        const [transactionValue] = extractPathForTransaction(req, {
          path: true,
          method: shouldIncludeMethodInTransactionName,
          customRoute: name
        });
        processedEvent.transaction = transactionValue;
      }
      return processedEvent;
    }
  };
};
var requestDataIntegration = defineIntegration(_requestDataIntegration);
var RequestData = convertIntegrationFnToClass(INTEGRATION_NAME, requestDataIntegration);
function convertReqDataIntegrationOptsToAddReqDataOpts(integrationOptions) {
  const {
    transactionNamingScheme,
    include: { ip, user, ...requestOptions }
  } = integrationOptions;
  const requestIncludeKeys = [];
  for (const [key, value] of Object.entries(requestOptions)) {
    if (value) {
      requestIncludeKeys.push(key);
    }
  }
  let addReqDataUserOpt;
  if (user === void 0) {
    addReqDataUserOpt = true;
  } else if (typeof user === "boolean") {
    addReqDataUserOpt = user;
  } else {
    const userIncludeKeys = [];
    for (const [key, value] of Object.entries(user)) {
      if (value) {
        userIncludeKeys.push(key);
      }
    }
    addReqDataUserOpt = userIncludeKeys;
  }
  return {
    include: {
      ip,
      user: addReqDataUserOpt,
      request: requestIncludeKeys.length !== 0 ? requestIncludeKeys : void 0,
      transaction: transactionNamingScheme
    }
  };
}
function getSDKName(client) {
  try {
    return client.getOptions()._metadata.sdk.name;
  } catch (err) {
    return void 0;
  }
}

// node_modules/@sentry/core/esm/integrations/inboundfilters.js
var DEFAULT_IGNORE_ERRORS = [/^Script error\.?$/, /^Javascript error: Script error\.? on line 0$/];
var DEFAULT_IGNORE_TRANSACTIONS = [
  /^.*\/healthcheck$/,
  /^.*\/healthy$/,
  /^.*\/live$/,
  /^.*\/ready$/,
  /^.*\/heartbeat$/,
  /^.*\/health$/,
  /^.*\/healthz$/
];
var INTEGRATION_NAME2 = "InboundFilters";
var _inboundFiltersIntegration = (options = {}) => {
  return {
    name: INTEGRATION_NAME2,
    // TODO v8: Remove this
    setupOnce() {
    },
    // eslint-disable-line @typescript-eslint/no-empty-function
    processEvent(event, _hint, client) {
      const clientOptions = client.getOptions();
      const mergedOptions = _mergeOptions(options, clientOptions);
      return _shouldDropEvent(event, mergedOptions) ? null : event;
    }
  };
};
var inboundFiltersIntegration = defineIntegration(_inboundFiltersIntegration);
var InboundFilters = convertIntegrationFnToClass(
  INTEGRATION_NAME2,
  inboundFiltersIntegration
);
function _mergeOptions(internalOptions = {}, clientOptions = {}) {
  return {
    allowUrls: [...internalOptions.allowUrls || [], ...clientOptions.allowUrls || []],
    denyUrls: [...internalOptions.denyUrls || [], ...clientOptions.denyUrls || []],
    ignoreErrors: [
      ...internalOptions.ignoreErrors || [],
      ...clientOptions.ignoreErrors || [],
      ...internalOptions.disableErrorDefaults ? [] : DEFAULT_IGNORE_ERRORS
    ],
    ignoreTransactions: [
      ...internalOptions.ignoreTransactions || [],
      ...clientOptions.ignoreTransactions || [],
      ...internalOptions.disableTransactionDefaults ? [] : DEFAULT_IGNORE_TRANSACTIONS
    ],
    ignoreInternal: internalOptions.ignoreInternal !== void 0 ? internalOptions.ignoreInternal : true
  };
}
function _shouldDropEvent(event, options) {
  if (options.ignoreInternal && _isSentryError(event)) {
    DEBUG_BUILD2 && logger.warn(`Event dropped due to being internal Sentry Error.
Event: ${getEventDescription(event)}`);
    return true;
  }
  if (_isIgnoredError(event, options.ignoreErrors)) {
    DEBUG_BUILD2 && logger.warn(
      `Event dropped due to being matched by \`ignoreErrors\` option.
Event: ${getEventDescription(event)}`
    );
    return true;
  }
  if (_isIgnoredTransaction(event, options.ignoreTransactions)) {
    DEBUG_BUILD2 && logger.warn(
      `Event dropped due to being matched by \`ignoreTransactions\` option.
Event: ${getEventDescription(event)}`
    );
    return true;
  }
  if (_isDeniedUrl(event, options.denyUrls)) {
    DEBUG_BUILD2 && logger.warn(
      `Event dropped due to being matched by \`denyUrls\` option.
Event: ${getEventDescription(
        event
      )}.
Url: ${_getEventFilterUrl(event)}`
    );
    return true;
  }
  if (!_isAllowedUrl(event, options.allowUrls)) {
    DEBUG_BUILD2 && logger.warn(
      `Event dropped due to not being matched by \`allowUrls\` option.
Event: ${getEventDescription(
        event
      )}.
Url: ${_getEventFilterUrl(event)}`
    );
    return true;
  }
  return false;
}
function _isIgnoredError(event, ignoreErrors) {
  if (event.type || !ignoreErrors || !ignoreErrors.length) {
    return false;
  }
  return _getPossibleEventMessages(event).some((message) => stringMatchesSomePattern(message, ignoreErrors));
}
function _isIgnoredTransaction(event, ignoreTransactions) {
  if (event.type !== "transaction" || !ignoreTransactions || !ignoreTransactions.length) {
    return false;
  }
  const name = event.transaction;
  return name ? stringMatchesSomePattern(name, ignoreTransactions) : false;
}
function _isDeniedUrl(event, denyUrls) {
  if (!denyUrls || !denyUrls.length) {
    return false;
  }
  const url = _getEventFilterUrl(event);
  return !url ? false : stringMatchesSomePattern(url, denyUrls);
}
function _isAllowedUrl(event, allowUrls) {
  if (!allowUrls || !allowUrls.length) {
    return true;
  }
  const url = _getEventFilterUrl(event);
  return !url ? true : stringMatchesSomePattern(url, allowUrls);
}
function _getPossibleEventMessages(event) {
  const possibleMessages = [];
  if (event.message) {
    possibleMessages.push(event.message);
  }
  let lastException;
  try {
    lastException = event.exception.values[event.exception.values.length - 1];
  } catch (e2) {
  }
  if (lastException) {
    if (lastException.value) {
      possibleMessages.push(lastException.value);
      if (lastException.type) {
        possibleMessages.push(`${lastException.type}: ${lastException.value}`);
      }
    }
  }
  if (DEBUG_BUILD2 && possibleMessages.length === 0) {
    logger.error(`Could not extract message for event ${getEventDescription(event)}`);
  }
  return possibleMessages;
}
function _isSentryError(event) {
  try {
    return event.exception.values[0].type === "SentryError";
  } catch (e2) {
  }
  return false;
}
function _getLastValidUrl(frames = []) {
  for (let i2 = frames.length - 1; i2 >= 0; i2--) {
    const frame = frames[i2];
    if (frame && frame.filename !== "<anonymous>" && frame.filename !== "[native code]") {
      return frame.filename || null;
    }
  }
  return null;
}
function _getEventFilterUrl(event) {
  try {
    let frames;
    try {
      frames = event.exception.values[0].stacktrace.frames;
    } catch (e2) {
    }
    return frames ? _getLastValidUrl(frames) : null;
  } catch (oO) {
    DEBUG_BUILD2 && logger.error(`Cannot extract url for event ${getEventDescription(event)}`);
    return null;
  }
}

// node_modules/@sentry/core/esm/integrations/functiontostring.js
var originalFunctionToString;
var INTEGRATION_NAME3 = "FunctionToString";
var SETUP_CLIENTS = /* @__PURE__ */ new WeakMap();
var _functionToStringIntegration = () => {
  return {
    name: INTEGRATION_NAME3,
    setupOnce() {
      originalFunctionToString = Function.prototype.toString;
      try {
        Function.prototype.toString = function(...args) {
          const originalFunction = getOriginalFunction(this);
          const context = SETUP_CLIENTS.has(getClient()) && originalFunction !== void 0 ? originalFunction : this;
          return originalFunctionToString.apply(context, args);
        };
      } catch (e2) {
      }
    },
    setup(client) {
      SETUP_CLIENTS.set(client, true);
    }
  };
};
var functionToStringIntegration = defineIntegration(_functionToStringIntegration);
var FunctionToString = convertIntegrationFnToClass(
  INTEGRATION_NAME3,
  functionToStringIntegration
);

// node_modules/@sentry/core/esm/integrations/linkederrors.js
var DEFAULT_KEY = "cause";
var DEFAULT_LIMIT = 5;
var INTEGRATION_NAME4 = "LinkedErrors";
var _linkedErrorsIntegration = (options = {}) => {
  const limit = options.limit || DEFAULT_LIMIT;
  const key = options.key || DEFAULT_KEY;
  return {
    name: INTEGRATION_NAME4,
    // TODO v8: Remove this
    setupOnce() {
    },
    // eslint-disable-line @typescript-eslint/no-empty-function
    preprocessEvent(event, hint, client) {
      const options2 = client.getOptions();
      applyAggregateErrorsToEvent(
        exceptionFromError,
        options2.stackParser,
        options2.maxValueLength,
        key,
        limit,
        event,
        hint
      );
    }
  };
};
var linkedErrorsIntegration = defineIntegration(_linkedErrorsIntegration);
var LinkedErrors = convertIntegrationFnToClass(INTEGRATION_NAME4, linkedErrorsIntegration);

// node_modules/@sentry/core/esm/integrations/index.js
var integrations_exports = {};
__export(integrations_exports, {
  FunctionToString: () => FunctionToString,
  InboundFilters: () => InboundFilters,
  LinkedErrors: () => LinkedErrors
});

// node_modules/@sentry/core/esm/index.js
var Integrations = integrations_exports;

// node_modules/@sentry-internal/tracing/esm/common/debug-build.js
var DEBUG_BUILD3 = typeof __SENTRY_DEBUG__ === "undefined" || __SENTRY_DEBUG__;

// node_modules/@sentry-internal/tracing/esm/node/integrations/utils/node-utils.js
function shouldDisableAutoInstrumentation(getCurrentHub2) {
  const clientOptions = _optionalChain([getCurrentHub2, "call", (_) => _(), "access", (_2) => _2.getClient, "call", (_3) => _3(), "optionalAccess", (_4) => _4.getOptions, "call", (_5) => _5()]);
  const instrumenter = _optionalChain([clientOptions, "optionalAccess", (_6) => _6.instrumenter]) || "sentry";
  return instrumenter !== "sentry";
}

// node_modules/@sentry-internal/tracing/esm/node/integrations/express.js
var Express = class _Express {
  /**
   * @inheritDoc
   */
  static __initStatic() {
    this.id = "Express";
  }
  /**
   * @inheritDoc
   */
  /**
   * Express App instance
   */
  /**
   * @inheritDoc
   */
  constructor(options = {}) {
    this.name = _Express.id;
    this._router = options.router || options.app;
    this._methods = (Array.isArray(options.methods) ? options.methods : []).concat("use");
  }
  /**
   * @inheritDoc
   */
  setupOnce(_, getCurrentHub2) {
    if (!this._router) {
      DEBUG_BUILD3 && logger.error("ExpressIntegration is missing an Express instance");
      return;
    }
    if (shouldDisableAutoInstrumentation(getCurrentHub2)) {
      DEBUG_BUILD3 && logger.log("Express Integration is skipped because of instrumenter configuration.");
      return;
    }
    instrumentMiddlewares(this._router, this._methods);
    instrumentRouter(this._router);
  }
};
Express.__initStatic();
function wrap(fn, method) {
  const arity = fn.length;
  switch (arity) {
    case 2: {
      return function(req, res) {
        const transaction = res.__sentry_transaction;
        if (transaction) {
          const span = transaction.startChild({
            description: fn.name,
            op: `middleware.express.${method}`,
            origin: "auto.middleware.express"
          });
          res.once("finish", () => {
            span.end();
          });
        }
        return fn.call(this, req, res);
      };
    }
    case 3: {
      return function(req, res, next) {
        const transaction = res.__sentry_transaction;
        const span = _optionalChain([transaction, "optionalAccess", (_2) => _2.startChild, "call", (_3) => _3({
          description: fn.name,
          op: `middleware.express.${method}`,
          origin: "auto.middleware.express"
        })]);
        fn.call(this, req, res, function(...args) {
          _optionalChain([span, "optionalAccess", (_4) => _4.end, "call", (_5) => _5()]);
          next.call(this, ...args);
        });
      };
    }
    case 4: {
      return function(err, req, res, next) {
        const transaction = res.__sentry_transaction;
        const span = _optionalChain([transaction, "optionalAccess", (_6) => _6.startChild, "call", (_7) => _7({
          description: fn.name,
          op: `middleware.express.${method}`,
          origin: "auto.middleware.express"
        })]);
        fn.call(this, err, req, res, function(...args) {
          _optionalChain([span, "optionalAccess", (_8) => _8.end, "call", (_9) => _9()]);
          next.call(this, ...args);
        });
      };
    }
    default: {
      throw new Error(`Express middleware takes 2-4 arguments. Got: ${arity}`);
    }
  }
}
function wrapMiddlewareArgs(args, method) {
  return args.map((arg) => {
    if (typeof arg === "function") {
      return wrap(arg, method);
    }
    if (Array.isArray(arg)) {
      return arg.map((a) => {
        if (typeof a === "function") {
          return wrap(a, method);
        }
        return a;
      });
    }
    return arg;
  });
}
function patchMiddleware(router, method) {
  const originalCallback = router[method];
  router[method] = function(...args) {
    return originalCallback.call(this, ...wrapMiddlewareArgs(args, method));
  };
  return router;
}
function instrumentMiddlewares(router, methods = []) {
  methods.forEach((method) => patchMiddleware(router, method));
}
function instrumentRouter(appOrRouter) {
  const isApp = "settings" in appOrRouter;
  if (isApp && appOrRouter._router === void 0 && appOrRouter.lazyrouter) {
    appOrRouter.lazyrouter();
  }
  const router = isApp ? appOrRouter._router : appOrRouter;
  if (!router) {
    DEBUG_BUILD3 && logger.debug("Cannot instrument router for URL Parameterization (did not find a valid router).");
    DEBUG_BUILD3 && logger.debug("Routing instrumentation is currently only supported in Express 4.");
    return;
  }
  const routerProto = Object.getPrototypeOf(router);
  const originalProcessParams = routerProto.process_params;
  routerProto.process_params = function process_params(layer, called, req, res, done) {
    if (!req._reconstructedRoute) {
      req._reconstructedRoute = "";
    }
    const { layerRoutePath, isRegex, isArray, numExtraSegments } = getLayerRoutePathInfo(layer);
    if (layerRoutePath || isRegex || isArray) {
      req._hasParameters = true;
    }
    let partialRoute;
    if (layerRoutePath) {
      partialRoute = layerRoutePath;
    } else {
      partialRoute = preventDuplicateSegments(req.originalUrl, req._reconstructedRoute, layer.path) || "";
    }
    const finalPartialRoute = partialRoute.split("/").filter((segment) => segment.length > 0 && (isRegex || isArray || !segment.includes("*"))).join("/");
    if (finalPartialRoute && finalPartialRoute.length > 0) {
      req._reconstructedRoute += `/${finalPartialRoute}${isRegex ? "/" : ""}`;
    }
    const urlLength = getNumberOfUrlSegments(stripUrlQueryAndFragment(req.originalUrl || "")) + numExtraSegments;
    const routeLength = getNumberOfUrlSegments(req._reconstructedRoute);
    if (urlLength === routeLength) {
      if (!req._hasParameters) {
        if (req._reconstructedRoute !== req.originalUrl) {
          req._reconstructedRoute = req.originalUrl ? stripUrlQueryAndFragment(req.originalUrl) : req.originalUrl;
        }
      }
      const transaction = res.__sentry_transaction;
      const attributes = transaction && spanToJSON(transaction).data || {};
      if (transaction && attributes[SEMANTIC_ATTRIBUTE_SENTRY_SOURCE] !== "custom") {
        const finalRoute = req._reconstructedRoute || "/";
        const [name, source] = extractPathForTransaction(req, { path: true, method: true, customRoute: finalRoute });
        transaction.updateName(name);
        transaction.setAttribute(SEMANTIC_ATTRIBUTE_SENTRY_SOURCE, source);
      }
    }
    return originalProcessParams.call(this, layer, called, req, res, done);
  };
}
var extractOriginalRoute = (path, regexp, keys) => {
  if (!path || !regexp || !keys || Object.keys(keys).length === 0 || !_optionalChain([keys, "access", (_10) => _10[0], "optionalAccess", (_11) => _11.offset])) {
    return void 0;
  }
  const orderedKeys = keys.sort((a, b) => a.offset - b.offset);
  const pathRegex = new RegExp(regexp, `${regexp.flags}d`);
  const execResult = pathRegex.exec(path);
  if (!execResult || !execResult.indices) {
    return void 0;
  }
  const [, ...paramIndices] = execResult.indices;
  if (paramIndices.length !== orderedKeys.length) {
    return void 0;
  }
  let resultPath = path;
  let indexShift = 0;
  paramIndices.forEach((item, index) => {
    if (item) {
      const [startOffset, endOffset] = item;
      const substr1 = resultPath.substring(0, startOffset - indexShift);
      const replacement = `:${orderedKeys[index].name}`;
      const substr2 = resultPath.substring(endOffset - indexShift);
      resultPath = substr1 + replacement + substr2;
      indexShift = indexShift + (endOffset - startOffset - replacement.length);
    }
  });
  return resultPath;
};
function getLayerRoutePathInfo(layer) {
  let lrp = _optionalChain([layer, "access", (_12) => _12.route, "optionalAccess", (_13) => _13.path]);
  const isRegex = isRegExp(lrp);
  const isArray = Array.isArray(lrp);
  if (!lrp) {
    const [major] = GLOBAL_OBJ.process.versions.node.split(".").map(Number);
    if (major >= 16) {
      lrp = extractOriginalRoute(layer.path, layer.regexp, layer.keys);
    }
  }
  if (!lrp) {
    return { isRegex, isArray, numExtraSegments: 0 };
  }
  const numExtraSegments = isArray ? Math.max(getNumberOfArrayUrlSegments(lrp) - getNumberOfUrlSegments(layer.path || ""), 0) : 0;
  const layerRoutePath = getLayerRoutePathString(isArray, lrp);
  return { layerRoutePath, isRegex, isArray, numExtraSegments };
}
function getNumberOfArrayUrlSegments(routesArray) {
  return routesArray.reduce((accNumSegments, currentRoute) => {
    return accNumSegments + getNumberOfUrlSegments(currentRoute.toString());
  }, 0);
}
function getLayerRoutePathString(isArray, lrp) {
  if (isArray) {
    return lrp.map((r2) => r2.toString()).join(",");
  }
  return lrp && lrp.toString();
}
function preventDuplicateSegments(originalUrl, reconstructedRoute, layerPath) {
  const normalizeURL = stripUrlQueryAndFragment(originalUrl || "");
  const originalUrlSplit = _optionalChain([normalizeURL, "optionalAccess", (_14) => _14.split, "call", (_15) => _15("/"), "access", (_16) => _16.filter, "call", (_17) => _17((v) => !!v)]);
  let tempCounter = 0;
  const currentOffset = _optionalChain([reconstructedRoute, "optionalAccess", (_18) => _18.split, "call", (_19) => _19("/"), "access", (_20) => _20.filter, "call", (_21) => _21((v) => !!v), "access", (_22) => _22.length]) || 0;
  const result = _optionalChain([
    layerPath,
    "optionalAccess",
    (_23) => _23.split,
    "call",
    (_24) => _24("/"),
    "access",
    (_25) => _25.filter,
    "call",
    (_26) => _26((segment) => {
      if (_optionalChain([originalUrlSplit, "optionalAccess", (_27) => _27[currentOffset + tempCounter]]) === segment) {
        tempCounter += 1;
        return true;
      }
      return false;
    }),
    "access",
    (_28) => _28.join,
    "call",
    (_29) => _29("/")
  ]);
  return result;
}

// node_modules/@sentry-internal/tracing/esm/node/integrations/postgres.js
var Postgres = class _Postgres {
  /**
   * @inheritDoc
   */
  static __initStatic() {
    this.id = "Postgres";
  }
  /**
   * @inheritDoc
   */
  constructor(options = {}) {
    this.name = _Postgres.id;
    this._usePgNative = !!options.usePgNative;
    this._module = options.module;
  }
  /** @inheritdoc */
  loadDependency() {
    return this._module = this._module || loadModule("pg");
  }
  /**
   * @inheritDoc
   */
  setupOnce(_, getCurrentHub2) {
    if (shouldDisableAutoInstrumentation(getCurrentHub2)) {
      DEBUG_BUILD3 && logger.log("Postgres Integration is skipped because of instrumenter configuration.");
      return;
    }
    const pkg = this.loadDependency();
    if (!pkg) {
      DEBUG_BUILD3 && logger.error("Postgres Integration was unable to require `pg` package.");
      return;
    }
    const Client = this._usePgNative ? _optionalChain([pkg, "access", (_2) => _2.native, "optionalAccess", (_3) => _3.Client]) : pkg.Client;
    if (!Client) {
      DEBUG_BUILD3 && logger.error("Postgres Integration was unable to access 'pg-native' bindings.");
      return;
    }
    fill(Client.prototype, "query", function(orig) {
      return function(config, values, callback) {
        const scope = getCurrentHub2().getScope();
        const parentSpan = scope.getSpan();
        const data = {
          "db.system": "postgresql"
        };
        try {
          if (this.database) {
            data["db.name"] = this.database;
          }
          if (this.host) {
            data["server.address"] = this.host;
          }
          if (this.port) {
            data["server.port"] = this.port;
          }
          if (this.user) {
            data["db.user"] = this.user;
          }
        } catch (e2) {
        }
        const span = _optionalChain([parentSpan, "optionalAccess", (_4) => _4.startChild, "call", (_5) => _5({
          description: typeof config === "string" ? config : config.text,
          op: "db",
          origin: "auto.db.postgres",
          data
        })]);
        if (typeof callback === "function") {
          return orig.call(this, config, values, function(err, result) {
            _optionalChain([span, "optionalAccess", (_6) => _6.end, "call", (_7) => _7()]);
            callback(err, result);
          });
        }
        if (typeof values === "function") {
          return orig.call(this, config, function(err, result) {
            _optionalChain([span, "optionalAccess", (_8) => _8.end, "call", (_9) => _9()]);
            values(err, result);
          });
        }
        const rv = typeof values !== "undefined" ? orig.call(this, config, values) : orig.call(this, config);
        if (isThenable(rv)) {
          return rv.then((res) => {
            _optionalChain([span, "optionalAccess", (_10) => _10.end, "call", (_11) => _11()]);
            return res;
          });
        }
        _optionalChain([span, "optionalAccess", (_12) => _12.end, "call", (_13) => _13()]);
        return rv;
      };
    });
  }
};
Postgres.__initStatic();

// node_modules/@sentry-internal/tracing/esm/node/integrations/mysql.js
var Mysql = class _Mysql {
  /**
   * @inheritDoc
   */
  static __initStatic() {
    this.id = "Mysql";
  }
  /**
   * @inheritDoc
   */
  constructor() {
    this.name = _Mysql.id;
  }
  /** @inheritdoc */
  loadDependency() {
    return this._module = this._module || loadModule("mysql/lib/Connection.js");
  }
  /**
   * @inheritDoc
   */
  setupOnce(_, getCurrentHub2) {
    if (shouldDisableAutoInstrumentation(getCurrentHub2)) {
      DEBUG_BUILD3 && logger.log("Mysql Integration is skipped because of instrumenter configuration.");
      return;
    }
    const pkg = this.loadDependency();
    if (!pkg) {
      DEBUG_BUILD3 && logger.error("Mysql Integration was unable to require `mysql` package.");
      return;
    }
    let mySqlConfig = void 0;
    try {
      pkg.prototype.connect = new Proxy(pkg.prototype.connect, {
        apply(wrappingTarget, thisArg, args) {
          if (!mySqlConfig) {
            mySqlConfig = thisArg.config;
          }
          return wrappingTarget.apply(thisArg, args);
        }
      });
    } catch (e2) {
      DEBUG_BUILD3 && logger.error("Mysql Integration was unable to instrument `mysql` config.");
    }
    function spanDataFromConfig() {
      if (!mySqlConfig) {
        return {};
      }
      return {
        "server.address": mySqlConfig.host,
        "server.port": mySqlConfig.port,
        "db.user": mySqlConfig.user
      };
    }
    function finishSpan(span) {
      if (!span) {
        return;
      }
      const data = spanDataFromConfig();
      Object.keys(data).forEach((key) => {
        span.setAttribute(key, data[key]);
      });
      span.end();
    }
    fill(pkg, "createQuery", function(orig) {
      return function(options, values, callback) {
        const scope = getCurrentHub2().getScope();
        const parentSpan = scope.getSpan();
        const span = _optionalChain([parentSpan, "optionalAccess", (_2) => _2.startChild, "call", (_3) => _3({
          description: typeof options === "string" ? options : options.sql,
          op: "db",
          origin: "auto.db.mysql",
          data: {
            "db.system": "mysql"
          }
        })]);
        if (typeof callback === "function") {
          return orig.call(this, options, values, function(err, result, fields) {
            finishSpan(span);
            callback(err, result, fields);
          });
        }
        if (typeof values === "function") {
          return orig.call(this, options, function(err, result, fields) {
            finishSpan(span);
            values(err, result, fields);
          });
        }
        const query = orig.call(this, options, values);
        query.on("end", () => {
          finishSpan(span);
        });
        return query;
      };
    });
  }
};
Mysql.__initStatic();

// node_modules/@sentry-internal/tracing/esm/node/integrations/mongo.js
var OPERATIONS = [
  "aggregate",
  // aggregate(pipeline, options, callback)
  "bulkWrite",
  // bulkWrite(operations, options, callback)
  "countDocuments",
  // countDocuments(query, options, callback)
  "createIndex",
  // createIndex(fieldOrSpec, options, callback)
  "createIndexes",
  // createIndexes(indexSpecs, options, callback)
  "deleteMany",
  // deleteMany(filter, options, callback)
  "deleteOne",
  // deleteOne(filter, options, callback)
  "distinct",
  // distinct(key, query, options, callback)
  "drop",
  // drop(options, callback)
  "dropIndex",
  // dropIndex(indexName, options, callback)
  "dropIndexes",
  // dropIndexes(options, callback)
  "estimatedDocumentCount",
  // estimatedDocumentCount(options, callback)
  "find",
  // find(query, options, callback)
  "findOne",
  // findOne(query, options, callback)
  "findOneAndDelete",
  // findOneAndDelete(filter, options, callback)
  "findOneAndReplace",
  // findOneAndReplace(filter, replacement, options, callback)
  "findOneAndUpdate",
  // findOneAndUpdate(filter, update, options, callback)
  "indexes",
  // indexes(options, callback)
  "indexExists",
  // indexExists(indexes, options, callback)
  "indexInformation",
  // indexInformation(options, callback)
  "initializeOrderedBulkOp",
  // initializeOrderedBulkOp(options, callback)
  "insertMany",
  // insertMany(docs, options, callback)
  "insertOne",
  // insertOne(doc, options, callback)
  "isCapped",
  // isCapped(options, callback)
  "mapReduce",
  // mapReduce(map, reduce, options, callback)
  "options",
  // options(options, callback)
  "parallelCollectionScan",
  // parallelCollectionScan(options, callback)
  "rename",
  // rename(newName, options, callback)
  "replaceOne",
  // replaceOne(filter, doc, options, callback)
  "stats",
  // stats(options, callback)
  "updateMany",
  // updateMany(filter, update, options, callback)
  "updateOne"
  // updateOne(filter, update, options, callback)
];
var OPERATION_SIGNATURES = {
  // aggregate intentionally not included because `pipeline` arguments are too complex to serialize well
  // see https://github.com/getsentry/sentry-javascript/pull/3102
  bulkWrite: ["operations"],
  countDocuments: ["query"],
  createIndex: ["fieldOrSpec"],
  createIndexes: ["indexSpecs"],
  deleteMany: ["filter"],
  deleteOne: ["filter"],
  distinct: ["key", "query"],
  dropIndex: ["indexName"],
  find: ["query"],
  findOne: ["query"],
  findOneAndDelete: ["filter"],
  findOneAndReplace: ["filter", "replacement"],
  findOneAndUpdate: ["filter", "update"],
  indexExists: ["indexes"],
  insertMany: ["docs"],
  insertOne: ["doc"],
  mapReduce: ["map", "reduce"],
  rename: ["newName"],
  replaceOne: ["filter", "doc"],
  updateMany: ["filter", "update"],
  updateOne: ["filter", "update"]
};
function isCursor(maybeCursor) {
  return maybeCursor && typeof maybeCursor === "object" && maybeCursor.once && typeof maybeCursor.once === "function";
}
var Mongo = class _Mongo {
  /**
   * @inheritDoc
   */
  static __initStatic() {
    this.id = "Mongo";
  }
  /**
   * @inheritDoc
   */
  /**
   * @inheritDoc
   */
  constructor(options = {}) {
    this.name = _Mongo.id;
    this._operations = Array.isArray(options.operations) ? options.operations : OPERATIONS;
    this._describeOperations = "describeOperations" in options ? options.describeOperations : true;
    this._useMongoose = !!options.useMongoose;
  }
  /** @inheritdoc */
  loadDependency() {
    const moduleName = this._useMongoose ? "mongoose" : "mongodb";
    return this._module = this._module || loadModule(moduleName);
  }
  /**
   * @inheritDoc
   */
  setupOnce(_, getCurrentHub2) {
    if (shouldDisableAutoInstrumentation(getCurrentHub2)) {
      DEBUG_BUILD3 && logger.log("Mongo Integration is skipped because of instrumenter configuration.");
      return;
    }
    const pkg = this.loadDependency();
    if (!pkg) {
      const moduleName = this._useMongoose ? "mongoose" : "mongodb";
      DEBUG_BUILD3 && logger.error(`Mongo Integration was unable to require \`${moduleName}\` package.`);
      return;
    }
    this._instrumentOperations(pkg.Collection, this._operations, getCurrentHub2);
  }
  /**
   * Patches original collection methods
   */
  _instrumentOperations(collection, operations, getCurrentHub2) {
    operations.forEach((operation) => this._patchOperation(collection, operation, getCurrentHub2));
  }
  /**
   * Patches original collection to utilize our tracing functionality
   */
  _patchOperation(collection, operation, getCurrentHub2) {
    if (!(operation in collection.prototype))
      return;
    const getSpanContext = this._getSpanContextFromOperationArguments.bind(this);
    fill(collection.prototype, operation, function(orig) {
      return function(...args) {
        const lastArg = args[args.length - 1];
        const hub = getCurrentHub2();
        const scope = hub.getScope();
        const client = hub.getClient();
        const parentSpan = scope.getSpan();
        const sendDefaultPii = _optionalChain([client, "optionalAccess", (_2) => _2.getOptions, "call", (_3) => _3(), "access", (_4) => _4.sendDefaultPii]);
        if (typeof lastArg !== "function" || operation === "mapReduce" && args.length === 2) {
          const span2 = _optionalChain([parentSpan, "optionalAccess", (_5) => _5.startChild, "call", (_6) => _6(getSpanContext(this, operation, args, sendDefaultPii))]);
          const maybePromiseOrCursor = orig.call(this, ...args);
          if (isThenable(maybePromiseOrCursor)) {
            return maybePromiseOrCursor.then((res) => {
              _optionalChain([span2, "optionalAccess", (_7) => _7.end, "call", (_8) => _8()]);
              return res;
            });
          } else if (isCursor(maybePromiseOrCursor)) {
            const cursor = maybePromiseOrCursor;
            try {
              cursor.once("close", () => {
                _optionalChain([span2, "optionalAccess", (_9) => _9.end, "call", (_10) => _10()]);
              });
            } catch (e2) {
              _optionalChain([span2, "optionalAccess", (_11) => _11.end, "call", (_12) => _12()]);
            }
            return cursor;
          } else {
            _optionalChain([span2, "optionalAccess", (_13) => _13.end, "call", (_14) => _14()]);
            return maybePromiseOrCursor;
          }
        }
        const span = _optionalChain([parentSpan, "optionalAccess", (_15) => _15.startChild, "call", (_16) => _16(getSpanContext(this, operation, args.slice(0, -1)))]);
        return orig.call(this, ...args.slice(0, -1), function(err, result) {
          _optionalChain([span, "optionalAccess", (_17) => _17.end, "call", (_18) => _18()]);
          lastArg(err, result);
        });
      };
    });
  }
  /**
   * Form a SpanContext based on the user input to a given operation.
   */
  _getSpanContextFromOperationArguments(collection, operation, args, sendDefaultPii = false) {
    const data = {
      "db.system": "mongodb",
      "db.name": collection.dbName,
      "db.operation": operation,
      "db.mongodb.collection": collection.collectionName
    };
    const spanContext = {
      op: "db",
      // TODO v8: Use `${collection.collectionName}.${operation}`
      origin: "auto.db.mongo",
      description: operation,
      data
    };
    const signature = OPERATION_SIGNATURES[operation];
    const shouldDescribe = Array.isArray(this._describeOperations) ? this._describeOperations.includes(operation) : this._describeOperations;
    if (!signature || !shouldDescribe || !sendDefaultPii) {
      return spanContext;
    }
    try {
      if (operation === "mapReduce") {
        const [map, reduce] = args;
        data[signature[0]] = typeof map === "string" ? map : map.name || "<anonymous>";
        data[signature[1]] = typeof reduce === "string" ? reduce : reduce.name || "<anonymous>";
      } else {
        for (let i2 = 0; i2 < signature.length; i2++) {
          data[`db.mongodb.${signature[i2]}`] = JSON.stringify(args[i2]);
        }
      }
    } catch (_oO) {
    }
    return spanContext;
  }
};
Mongo.__initStatic();

// node_modules/@sentry-internal/tracing/esm/node/integrations/prisma.js
function isValidPrismaClient(possibleClient) {
  return !!possibleClient && !!possibleClient["$use"];
}
var Prisma = class _Prisma {
  /**
   * @inheritDoc
   */
  static __initStatic() {
    this.id = "Prisma";
  }
  /**
   * @inheritDoc
   */
  /**
   * @inheritDoc
   */
  constructor(options = {}) {
    this.name = _Prisma.id;
    if (isValidPrismaClient(options.client) && !options.client._sentryInstrumented) {
      addNonEnumerableProperty(options.client, "_sentryInstrumented", true);
      const clientData = {};
      try {
        const engineConfig = options.client._engineConfig;
        if (engineConfig) {
          const { activeProvider, clientVersion } = engineConfig;
          if (activeProvider) {
            clientData["db.system"] = activeProvider;
          }
          if (clientVersion) {
            clientData["db.prisma.version"] = clientVersion;
          }
        }
      } catch (e2) {
      }
      options.client.$use((params, next) => {
        if (shouldDisableAutoInstrumentation(getCurrentHub)) {
          return next(params);
        }
        const action = params.action;
        const model = params.model;
        return startSpan(
          {
            name: model ? `${model} ${action}` : action,
            onlyIfParent: true,
            op: "db.prisma",
            attributes: {
              [SEMANTIC_ATTRIBUTE_SENTRY_ORIGIN]: "auto.db.prisma"
            },
            data: { ...clientData, "db.operation": action }
          },
          () => next(params)
        );
      });
    } else {
      DEBUG_BUILD3 && logger.warn("Unsupported Prisma client provided to PrismaIntegration. Provided client:", options.client);
    }
  }
  /**
   * @inheritDoc
   */
  setupOnce() {
  }
};
Prisma.__initStatic();

// node_modules/@sentry-internal/tracing/esm/node/integrations/graphql.js
var GraphQL = class _GraphQL {
  /**
   * @inheritDoc
   */
  static __initStatic() {
    this.id = "GraphQL";
  }
  /**
   * @inheritDoc
   */
  constructor() {
    this.name = _GraphQL.id;
  }
  /** @inheritdoc */
  loadDependency() {
    return this._module = this._module || loadModule("graphql/execution/execute.js");
  }
  /**
   * @inheritDoc
   */
  setupOnce(_, getCurrentHub2) {
    if (shouldDisableAutoInstrumentation(getCurrentHub2)) {
      DEBUG_BUILD3 && logger.log("GraphQL Integration is skipped because of instrumenter configuration.");
      return;
    }
    const pkg = this.loadDependency();
    if (!pkg) {
      DEBUG_BUILD3 && logger.error("GraphQL Integration was unable to require graphql/execution package.");
      return;
    }
    fill(pkg, "execute", function(orig) {
      return function(...args) {
        const scope = getCurrentHub2().getScope();
        const parentSpan = scope.getSpan();
        const span = _optionalChain([parentSpan, "optionalAccess", (_2) => _2.startChild, "call", (_3) => _3({
          description: "execute",
          op: "graphql.execute",
          origin: "auto.graphql.graphql"
        })]);
        _optionalChain([scope, "optionalAccess", (_4) => _4.setSpan, "call", (_5) => _5(span)]);
        const rv = orig.call(this, ...args);
        if (isThenable(rv)) {
          return rv.then((res) => {
            _optionalChain([span, "optionalAccess", (_6) => _6.end, "call", (_7) => _7()]);
            _optionalChain([scope, "optionalAccess", (_8) => _8.setSpan, "call", (_9) => _9(parentSpan)]);
            return res;
          });
        }
        _optionalChain([span, "optionalAccess", (_10) => _10.end, "call", (_11) => _11()]);
        _optionalChain([scope, "optionalAccess", (_12) => _12.setSpan, "call", (_13) => _13(parentSpan)]);
        return rv;
      };
    });
  }
};
GraphQL.__initStatic();

// node_modules/@sentry-internal/tracing/esm/node/integrations/apollo.js
var Apollo = class _Apollo {
  /**
   * @inheritDoc
   */
  static __initStatic() {
    this.id = "Apollo";
  }
  /**
   * @inheritDoc
   */
  /**
   * @inheritDoc
   */
  constructor(options = {
    useNestjs: false
  }) {
    this.name = _Apollo.id;
    this._useNest = !!options.useNestjs;
  }
  /** @inheritdoc */
  loadDependency() {
    if (this._useNest) {
      this._module = this._module || loadModule("@nestjs/graphql");
    } else {
      this._module = this._module || loadModule("apollo-server-core");
    }
    return this._module;
  }
  /**
   * @inheritDoc
   */
  setupOnce(_, getCurrentHub2) {
    if (shouldDisableAutoInstrumentation(getCurrentHub2)) {
      DEBUG_BUILD3 && logger.log("Apollo Integration is skipped because of instrumenter configuration.");
      return;
    }
    if (this._useNest) {
      const pkg = this.loadDependency();
      if (!pkg) {
        DEBUG_BUILD3 && logger.error("Apollo-NestJS Integration was unable to require @nestjs/graphql package.");
        return;
      }
      fill(
        pkg.GraphQLFactory.prototype,
        "mergeWithSchema",
        function(orig) {
          return function(...args) {
            fill(this.resolversExplorerService, "explore", function(orig2) {
              return function() {
                const resolvers = arrayify(orig2.call(this));
                const instrumentedResolvers = instrumentResolvers(resolvers, getCurrentHub2);
                return instrumentedResolvers;
              };
            });
            return orig.call(this, ...args);
          };
        }
      );
    } else {
      const pkg = this.loadDependency();
      if (!pkg) {
        DEBUG_BUILD3 && logger.error("Apollo Integration was unable to require apollo-server-core package.");
        return;
      }
      fill(pkg.ApolloServerBase.prototype, "constructSchema", function(orig) {
        return function() {
          if (!this.config.resolvers) {
            if (DEBUG_BUILD3) {
              if (this.config.schema) {
                logger.warn(
                  "Apollo integration is not able to trace `ApolloServer` instances constructed via `schema` property.If you are using NestJS with Apollo, please use `Sentry.Integrations.Apollo({ useNestjs: true })` instead."
                );
                logger.warn();
              } else if (this.config.modules) {
                logger.warn(
                  "Apollo integration is not able to trace `ApolloServer` instances constructed via `modules` property."
                );
              }
              logger.error("Skipping tracing as no resolvers found on the `ApolloServer` instance.");
            }
            return orig.call(this);
          }
          const resolvers = arrayify(this.config.resolvers);
          this.config.resolvers = instrumentResolvers(resolvers, getCurrentHub2);
          return orig.call(this);
        };
      });
    }
  }
};
Apollo.__initStatic();
function instrumentResolvers(resolvers, getCurrentHub2) {
  return resolvers.map((model) => {
    Object.keys(model).forEach((resolverGroupName) => {
      Object.keys(model[resolverGroupName]).forEach((resolverName) => {
        if (typeof model[resolverGroupName][resolverName] !== "function") {
          return;
        }
        wrapResolver(model, resolverGroupName, resolverName, getCurrentHub2);
      });
    });
    return model;
  });
}
function wrapResolver(model, resolverGroupName, resolverName, getCurrentHub2) {
  fill(model[resolverGroupName], resolverName, function(orig) {
    return function(...args) {
      const scope = getCurrentHub2().getScope();
      const parentSpan = scope.getSpan();
      const span = _optionalChain([parentSpan, "optionalAccess", (_2) => _2.startChild, "call", (_3) => _3({
        description: `${resolverGroupName}.${resolverName}`,
        op: "graphql.resolve",
        origin: "auto.graphql.apollo"
      })]);
      const rv = orig.call(this, ...args);
      if (isThenable(rv)) {
        return rv.then((res) => {
          _optionalChain([span, "optionalAccess", (_4) => _4.end, "call", (_5) => _5()]);
          return res;
        });
      }
      _optionalChain([span, "optionalAccess", (_6) => _6.end, "call", (_7) => _7()]);
      return rv;
    };
  });
}

// node_modules/@sentry/node/esm/transports/http.js
var http4 = __toESM(require("http"));
var https2 = __toESM(require("https"));
var import_stream = require("stream");
var import_url4 = require("url");
var import_zlib = require("zlib");

// node_modules/@sentry/node/esm/proxy/index.js
var import_assert = __toESM(require("assert"));
var net = __toESM(require("net"));
var tls = __toESM(require("tls"));
var import_url3 = require("url");

// node_modules/@sentry/node/esm/proxy/base.js
var http3 = __toESM(require("http"));
var INTERNAL = Symbol("AgentBaseInternalState");
var Agent2 = class extends http3.Agent {
  // Set by `http.Agent` - missing from `@types/node`
  constructor(opts) {
    super(opts);
    this[INTERNAL] = {};
  }
  /**
   * Determine whether this is an `http` or `https` request.
   */
  isSecureEndpoint(options) {
    if (options) {
      if (typeof options.secureEndpoint === "boolean") {
        return options.secureEndpoint;
      }
      if (typeof options.protocol === "string") {
        return options.protocol === "https:";
      }
    }
    const { stack } = new Error();
    if (typeof stack !== "string")
      return false;
    return stack.split("\n").some((l) => l.indexOf("(https.js:") !== -1 || l.indexOf("node:https:") !== -1);
  }
  createSocket(req, options, cb) {
    const connectOpts = {
      ...options,
      secureEndpoint: this.isSecureEndpoint(options)
    };
    Promise.resolve().then(() => this.connect(req, connectOpts)).then((socket) => {
      if (socket instanceof http3.Agent) {
        return socket.addRequest(req, connectOpts);
      }
      this[INTERNAL].currentSocket = socket;
      super.createSocket(req, options, cb);
    }, cb);
  }
  createConnection() {
    const socket = this[INTERNAL].currentSocket;
    this[INTERNAL].currentSocket = void 0;
    if (!socket) {
      throw new Error("No socket was returned in the `connect()` function");
    }
    return socket;
  }
  get defaultPort() {
    return _nullishCoalesce(this[INTERNAL].defaultPort, () => this.protocol === "https:" ? 443 : 80);
  }
  set defaultPort(v) {
    if (this[INTERNAL]) {
      this[INTERNAL].defaultPort = v;
    }
  }
  get protocol() {
    return _nullishCoalesce(this[INTERNAL].protocol, () => this.isSecureEndpoint() ? "https:" : "http:");
  }
  set protocol(v) {
    if (this[INTERNAL]) {
      this[INTERNAL].protocol = v;
    }
  }
};

// node_modules/@sentry/node/esm/proxy/parse-proxy-response.js
function debug(...args) {
  logger.log("[https-proxy-agent:parse-proxy-response]", ...args);
}
function parseProxyResponse(socket) {
  return new Promise((resolve2, reject) => {
    let buffersLength = 0;
    const buffers = [];
    function read() {
      const b = socket.read();
      if (b)
        ondata(b);
      else
        socket.once("readable", read);
    }
    function cleanup() {
      socket.removeListener("end", onend);
      socket.removeListener("error", onerror);
      socket.removeListener("readable", read);
    }
    function onend() {
      cleanup();
      debug("onend");
      reject(new Error("Proxy connection ended before receiving CONNECT response"));
    }
    function onerror(err) {
      cleanup();
      debug("onerror %o", err);
      reject(err);
    }
    function ondata(b) {
      buffers.push(b);
      buffersLength += b.length;
      const buffered = Buffer.concat(buffers, buffersLength);
      const endOfHeaders = buffered.indexOf("\r\n\r\n");
      if (endOfHeaders === -1) {
        debug("have not received end of HTTP headers yet...");
        read();
        return;
      }
      const headerParts = buffered.slice(0, endOfHeaders).toString("ascii").split("\r\n");
      const firstLine = headerParts.shift();
      if (!firstLine) {
        socket.destroy();
        return reject(new Error("No header received from proxy CONNECT response"));
      }
      const firstLineParts = firstLine.split(" ");
      const statusCode = +firstLineParts[1];
      const statusText = firstLineParts.slice(2).join(" ");
      const headers = {};
      for (const header of headerParts) {
        if (!header)
          continue;
        const firstColon = header.indexOf(":");
        if (firstColon === -1) {
          socket.destroy();
          return reject(new Error(`Invalid header from proxy CONNECT response: "${header}"`));
        }
        const key = header.slice(0, firstColon).toLowerCase();
        const value = header.slice(firstColon + 1).trimStart();
        const current = headers[key];
        if (typeof current === "string") {
          headers[key] = [current, value];
        } else if (Array.isArray(current)) {
          current.push(value);
        } else {
          headers[key] = value;
        }
      }
      debug("got proxy server response: %o %o", firstLine, headers);
      cleanup();
      resolve2({
        connect: {
          statusCode,
          statusText,
          headers
        },
        buffered
      });
    }
    socket.on("error", onerror);
    socket.on("end", onend);
    read();
  });
}

// node_modules/@sentry/node/esm/proxy/index.js
function debug2(...args) {
  logger.log("[https-proxy-agent]", ...args);
}
var HttpsProxyAgent = class extends Agent2 {
  static __initStatic() {
    this.protocols = ["http", "https"];
  }
  constructor(proxy, opts) {
    super(opts);
    this.options = {};
    this.proxy = typeof proxy === "string" ? new import_url3.URL(proxy) : proxy;
    this.proxyHeaders = _nullishCoalesce(_optionalChain([opts, "optionalAccess", (_2) => _2.headers]), () => ({}));
    debug2("Creating new HttpsProxyAgent instance: %o", this.proxy.href);
    const host = (this.proxy.hostname || this.proxy.host).replace(/^\[|\]$/g, "");
    const port = this.proxy.port ? parseInt(this.proxy.port, 10) : this.proxy.protocol === "https:" ? 443 : 80;
    this.connectOpts = {
      // Attempt to negotiate http/1.1 for proxy servers that support http/2
      ALPNProtocols: ["http/1.1"],
      ...opts ? omit(opts, "headers") : null,
      host,
      port
    };
  }
  /**
   * Called when the node-core HTTP client library is creating a
   * new HTTP request.
   */
  async connect(req, opts) {
    const { proxy } = this;
    if (!opts.host) {
      throw new TypeError('No "host" provided');
    }
    let socket;
    if (proxy.protocol === "https:") {
      debug2("Creating `tls.Socket`: %o", this.connectOpts);
      const servername = this.connectOpts.servername || this.connectOpts.host;
      socket = tls.connect({
        ...this.connectOpts,
        servername: servername && net.isIP(servername) ? void 0 : servername
      });
    } else {
      debug2("Creating `net.Socket`: %o", this.connectOpts);
      socket = net.connect(this.connectOpts);
    }
    const headers = typeof this.proxyHeaders === "function" ? this.proxyHeaders() : { ...this.proxyHeaders };
    const host = net.isIPv6(opts.host) ? `[${opts.host}]` : opts.host;
    let payload = `CONNECT ${host}:${opts.port} HTTP/1.1\r
`;
    if (proxy.username || proxy.password) {
      const auth = `${decodeURIComponent(proxy.username)}:${decodeURIComponent(proxy.password)}`;
      headers["Proxy-Authorization"] = `Basic ${Buffer.from(auth).toString("base64")}`;
    }
    headers.Host = `${host}:${opts.port}`;
    if (!headers["Proxy-Connection"]) {
      headers["Proxy-Connection"] = this.keepAlive ? "Keep-Alive" : "close";
    }
    for (const name of Object.keys(headers)) {
      payload += `${name}: ${headers[name]}\r
`;
    }
    const proxyResponsePromise = parseProxyResponse(socket);
    socket.write(`${payload}\r
`);
    const { connect: connect3, buffered } = await proxyResponsePromise;
    req.emit("proxyConnect", connect3);
    this.emit("proxyConnect", connect3, req);
    if (connect3.statusCode === 200) {
      req.once("socket", resume);
      if (opts.secureEndpoint) {
        debug2("Upgrading socket connection to TLS");
        const servername = opts.servername || opts.host;
        return tls.connect({
          ...omit(opts, "host", "path", "port"),
          socket,
          servername: net.isIP(servername) ? void 0 : servername
        });
      }
      return socket;
    }
    socket.destroy();
    const fakeSocket = new net.Socket({ writable: false });
    fakeSocket.readable = true;
    req.once("socket", (s2) => {
      debug2("Replaying proxy buffer for failed request");
      (0, import_assert.default)(s2.listenerCount("data") > 0);
      s2.push(buffered);
      s2.push(null);
    });
    return fakeSocket;
  }
};
HttpsProxyAgent.__initStatic();
function resume(socket) {
  socket.resume();
}
function omit(obj, ...keys) {
  const ret = {};
  let key;
  for (key in obj) {
    if (!keys.includes(key)) {
      ret[key] = obj[key];
    }
  }
  return ret;
}

// node_modules/@sentry/node/esm/transports/http.js
var GZIP_THRESHOLD = 1024 * 32;
function streamFromBody(body) {
  return new import_stream.Readable({
    read() {
      this.push(body);
      this.push(null);
    }
  });
}
function makeNodeTransport(options) {
  let urlSegments;
  try {
    urlSegments = new import_url4.URL(options.url);
  } catch (e2) {
    consoleSandbox(() => {
      console.warn(
        "[@sentry/node]: Invalid dsn or tunnel option, will not send any events. The tunnel option must be a full URL when used."
      );
    });
    return createTransport(options, () => Promise.resolve({}));
  }
  const isHttps = urlSegments.protocol === "https:";
  const proxy = applyNoProxyOption(
    urlSegments,
    options.proxy || (isHttps ? process.env.https_proxy : void 0) || process.env.http_proxy
  );
  const nativeHttpModule = isHttps ? https2 : http4;
  const keepAlive = options.keepAlive === void 0 ? false : options.keepAlive;
  const agent = proxy ? new HttpsProxyAgent(proxy) : new nativeHttpModule.Agent({ keepAlive, maxSockets: 30, timeout: 2e3 });
  const requestExecutor = createRequestExecutor(options, _nullishCoalesce(options.httpModule, () => nativeHttpModule), agent);
  return createTransport(options, requestExecutor);
}
function applyNoProxyOption(transportUrlSegments, proxy) {
  const { no_proxy } = process.env;
  const urlIsExemptFromProxy = no_proxy && no_proxy.split(",").some(
    (exemption) => transportUrlSegments.host.endsWith(exemption) || transportUrlSegments.hostname.endsWith(exemption)
  );
  if (urlIsExemptFromProxy) {
    return void 0;
  } else {
    return proxy;
  }
}
function createRequestExecutor(options, httpModule, agent) {
  const { hostname, pathname, port, protocol, search } = new import_url4.URL(options.url);
  return function makeRequest(request) {
    return new Promise((resolve2, reject) => {
      let body = streamFromBody(request.body);
      const headers = { ...options.headers };
      if (request.body.length > GZIP_THRESHOLD) {
        headers["content-encoding"] = "gzip";
        body = body.pipe((0, import_zlib.createGzip)());
      }
      const req = httpModule.request(
        {
          method: "POST",
          agent,
          headers,
          hostname,
          path: `${pathname}${search}`,
          port,
          protocol,
          ca: options.caCerts
        },
        (res) => {
          res.on("data", () => {
          });
          res.on("end", () => {
          });
          res.setEncoding("utf8");
          const retryAfterHeader = _nullishCoalesce(res.headers["retry-after"], () => null);
          const rateLimitsHeader = _nullishCoalesce(res.headers["x-sentry-rate-limits"], () => null);
          resolve2({
            statusCode: res.statusCode,
            headers: {
              "retry-after": retryAfterHeader,
              "x-sentry-rate-limits": Array.isArray(rateLimitsHeader) ? rateLimitsHeader[0] : rateLimitsHeader
            }
          });
        }
      );
      req.on("error", reject);
      body.pipe(req);
    });
  };
}

// node_modules/@sentry/node/esm/nodeVersion.js
var NODE_VERSION = parseSemver(process.versions.node);

// node_modules/@sentry/node/esm/integrations/console.js
var util = __toESM(require("util"));
var INTEGRATION_NAME5 = "Console";
var _consoleIntegration = () => {
  return {
    name: INTEGRATION_NAME5,
    // TODO v8: Remove this
    setupOnce() {
    },
    // eslint-disable-line @typescript-eslint/no-empty-function
    setup(client) {
      addConsoleInstrumentationHandler(({ args, level }) => {
        if (getClient() !== client) {
          return;
        }
        addBreadcrumb(
          {
            category: "console",
            level: severityLevelFromString(level),
            message: util.format.apply(void 0, args)
          },
          {
            input: [...args],
            level
          }
        );
      });
    }
  };
};
var consoleIntegration = defineIntegration(_consoleIntegration);
var Console = convertIntegrationFnToClass(INTEGRATION_NAME5, consoleIntegration);

// node_modules/@sentry/node/esm/integrations/context.js
var import_child_process = require("child_process");
var import_fs = require("fs");
var os = __toESM(require("os"));
var import_path2 = require("path");
var import_util = require("util");
var readFileAsync = (0, import_util.promisify)(import_fs.readFile);
var readDirAsync = (0, import_util.promisify)(import_fs.readdir);
var INTEGRATION_NAME6 = "Context";
var _nodeContextIntegration = (options = {}) => {
  let cachedContext;
  const _options = {
    app: true,
    os: true,
    device: true,
    culture: true,
    cloudResource: true,
    ...options
  };
  async function addContext(event) {
    if (cachedContext === void 0) {
      cachedContext = _getContexts();
    }
    const updatedContext = _updateContext(await cachedContext);
    event.contexts = {
      ...event.contexts,
      app: { ...updatedContext.app, ..._optionalChain([event, "access", (_) => _.contexts, "optionalAccess", (_2) => _2.app]) },
      os: { ...updatedContext.os, ..._optionalChain([event, "access", (_3) => _3.contexts, "optionalAccess", (_4) => _4.os]) },
      device: { ...updatedContext.device, ..._optionalChain([event, "access", (_5) => _5.contexts, "optionalAccess", (_6) => _6.device]) },
      culture: { ...updatedContext.culture, ..._optionalChain([event, "access", (_7) => _7.contexts, "optionalAccess", (_8) => _8.culture]) },
      cloud_resource: { ...updatedContext.cloud_resource, ..._optionalChain([event, "access", (_9) => _9.contexts, "optionalAccess", (_10) => _10.cloud_resource]) }
    };
    return event;
  }
  async function _getContexts() {
    const contexts = {};
    if (_options.os) {
      contexts.os = await getOsContext();
    }
    if (_options.app) {
      contexts.app = getAppContext();
    }
    if (_options.device) {
      contexts.device = getDeviceContext(_options.device);
    }
    if (_options.culture) {
      const culture = getCultureContext();
      if (culture) {
        contexts.culture = culture;
      }
    }
    if (_options.cloudResource) {
      contexts.cloud_resource = getCloudResourceContext();
    }
    return contexts;
  }
  return {
    name: INTEGRATION_NAME6,
    // TODO v8: Remove this
    setupOnce() {
    },
    // eslint-disable-line @typescript-eslint/no-empty-function
    processEvent(event) {
      return addContext(event);
    }
  };
};
var nodeContextIntegration = defineIntegration(_nodeContextIntegration);
var Context = convertIntegrationFnToClass(INTEGRATION_NAME6, nodeContextIntegration);
function _updateContext(contexts) {
  if (_optionalChain([contexts, "optionalAccess", (_11) => _11.app, "optionalAccess", (_12) => _12.app_memory])) {
    contexts.app.app_memory = process.memoryUsage().rss;
  }
  if (_optionalChain([contexts, "optionalAccess", (_13) => _13.device, "optionalAccess", (_14) => _14.free_memory])) {
    contexts.device.free_memory = os.freemem();
  }
  return contexts;
}
async function getOsContext() {
  const platformId = os.platform();
  switch (platformId) {
    case "darwin":
      return getDarwinInfo();
    case "linux":
      return getLinuxInfo();
    default:
      return {
        name: PLATFORM_NAMES[platformId] || platformId,
        version: os.release()
      };
  }
}
function getCultureContext() {
  try {
    if (typeof process.versions.icu !== "string") {
      return;
    }
    const january = /* @__PURE__ */ new Date(9e8);
    const spanish = new Intl.DateTimeFormat("es", { month: "long" });
    if (spanish.format(january) === "enero") {
      const options = Intl.DateTimeFormat().resolvedOptions();
      return {
        locale: options.locale,
        timezone: options.timeZone
      };
    }
  } catch (err) {
  }
  return;
}
function getAppContext() {
  const app_memory = process.memoryUsage().rss;
  const app_start_time = new Date(Date.now() - process.uptime() * 1e3).toISOString();
  return { app_start_time, app_memory };
}
function getDeviceContext(deviceOpt) {
  const device = {};
  let uptime2;
  try {
    uptime2 = os.uptime && os.uptime();
  } catch (e2) {
  }
  if (typeof uptime2 === "number") {
    device.boot_time = new Date(Date.now() - uptime2 * 1e3).toISOString();
  }
  device.arch = os.arch();
  if (deviceOpt === true || deviceOpt.memory) {
    device.memory_size = os.totalmem();
    device.free_memory = os.freemem();
  }
  if (deviceOpt === true || deviceOpt.cpu) {
    const cpuInfo = os.cpus();
    if (cpuInfo && cpuInfo.length) {
      const firstCpu = cpuInfo[0];
      device.processor_count = cpuInfo.length;
      device.cpu_description = firstCpu.model;
      device.processor_frequency = firstCpu.speed;
    }
  }
  return device;
}
var PLATFORM_NAMES = {
  aix: "IBM AIX",
  freebsd: "FreeBSD",
  openbsd: "OpenBSD",
  sunos: "SunOS",
  win32: "Windows"
};
var LINUX_DISTROS = [
  { name: "fedora-release", distros: ["Fedora"] },
  { name: "redhat-release", distros: ["Red Hat Linux", "Centos"] },
  { name: "redhat_version", distros: ["Red Hat Linux"] },
  { name: "SuSE-release", distros: ["SUSE Linux"] },
  { name: "lsb-release", distros: ["Ubuntu Linux", "Arch Linux"] },
  { name: "debian_version", distros: ["Debian"] },
  { name: "debian_release", distros: ["Debian"] },
  { name: "arch-release", distros: ["Arch Linux"] },
  { name: "gentoo-release", distros: ["Gentoo Linux"] },
  { name: "novell-release", distros: ["SUSE Linux"] },
  { name: "alpine-release", distros: ["Alpine Linux"] }
];
var LINUX_VERSIONS = {
  alpine: (content) => content,
  arch: (content) => matchFirst(/distrib_release=(.*)/, content),
  centos: (content) => matchFirst(/release ([^ ]+)/, content),
  debian: (content) => content,
  fedora: (content) => matchFirst(/release (..)/, content),
  mint: (content) => matchFirst(/distrib_release=(.*)/, content),
  red: (content) => matchFirst(/release ([^ ]+)/, content),
  suse: (content) => matchFirst(/VERSION = (.*)\n/, content),
  ubuntu: (content) => matchFirst(/distrib_release=(.*)/, content)
};
function matchFirst(regex, text) {
  const match = regex.exec(text);
  return match ? match[1] : void 0;
}
async function getDarwinInfo() {
  const darwinInfo = {
    kernel_version: os.release(),
    name: "Mac OS X",
    version: `10.${Number(os.release().split(".")[0]) - 4}`
  };
  try {
    const output = await new Promise((resolve2, reject) => {
      (0, import_child_process.execFile)("/usr/bin/sw_vers", (error, stdout) => {
        if (error) {
          reject(error);
          return;
        }
        resolve2(stdout);
      });
    });
    darwinInfo.name = matchFirst(/^ProductName:\s+(.*)$/m, output);
    darwinInfo.version = matchFirst(/^ProductVersion:\s+(.*)$/m, output);
    darwinInfo.build = matchFirst(/^BuildVersion:\s+(.*)$/m, output);
  } catch (e2) {
  }
  return darwinInfo;
}
function getLinuxDistroId(name) {
  return name.split(" ")[0].toLowerCase();
}
async function getLinuxInfo() {
  const linuxInfo = {
    kernel_version: os.release(),
    name: "Linux"
  };
  try {
    const etcFiles = await readDirAsync("/etc");
    const distroFile = LINUX_DISTROS.find((file) => etcFiles.includes(file.name));
    if (!distroFile) {
      return linuxInfo;
    }
    const distroPath = (0, import_path2.join)("/etc", distroFile.name);
    const contents = (await readFileAsync(distroPath, { encoding: "utf-8" })).toLowerCase();
    const { distros } = distroFile;
    linuxInfo.name = distros.find((d) => contents.indexOf(getLinuxDistroId(d)) >= 0) || distros[0];
    const id = getLinuxDistroId(linuxInfo.name);
    linuxInfo.version = LINUX_VERSIONS[id](contents);
  } catch (e2) {
  }
  return linuxInfo;
}
function getCloudResourceContext() {
  if (process.env.VERCEL) {
    return {
      "cloud.provider": "vercel",
      "cloud.region": process.env.VERCEL_REGION
    };
  } else if (process.env.AWS_REGION) {
    return {
      "cloud.provider": "aws",
      "cloud.region": process.env.AWS_REGION,
      "cloud.platform": process.env.AWS_EXECUTION_ENV
    };
  } else if (process.env.GCP_PROJECT) {
    return {
      "cloud.provider": "gcp"
    };
  } else if (process.env.ALIYUN_REGION_ID) {
    return {
      "cloud.provider": "alibaba_cloud",
      "cloud.region": process.env.ALIYUN_REGION_ID
    };
  } else if (process.env.WEBSITE_SITE_NAME && process.env.REGION_NAME) {
    return {
      "cloud.provider": "azure",
      "cloud.region": process.env.REGION_NAME
    };
  } else if (process.env.IBM_CLOUD_REGION) {
    return {
      "cloud.provider": "ibm_cloud",
      "cloud.region": process.env.IBM_CLOUD_REGION
    };
  } else if (process.env.TENCENTCLOUD_REGION) {
    return {
      "cloud.provider": "tencent_cloud",
      "cloud.region": process.env.TENCENTCLOUD_REGION,
      "cloud.account.id": process.env.TENCENTCLOUD_APPID,
      "cloud.availability_zone": process.env.TENCENTCLOUD_ZONE
    };
  } else if (process.env.NETLIFY) {
    return {
      "cloud.provider": "netlify"
    };
  } else if (process.env.FLY_REGION) {
    return {
      "cloud.provider": "fly.io",
      "cloud.region": process.env.FLY_REGION
    };
  } else if (process.env.DYNO) {
    return {
      "cloud.provider": "heroku"
    };
  } else {
    return void 0;
  }
}

// node_modules/@sentry/node/esm/integrations/contextlines.js
var import_fs2 = require("fs");
var FILE_CONTENT_CACHE = new LRUMap(100);
var DEFAULT_LINES_OF_CONTEXT = 7;
var INTEGRATION_NAME7 = "ContextLines";
function readTextFileAsync(path) {
  return new Promise((resolve2, reject) => {
    (0, import_fs2.readFile)(path, "utf8", (err, data) => {
      if (err)
        reject(err);
      else
        resolve2(data);
    });
  });
}
var _contextLinesIntegration = (options = {}) => {
  const contextLines = options.frameContextLines !== void 0 ? options.frameContextLines : DEFAULT_LINES_OF_CONTEXT;
  return {
    name: INTEGRATION_NAME7,
    // TODO v8: Remove this
    setupOnce() {
    },
    // eslint-disable-line @typescript-eslint/no-empty-function
    processEvent(event) {
      return addSourceContext(event, contextLines);
    }
  };
};
var contextLinesIntegration = defineIntegration(_contextLinesIntegration);
var ContextLines = convertIntegrationFnToClass(INTEGRATION_NAME7, contextLinesIntegration);
async function addSourceContext(event, contextLines) {
  const enqueuedReadSourceFileTasks = {};
  const readSourceFileTasks = [];
  if (contextLines > 0 && _optionalChain([event, "access", (_2) => _2.exception, "optionalAccess", (_3) => _3.values])) {
    for (const exception of event.exception.values) {
      if (!_optionalChain([exception, "access", (_4) => _4.stacktrace, "optionalAccess", (_5) => _5.frames])) {
        continue;
      }
      for (let i2 = exception.stacktrace.frames.length - 1; i2 >= 0; i2--) {
        const frame = exception.stacktrace.frames[i2];
        if (frame.filename && !enqueuedReadSourceFileTasks[frame.filename] && !FILE_CONTENT_CACHE.get(frame.filename)) {
          readSourceFileTasks.push(_readSourceFile(frame.filename));
          enqueuedReadSourceFileTasks[frame.filename] = 1;
        }
      }
    }
  }
  if (readSourceFileTasks.length > 0) {
    await Promise.all(readSourceFileTasks);
  }
  if (contextLines > 0 && _optionalChain([event, "access", (_6) => _6.exception, "optionalAccess", (_7) => _7.values])) {
    for (const exception of event.exception.values) {
      if (exception.stacktrace && exception.stacktrace.frames) {
        await addSourceContextToFrames(exception.stacktrace.frames, contextLines);
      }
    }
  }
  return event;
}
function addSourceContextToFrames(frames, contextLines) {
  for (const frame of frames) {
    if (frame.filename && frame.context_line === void 0) {
      const sourceFileLines = FILE_CONTENT_CACHE.get(frame.filename);
      if (sourceFileLines) {
        try {
          addContextToFrame(sourceFileLines, frame, contextLines);
        } catch (e2) {
        }
      }
    }
  }
}
async function _readSourceFile(filename) {
  const cachedFile = FILE_CONTENT_CACHE.get(filename);
  if (cachedFile === null) {
    return null;
  }
  if (cachedFile !== void 0) {
    return cachedFile;
  }
  let content = null;
  try {
    const rawFileContents = await readTextFileAsync(filename);
    content = rawFileContents.split("\n");
  } catch (_) {
  }
  FILE_CONTENT_CACHE.set(filename, content);
  return content;
}

// node_modules/@sentry/node/esm/debug-build.js
var DEBUG_BUILD4 = typeof __SENTRY_DEBUG__ === "undefined" || __SENTRY_DEBUG__;

// node_modules/@sentry/node/esm/integrations/utils/http.js
var import_url5 = require("url");
function extractRawUrl(requestOptions) {
  const { protocol, hostname, port } = parseRequestOptions(requestOptions);
  const path = requestOptions.path ? requestOptions.path : "/";
  return `${protocol}//${hostname}${port}${path}`;
}
function extractUrl(requestOptions) {
  const { protocol, hostname, port } = parseRequestOptions(requestOptions);
  const path = requestOptions.pathname || "/";
  const authority = requestOptions.auth ? redactAuthority(requestOptions.auth) : "";
  return `${protocol}//${authority}${hostname}${port}${path}`;
}
function redactAuthority(auth) {
  const [user, password] = auth.split(":");
  return `${user ? "[Filtered]" : ""}:${password ? "[Filtered]" : ""}@`;
}
function cleanSpanDescription(description, requestOptions, request) {
  if (!description) {
    return description;
  }
  let [method, requestUrl] = description.split(" ");
  if (requestOptions.host && !requestOptions.protocol) {
    requestOptions.protocol = _optionalChain([request, "optionalAccess", (_) => _.agent, "optionalAccess", (_2) => _2.protocol]);
    requestUrl = extractUrl(requestOptions);
  }
  if (_optionalChain([requestUrl, "optionalAccess", (_3) => _3.startsWith, "call", (_4) => _4("///")])) {
    requestUrl = requestUrl.slice(2);
  }
  return `${method} ${requestUrl}`;
}
function urlToOptions(url) {
  const options = {
    protocol: url.protocol,
    hostname: typeof url.hostname === "string" && url.hostname.startsWith("[") ? url.hostname.slice(1, -1) : url.hostname,
    hash: url.hash,
    search: url.search,
    pathname: url.pathname,
    path: `${url.pathname || ""}${url.search || ""}`,
    href: url.href
  };
  if (url.port !== "") {
    options.port = Number(url.port);
  }
  if (url.username || url.password) {
    options.auth = `${url.username}:${url.password}`;
  }
  return options;
}
function normalizeRequestArgs(httpModule, requestArgs) {
  let callback, requestOptions;
  if (typeof requestArgs[requestArgs.length - 1] === "function") {
    callback = requestArgs.pop();
  }
  if (typeof requestArgs[0] === "string") {
    requestOptions = urlToOptions(new import_url5.URL(requestArgs[0]));
  } else if (requestArgs[0] instanceof import_url5.URL) {
    requestOptions = urlToOptions(requestArgs[0]);
  } else {
    requestOptions = requestArgs[0];
    try {
      const parsed = new import_url5.URL(
        requestOptions.path || "",
        `${requestOptions.protocol || "http:"}//${requestOptions.hostname}`
      );
      requestOptions = {
        pathname: parsed.pathname,
        search: parsed.search,
        hash: parsed.hash,
        ...requestOptions
      };
    } catch (e2) {
    }
  }
  if (requestArgs.length === 2) {
    requestOptions = { ...requestOptions, ...requestArgs[1] };
  }
  if (requestOptions.protocol === void 0) {
    if (NODE_VERSION.major > 8) {
      requestOptions.protocol = _optionalChain([_optionalChain([httpModule, "optionalAccess", (_5) => _5.globalAgent]), "optionalAccess", (_6) => _6.protocol]) || _optionalChain([requestOptions.agent, "optionalAccess", (_7) => _7.protocol]) || _optionalChain([requestOptions._defaultAgent, "optionalAccess", (_8) => _8.protocol]);
    } else {
      requestOptions.protocol = _optionalChain([requestOptions.agent, "optionalAccess", (_9) => _9.protocol]) || _optionalChain([requestOptions._defaultAgent, "optionalAccess", (_10) => _10.protocol]) || _optionalChain([_optionalChain([httpModule, "optionalAccess", (_11) => _11.globalAgent]), "optionalAccess", (_12) => _12.protocol]);
    }
  }
  if (callback) {
    return [requestOptions, callback];
  } else {
    return [requestOptions];
  }
}
function parseRequestOptions(requestOptions) {
  const protocol = requestOptions.protocol || "";
  const hostname = requestOptions.hostname || requestOptions.host || "";
  const port = !requestOptions.port || requestOptions.port === 80 || requestOptions.port === 443 || /^(.*):(\d+)$/.test(hostname) ? "" : `:${requestOptions.port}`;
  return { protocol, hostname, port };
}

// node_modules/@sentry/node/esm/integrations/http.js
var _httpIntegration = (options = {}) => {
  const { breadcrumbs, tracing, shouldCreateSpanForRequest } = options;
  const convertedOptions = {
    breadcrumbs,
    tracing: tracing === false ? false : dropUndefinedKeys({
      // If tracing is forced to `true`, we don't want to set `enableIfHasTracingEnabled`
      enableIfHasTracingEnabled: tracing === true ? void 0 : true,
      shouldCreateSpanForRequest
    })
  };
  return new Http(convertedOptions);
};
var httpIntegration = defineIntegration(_httpIntegration);
var Http = class _Http {
  /**
   * @inheritDoc
   */
  static __initStatic() {
    this.id = "Http";
  }
  /**
   * @inheritDoc
   */
  // eslint-disable-next-line deprecation/deprecation
  __init() {
    this.name = _Http.id;
  }
  /**
   * @inheritDoc
   */
  constructor(options = {}) {
    _Http.prototype.__init.call(this);
    this._breadcrumbs = typeof options.breadcrumbs === "undefined" ? true : options.breadcrumbs;
    this._tracing = !options.tracing ? void 0 : options.tracing === true ? {} : options.tracing;
  }
  /**
   * @inheritDoc
   */
  setupOnce(_addGlobalEventProcessor, setupOnceGetCurrentHub) {
    const clientOptions = _optionalChain([setupOnceGetCurrentHub, "call", (_) => _(), "access", (_2) => _2.getClient, "call", (_3) => _3(), "optionalAccess", (_4) => _4.getOptions, "call", (_5) => _5()]);
    const shouldCreateSpans = _shouldCreateSpans(this._tracing, clientOptions);
    if (!this._breadcrumbs && !shouldCreateSpans) {
      return;
    }
    if (clientOptions && clientOptions.instrumenter !== "sentry") {
      DEBUG_BUILD4 && logger.log("HTTP Integration is skipped because of instrumenter configuration.");
      return;
    }
    const shouldCreateSpanForRequest = _getShouldCreateSpanForRequest(shouldCreateSpans, this._tracing, clientOptions);
    const tracePropagationTargets = _optionalChain([clientOptions, "optionalAccess", (_6) => _6.tracePropagationTargets]) || _optionalChain([this, "access", (_7) => _7._tracing, "optionalAccess", (_8) => _8.tracePropagationTargets]);
    const httpModule = require("http");
    const wrappedHttpHandlerMaker = _createWrappedRequestMethodFactory(
      httpModule,
      this._breadcrumbs,
      shouldCreateSpanForRequest,
      tracePropagationTargets
    );
    fill(httpModule, "get", wrappedHttpHandlerMaker);
    fill(httpModule, "request", wrappedHttpHandlerMaker);
    if (NODE_VERSION.major > 8) {
      const httpsModule = require("https");
      const wrappedHttpsHandlerMaker = _createWrappedRequestMethodFactory(
        httpsModule,
        this._breadcrumbs,
        shouldCreateSpanForRequest,
        tracePropagationTargets
      );
      fill(httpsModule, "get", wrappedHttpsHandlerMaker);
      fill(httpsModule, "request", wrappedHttpsHandlerMaker);
    }
  }
};
Http.__initStatic();
function _createWrappedRequestMethodFactory(httpModule, breadcrumbsEnabled, shouldCreateSpanForRequest, tracePropagationTargets) {
  const createSpanUrlMap = new LRUMap(100);
  const headersUrlMap = new LRUMap(100);
  const shouldCreateSpan = (url) => {
    if (shouldCreateSpanForRequest === void 0) {
      return true;
    }
    const cachedDecision = createSpanUrlMap.get(url);
    if (cachedDecision !== void 0) {
      return cachedDecision;
    }
    const decision = shouldCreateSpanForRequest(url);
    createSpanUrlMap.set(url, decision);
    return decision;
  };
  const shouldAttachTraceData = (url) => {
    if (tracePropagationTargets === void 0) {
      return true;
    }
    const cachedDecision = headersUrlMap.get(url);
    if (cachedDecision !== void 0) {
      return cachedDecision;
    }
    const decision = stringMatchesSomePattern(url, tracePropagationTargets);
    headersUrlMap.set(url, decision);
    return decision;
  };
  function addRequestBreadcrumb(event, requestSpanData, req, res) {
    if (!getCurrentHub().getIntegration(Http)) {
      return;
    }
    addBreadcrumb(
      {
        category: "http",
        data: {
          status_code: res && res.statusCode,
          ...requestSpanData
        },
        type: "http"
      },
      {
        event,
        request: req,
        response: res
      }
    );
  }
  return function wrappedRequestMethodFactory(originalRequestMethod) {
    return function wrappedMethod(...args) {
      const requestArgs = normalizeRequestArgs(httpModule, args);
      const requestOptions = requestArgs[0];
      const rawRequestUrl = extractRawUrl(requestOptions);
      const requestUrl = extractUrl(requestOptions);
      const client = getClient();
      if (isSentryRequestUrl(requestUrl, client)) {
        return originalRequestMethod.apply(httpModule, requestArgs);
      }
      const scope = getCurrentScope();
      const isolationScope = getIsolationScope();
      const parentSpan = getActiveSpan();
      const data = getRequestSpanData(requestUrl, requestOptions);
      const requestSpan = shouldCreateSpan(rawRequestUrl) ? (
        // eslint-disable-next-line deprecation/deprecation
        _optionalChain([parentSpan, "optionalAccess", (_9) => _9.startChild, "call", (_10) => _10({
          op: "http.client",
          origin: "auto.http.node.http",
          description: `${data["http.method"]} ${data.url}`,
          data
        })])
      ) : void 0;
      if (client && shouldAttachTraceData(rawRequestUrl)) {
        const { traceId, spanId, sampled, dsc } = {
          ...isolationScope.getPropagationContext(),
          ...scope.getPropagationContext()
        };
        const sentryTraceHeader = requestSpan ? spanToTraceHeader(requestSpan) : generateSentryTraceHeader(traceId, spanId, sampled);
        const sentryBaggageHeader = dynamicSamplingContextToSentryBaggageHeader(
          dsc || (requestSpan ? getDynamicSamplingContextFromSpan(requestSpan) : getDynamicSamplingContextFromClient(traceId, client, scope))
        );
        addHeadersToRequestOptions(requestOptions, requestUrl, sentryTraceHeader, sentryBaggageHeader);
      } else {
        DEBUG_BUILD4 && logger.log(
          `[Tracing] Not adding sentry-trace header to outgoing request (${requestUrl}) due to mismatching tracePropagationTargets option.`
        );
      }
      return originalRequestMethod.apply(httpModule, requestArgs).once("response", function(res) {
        const req = this;
        if (breadcrumbsEnabled) {
          addRequestBreadcrumb("response", data, req, res);
        }
        if (requestSpan) {
          if (res.statusCode) {
            setHttpStatus(requestSpan, res.statusCode);
          }
          requestSpan.updateName(
            cleanSpanDescription(spanToJSON(requestSpan).description || "", requestOptions, req) || ""
          );
          requestSpan.end();
        }
      }).once("error", function() {
        const req = this;
        if (breadcrumbsEnabled) {
          addRequestBreadcrumb("error", data, req);
        }
        if (requestSpan) {
          setHttpStatus(requestSpan, 500);
          requestSpan.updateName(
            cleanSpanDescription(spanToJSON(requestSpan).description || "", requestOptions, req) || ""
          );
          requestSpan.end();
        }
      });
    };
  };
}
function addHeadersToRequestOptions(requestOptions, requestUrl, sentryTraceHeader, sentryBaggageHeader) {
  const headers = requestOptions.headers || {};
  if (headers["sentry-trace"]) {
    return;
  }
  DEBUG_BUILD4 && logger.log(`[Tracing] Adding sentry-trace header ${sentryTraceHeader} to outgoing request to "${requestUrl}": `);
  requestOptions.headers = {
    ...requestOptions.headers,
    "sentry-trace": sentryTraceHeader,
    // Setting a header to `undefined` will crash in node so we only set the baggage header when it's defined
    ...sentryBaggageHeader && sentryBaggageHeader.length > 0 && { baggage: normalizeBaggageHeader(requestOptions, sentryBaggageHeader) }
  };
}
function getRequestSpanData(requestUrl, requestOptions) {
  const method = requestOptions.method || "GET";
  const data = {
    url: requestUrl,
    "http.method": method
  };
  if (requestOptions.hash) {
    data["http.fragment"] = requestOptions.hash.substring(1);
  }
  if (requestOptions.search) {
    data["http.query"] = requestOptions.search.substring(1);
  }
  return data;
}
function normalizeBaggageHeader(requestOptions, sentryBaggageHeader) {
  if (!requestOptions.headers || !requestOptions.headers.baggage) {
    return sentryBaggageHeader;
  } else if (!sentryBaggageHeader) {
    return requestOptions.headers.baggage;
  } else if (Array.isArray(requestOptions.headers.baggage)) {
    return [...requestOptions.headers.baggage, sentryBaggageHeader];
  }
  return [requestOptions.headers.baggage, sentryBaggageHeader];
}
function _shouldCreateSpans(tracingOptions, clientOptions) {
  return tracingOptions === void 0 ? false : tracingOptions.enableIfHasTracingEnabled ? hasTracingEnabled(clientOptions) : true;
}
function _getShouldCreateSpanForRequest(shouldCreateSpans, tracingOptions, clientOptions) {
  const handler = shouldCreateSpans ? (
    // eslint-disable-next-line deprecation/deprecation
    _optionalChain([tracingOptions, "optionalAccess", (_11) => _11.shouldCreateSpanForRequest]) || _optionalChain([clientOptions, "optionalAccess", (_12) => _12.shouldCreateSpanForRequest])
  ) : () => false;
  return handler;
}

// node_modules/@sentry/node/esm/integrations/local-variables/common.js
function createRateLimiter(maxPerSecond, enable, disable) {
  let count = 0;
  let retrySeconds = 5;
  let disabledTimeout = 0;
  setInterval(() => {
    if (disabledTimeout === 0) {
      if (count > maxPerSecond) {
        retrySeconds *= 2;
        disable(retrySeconds);
        if (retrySeconds > 86400) {
          retrySeconds = 86400;
        }
        disabledTimeout = retrySeconds;
      }
    } else {
      disabledTimeout -= 1;
      if (disabledTimeout === 0) {
        enable();
      }
    }
    count = 0;
  }, 1e3).unref();
  return () => {
    count += 1;
  };
}
function isAnonymous(name) {
  return name !== void 0 && (name.length === 0 || name === "?" || name === "<anonymous>");
}
function functionNamesMatch(a, b) {
  return a === b || isAnonymous(a) && isAnonymous(b);
}
function hashFrames(frames) {
  if (frames === void 0) {
    return;
  }
  return frames.slice(-10).reduce((acc, frame) => `${acc},${frame.function},${frame.lineno},${frame.colno}`, "");
}
function hashFromStack(stackParser, stack) {
  if (stack === void 0) {
    return void 0;
  }
  return hashFrames(stackParser(stack, 1));
}

// node_modules/@sentry/node/esm/integrations/local-variables/local-variables-sync.js
function createCallbackList(complete) {
  let callbacks = [];
  let completedCalled = false;
  function checkedComplete(result) {
    callbacks = [];
    if (completedCalled) {
      return;
    }
    completedCalled = true;
    complete(result);
  }
  callbacks.push(checkedComplete);
  function add(fn) {
    callbacks.push(fn);
  }
  function next(result) {
    const popped = callbacks.pop() || checkedComplete;
    try {
      popped(result);
    } catch (_) {
      checkedComplete(result);
    }
  }
  return { add, next };
}
var AsyncSession = class {
  /** Throws if inspector API is not available */
  constructor() {
    const { Session } = require("inspector");
    this._session = new Session();
  }
  /** @inheritdoc */
  configureAndConnect(onPause, captureAll) {
    this._session.connect();
    this._session.on("Debugger.paused", (event) => {
      onPause(event, () => {
        this._session.post("Debugger.resume");
      });
    });
    this._session.post("Debugger.enable");
    this._session.post("Debugger.setPauseOnExceptions", { state: captureAll ? "all" : "uncaught" });
  }
  setPauseOnExceptions(captureAll) {
    this._session.post("Debugger.setPauseOnExceptions", { state: captureAll ? "all" : "uncaught" });
  }
  /** @inheritdoc */
  getLocalVariables(objectId, complete) {
    this._getProperties(objectId, (props) => {
      const { add, next } = createCallbackList(complete);
      for (const prop of props) {
        if (_optionalChain([prop, "optionalAccess", (_2) => _2.value, "optionalAccess", (_3) => _3.objectId]) && _optionalChain([prop, "optionalAccess", (_4) => _4.value, "access", (_5) => _5.className]) === "Array") {
          const id = prop.value.objectId;
          add((vars) => this._unrollArray(id, prop.name, vars, next));
        } else if (_optionalChain([prop, "optionalAccess", (_6) => _6.value, "optionalAccess", (_7) => _7.objectId]) && _optionalChain([prop, "optionalAccess", (_8) => _8.value, "optionalAccess", (_9) => _9.className]) === "Object") {
          const id = prop.value.objectId;
          add((vars) => this._unrollObject(id, prop.name, vars, next));
        } else if (_optionalChain([prop, "optionalAccess", (_10) => _10.value, "optionalAccess", (_11) => _11.value]) || _optionalChain([prop, "optionalAccess", (_12) => _12.value, "optionalAccess", (_13) => _13.description])) {
          add((vars) => this._unrollOther(prop, vars, next));
        }
      }
      next({});
    });
  }
  /**
   * Gets all the PropertyDescriptors of an object
   */
  _getProperties(objectId, next) {
    this._session.post(
      "Runtime.getProperties",
      {
        objectId,
        ownProperties: true
      },
      (err, params) => {
        if (err) {
          next([]);
        } else {
          next(params.result);
        }
      }
    );
  }
  /**
   * Unrolls an array property
   */
  _unrollArray(objectId, name, vars, next) {
    this._getProperties(objectId, (props) => {
      vars[name] = props.filter((v) => v.name !== "length" && !isNaN(parseInt(v.name, 10))).sort((a, b) => parseInt(a.name, 10) - parseInt(b.name, 10)).map((v) => _optionalChain([v, "optionalAccess", (_14) => _14.value, "optionalAccess", (_15) => _15.value]));
      next(vars);
    });
  }
  /**
   * Unrolls an object property
   */
  _unrollObject(objectId, name, vars, next) {
    this._getProperties(objectId, (props) => {
      vars[name] = props.map((v) => [v.name, _optionalChain([v, "optionalAccess", (_16) => _16.value, "optionalAccess", (_17) => _17.value])]).reduce((obj, [key, val]) => {
        obj[key] = val;
        return obj;
      }, {});
      next(vars);
    });
  }
  /**
   * Unrolls other properties
   */
  _unrollOther(prop, vars, next) {
    if (_optionalChain([prop, "optionalAccess", (_18) => _18.value, "optionalAccess", (_19) => _19.value])) {
      vars[prop.name] = prop.value.value;
    } else if (_optionalChain([prop, "optionalAccess", (_20) => _20.value, "optionalAccess", (_21) => _21.description]) && _optionalChain([prop, "optionalAccess", (_22) => _22.value, "optionalAccess", (_23) => _23.type]) !== "function") {
      vars[prop.name] = `<${prop.value.description}>`;
    }
    next(vars);
  }
};
function tryNewAsyncSession() {
  try {
    return new AsyncSession();
  } catch (e2) {
    return void 0;
  }
}
var INTEGRATION_NAME8 = "LocalVariables";
var _localVariablesSyncIntegration = (options = {}, session = tryNewAsyncSession()) => {
  const cachedFrames = new LRUMap(20);
  let rateLimiter;
  let shouldProcessEvent = false;
  function handlePaused(stackParser, { params: { reason, data, callFrames } }, complete) {
    if (reason !== "exception" && reason !== "promiseRejection") {
      complete();
      return;
    }
    _optionalChain([rateLimiter, "optionalCall", (_24) => _24()]);
    const exceptionHash = hashFromStack(stackParser, _optionalChain([data, "optionalAccess", (_25) => _25.description]));
    if (exceptionHash == void 0) {
      complete();
      return;
    }
    const { add, next } = createCallbackList((frames) => {
      cachedFrames.set(exceptionHash, frames);
      complete();
    });
    for (let i2 = 0; i2 < Math.min(callFrames.length, 5); i2++) {
      const { scopeChain, functionName, this: obj } = callFrames[i2];
      const localScope = scopeChain.find((scope) => scope.type === "local");
      const fn = obj.className === "global" || !obj.className ? functionName : `${obj.className}.${functionName}`;
      if (_optionalChain([localScope, "optionalAccess", (_26) => _26.object, "access", (_27) => _27.objectId]) === void 0) {
        add((frames) => {
          frames[i2] = { function: fn };
          next(frames);
        });
      } else {
        const id = localScope.object.objectId;
        add(
          (frames) => _optionalChain([session, "optionalAccess", (_28) => _28.getLocalVariables, "call", (_29) => _29(id, (vars) => {
            frames[i2] = { function: fn, vars };
            next(frames);
          })])
        );
      }
    }
    next([]);
  }
  function addLocalVariablesToException(exception) {
    const hash = hashFrames(_optionalChain([exception, "optionalAccess", (_30) => _30.stacktrace, "optionalAccess", (_31) => _31.frames]));
    if (hash === void 0) {
      return;
    }
    const cachedFrame = cachedFrames.remove(hash);
    if (cachedFrame === void 0) {
      return;
    }
    const frameCount = _optionalChain([exception, "access", (_32) => _32.stacktrace, "optionalAccess", (_33) => _33.frames, "optionalAccess", (_34) => _34.length]) || 0;
    for (let i2 = 0; i2 < frameCount; i2++) {
      const frameIndex = frameCount - i2 - 1;
      if (!_optionalChain([exception, "optionalAccess", (_35) => _35.stacktrace, "optionalAccess", (_36) => _36.frames, "optionalAccess", (_37) => _37[frameIndex]]) || !cachedFrame[i2]) {
        break;
      }
      if (
        // We need to have vars to add
        cachedFrame[i2].vars === void 0 || // We're not interested in frames that are not in_app because the vars are not relevant
        exception.stacktrace.frames[frameIndex].in_app === false || // The function names need to match
        !functionNamesMatch(exception.stacktrace.frames[frameIndex].function, cachedFrame[i2].function)
      ) {
        continue;
      }
      exception.stacktrace.frames[frameIndex].vars = cachedFrame[i2].vars;
    }
  }
  function addLocalVariablesToEvent(event) {
    for (const exception of _optionalChain([event, "optionalAccess", (_38) => _38.exception, "optionalAccess", (_39) => _39.values]) || []) {
      addLocalVariablesToException(exception);
    }
    return event;
  }
  return {
    name: INTEGRATION_NAME8,
    setupOnce() {
      const client = getClient();
      const clientOptions = _optionalChain([client, "optionalAccess", (_40) => _40.getOptions, "call", (_41) => _41()]);
      if (session && _optionalChain([clientOptions, "optionalAccess", (_42) => _42.includeLocalVariables])) {
        const unsupportedNodeVersion = NODE_VERSION.major < 18;
        if (unsupportedNodeVersion) {
          logger.log("The `LocalVariables` integration is only supported on Node >= v18.");
          return;
        }
        const captureAll = options.captureAllExceptions !== false;
        session.configureAndConnect(
          (ev, complete) => handlePaused(clientOptions.stackParser, ev, complete),
          captureAll
        );
        if (captureAll) {
          const max = options.maxExceptionsPerSecond || 50;
          rateLimiter = createRateLimiter(
            max,
            () => {
              logger.log("Local variables rate-limit lifted.");
              _optionalChain([session, "optionalAccess", (_43) => _43.setPauseOnExceptions, "call", (_44) => _44(true)]);
            },
            (seconds) => {
              logger.log(
                `Local variables rate-limit exceeded. Disabling capturing of caught exceptions for ${seconds} seconds.`
              );
              _optionalChain([session, "optionalAccess", (_45) => _45.setPauseOnExceptions, "call", (_46) => _46(false)]);
            }
          );
        }
        shouldProcessEvent = true;
      }
    },
    processEvent(event) {
      if (shouldProcessEvent) {
        return addLocalVariablesToEvent(event);
      }
      return event;
    },
    // These are entirely for testing
    _getCachedFramesCount() {
      return cachedFrames.size;
    },
    _getFirstCachedFrame() {
      return cachedFrames.values()[0];
    }
  };
};
var localVariablesSyncIntegration = defineIntegration(_localVariablesSyncIntegration);
var LocalVariablesSync = convertIntegrationFnToClass(
  INTEGRATION_NAME8,
  localVariablesSyncIntegration
);

// node_modules/@sentry/node/esm/integrations/local-variables/index.js
var LocalVariables = LocalVariablesSync;

// node_modules/@sentry/node/esm/integrations/modules.js
var import_fs3 = require("fs");
var import_path3 = require("path");
var moduleCache;
var INTEGRATION_NAME9 = "Modules";
function getPaths() {
  try {
    return require.cache ? Object.keys(require.cache) : [];
  } catch (e2) {
    return [];
  }
}
function collectModules() {
  const mainPaths = require.main && require.main.paths || [];
  const paths = getPaths();
  const infos = {};
  const seen = {};
  paths.forEach((path) => {
    let dir = path;
    const updir = () => {
      const orig = dir;
      dir = (0, import_path3.dirname)(orig);
      if (!dir || orig === dir || seen[orig]) {
        return void 0;
      }
      if (mainPaths.indexOf(dir) < 0) {
        return updir();
      }
      const pkgfile = (0, import_path3.join)(orig, "package.json");
      seen[orig] = true;
      if (!(0, import_fs3.existsSync)(pkgfile)) {
        return updir();
      }
      try {
        const info = JSON.parse((0, import_fs3.readFileSync)(pkgfile, "utf8"));
        infos[info.name] = info.version;
      } catch (_oO) {
      }
    };
    updir();
  });
  return infos;
}
function _getModules() {
  if (!moduleCache) {
    moduleCache = collectModules();
  }
  return moduleCache;
}
var _modulesIntegration = () => {
  return {
    name: INTEGRATION_NAME9,
    // TODO v8: Remove this
    setupOnce() {
    },
    // eslint-disable-line @typescript-eslint/no-empty-function
    processEvent(event) {
      event.modules = {
        ...event.modules,
        ..._getModules()
      };
      return event;
    }
  };
};
var modulesIntegration = defineIntegration(_modulesIntegration);
var Modules = convertIntegrationFnToClass(INTEGRATION_NAME9, modulesIntegration);

// node_modules/@sentry/node/esm/integrations/utils/errorhandling.js
var DEFAULT_SHUTDOWN_TIMEOUT = 2e3;
function logAndExitProcess(error) {
  consoleSandbox(() => {
    console.error(error);
  });
  const client = getClient();
  if (client === void 0) {
    DEBUG_BUILD4 && logger.warn("No NodeClient was defined, we are exiting the process now.");
    global.process.exit(1);
  }
  const options = client.getOptions();
  const timeout = options && options.shutdownTimeout && options.shutdownTimeout > 0 && options.shutdownTimeout || DEFAULT_SHUTDOWN_TIMEOUT;
  client.close(timeout).then(
    (result) => {
      if (!result) {
        DEBUG_BUILD4 && logger.warn("We reached the timeout for emptying the request buffer, still exiting now!");
      }
      global.process.exit(1);
    },
    (error2) => {
      DEBUG_BUILD4 && logger.error(error2);
    }
  );
}

// node_modules/@sentry/node/esm/integrations/onuncaughtexception.js
var INTEGRATION_NAME10 = "OnUncaughtException";
var _onUncaughtExceptionIntegration = (options = {}) => {
  const _options = {
    exitEvenIfOtherHandlersAreRegistered: true,
    ...options
  };
  return {
    name: INTEGRATION_NAME10,
    // TODO v8: Remove this
    setupOnce() {
    },
    // eslint-disable-line @typescript-eslint/no-empty-function
    setup(client) {
      global.process.on("uncaughtException", makeErrorHandler(client, _options));
    }
  };
};
var onUncaughtExceptionIntegration = defineIntegration(_onUncaughtExceptionIntegration);
var OnUncaughtException = convertIntegrationFnToClass(
  INTEGRATION_NAME10,
  onUncaughtExceptionIntegration
);
function makeErrorHandler(client, options) {
  const timeout = 2e3;
  let caughtFirstError = false;
  let caughtSecondError = false;
  let calledFatalError = false;
  let firstError;
  const clientOptions = client.getOptions();
  return Object.assign(
    (error) => {
      let onFatalError = logAndExitProcess;
      if (options.onFatalError) {
        onFatalError = options.onFatalError;
      } else if (clientOptions.onFatalError) {
        onFatalError = clientOptions.onFatalError;
      }
      const userProvidedListenersCount = global.process.listeners("uncaughtException").reduce((acc, listener) => {
        if (
          // There are 3 listeners we ignore:
          listener.name === "domainUncaughtExceptionClear" || // as soon as we're using domains this listener is attached by node itself
          listener.tag && listener.tag === "sentry_tracingErrorCallback" || // the handler we register for tracing
          listener._errorHandler
        ) {
          return acc;
        } else {
          return acc + 1;
        }
      }, 0);
      const processWouldExit = userProvidedListenersCount === 0;
      const shouldApplyFatalHandlingLogic = options.exitEvenIfOtherHandlersAreRegistered || processWouldExit;
      if (!caughtFirstError) {
        firstError = error;
        caughtFirstError = true;
        if (getClient() === client) {
          captureException(error, {
            originalException: error,
            captureContext: {
              level: "fatal"
            },
            mechanism: {
              handled: false,
              type: "onuncaughtexception"
            }
          });
        }
        if (!calledFatalError && shouldApplyFatalHandlingLogic) {
          calledFatalError = true;
          onFatalError(error);
        }
      } else {
        if (shouldApplyFatalHandlingLogic) {
          if (calledFatalError) {
            DEBUG_BUILD4 && logger.warn(
              "uncaught exception after calling fatal error shutdown callback - this is bad! forcing shutdown"
            );
            logAndExitProcess(error);
          } else if (!caughtSecondError) {
            caughtSecondError = true;
            setTimeout(() => {
              if (!calledFatalError) {
                calledFatalError = true;
                onFatalError(firstError, error);
              }
            }, timeout);
          }
        }
      }
    },
    { _errorHandler: true }
  );
}

// node_modules/@sentry/node/esm/integrations/onunhandledrejection.js
var INTEGRATION_NAME11 = "OnUnhandledRejection";
var _onUnhandledRejectionIntegration = (options = {}) => {
  const mode = options.mode || "warn";
  return {
    name: INTEGRATION_NAME11,
    // TODO v8: Remove this
    setupOnce() {
    },
    // eslint-disable-line @typescript-eslint/no-empty-function
    setup(client) {
      global.process.on("unhandledRejection", makeUnhandledPromiseHandler(client, { mode }));
    }
  };
};
var onUnhandledRejectionIntegration = defineIntegration(_onUnhandledRejectionIntegration);
var OnUnhandledRejection = convertIntegrationFnToClass(
  INTEGRATION_NAME11,
  onUnhandledRejectionIntegration
);
function makeUnhandledPromiseHandler(client, options) {
  return function sendUnhandledPromise(reason, promise) {
    if (getClient() !== client) {
      return;
    }
    captureException(reason, {
      originalException: promise,
      captureContext: {
        extra: { unhandledPromiseRejection: true }
      },
      mechanism: {
        handled: false,
        type: "onunhandledrejection"
      }
    });
    handleRejection(reason, options);
  };
}
function handleRejection(reason, options) {
  const rejectionWarning = "This error originated either by throwing inside of an async function without a catch block, or by rejecting a promise which was not handled with .catch(). The promise rejected with the reason:";
  if (options.mode === "warn") {
    consoleSandbox(() => {
      console.warn(rejectionWarning);
      console.error(reason && reason.stack ? reason.stack : reason);
    });
  } else if (options.mode === "strict") {
    consoleSandbox(() => {
      console.warn(rejectionWarning);
    });
    logAndExitProcess(reason);
  }
}

// node_modules/@sentry/node/esm/integrations/spotlight.js
var http5 = __toESM(require("http"));
var import_url6 = require("url");
var INTEGRATION_NAME12 = "Spotlight";
var _spotlightIntegration = (options = {}) => {
  const _options = {
    sidecarUrl: options.sidecarUrl || "http://localhost:8969/stream"
  };
  return {
    name: INTEGRATION_NAME12,
    // TODO v8: Remove this
    setupOnce() {
    },
    // eslint-disable-line @typescript-eslint/no-empty-function
    setup(client) {
      if (typeof process === "object" && process.env && process.env.NODE_ENV !== "development") {
        logger.warn("[Spotlight] It seems you're not in dev mode. Do you really want to have Spotlight enabled?");
      }
      connectToSpotlight(client, _options);
    }
  };
};
var spotlightIntegration = defineIntegration(_spotlightIntegration);
var Spotlight = convertIntegrationFnToClass(INTEGRATION_NAME12, spotlightIntegration);
function connectToSpotlight(client, options) {
  const spotlightUrl = parseSidecarUrl(options.sidecarUrl);
  if (!spotlightUrl) {
    return;
  }
  let failedRequests = 0;
  if (typeof client.on !== "function") {
    logger.warn("[Spotlight] Cannot connect to spotlight due to missing method on SDK client (`client.on`)");
    return;
  }
  client.on("beforeEnvelope", (envelope) => {
    if (failedRequests > 3) {
      logger.warn("[Spotlight] Disabled Sentry -> Spotlight integration due to too many failed requests");
      return;
    }
    const serializedEnvelope = serializeEnvelope(envelope);
    const request = getNativeHttpRequest();
    const req = request(
      {
        method: "POST",
        path: spotlightUrl.pathname,
        hostname: spotlightUrl.hostname,
        port: spotlightUrl.port,
        headers: {
          "Content-Type": "application/x-sentry-envelope"
        }
      },
      (res) => {
        res.on("data", () => {
        });
        res.on("end", () => {
        });
        res.setEncoding("utf8");
      }
    );
    req.on("error", () => {
      failedRequests++;
      logger.warn("[Spotlight] Failed to send envelope to Spotlight Sidecar");
    });
    req.write(serializedEnvelope);
    req.end();
  });
}
function parseSidecarUrl(url) {
  try {
    return new import_url6.URL(`${url}`);
  } catch (e2) {
    logger.warn(`[Spotlight] Invalid sidecar URL: ${url}`);
    return void 0;
  }
}
function getNativeHttpRequest() {
  const { request } = http5;
  if (isWrapped(request)) {
    return request.__sentry_original__;
  }
  return request;
}
function isWrapped(impl) {
  return "__sentry_original__" in impl;
}

// node_modules/@sentry/node/esm/integrations/undici/index.js
var ChannelName;
(function(ChannelName2) {
  const RequestCreate = "undici:request:create";
  ChannelName2["RequestCreate"] = RequestCreate;
  const RequestEnd = "undici:request:headers";
  ChannelName2["RequestEnd"] = RequestEnd;
  const RequestError = "undici:request:error";
  ChannelName2["RequestError"] = RequestError;
})(ChannelName || (ChannelName = {}));
var _nativeNodeFetchintegration = (options) => {
  return new Undici(options);
};
var nativeNodeFetchintegration = defineIntegration(_nativeNodeFetchintegration);
var Undici = class _Undici {
  /**
   * @inheritDoc
   */
  static __initStatic() {
    this.id = "Undici";
  }
  /**
   * @inheritDoc
   */
  // eslint-disable-next-line deprecation/deprecation
  __init() {
    this.name = _Undici.id;
  }
  __init2() {
    this._createSpanUrlMap = new LRUMap(100);
  }
  __init3() {
    this._headersUrlMap = new LRUMap(100);
  }
  constructor(_options = {}) {
    _Undici.prototype.__init.call(this);
    _Undici.prototype.__init2.call(this);
    _Undici.prototype.__init3.call(this);
    _Undici.prototype.__init4.call(this);
    _Undici.prototype.__init5.call(this);
    _Undici.prototype.__init6.call(this);
    this._options = {
      breadcrumbs: _options.breadcrumbs === void 0 ? true : _options.breadcrumbs,
      tracing: _options.tracing,
      shouldCreateSpanForRequest: _options.shouldCreateSpanForRequest
    };
  }
  /**
   * @inheritDoc
   */
  setupOnce(_addGlobalEventProcessor) {
    if (NODE_VERSION.major < 16) {
      return;
    }
    let ds;
    try {
      ds = require("diagnostics_channel");
    } catch (e2) {
    }
    if (!ds || !ds.subscribe) {
      return;
    }
    ds.subscribe(ChannelName.RequestCreate, this._onRequestCreate);
    ds.subscribe(ChannelName.RequestEnd, this._onRequestEnd);
    ds.subscribe(ChannelName.RequestError, this._onRequestError);
  }
  /** Helper that wraps shouldCreateSpanForRequest option */
  _shouldCreateSpan(url) {
    if (this._options.tracing === false || this._options.tracing === void 0 && !hasTracingEnabled()) {
      return false;
    }
    if (this._options.shouldCreateSpanForRequest === void 0) {
      return true;
    }
    const cachedDecision = this._createSpanUrlMap.get(url);
    if (cachedDecision !== void 0) {
      return cachedDecision;
    }
    const decision = this._options.shouldCreateSpanForRequest(url);
    this._createSpanUrlMap.set(url, decision);
    return decision;
  }
  __init4() {
    this._onRequestCreate = (message) => {
      if (!_optionalChain([getClient, "call", (_10) => _10(), "optionalAccess", (_11) => _11.getIntegration, "call", (_12) => _12(_Undici)])) {
        return;
      }
      const { request } = message;
      const stringUrl = request.origin ? request.origin.toString() + request.path : request.path;
      const client = getClient();
      if (!client) {
        return;
      }
      if (isSentryRequestUrl(stringUrl, client) || request.__sentry_span__ !== void 0) {
        return;
      }
      const clientOptions = client.getOptions();
      const scope = getCurrentScope();
      const isolationScope = getIsolationScope();
      const parentSpan = getActiveSpan();
      const span = this._shouldCreateSpan(stringUrl) ? createRequestSpan(parentSpan, request, stringUrl) : void 0;
      if (span) {
        request.__sentry_span__ = span;
      }
      const shouldAttachTraceData = (url) => {
        if (clientOptions.tracePropagationTargets === void 0) {
          return true;
        }
        const cachedDecision = this._headersUrlMap.get(url);
        if (cachedDecision !== void 0) {
          return cachedDecision;
        }
        const decision = stringMatchesSomePattern(url, clientOptions.tracePropagationTargets);
        this._headersUrlMap.set(url, decision);
        return decision;
      };
      if (shouldAttachTraceData(stringUrl)) {
        const { traceId, spanId, sampled, dsc } = {
          ...isolationScope.getPropagationContext(),
          ...scope.getPropagationContext()
        };
        const sentryTraceHeader = span ? spanToTraceHeader(span) : generateSentryTraceHeader(traceId, spanId, sampled);
        const sentryBaggageHeader = dynamicSamplingContextToSentryBaggageHeader(
          dsc || (span ? getDynamicSamplingContextFromSpan(span) : getDynamicSamplingContextFromClient(traceId, client, scope))
        );
        setHeadersOnRequest(request, sentryTraceHeader, sentryBaggageHeader);
      }
    };
  }
  __init5() {
    this._onRequestEnd = (message) => {
      if (!_optionalChain([getClient, "call", (_13) => _13(), "optionalAccess", (_14) => _14.getIntegration, "call", (_15) => _15(_Undici)])) {
        return;
      }
      const { request, response } = message;
      const stringUrl = request.origin ? request.origin.toString() + request.path : request.path;
      if (isSentryRequestUrl(stringUrl, getClient())) {
        return;
      }
      const span = request.__sentry_span__;
      if (span) {
        setHttpStatus(span, response.statusCode);
        span.end();
      }
      if (this._options.breadcrumbs) {
        addBreadcrumb(
          {
            category: "http",
            data: {
              method: request.method,
              status_code: response.statusCode,
              url: stringUrl
            },
            type: "http"
          },
          {
            event: "response",
            request,
            response
          }
        );
      }
    };
  }
  __init6() {
    this._onRequestError = (message) => {
      if (!_optionalChain([getClient, "call", (_16) => _16(), "optionalAccess", (_17) => _17.getIntegration, "call", (_18) => _18(_Undici)])) {
        return;
      }
      const { request } = message;
      const stringUrl = request.origin ? request.origin.toString() + request.path : request.path;
      if (isSentryRequestUrl(stringUrl, getClient())) {
        return;
      }
      const span = request.__sentry_span__;
      if (span) {
        span.setStatus("internal_error");
        span.end();
      }
      if (this._options.breadcrumbs) {
        addBreadcrumb(
          {
            category: "http",
            data: {
              method: request.method,
              url: stringUrl
            },
            level: "error",
            type: "http"
          },
          {
            event: "error",
            request
          }
        );
      }
    };
  }
};
Undici.__initStatic();
function setHeadersOnRequest(request, sentryTrace, sentryBaggageHeader) {
  const headerLines = request.headers.split("\r\n");
  const hasSentryHeaders = headerLines.some((headerLine) => headerLine.startsWith("sentry-trace:"));
  if (hasSentryHeaders) {
    return;
  }
  request.addHeader("sentry-trace", sentryTrace);
  if (sentryBaggageHeader) {
    request.addHeader("baggage", sentryBaggageHeader);
  }
}
function createRequestSpan(activeSpan, request, stringUrl) {
  const url = parseUrl(stringUrl);
  const method = request.method || "GET";
  const data = {
    "http.method": method
  };
  if (url.search) {
    data["http.query"] = url.search;
  }
  if (url.hash) {
    data["http.fragment"] = url.hash;
  }
  return _optionalChain([activeSpan, "optionalAccess", (_19) => _19.startChild, "call", (_20) => _20({
    op: "http.client",
    origin: "auto.http.node.undici",
    description: `${method} ${getSanitizedUrlString(url)}`,
    data
  })]);
}

// node_modules/@sentry/node/esm/module.js
var import_path4 = require("path");
function normalizeWindowsPath(path) {
  return path.replace(/^[A-Z]:/, "").replace(/\\/g, "/");
}
function createGetModuleFromFilename(basePath = process.argv[1] ? dirname(process.argv[1]) : process.cwd(), isWindows = import_path4.sep === "\\") {
  const normalizedBase = isWindows ? normalizeWindowsPath(basePath) : basePath;
  return (filename) => {
    if (!filename) {
      return;
    }
    const normalizedFilename = isWindows ? normalizeWindowsPath(filename) : filename;
    let { dir, base: file, ext } = import_path4.posix.parse(normalizedFilename);
    if (ext === ".js" || ext === ".mjs" || ext === ".cjs") {
      file = file.slice(0, ext.length * -1);
    }
    if (!dir) {
      dir = ".";
    }
    const n = dir.lastIndexOf("/node_modules");
    if (n > -1) {
      return `${dir.slice(n + 14).replace(/\//g, ".")}:${file}`;
    }
    if (dir.startsWith(normalizedBase)) {
      let moduleName = dir.slice(normalizedBase.length + 1).replace(/\//g, ".");
      if (moduleName) {
        moduleName += ":";
      }
      moduleName += file;
      return moduleName;
    }
    return file;
  };
}

// node_modules/@sentry/node/esm/integrations/anr/index.js
var import_url7 = require("url");

// node_modules/@sentry/node/esm/integrations/anr/worker-script.js
var base64WorkerScript = "aW1wb3J0IHsgU2Vzc2lvbiB9IGZyb20gJ2luc3BlY3Rvcic7CmltcG9ydCB7IHdvcmtlckRhdGEsIHBhcmVudFBvcnQgfSBmcm9tICd3b3JrZXJfdGhyZWFkcyc7CmltcG9ydCB7IHBvc2l4LCBzZXAgfSBmcm9tICdwYXRoJzsKaW1wb3J0ICogYXMgaHR0cCBmcm9tICdodHRwJzsKaW1wb3J0ICogYXMgaHR0cHMgZnJvbSAnaHR0cHMnOwppbXBvcnQgeyBSZWFkYWJsZSB9IGZyb20gJ3N0cmVhbSc7CmltcG9ydCB7IFVSTCB9IGZyb20gJ3VybCc7CmltcG9ydCB7IGNyZWF0ZUd6aXAgfSBmcm9tICd6bGliJzsKaW1wb3J0IGFzc2VydCBmcm9tICdhc3NlcnQnOwppbXBvcnQgKiBhcyBuZXQgZnJvbSAnbmV0JzsKaW1wb3J0ICogYXMgdGxzIGZyb20gJ3Rscyc7CgovLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L3VuYm91bmQtbWV0aG9kCmNvbnN0IG9iamVjdFRvU3RyaW5nID0gT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZzsKCi8qKgogKiBDaGVja3Mgd2hldGhlciBnaXZlbiB2YWx1ZSdzIHR5cGUgaXMgb25lIG9mIGEgZmV3IEVycm9yIG9yIEVycm9yLWxpa2UKICoge0BsaW5rIGlzRXJyb3J9LgogKgogKiBAcGFyYW0gd2F0IEEgdmFsdWUgdG8gYmUgY2hlY2tlZC4KICogQHJldHVybnMgQSBib29sZWFuIHJlcHJlc2VudGluZyB0aGUgcmVzdWx0LgogKi8KZnVuY3Rpb24gaXNFcnJvcih3YXQpIHsKICBzd2l0Y2ggKG9iamVjdFRvU3RyaW5nLmNhbGwod2F0KSkgewogICAgY2FzZSAnW29iamVjdCBFcnJvcl0nOgogICAgY2FzZSAnW29iamVjdCBFeGNlcHRpb25dJzoKICAgIGNhc2UgJ1tvYmplY3QgRE9NRXhjZXB0aW9uXSc6CiAgICAgIHJldHVybiB0cnVlOwogICAgZGVmYXVsdDoKICAgICAgcmV0dXJuIGlzSW5zdGFuY2VPZih3YXQsIEVycm9yKTsKICB9Cn0KLyoqCiAqIENoZWNrcyB3aGV0aGVyIGdpdmVuIHZhbHVlIGlzIGFuIGluc3RhbmNlIG9mIHRoZSBnaXZlbiBidWlsdC1pbiBjbGFzcy4KICoKICogQHBhcmFtIHdhdCBUaGUgdmFsdWUgdG8gYmUgY2hlY2tlZAogKiBAcGFyYW0gY2xhc3NOYW1lCiAqIEByZXR1cm5zIEEgYm9vbGVhbiByZXByZXNlbnRpbmcgdGhlIHJlc3VsdC4KICovCmZ1bmN0aW9uIGlzQnVpbHRpbih3YXQsIGNsYXNzTmFtZSkgewogIHJldHVybiBvYmplY3RUb1N0cmluZy5jYWxsKHdhdCkgPT09IGBbb2JqZWN0ICR7Y2xhc3NOYW1lfV1gOwp9CgovKioKICogQ2hlY2tzIHdoZXRoZXIgZ2l2ZW4gdmFsdWUncyB0eXBlIGlzIGEgc3RyaW5nCiAqIHtAbGluayBpc1N0cmluZ30uCiAqCiAqIEBwYXJhbSB3YXQgQSB2YWx1ZSB0byBiZSBjaGVja2VkLgogKiBAcmV0dXJucyBBIGJvb2xlYW4gcmVwcmVzZW50aW5nIHRoZSByZXN1bHQuCiAqLwpmdW5jdGlvbiBpc1N0cmluZyh3YXQpIHsKICByZXR1cm4gaXNCdWlsdGluKHdhdCwgJ1N0cmluZycpOwp9CgovKioKICogQ2hlY2tzIHdoZXRoZXIgZ2l2ZW4gdmFsdWUncyB0eXBlIGlzIGFuIG9iamVjdCBsaXRlcmFsLCBvciBhIGNsYXNzIGluc3RhbmNlLgogKiB7QGxpbmsgaXNQbGFpbk9iamVjdH0uCiAqCiAqIEBwYXJhbSB3YXQgQSB2YWx1ZSB0byBiZSBjaGVja2VkLgogKiBAcmV0dXJucyBBIGJvb2xlYW4gcmVwcmVzZW50aW5nIHRoZSByZXN1bHQuCiAqLwpmdW5jdGlvbiBpc1BsYWluT2JqZWN0KHdhdCkgewogIHJldHVybiBpc0J1aWx0aW4od2F0LCAnT2JqZWN0Jyk7Cn0KCi8qKgogKiBDaGVja3Mgd2hldGhlciBnaXZlbiB2YWx1ZSdzIHR5cGUgaXMgYW4gRXZlbnQgaW5zdGFuY2UKICoge0BsaW5rIGlzRXZlbnR9LgogKgogKiBAcGFyYW0gd2F0IEEgdmFsdWUgdG8gYmUgY2hlY2tlZC4KICogQHJldHVybnMgQSBib29sZWFuIHJlcHJlc2VudGluZyB0aGUgcmVzdWx0LgogKi8KZnVuY3Rpb24gaXNFdmVudCh3YXQpIHsKICByZXR1cm4gdHlwZW9mIEV2ZW50ICE9PSAndW5kZWZpbmVkJyAmJiBpc0luc3RhbmNlT2Yod2F0LCBFdmVudCk7Cn0KCi8qKgogKiBDaGVja3Mgd2hldGhlciBnaXZlbiB2YWx1ZSdzIHR5cGUgaXMgYW4gRWxlbWVudCBpbnN0YW5jZQogKiB7QGxpbmsgaXNFbGVtZW50fS4KICoKICogQHBhcmFtIHdhdCBBIHZhbHVlIHRvIGJlIGNoZWNrZWQuCiAqIEByZXR1cm5zIEEgYm9vbGVhbiByZXByZXNlbnRpbmcgdGhlIHJlc3VsdC4KICovCmZ1bmN0aW9uIGlzRWxlbWVudCh3YXQpIHsKICByZXR1cm4gdHlwZW9mIEVsZW1lbnQgIT09ICd1bmRlZmluZWQnICYmIGlzSW5zdGFuY2VPZih3YXQsIEVsZW1lbnQpOwp9CgovKioKICogQ2hlY2tzIHdoZXRoZXIgZ2l2ZW4gdmFsdWUgaGFzIGEgdGhlbiBmdW5jdGlvbi4KICogQHBhcmFtIHdhdCBBIHZhbHVlIHRvIGJlIGNoZWNrZWQuCiAqLwpmdW5jdGlvbiBpc1RoZW5hYmxlKHdhdCkgewogIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tdW5zYWZlLW1lbWJlci1hY2Nlc3MKICByZXR1cm4gQm9vbGVhbih3YXQgJiYgd2F0LnRoZW4gJiYgdHlwZW9mIHdhdC50aGVuID09PSAnZnVuY3Rpb24nKTsKfQoKLyoqCiAqIENoZWNrcyB3aGV0aGVyIGdpdmVuIHZhbHVlJ3MgdHlwZSBpcyBhIFN5bnRoZXRpY0V2ZW50CiAqIHtAbGluayBpc1N5bnRoZXRpY0V2ZW50fS4KICoKICogQHBhcmFtIHdhdCBBIHZhbHVlIHRvIGJlIGNoZWNrZWQuCiAqIEByZXR1cm5zIEEgYm9vbGVhbiByZXByZXNlbnRpbmcgdGhlIHJlc3VsdC4KICovCmZ1bmN0aW9uIGlzU3ludGhldGljRXZlbnQod2F0KSB7CiAgcmV0dXJuIGlzUGxhaW5PYmplY3Qod2F0KSAmJiAnbmF0aXZlRXZlbnQnIGluIHdhdCAmJiAncHJldmVudERlZmF1bHQnIGluIHdhdCAmJiAnc3RvcFByb3BhZ2F0aW9uJyBpbiB3YXQ7Cn0KCi8qKgogKiBDaGVja3Mgd2hldGhlciBnaXZlbiB2YWx1ZSBpcyBOYU4KICoge0BsaW5rIGlzTmFOfS4KICoKICogQHBhcmFtIHdhdCBBIHZhbHVlIHRvIGJlIGNoZWNrZWQuCiAqIEByZXR1cm5zIEEgYm9vbGVhbiByZXByZXNlbnRpbmcgdGhlIHJlc3VsdC4KICovCmZ1bmN0aW9uIGlzTmFOJDEod2F0KSB7CiAgcmV0dXJuIHR5cGVvZiB3YXQgPT09ICdudW1iZXInICYmIHdhdCAhPT0gd2F0Owp9CgovKioKICogQ2hlY2tzIHdoZXRoZXIgZ2l2ZW4gdmFsdWUncyB0eXBlIGlzIGFuIGluc3RhbmNlIG9mIHByb3ZpZGVkIGNvbnN0cnVjdG9yLgogKiB7QGxpbmsgaXNJbnN0YW5jZU9mfS4KICoKICogQHBhcmFtIHdhdCBBIHZhbHVlIHRvIGJlIGNoZWNrZWQuCiAqIEBwYXJhbSBiYXNlIEEgY29uc3RydWN0b3IgdG8gYmUgdXNlZCBpbiBhIGNoZWNrLgogKiBAcmV0dXJucyBBIGJvb2xlYW4gcmVwcmVzZW50aW5nIHRoZSByZXN1bHQuCiAqLwpmdW5jdGlvbiBpc0luc3RhbmNlT2Yod2F0LCBiYXNlKSB7CiAgdHJ5IHsKICAgIHJldHVybiB3YXQgaW5zdGFuY2VvZiBiYXNlOwogIH0gY2F0Y2ggKF9lKSB7CiAgICByZXR1cm4gZmFsc2U7CiAgfQp9CgovKioKICogQ2hlY2tzIHdoZXRoZXIgZ2l2ZW4gdmFsdWUncyB0eXBlIGlzIGEgVnVlIFZpZXdNb2RlbC4KICoKICogQHBhcmFtIHdhdCBBIHZhbHVlIHRvIGJlIGNoZWNrZWQuCiAqIEByZXR1cm5zIEEgYm9vbGVhbiByZXByZXNlbnRpbmcgdGhlIHJlc3VsdC4KICovCmZ1bmN0aW9uIGlzVnVlVmlld01vZGVsKHdhdCkgewogIC8vIE5vdCB1c2luZyBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nIGJlY2F1c2UgaW4gVnVlIDMgaXQgd291bGQgcmVhZCB0aGUgaW5zdGFuY2UncyBTeW1ib2woU3ltYm9sLnRvU3RyaW5nVGFnKSBwcm9wZXJ0eS4KICByZXR1cm4gISEodHlwZW9mIHdhdCA9PT0gJ29iamVjdCcgJiYgd2F0ICE9PSBudWxsICYmICgod2F0ICkuX19pc1Z1ZSB8fCAod2F0ICkuX2lzVnVlKSk7Cn0KCi8qKiBJbnRlcm5hbCBnbG9iYWwgd2l0aCBjb21tb24gcHJvcGVydGllcyBhbmQgU2VudHJ5IGV4dGVuc2lvbnMgICovCgovLyBUaGUgY29kZSBiZWxvdyBmb3IgJ2lzR2xvYmFsT2JqJyBhbmQgJ0dMT0JBTF9PQkonIHdhcyBjb3BpZWQgZnJvbSBjb3JlLWpzIGJlZm9yZSBtb2RpZmljYXRpb24KLy8gaHR0cHM6Ly9naXRodWIuY29tL3psb2lyb2NrL2NvcmUtanMvYmxvYi8xYjk0NGRmNTUyODJjZGM5OWM5MGRiNWY0OWViMGI2ZWRhMmNjMGEzL3BhY2thZ2VzL2NvcmUtanMvaW50ZXJuYWxzL2dsb2JhbC5qcwovLyBjb3JlLWpzIGhhcyB0aGUgZm9sbG93aW5nIGxpY2VuY2U6Ci8vCi8vIENvcHlyaWdodCAoYykgMjAxNC0yMDIyIERlbmlzIFB1c2hrYXJldgovLwovLyBQZXJtaXNzaW9uIGlzIGhlcmVieSBncmFudGVkLCBmcmVlIG9mIGNoYXJnZSwgdG8gYW55IHBlcnNvbiBvYnRhaW5pbmcgYSBjb3B5Ci8vIG9mIHRoaXMgc29mdHdhcmUgYW5kIGFzc29jaWF0ZWQgZG9jdW1lbnRhdGlvbiBmaWxlcyAodGhlICJTb2Z0d2FyZSIpLCB0byBkZWFsCi8vIGluIHRoZSBTb2Z0d2FyZSB3aXRob3V0IHJlc3RyaWN0aW9uLCBpbmNsdWRpbmcgd2l0aG91dCBsaW1pdGF0aW9uIHRoZSByaWdodHMKLy8gdG8gdXNlLCBjb3B5LCBtb2RpZnksIG1lcmdlLCBwdWJsaXNoLCBkaXN0cmlidXRlLCBzdWJsaWNlbnNlLCBhbmQvb3Igc2VsbAovLyBjb3BpZXMgb2YgdGhlIFNvZnR3YXJlLCBhbmQgdG8gcGVybWl0IHBlcnNvbnMgdG8gd2hvbSB0aGUgU29mdHdhcmUgaXMKLy8gZnVybmlzaGVkIHRvIGRvIHNvLCBzdWJqZWN0IHRvIHRoZSBmb2xsb3dpbmcgY29uZGl0aW9uczoKLy8KLy8gVGhlIGFib3ZlIGNvcHlyaWdodCBub3RpY2UgYW5kIHRoaXMgcGVybWlzc2lvbiBub3RpY2Ugc2hhbGwgYmUgaW5jbHVkZWQgaW4KLy8gYWxsIGNvcGllcyBvciBzdWJzdGFudGlhbCBwb3J0aW9ucyBvZiB0aGUgU29mdHdhcmUuCi8vCi8vIFRIRSBTT0ZUV0FSRSBJUyBQUk9WSURFRCAiQVMgSVMiLCBXSVRIT1VUIFdBUlJBTlRZIE9GIEFOWSBLSU5ELCBFWFBSRVNTIE9SCi8vIElNUExJRUQsIElOQ0xVRElORyBCVVQgTk9UIExJTUlURUQgVE8gVEhFIFdBUlJBTlRJRVMgT0YgTUVSQ0hBTlRBQklMSVRZLAovLyBGSVRORVNTIEZPUiBBIFBBUlRJQ1VMQVIgUFVSUE9TRSBBTkQgTk9OSU5GUklOR0VNRU5ULiBJTiBOTyBFVkVOVCBTSEFMTCBUSEUKLy8gQVVUSE9SUyBPUiBDT1BZUklHSFQgSE9MREVSUyBCRSBMSUFCTEUgRk9SIEFOWSBDTEFJTSwgREFNQUdFUyBPUiBPVEhFUgovLyBMSUFCSUxJVFksIFdIRVRIRVIgSU4gQU4gQUNUSU9OIE9GIENPTlRSQUNULCBUT1JUIE9SIE9USEVSV0lTRSwgQVJJU0lORyBGUk9NLAovLyBPVVQgT0YgT1IgSU4gQ09OTkVDVElPTiBXSVRIIFRIRSBTT0ZUV0FSRSBPUiBUSEUgVVNFIE9SIE9USEVSIERFQUxJTkdTIElOCi8vIFRIRSBTT0ZUV0FSRS4KCi8qKiBSZXR1cm5zICdvYmonIGlmIGl0J3MgdGhlIGdsb2JhbCBvYmplY3QsIG90aGVyd2lzZSByZXR1cm5zIHVuZGVmaW5lZCAqLwpmdW5jdGlvbiBpc0dsb2JhbE9iaihvYmopIHsKICByZXR1cm4gb2JqICYmIG9iai5NYXRoID09IE1hdGggPyBvYmogOiB1bmRlZmluZWQ7Cn0KCi8qKiBHZXQncyB0aGUgZ2xvYmFsIG9iamVjdCBmb3IgdGhlIGN1cnJlbnQgSmF2YVNjcmlwdCBydW50aW1lICovCmNvbnN0IEdMT0JBTF9PQkogPQogICh0eXBlb2YgZ2xvYmFsVGhpcyA9PSAnb2JqZWN0JyAmJiBpc0dsb2JhbE9iaihnbG9iYWxUaGlzKSkgfHwKICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tcmVzdHJpY3RlZC1nbG9iYWxzCiAgKHR5cGVvZiB3aW5kb3cgPT0gJ29iamVjdCcgJiYgaXNHbG9iYWxPYmood2luZG93KSkgfHwKICAodHlwZW9mIHNlbGYgPT0gJ29iamVjdCcgJiYgaXNHbG9iYWxPYmooc2VsZikpIHx8CiAgKHR5cGVvZiBnbG9iYWwgPT0gJ29iamVjdCcgJiYgaXNHbG9iYWxPYmooZ2xvYmFsKSkgfHwKICAoZnVuY3Rpb24gKCkgewogICAgcmV0dXJuIHRoaXM7CiAgfSkoKSB8fAogIHt9OwoKLyoqCiAqIEBkZXByZWNhdGVkIFVzZSBHTE9CQUxfT0JKIGluc3RlYWQgb3IgV0lORE9XIGZyb20gQHNlbnRyeS9icm93c2VyLiBUaGlzIHdpbGwgYmUgcmVtb3ZlZCBpbiB2OAogKi8KZnVuY3Rpb24gZ2V0R2xvYmFsT2JqZWN0KCkgewogIHJldHVybiBHTE9CQUxfT0JKIDsKfQoKLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGRlcHJlY2F0aW9uL2RlcHJlY2F0aW9uCmNvbnN0IFdJTkRPVyA9IGdldEdsb2JhbE9iamVjdCgpOwoKY29uc3QgREVGQVVMVF9NQVhfU1RSSU5HX0xFTkdUSCA9IDgwOwoKLyoqCiAqIEdpdmVuIGEgY2hpbGQgRE9NIGVsZW1lbnQsIHJldHVybnMgYSBxdWVyeS1zZWxlY3RvciBzdGF0ZW1lbnQgZGVzY3JpYmluZyB0aGF0CiAqIGFuZCBpdHMgYW5jZXN0b3JzCiAqIGUuZy4gW0hUTUxFbGVtZW50XSA9PiBib2R5ID4gZGl2ID4gaW5wdXQjZm9vLmJ0bltuYW1lPWJhel0KICogQHJldHVybnMgZ2VuZXJhdGVkIERPTSBwYXRoCiAqLwpmdW5jdGlvbiBodG1sVHJlZUFzU3RyaW5nKAogIGVsZW0sCiAgb3B0aW9ucyA9IHt9LAopIHsKICBpZiAoIWVsZW0pIHsKICAgIHJldHVybiAnPHVua25vd24+JzsKICB9CgogIC8vIHRyeS9jYXRjaCBib3RoOgogIC8vIC0gYWNjZXNzaW5nIGV2ZW50LnRhcmdldCAoc2VlIGdldHNlbnRyeS9yYXZlbi1qcyM4MzgsICM3NjgpCiAgLy8gLSBgaHRtbFRyZWVBc1N0cmluZ2AgYmVjYXVzZSBpdCdzIGNvbXBsZXgsIGFuZCBqdXN0IGFjY2Vzc2luZyB0aGUgRE9NIGluY29ycmVjdGx5CiAgLy8gLSBjYW4gdGhyb3cgYW4gZXhjZXB0aW9uIGluIHNvbWUgY2lyY3Vtc3RhbmNlcy4KICB0cnkgewogICAgbGV0IGN1cnJlbnRFbGVtID0gZWxlbSA7CiAgICBjb25zdCBNQVhfVFJBVkVSU0VfSEVJR0hUID0gNTsKICAgIGNvbnN0IG91dCA9IFtdOwogICAgbGV0IGhlaWdodCA9IDA7CiAgICBsZXQgbGVuID0gMDsKICAgIGNvbnN0IHNlcGFyYXRvciA9ICcgPiAnOwogICAgY29uc3Qgc2VwTGVuZ3RoID0gc2VwYXJhdG9yLmxlbmd0aDsKICAgIGxldCBuZXh0U3RyOwogICAgY29uc3Qga2V5QXR0cnMgPSBBcnJheS5pc0FycmF5KG9wdGlvbnMpID8gb3B0aW9ucyA6IG9wdGlvbnMua2V5QXR0cnM7CiAgICBjb25zdCBtYXhTdHJpbmdMZW5ndGggPSAoIUFycmF5LmlzQXJyYXkob3B0aW9ucykgJiYgb3B0aW9ucy5tYXhTdHJpbmdMZW5ndGgpIHx8IERFRkFVTFRfTUFYX1NUUklOR19MRU5HVEg7CgogICAgd2hpbGUgKGN1cnJlbnRFbGVtICYmIGhlaWdodCsrIDwgTUFYX1RSQVZFUlNFX0hFSUdIVCkgewogICAgICBuZXh0U3RyID0gX2h0bWxFbGVtZW50QXNTdHJpbmcoY3VycmVudEVsZW0sIGtleUF0dHJzKTsKICAgICAgLy8gYmFpbCBvdXQgaWYKICAgICAgLy8gLSBuZXh0U3RyIGlzIHRoZSAnaHRtbCcgZWxlbWVudAogICAgICAvLyAtIHRoZSBsZW5ndGggb2YgdGhlIHN0cmluZyB0aGF0IHdvdWxkIGJlIGNyZWF0ZWQgZXhjZWVkcyBtYXhTdHJpbmdMZW5ndGgKICAgICAgLy8gICAoaWdub3JlIHRoaXMgbGltaXQgaWYgd2UgYXJlIG9uIHRoZSBmaXJzdCBpdGVyYXRpb24pCiAgICAgIGlmIChuZXh0U3RyID09PSAnaHRtbCcgfHwgKGhlaWdodCA+IDEgJiYgbGVuICsgb3V0Lmxlbmd0aCAqIHNlcExlbmd0aCArIG5leHRTdHIubGVuZ3RoID49IG1heFN0cmluZ0xlbmd0aCkpIHsKICAgICAgICBicmVhazsKICAgICAgfQoKICAgICAgb3V0LnB1c2gobmV4dFN0cik7CgogICAgICBsZW4gKz0gbmV4dFN0ci5sZW5ndGg7CiAgICAgIGN1cnJlbnRFbGVtID0gY3VycmVudEVsZW0ucGFyZW50Tm9kZTsKICAgIH0KCiAgICByZXR1cm4gb3V0LnJldmVyc2UoKS5qb2luKHNlcGFyYXRvcik7CiAgfSBjYXRjaCAoX29PKSB7CiAgICByZXR1cm4gJzx1bmtub3duPic7CiAgfQp9CgovKioKICogUmV0dXJucyBhIHNpbXBsZSwgcXVlcnktc2VsZWN0b3IgcmVwcmVzZW50YXRpb24gb2YgYSBET00gZWxlbWVudAogKiBlLmcuIFtIVE1MRWxlbWVudF0gPT4gaW5wdXQjZm9vLmJ0bltuYW1lPWJhel0KICogQHJldHVybnMgZ2VuZXJhdGVkIERPTSBwYXRoCiAqLwpmdW5jdGlvbiBfaHRtbEVsZW1lbnRBc1N0cmluZyhlbCwga2V5QXR0cnMpIHsKICBjb25zdCBlbGVtID0gZWwKCjsKCiAgY29uc3Qgb3V0ID0gW107CiAgbGV0IGNsYXNzTmFtZTsKICBsZXQgY2xhc3NlczsKICBsZXQga2V5OwogIGxldCBhdHRyOwogIGxldCBpOwoKICBpZiAoIWVsZW0gfHwgIWVsZW0udGFnTmFtZSkgewogICAgcmV0dXJuICcnOwogIH0KCiAgLy8gQHRzLWV4cGVjdC1lcnJvciBXSU5ET1cgaGFzIEhUTUxFbGVtZW50CiAgaWYgKFdJTkRPVy5IVE1MRWxlbWVudCkgewogICAgLy8gSWYgdXNpbmcgdGhlIGNvbXBvbmVudCBuYW1lIGFubm90YXRpb24gcGx1Z2luLCB0aGlzIHZhbHVlIG1heSBiZSBhdmFpbGFibGUgb24gdGhlIERPTSBub2RlCiAgICBpZiAoZWxlbSBpbnN0YW5jZW9mIEhUTUxFbGVtZW50ICYmIGVsZW0uZGF0YXNldCAmJiBlbGVtLmRhdGFzZXRbJ3NlbnRyeUNvbXBvbmVudCddKSB7CiAgICAgIHJldHVybiBlbGVtLmRhdGFzZXRbJ3NlbnRyeUNvbXBvbmVudCddOwogICAgfQogIH0KCiAgb3V0LnB1c2goZWxlbS50YWdOYW1lLnRvTG93ZXJDYXNlKCkpOwoKICAvLyBQYWlycyBvZiBhdHRyaWJ1dGUga2V5cyBkZWZpbmVkIGluIGBzZXJpYWxpemVBdHRyaWJ1dGVgIGFuZCB0aGVpciB2YWx1ZXMgb24gZWxlbWVudC4KICBjb25zdCBrZXlBdHRyUGFpcnMgPQogICAga2V5QXR0cnMgJiYga2V5QXR0cnMubGVuZ3RoCiAgICAgID8ga2V5QXR0cnMuZmlsdGVyKGtleUF0dHIgPT4gZWxlbS5nZXRBdHRyaWJ1dGUoa2V5QXR0cikpLm1hcChrZXlBdHRyID0+IFtrZXlBdHRyLCBlbGVtLmdldEF0dHJpYnV0ZShrZXlBdHRyKV0pCiAgICAgIDogbnVsbDsKCiAgaWYgKGtleUF0dHJQYWlycyAmJiBrZXlBdHRyUGFpcnMubGVuZ3RoKSB7CiAgICBrZXlBdHRyUGFpcnMuZm9yRWFjaChrZXlBdHRyUGFpciA9PiB7CiAgICAgIG91dC5wdXNoKGBbJHtrZXlBdHRyUGFpclswXX09IiR7a2V5QXR0clBhaXJbMV19Il1gKTsKICAgIH0pOwogIH0gZWxzZSB7CiAgICBpZiAoZWxlbS5pZCkgewogICAgICBvdXQucHVzaChgIyR7ZWxlbS5pZH1gKTsKICAgIH0KCiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgcHJlZmVyLWNvbnN0CiAgICBjbGFzc05hbWUgPSBlbGVtLmNsYXNzTmFtZTsKICAgIGlmIChjbGFzc05hbWUgJiYgaXNTdHJpbmcoY2xhc3NOYW1lKSkgewogICAgICBjbGFzc2VzID0gY2xhc3NOYW1lLnNwbGl0KC9ccysvKTsKICAgICAgZm9yIChpID0gMDsgaSA8IGNsYXNzZXMubGVuZ3RoOyBpKyspIHsKICAgICAgICBvdXQucHVzaChgLiR7Y2xhc3Nlc1tpXX1gKTsKICAgICAgfQogICAgfQogIH0KICBjb25zdCBhbGxvd2VkQXR0cnMgPSBbJ2FyaWEtbGFiZWwnLCAndHlwZScsICduYW1lJywgJ3RpdGxlJywgJ2FsdCddOwogIGZvciAoaSA9IDA7IGkgPCBhbGxvd2VkQXR0cnMubGVuZ3RoOyBpKyspIHsKICAgIGtleSA9IGFsbG93ZWRBdHRyc1tpXTsKICAgIGF0dHIgPSBlbGVtLmdldEF0dHJpYnV0ZShrZXkpOwogICAgaWYgKGF0dHIpIHsKICAgICAgb3V0LnB1c2goYFske2tleX09IiR7YXR0cn0iXWApOwogICAgfQogIH0KICByZXR1cm4gb3V0LmpvaW4oJycpOwp9CgovKioKICogVGhpcyBzZXJ2ZXMgYXMgYSBidWlsZCB0aW1lIGZsYWcgdGhhdCB3aWxsIGJlIHRydWUgYnkgZGVmYXVsdCwgYnV0IGZhbHNlIGluIG5vbi1kZWJ1ZyBidWlsZHMgb3IgaWYgdXNlcnMgcmVwbGFjZSBgX19TRU5UUllfREVCVUdfX2AgaW4gdGhlaXIgZ2VuZXJhdGVkIGNvZGUuCiAqCiAqIEFUVEVOVElPTjogVGhpcyBjb25zdGFudCBtdXN0IG5ldmVyIGNyb3NzIHBhY2thZ2UgYm91bmRhcmllcyAoaS5lLiBiZSBleHBvcnRlZCkgdG8gZ3VhcmFudGVlIHRoYXQgaXQgY2FuIGJlIHVzZWQgZm9yIHRyZWUgc2hha2luZy4KICovCmNvbnN0IERFQlVHX0JVSUxEJDEgPSAodHlwZW9mIF9fU0VOVFJZX0RFQlVHX18gPT09ICd1bmRlZmluZWQnIHx8IF9fU0VOVFJZX0RFQlVHX18pOwoKLyoqIFByZWZpeCBmb3IgbG9nZ2luZyBzdHJpbmdzICovCmNvbnN0IFBSRUZJWCA9ICdTZW50cnkgTG9nZ2VyICc7Cgpjb25zdCBDT05TT0xFX0xFVkVMUyA9IFsKICAnZGVidWcnLAogICdpbmZvJywKICAnd2FybicsCiAgJ2Vycm9yJywKICAnbG9nJywKICAnYXNzZXJ0JywKICAndHJhY2UnLApdIDsKCi8qKiBUaGlzIG1heSBiZSBtdXRhdGVkIGJ5IHRoZSBjb25zb2xlIGluc3RydW1lbnRhdGlvbi4gKi8KY29uc3Qgb3JpZ2luYWxDb25zb2xlTWV0aG9kcwoKID0ge307CgovKiogSlNEb2MgKi8KCi8qKgogKiBUZW1wb3JhcmlseSBkaXNhYmxlIHNlbnRyeSBjb25zb2xlIGluc3RydW1lbnRhdGlvbnMuCiAqCiAqIEBwYXJhbSBjYWxsYmFjayBUaGUgZnVuY3Rpb24gdG8gcnVuIGFnYWluc3QgdGhlIG9yaWdpbmFsIGBjb25zb2xlYCBtZXNzYWdlcwogKiBAcmV0dXJucyBUaGUgcmVzdWx0cyBvZiB0aGUgY2FsbGJhY2sKICovCmZ1bmN0aW9uIGNvbnNvbGVTYW5kYm94KGNhbGxiYWNrKSB7CiAgaWYgKCEoJ2NvbnNvbGUnIGluIEdMT0JBTF9PQkopKSB7CiAgICByZXR1cm4gY2FsbGJhY2soKTsKICB9CgogIGNvbnN0IGNvbnNvbGUgPSBHTE9CQUxfT0JKLmNvbnNvbGUgOwogIGNvbnN0IHdyYXBwZWRGdW5jcyA9IHt9OwoKICBjb25zdCB3cmFwcGVkTGV2ZWxzID0gT2JqZWN0LmtleXMob3JpZ2luYWxDb25zb2xlTWV0aG9kcykgOwoKICAvLyBSZXN0b3JlIGFsbCB3cmFwcGVkIGNvbnNvbGUgbWV0aG9kcwogIHdyYXBwZWRMZXZlbHMuZm9yRWFjaChsZXZlbCA9PiB7CiAgICBjb25zdCBvcmlnaW5hbENvbnNvbGVNZXRob2QgPSBvcmlnaW5hbENvbnNvbGVNZXRob2RzW2xldmVsXSA7CiAgICB3cmFwcGVkRnVuY3NbbGV2ZWxdID0gY29uc29sZVtsZXZlbF0gOwogICAgY29uc29sZVtsZXZlbF0gPSBvcmlnaW5hbENvbnNvbGVNZXRob2Q7CiAgfSk7CgogIHRyeSB7CiAgICByZXR1cm4gY2FsbGJhY2soKTsKICB9IGZpbmFsbHkgewogICAgLy8gUmV2ZXJ0IHJlc3RvcmF0aW9uIHRvIHdyYXBwZWQgc3RhdGUKICAgIHdyYXBwZWRMZXZlbHMuZm9yRWFjaChsZXZlbCA9PiB7CiAgICAgIGNvbnNvbGVbbGV2ZWxdID0gd3JhcHBlZEZ1bmNzW2xldmVsXSA7CiAgICB9KTsKICB9Cn0KCmZ1bmN0aW9uIG1ha2VMb2dnZXIoKSB7CiAgbGV0IGVuYWJsZWQgPSBmYWxzZTsKICBjb25zdCBsb2dnZXIgPSB7CiAgICBlbmFibGU6ICgpID0+IHsKICAgICAgZW5hYmxlZCA9IHRydWU7CiAgICB9LAogICAgZGlzYWJsZTogKCkgPT4gewogICAgICBlbmFibGVkID0gZmFsc2U7CiAgICB9LAogICAgaXNFbmFibGVkOiAoKSA9PiBlbmFibGVkLAogIH07CgogIGlmIChERUJVR19CVUlMRCQxKSB7CiAgICBDT05TT0xFX0xFVkVMUy5mb3JFYWNoKG5hbWUgPT4gewogICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueQogICAgICBsb2dnZXJbbmFtZV0gPSAoLi4uYXJncykgPT4gewogICAgICAgIGlmIChlbmFibGVkKSB7CiAgICAgICAgICBjb25zb2xlU2FuZGJveCgoKSA9PiB7CiAgICAgICAgICAgIEdMT0JBTF9PQkouY29uc29sZVtuYW1lXShgJHtQUkVGSVh9WyR7bmFtZX1dOmAsIC4uLmFyZ3MpOwogICAgICAgICAgfSk7CiAgICAgICAgfQogICAgICB9OwogICAgfSk7CiAgfSBlbHNlIHsKICAgIENPTlNPTEVfTEVWRUxTLmZvckVhY2gobmFtZSA9PiB7CiAgICAgIGxvZ2dlcltuYW1lXSA9ICgpID0+IHVuZGVmaW5lZDsKICAgIH0pOwogIH0KCiAgcmV0dXJuIGxvZ2dlciA7Cn0KCmNvbnN0IGxvZ2dlciA9IG1ha2VMb2dnZXIoKTsKCi8qKgogKiBSZW5kZXJzIHRoZSBzdHJpbmcgcmVwcmVzZW50YXRpb24gb2YgdGhpcyBEc24uCiAqCiAqIEJ5IGRlZmF1bHQsIHRoaXMgd2lsbCByZW5kZXIgdGhlIHB1YmxpYyByZXByZXNlbnRhdGlvbiB3aXRob3V0IHRoZSBwYXNzd29yZAogKiBjb21wb25lbnQuIFRvIGdldCB0aGUgZGVwcmVjYXRlZCBwcml2YXRlIHJlcHJlc2VudGF0aW9uLCBzZXQgYHdpdGhQYXNzd29yZGAKICogdG8gdHJ1ZS4KICoKICogQHBhcmFtIHdpdGhQYXNzd29yZCBXaGVuIHNldCB0byB0cnVlLCB0aGUgcGFzc3dvcmQgd2lsbCBiZSBpbmNsdWRlZC4KICovCmZ1bmN0aW9uIGRzblRvU3RyaW5nKGRzbiwgd2l0aFBhc3N3b3JkID0gZmFsc2UpIHsKICBjb25zdCB7IGhvc3QsIHBhdGgsIHBhc3MsIHBvcnQsIHByb2plY3RJZCwgcHJvdG9jb2wsIHB1YmxpY0tleSB9ID0gZHNuOwogIHJldHVybiAoCiAgICBgJHtwcm90b2NvbH06Ly8ke3B1YmxpY0tleX0ke3dpdGhQYXNzd29yZCAmJiBwYXNzID8gYDoke3Bhc3N9YCA6ICcnfWAgKwogICAgYEAke2hvc3R9JHtwb3J0ID8gYDoke3BvcnR9YCA6ICcnfS8ke3BhdGggPyBgJHtwYXRofS9gIDogcGF0aH0ke3Byb2plY3RJZH1gCiAgKTsKfQoKLyoqIEFuIGVycm9yIGVtaXR0ZWQgYnkgU2VudHJ5IFNES3MgYW5kIHJlbGF0ZWQgdXRpbGl0aWVzLiAqLwpjbGFzcyBTZW50cnlFcnJvciBleHRlbmRzIEVycm9yIHsKICAvKiogRGlzcGxheSBuYW1lIG9mIHRoaXMgZXJyb3IgaW5zdGFuY2UuICovCgogICBjb25zdHJ1Y3RvciggbWVzc2FnZSwgbG9nTGV2ZWwgPSAnd2FybicpIHsKICAgIHN1cGVyKG1lc3NhZ2UpO3RoaXMubWVzc2FnZSA9IG1lc3NhZ2U7CiAgICB0aGlzLm5hbWUgPSBuZXcudGFyZ2V0LnByb3RvdHlwZS5jb25zdHJ1Y3Rvci5uYW1lOwogICAgLy8gVGhpcyBzZXRzIHRoZSBwcm90b3R5cGUgdG8gYmUgYEVycm9yYCwgbm90IGBTZW50cnlFcnJvcmAuIEl0J3MgdW5jbGVhciB3aHkgd2UgZG8gdGhpcywgYnV0IGNvbW1lbnRpbmcgdGhpcyBsaW5lCiAgICAvLyBvdXQgY2F1c2VzIHZhcmlvdXMgKHNlZW1pbmdseSB0b3RhbGx5IHVucmVsYXRlZCkgcGxheXdyaWdodCB0ZXN0cyBjb25zaXN0ZW50bHkgdGltZSBvdXQuIEZZSSwgdGhpcyBtYWtlcwogICAgLy8gaW5zdGFuY2VzIG9mIGBTZW50cnlFcnJvcmAgZmFpbCBgb2JqIGluc3RhbmNlb2YgU2VudHJ5RXJyb3JgIGNoZWNrcy4KICAgIE9iamVjdC5zZXRQcm90b3R5cGVPZih0aGlzLCBuZXcudGFyZ2V0LnByb3RvdHlwZSk7CiAgICB0aGlzLmxvZ0xldmVsID0gbG9nTGV2ZWw7CiAgfQp9CgovKioKICogRW5jb2RlcyBnaXZlbiBvYmplY3QgaW50byB1cmwtZnJpZW5kbHkgZm9ybWF0CiAqCiAqIEBwYXJhbSBvYmplY3QgQW4gb2JqZWN0IHRoYXQgY29udGFpbnMgc2VyaWFsaXphYmxlIHZhbHVlcwogKiBAcmV0dXJucyBzdHJpbmcgRW5jb2RlZAogKi8KZnVuY3Rpb24gdXJsRW5jb2RlKG9iamVjdCkgewogIHJldHVybiBPYmplY3Qua2V5cyhvYmplY3QpCiAgICAubWFwKGtleSA9PiBgJHtlbmNvZGVVUklDb21wb25lbnQoa2V5KX09JHtlbmNvZGVVUklDb21wb25lbnQob2JqZWN0W2tleV0pfWApCiAgICAuam9pbignJicpOwp9CgovKioKICogVHJhbnNmb3JtcyBhbnkgYEVycm9yYCBvciBgRXZlbnRgIGludG8gYSBwbGFpbiBvYmplY3Qgd2l0aCBhbGwgb2YgdGhlaXIgZW51bWVyYWJsZSBwcm9wZXJ0aWVzLCBhbmQgc29tZSBvZiB0aGVpcgogKiBub24tZW51bWVyYWJsZSBwcm9wZXJ0aWVzIGF0dGFjaGVkLgogKgogKiBAcGFyYW0gdmFsdWUgSW5pdGlhbCBzb3VyY2UgdGhhdCB3ZSBoYXZlIHRvIHRyYW5zZm9ybSBpbiBvcmRlciBmb3IgaXQgdG8gYmUgdXNhYmxlIGJ5IHRoZSBzZXJpYWxpemVyCiAqIEByZXR1cm5zIEFuIEV2ZW50IG9yIEVycm9yIHR1cm5lZCBpbnRvIGFuIG9iamVjdCAtIG9yIHRoZSB2YWx1ZSBhcmd1cm1lbnQgaXRzZWxmLCB3aGVuIHZhbHVlIGlzIG5laXRoZXIgYW4gRXZlbnQgbm9yCiAqICBhbiBFcnJvci4KICovCmZ1bmN0aW9uIGNvbnZlcnRUb1BsYWluT2JqZWN0KAogIHZhbHVlLAopCgogewogIGlmIChpc0Vycm9yKHZhbHVlKSkgewogICAgcmV0dXJuIHsKICAgICAgbWVzc2FnZTogdmFsdWUubWVzc2FnZSwKICAgICAgbmFtZTogdmFsdWUubmFtZSwKICAgICAgc3RhY2s6IHZhbHVlLnN0YWNrLAogICAgICAuLi5nZXRPd25Qcm9wZXJ0aWVzKHZhbHVlKSwKICAgIH07CiAgfSBlbHNlIGlmIChpc0V2ZW50KHZhbHVlKSkgewogICAgY29uc3QgbmV3T2JqCgogPSB7CiAgICAgIHR5cGU6IHZhbHVlLnR5cGUsCiAgICAgIHRhcmdldDogc2VyaWFsaXplRXZlbnRUYXJnZXQodmFsdWUudGFyZ2V0KSwKICAgICAgY3VycmVudFRhcmdldDogc2VyaWFsaXplRXZlbnRUYXJnZXQodmFsdWUuY3VycmVudFRhcmdldCksCiAgICAgIC4uLmdldE93blByb3BlcnRpZXModmFsdWUpLAogICAgfTsKCiAgICBpZiAodHlwZW9mIEN1c3RvbUV2ZW50ICE9PSAndW5kZWZpbmVkJyAmJiBpc0luc3RhbmNlT2YodmFsdWUsIEN1c3RvbUV2ZW50KSkgewogICAgICBuZXdPYmouZGV0YWlsID0gdmFsdWUuZGV0YWlsOwogICAgfQoKICAgIHJldHVybiBuZXdPYmo7CiAgfSBlbHNlIHsKICAgIHJldHVybiB2YWx1ZTsKICB9Cn0KCi8qKiBDcmVhdGVzIGEgc3RyaW5nIHJlcHJlc2VudGF0aW9uIG9mIHRoZSB0YXJnZXQgb2YgYW4gYEV2ZW50YCBvYmplY3QgKi8KZnVuY3Rpb24gc2VyaWFsaXplRXZlbnRUYXJnZXQodGFyZ2V0KSB7CiAgdHJ5IHsKICAgIHJldHVybiBpc0VsZW1lbnQodGFyZ2V0KSA/IGh0bWxUcmVlQXNTdHJpbmcodGFyZ2V0KSA6IE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbCh0YXJnZXQpOwogIH0gY2F0Y2ggKF9vTykgewogICAgcmV0dXJuICc8dW5rbm93bj4nOwogIH0KfQoKLyoqIEZpbHRlcnMgb3V0IGFsbCBidXQgYW4gb2JqZWN0J3Mgb3duIHByb3BlcnRpZXMgKi8KZnVuY3Rpb24gZ2V0T3duUHJvcGVydGllcyhvYmopIHsKICBpZiAodHlwZW9mIG9iaiA9PT0gJ29iamVjdCcgJiYgb2JqICE9PSBudWxsKSB7CiAgICBjb25zdCBleHRyYWN0ZWRQcm9wcyA9IHt9OwogICAgZm9yIChjb25zdCBwcm9wZXJ0eSBpbiBvYmopIHsKICAgICAgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmosIHByb3BlcnR5KSkgewogICAgICAgIGV4dHJhY3RlZFByb3BzW3Byb3BlcnR5XSA9IChvYmogKVtwcm9wZXJ0eV07CiAgICAgIH0KICAgIH0KICAgIHJldHVybiBleHRyYWN0ZWRQcm9wczsKICB9IGVsc2UgewogICAgcmV0dXJuIHt9OwogIH0KfQoKLyoqCiAqIEdpdmVuIGFueSBvYmplY3QsIHJldHVybiBhIG5ldyBvYmplY3QgaGF2aW5nIHJlbW92ZWQgYWxsIGZpZWxkcyB3aG9zZSB2YWx1ZSB3YXMgYHVuZGVmaW5lZGAuCiAqIFdvcmtzIHJlY3Vyc2l2ZWx5IG9uIG9iamVjdHMgYW5kIGFycmF5cy4KICoKICogQXR0ZW50aW9uOiBUaGlzIGZ1bmN0aW9uIGtlZXBzIGNpcmN1bGFyIHJlZmVyZW5jZXMgaW4gdGhlIHJldHVybmVkIG9iamVjdC4KICovCmZ1bmN0aW9uIGRyb3BVbmRlZmluZWRLZXlzKGlucHV0VmFsdWUpIHsKICAvLyBUaGlzIG1hcCBrZWVwcyB0cmFjayBvZiB3aGF0IGFscmVhZHkgdmlzaXRlZCBub2RlcyBtYXAgdG8uCiAgLy8gT3VyIFNldCAtIGJhc2VkIG1lbW9CdWlsZGVyIGRvZXNuJ3Qgd29yayBoZXJlIGJlY2F1c2Ugd2Ugd2FudCB0byB0aGUgb3V0cHV0IG9iamVjdCB0byBoYXZlIHRoZSBzYW1lIGNpcmN1bGFyCiAgLy8gcmVmZXJlbmNlcyBhcyB0aGUgaW5wdXQgb2JqZWN0LgogIGNvbnN0IG1lbW9pemF0aW9uTWFwID0gbmV3IE1hcCgpOwoKICAvLyBUaGlzIGZ1bmN0aW9uIGp1c3QgcHJveGllcyBgX2Ryb3BVbmRlZmluZWRLZXlzYCB0byBrZWVwIHRoZSBgbWVtb0J1aWxkZXJgIG91dCBvZiB0aGlzIGZ1bmN0aW9uJ3MgQVBJCiAgcmV0dXJuIF9kcm9wVW5kZWZpbmVkS2V5cyhpbnB1dFZhbHVlLCBtZW1vaXphdGlvbk1hcCk7Cn0KCmZ1bmN0aW9uIF9kcm9wVW5kZWZpbmVkS2V5cyhpbnB1dFZhbHVlLCBtZW1vaXphdGlvbk1hcCkgewogIGlmIChpc1Bvam8oaW5wdXRWYWx1ZSkpIHsKICAgIC8vIElmIHRoaXMgbm9kZSBoYXMgYWxyZWFkeSBiZWVuIHZpc2l0ZWQgZHVlIHRvIGEgY2lyY3VsYXIgcmVmZXJlbmNlLCByZXR1cm4gdGhlIG9iamVjdCBpdCB3YXMgbWFwcGVkIHRvIGluIHRoZSBuZXcgb2JqZWN0CiAgICBjb25zdCBtZW1vVmFsID0gbWVtb2l6YXRpb25NYXAuZ2V0KGlucHV0VmFsdWUpOwogICAgaWYgKG1lbW9WYWwgIT09IHVuZGVmaW5lZCkgewogICAgICByZXR1cm4gbWVtb1ZhbCA7CiAgICB9CgogICAgY29uc3QgcmV0dXJuVmFsdWUgPSB7fTsKICAgIC8vIFN0b3JlIHRoZSBtYXBwaW5nIG9mIHRoaXMgdmFsdWUgaW4gY2FzZSB3ZSB2aXNpdCBpdCBhZ2FpbiwgaW4gY2FzZSBvZiBjaXJjdWxhciBkYXRhCiAgICBtZW1vaXphdGlvbk1hcC5zZXQoaW5wdXRWYWx1ZSwgcmV0dXJuVmFsdWUpOwoKICAgIGZvciAoY29uc3Qga2V5IG9mIE9iamVjdC5rZXlzKGlucHV0VmFsdWUpKSB7CiAgICAgIGlmICh0eXBlb2YgaW5wdXRWYWx1ZVtrZXldICE9PSAndW5kZWZpbmVkJykgewogICAgICAgIHJldHVyblZhbHVlW2tleV0gPSBfZHJvcFVuZGVmaW5lZEtleXMoaW5wdXRWYWx1ZVtrZXldLCBtZW1vaXphdGlvbk1hcCk7CiAgICAgIH0KICAgIH0KCiAgICByZXR1cm4gcmV0dXJuVmFsdWUgOwogIH0KCiAgaWYgKEFycmF5LmlzQXJyYXkoaW5wdXRWYWx1ZSkpIHsKICAgIC8vIElmIHRoaXMgbm9kZSBoYXMgYWxyZWFkeSBiZWVuIHZpc2l0ZWQgZHVlIHRvIGEgY2lyY3VsYXIgcmVmZXJlbmNlLCByZXR1cm4gdGhlIGFycmF5IGl0IHdhcyBtYXBwZWQgdG8gaW4gdGhlIG5ldyBvYmplY3QKICAgIGNvbnN0IG1lbW9WYWwgPSBtZW1vaXphdGlvbk1hcC5nZXQoaW5wdXRWYWx1ZSk7CiAgICBpZiAobWVtb1ZhbCAhPT0gdW5kZWZpbmVkKSB7CiAgICAgIHJldHVybiBtZW1vVmFsIDsKICAgIH0KCiAgICBjb25zdCByZXR1cm5WYWx1ZSA9IFtdOwogICAgLy8gU3RvcmUgdGhlIG1hcHBpbmcgb2YgdGhpcyB2YWx1ZSBpbiBjYXNlIHdlIHZpc2l0IGl0IGFnYWluLCBpbiBjYXNlIG9mIGNpcmN1bGFyIGRhdGEKICAgIG1lbW9pemF0aW9uTWFwLnNldChpbnB1dFZhbHVlLCByZXR1cm5WYWx1ZSk7CgogICAgaW5wdXRWYWx1ZS5mb3JFYWNoKChpdGVtKSA9PiB7CiAgICAgIHJldHVyblZhbHVlLnB1c2goX2Ryb3BVbmRlZmluZWRLZXlzKGl0ZW0sIG1lbW9pemF0aW9uTWFwKSk7CiAgICB9KTsKCiAgICByZXR1cm4gcmV0dXJuVmFsdWUgOwogIH0KCiAgcmV0dXJuIGlucHV0VmFsdWU7Cn0KCmZ1bmN0aW9uIGlzUG9qbyhpbnB1dCkgewogIGlmICghaXNQbGFpbk9iamVjdChpbnB1dCkpIHsKICAgIHJldHVybiBmYWxzZTsKICB9CgogIHRyeSB7CiAgICBjb25zdCBuYW1lID0gKE9iamVjdC5nZXRQcm90b3R5cGVPZihpbnB1dCkgKS5jb25zdHJ1Y3Rvci5uYW1lOwogICAgcmV0dXJuICFuYW1lIHx8IG5hbWUgPT09ICdPYmplY3QnOwogIH0gY2F0Y2ggKGUpIHsKICAgIHJldHVybiB0cnVlOwogIH0KfQoKLyoqCiAqIERvZXMgdGhpcyBmaWxlbmFtZSBsb29rIGxpa2UgaXQncyBwYXJ0IG9mIHRoZSBhcHAgY29kZT8KICovCmZ1bmN0aW9uIGZpbGVuYW1lSXNJbkFwcChmaWxlbmFtZSwgaXNOYXRpdmUgPSBmYWxzZSkgewogIGNvbnN0IGlzSW50ZXJuYWwgPQogICAgaXNOYXRpdmUgfHwKICAgIChmaWxlbmFtZSAmJgogICAgICAvLyBJdCdzIG5vdCBpbnRlcm5hbCBpZiBpdCdzIGFuIGFic29sdXRlIGxpbnV4IHBhdGgKICAgICAgIWZpbGVuYW1lLnN0YXJ0c1dpdGgoJy8nKSAmJgogICAgICAvLyBJdCdzIG5vdCBpbnRlcm5hbCBpZiBpdCdzIGFuIGFic29sdXRlIHdpbmRvd3MgcGF0aAogICAgICAhZmlsZW5hbWUubWF0Y2goL15bQS1aXTovKSAmJgogICAgICAvLyBJdCdzIG5vdCBpbnRlcm5hbCBpZiB0aGUgcGF0aCBpcyBzdGFydGluZyB3aXRoIGEgZG90CiAgICAgICFmaWxlbmFtZS5zdGFydHNXaXRoKCcuJykgJiYKICAgICAgLy8gSXQncyBub3QgaW50ZXJuYWwgaWYgdGhlIGZyYW1lIGhhcyBhIHByb3RvY29sLiBJbiBub2RlLCB0aGlzIGlzIHVzdWFsbHkgdGhlIGNhc2UgaWYgdGhlIGZpbGUgZ290IHByZS1wcm9jZXNzZWQgd2l0aCBhIGJ1bmRsZXIgbGlrZSB3ZWJwYWNrCiAgICAgICFmaWxlbmFtZS5tYXRjaCgvXlthLXpBLVpdKFthLXpBLVowLTkuXC0rXSkqOlwvXC8vKSk7IC8vIFNjaGVtYSBmcm9tOiBodHRwczovL3N0YWNrb3ZlcmZsb3cuY29tL2EvMzY0MTc4MgoKICAvLyBpbl9hcHAgaXMgYWxsIHRoYXQncyBub3QgYW4gaW50ZXJuYWwgTm9kZSBmdW5jdGlvbiBvciBhIG1vZHVsZSB3aXRoaW4gbm9kZV9tb2R1bGVzCiAgLy8gbm90ZSB0aGF0IGlzTmF0aXZlIGFwcGVhcnMgdG8gcmV0dXJuIHRydWUgZXZlbiBmb3Igbm9kZSBjb3JlIGxpYnJhcmllcwogIC8vIHNlZSBodHRwczovL2dpdGh1Yi5jb20vZ2V0c2VudHJ5L3JhdmVuLW5vZGUvaXNzdWVzLzE3NgoKICByZXR1cm4gIWlzSW50ZXJuYWwgJiYgZmlsZW5hbWUgIT09IHVuZGVmaW5lZCAmJiAhZmlsZW5hbWUuaW5jbHVkZXMoJ25vZGVfbW9kdWxlcy8nKTsKfQoKY29uc3QgU1RBQ0tUUkFDRV9GUkFNRV9MSU1JVCA9IDUwOwpjb25zdCBTVFJJUF9GUkFNRV9SRUdFWFAgPSAvY2FwdHVyZU1lc3NhZ2V8Y2FwdHVyZUV4Y2VwdGlvbi87CgovKioKICogUmVtb3ZlcyBTZW50cnkgZnJhbWVzIGZyb20gdGhlIHRvcCBhbmQgYm90dG9tIG9mIHRoZSBzdGFjayBpZiBwcmVzZW50IGFuZCBlbmZvcmNlcyBhIGxpbWl0IG9mIG1heCBudW1iZXIgb2YgZnJhbWVzLgogKiBBc3N1bWVzIHN0YWNrIGlucHV0IGlzIG9yZGVyZWQgZnJvbSB0b3AgdG8gYm90dG9tIGFuZCByZXR1cm5zIHRoZSByZXZlcnNlIHJlcHJlc2VudGF0aW9uIHNvIGNhbGwgc2l0ZSBvZiB0aGUKICogZnVuY3Rpb24gdGhhdCBjYXVzZWQgdGhlIGNyYXNoIGlzIHRoZSBsYXN0IGZyYW1lIGluIHRoZSBhcnJheS4KICogQGhpZGRlbgogKi8KZnVuY3Rpb24gc3RyaXBTZW50cnlGcmFtZXNBbmRSZXZlcnNlKHN0YWNrKSB7CiAgaWYgKCFzdGFjay5sZW5ndGgpIHsKICAgIHJldHVybiBbXTsKICB9CgogIGNvbnN0IGxvY2FsU3RhY2sgPSBBcnJheS5mcm9tKHN0YWNrKTsKCiAgLy8gSWYgc3RhY2sgc3RhcnRzIHdpdGggb25lIG9mIG91ciBBUEkgY2FsbHMsIHJlbW92ZSBpdCAoc3RhcnRzLCBtZWFuaW5nIGl0J3MgdGhlIHRvcCBvZiB0aGUgc3RhY2sgLSBha2EgbGFzdCBjYWxsKQogIGlmICgvc2VudHJ5V3JhcHBlZC8udGVzdChsb2NhbFN0YWNrW2xvY2FsU3RhY2subGVuZ3RoIC0gMV0uZnVuY3Rpb24gfHwgJycpKSB7CiAgICBsb2NhbFN0YWNrLnBvcCgpOwogIH0KCiAgLy8gUmV2ZXJzaW5nIGluIHRoZSBtaWRkbGUgb2YgdGhlIHByb2NlZHVyZSBhbGxvd3MgdXMgdG8ganVzdCBwb3AgdGhlIHZhbHVlcyBvZmYgdGhlIHN0YWNrCiAgbG9jYWxTdGFjay5yZXZlcnNlKCk7CgogIC8vIElmIHN0YWNrIGVuZHMgd2l0aCBvbmUgb2Ygb3VyIGludGVybmFsIEFQSSBjYWxscywgcmVtb3ZlIGl0IChlbmRzLCBtZWFuaW5nIGl0J3MgdGhlIGJvdHRvbSBvZiB0aGUgc3RhY2sgLSBha2EgdG9wLW1vc3QgY2FsbCkKICBpZiAoU1RSSVBfRlJBTUVfUkVHRVhQLnRlc3QobG9jYWxTdGFja1tsb2NhbFN0YWNrLmxlbmd0aCAtIDFdLmZ1bmN0aW9uIHx8ICcnKSkgewogICAgbG9jYWxTdGFjay5wb3AoKTsKCiAgICAvLyBXaGVuIHVzaW5nIHN5bnRoZXRpYyBldmVudHMsIHdlIHdpbGwgaGF2ZSBhIDIgbGV2ZWxzIGRlZXAgc3RhY2ssIGFzIGBuZXcgRXJyb3IoJ1NlbnRyeSBzeW50aGV0aWNFeGNlcHRpb24nKWAKICAgIC8vIGlzIHByb2R1Y2VkIHdpdGhpbiB0aGUgaHViIGl0c2VsZiwgbWFraW5nIGl0OgogICAgLy8KICAgIC8vICAgU2VudHJ5LmNhcHR1cmVFeGNlcHRpb24oKQogICAgLy8gICBnZXRDdXJyZW50SHViKCkuY2FwdHVyZUV4Y2VwdGlvbigpCiAgICAvLwogICAgLy8gaW5zdGVhZCBvZiBqdXN0IHRoZSB0b3AgYFNlbnRyeWAgY2FsbCBpdHNlbGYuCiAgICAvLyBUaGlzIGZvcmNlcyB1cyB0byBwb3NzaWJseSBzdHJpcCBhbiBhZGRpdGlvbmFsIGZyYW1lIGluIHRoZSBleGFjdCBzYW1lIHdhcyBhcyBhYm92ZS4KICAgIGlmIChTVFJJUF9GUkFNRV9SRUdFWFAudGVzdChsb2NhbFN0YWNrW2xvY2FsU3RhY2subGVuZ3RoIC0gMV0uZnVuY3Rpb24gfHwgJycpKSB7CiAgICAgIGxvY2FsU3RhY2sucG9wKCk7CiAgICB9CiAgfQoKICByZXR1cm4gbG9jYWxTdGFjay5zbGljZSgwLCBTVEFDS1RSQUNFX0ZSQU1FX0xJTUlUKS5tYXAoZnJhbWUgPT4gKHsKICAgIC4uLmZyYW1lLAogICAgZmlsZW5hbWU6IGZyYW1lLmZpbGVuYW1lIHx8IGxvY2FsU3RhY2tbbG9jYWxTdGFjay5sZW5ndGggLSAxXS5maWxlbmFtZSwKICAgIGZ1bmN0aW9uOiBmcmFtZS5mdW5jdGlvbiB8fCAnPycsCiAgfSkpOwp9Cgpjb25zdCBkZWZhdWx0RnVuY3Rpb25OYW1lID0gJzxhbm9ueW1vdXM+JzsKCi8qKgogKiBTYWZlbHkgZXh0cmFjdCBmdW5jdGlvbiBuYW1lIGZyb20gaXRzZWxmCiAqLwpmdW5jdGlvbiBnZXRGdW5jdGlvbk5hbWUoZm4pIHsKICB0cnkgewogICAgaWYgKCFmbiB8fCB0eXBlb2YgZm4gIT09ICdmdW5jdGlvbicpIHsKICAgICAgcmV0dXJuIGRlZmF1bHRGdW5jdGlvbk5hbWU7CiAgICB9CiAgICByZXR1cm4gZm4ubmFtZSB8fCBkZWZhdWx0RnVuY3Rpb25OYW1lOwogIH0gY2F0Y2ggKGUpIHsKICAgIC8vIEp1c3QgYWNjZXNzaW5nIGN1c3RvbSBwcm9wcyBpbiBzb21lIFNlbGVuaXVtIGVudmlyb25tZW50cwogICAgLy8gY2FuIGNhdXNlIGEgIlBlcm1pc3Npb24gZGVuaWVkIiBleGNlcHRpb24gKHNlZSByYXZlbi1qcyM0OTUpLgogICAgcmV0dXJuIGRlZmF1bHRGdW5jdGlvbk5hbWU7CiAgfQp9CgovKioKICogVVVJRDQgZ2VuZXJhdG9yCiAqCiAqIEByZXR1cm5zIHN0cmluZyBHZW5lcmF0ZWQgVVVJRDQuCiAqLwpmdW5jdGlvbiB1dWlkNCgpIHsKICBjb25zdCBnYmwgPSBHTE9CQUxfT0JKIDsKICBjb25zdCBjcnlwdG8gPSBnYmwuY3J5cHRvIHx8IGdibC5tc0NyeXB0bzsKCiAgbGV0IGdldFJhbmRvbUJ5dGUgPSAoKSA9PiBNYXRoLnJhbmRvbSgpICogMTY7CiAgdHJ5IHsKICAgIGlmIChjcnlwdG8gJiYgY3J5cHRvLnJhbmRvbVVVSUQpIHsKICAgICAgcmV0dXJuIGNyeXB0by5yYW5kb21VVUlEKCkucmVwbGFjZSgvLS9nLCAnJyk7CiAgICB9CiAgICBpZiAoY3J5cHRvICYmIGNyeXB0by5nZXRSYW5kb21WYWx1ZXMpIHsKICAgICAgZ2V0UmFuZG9tQnl0ZSA9ICgpID0+IHsKICAgICAgICAvLyBjcnlwdG8uZ2V0UmFuZG9tVmFsdWVzIG1pZ2h0IHJldHVybiB1bmRlZmluZWQgaW5zdGVhZCBvZiB0aGUgdHlwZWQgYXJyYXkKICAgICAgICAvLyBpbiBvbGQgQ2hyb21pdW0gdmVyc2lvbnMgKGUuZy4gMjMuMC4xMjM1LjAgKDE1MTQyMikpCiAgICAgICAgLy8gSG93ZXZlciwgYHR5cGVkQXJyYXlgIGlzIHN0aWxsIGZpbGxlZCBpbi1wbGFjZS4KICAgICAgICAvLyBAc2VlIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0FQSS9DcnlwdG8vZ2V0UmFuZG9tVmFsdWVzI3R5cGVkYXJyYXkKICAgICAgICBjb25zdCB0eXBlZEFycmF5ID0gbmV3IFVpbnQ4QXJyYXkoMSk7CiAgICAgICAgY3J5cHRvLmdldFJhbmRvbVZhbHVlcyh0eXBlZEFycmF5KTsKICAgICAgICByZXR1cm4gdHlwZWRBcnJheVswXTsKICAgICAgfTsKICAgIH0KICB9IGNhdGNoIChfKSB7CiAgICAvLyBzb21lIHJ1bnRpbWVzIGNhbiBjcmFzaCBpbnZva2luZyBjcnlwdG8KICAgIC8vIGh0dHBzOi8vZ2l0aHViLmNvbS9nZXRzZW50cnkvc2VudHJ5LWphdmFzY3JpcHQvaXNzdWVzLzg5MzUKICB9CgogIC8vIGh0dHA6Ly9zdGFja292ZXJmbG93LmNvbS9xdWVzdGlvbnMvMTA1MDM0L2hvdy10by1jcmVhdGUtYS1ndWlkLXV1aWQtaW4tamF2YXNjcmlwdC8yMTE3NTIzIzIxMTc1MjMKICAvLyBDb25jYXRlbmF0aW5nIHRoZSBmb2xsb3dpbmcgbnVtYmVycyBhcyBzdHJpbmdzIHJlc3VsdHMgaW4gJzEwMDAwMDAwMTAwMDQwMDA4MDAwMTAwMDAwMDAwMDAwJwogIHJldHVybiAoKFsxZTddICkgKyAxZTMgKyA0ZTMgKyA4ZTMgKyAxZTExKS5yZXBsYWNlKC9bMDE4XS9nLCBjID0+CiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tYml0d2lzZQogICAgKChjICkgXiAoKGdldFJhbmRvbUJ5dGUoKSAmIDE1KSA+PiAoKGMgKSAvIDQpKSkudG9TdHJpbmcoMTYpLAogICk7Cn0KCi8qIGVzbGludC1kaXNhYmxlIEB0eXBlc2NyaXB0LWVzbGludC9uby11bnNhZmUtbWVtYmVyLWFjY2VzcyAqLwovKiBlc2xpbnQtZGlzYWJsZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55ICovCgovKioKICogSGVscGVyIHRvIGRlY3ljbGUganNvbiBvYmplY3RzCiAqLwpmdW5jdGlvbiBtZW1vQnVpbGRlcigpIHsKICBjb25zdCBoYXNXZWFrU2V0ID0gdHlwZW9mIFdlYWtTZXQgPT09ICdmdW5jdGlvbic7CiAgY29uc3QgaW5uZXIgPSBoYXNXZWFrU2V0ID8gbmV3IFdlYWtTZXQoKSA6IFtdOwogIGZ1bmN0aW9uIG1lbW9pemUob2JqKSB7CiAgICBpZiAoaGFzV2Vha1NldCkgewogICAgICBpZiAoaW5uZXIuaGFzKG9iaikpIHsKICAgICAgICByZXR1cm4gdHJ1ZTsKICAgICAgfQogICAgICBpbm5lci5hZGQob2JqKTsKICAgICAgcmV0dXJuIGZhbHNlOwogICAgfQogICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9wcmVmZXItZm9yLW9mCiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGlubmVyLmxlbmd0aDsgaSsrKSB7CiAgICAgIGNvbnN0IHZhbHVlID0gaW5uZXJbaV07CiAgICAgIGlmICh2YWx1ZSA9PT0gb2JqKSB7CiAgICAgICAgcmV0dXJuIHRydWU7CiAgICAgIH0KICAgIH0KICAgIGlubmVyLnB1c2gob2JqKTsKICAgIHJldHVybiBmYWxzZTsKICB9CgogIGZ1bmN0aW9uIHVubWVtb2l6ZShvYmopIHsKICAgIGlmIChoYXNXZWFrU2V0KSB7CiAgICAgIGlubmVyLmRlbGV0ZShvYmopOwogICAgfSBlbHNlIHsKICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBpbm5lci5sZW5ndGg7IGkrKykgewogICAgICAgIGlmIChpbm5lcltpXSA9PT0gb2JqKSB7CiAgICAgICAgICBpbm5lci5zcGxpY2UoaSwgMSk7CiAgICAgICAgICBicmVhazsKICAgICAgICB9CiAgICAgIH0KICAgIH0KICB9CiAgcmV0dXJuIFttZW1vaXplLCB1bm1lbW9pemVdOwp9CgovKioKICogUmVjdXJzaXZlbHkgbm9ybWFsaXplcyB0aGUgZ2l2ZW4gb2JqZWN0LgogKgogKiAtIENyZWF0ZXMgYSBjb3B5IHRvIHByZXZlbnQgb3JpZ2luYWwgaW5wdXQgbXV0YXRpb24KICogLSBTa2lwcyBub24tZW51bWVyYWJsZSBwcm9wZXJ0aWVzCiAqIC0gV2hlbiBzdHJpbmdpZnlpbmcsIGNhbGxzIGB0b0pTT05gIGlmIGltcGxlbWVudGVkCiAqIC0gUmVtb3ZlcyBjaXJjdWxhciByZWZlcmVuY2VzCiAqIC0gVHJhbnNsYXRlcyBub24tc2VyaWFsaXphYmxlIHZhbHVlcyAoYHVuZGVmaW5lZGAvYE5hTmAvZnVuY3Rpb25zKSB0byBzZXJpYWxpemFibGUgZm9ybWF0CiAqIC0gVHJhbnNsYXRlcyBrbm93biBnbG9iYWwgb2JqZWN0cy9jbGFzc2VzIHRvIGEgc3RyaW5nIHJlcHJlc2VudGF0aW9ucwogKiAtIFRha2VzIGNhcmUgb2YgYEVycm9yYCBvYmplY3Qgc2VyaWFsaXphdGlvbgogKiAtIE9wdGlvbmFsbHkgbGltaXRzIGRlcHRoIG9mIGZpbmFsIG91dHB1dAogKiAtIE9wdGlvbmFsbHkgbGltaXRzIG51bWJlciBvZiBwcm9wZXJ0aWVzL2VsZW1lbnRzIGluY2x1ZGVkIGluIGFueSBzaW5nbGUgb2JqZWN0L2FycmF5CiAqCiAqIEBwYXJhbSBpbnB1dCBUaGUgb2JqZWN0IHRvIGJlIG5vcm1hbGl6ZWQuCiAqIEBwYXJhbSBkZXB0aCBUaGUgbWF4IGRlcHRoIHRvIHdoaWNoIHRvIG5vcm1hbGl6ZSB0aGUgb2JqZWN0LiAoQW55dGhpbmcgZGVlcGVyIHN0cmluZ2lmaWVkIHdob2xlLikKICogQHBhcmFtIG1heFByb3BlcnRpZXMgVGhlIG1heCBudW1iZXIgb2YgZWxlbWVudHMgb3IgcHJvcGVydGllcyB0byBiZSBpbmNsdWRlZCBpbiBhbnkgc2luZ2xlIGFycmF5IG9yCiAqIG9iamVjdCBpbiB0aGUgbm9ybWFsbGl6ZWQgb3V0cHV0LgogKiBAcmV0dXJucyBBIG5vcm1hbGl6ZWQgdmVyc2lvbiBvZiB0aGUgb2JqZWN0LCBvciBgIioqbm9uLXNlcmlhbGl6YWJsZSoqImAgaWYgYW55IGVycm9ycyBhcmUgdGhyb3duIGR1cmluZyBub3JtYWxpemF0aW9uLgogKi8KLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHBsaWNpdC1hbnkKZnVuY3Rpb24gbm9ybWFsaXplKGlucHV0LCBkZXB0aCA9IDEwMCwgbWF4UHJvcGVydGllcyA9ICtJbmZpbml0eSkgewogIHRyeSB7CiAgICAvLyBzaW5jZSB3ZSdyZSBhdCB0aGUgb3V0ZXJtb3N0IGxldmVsLCB3ZSBkb24ndCBwcm92aWRlIGEga2V5CiAgICByZXR1cm4gdmlzaXQoJycsIGlucHV0LCBkZXB0aCwgbWF4UHJvcGVydGllcyk7CiAgfSBjYXRjaCAoZXJyKSB7CiAgICByZXR1cm4geyBFUlJPUjogYCoqbm9uLXNlcmlhbGl6YWJsZSoqICgke2Vycn0pYCB9OwogIH0KfQoKLyoqCiAqIFZpc2l0cyBhIG5vZGUgdG8gcGVyZm9ybSBub3JtYWxpemF0aW9uIG9uIGl0CiAqCiAqIEBwYXJhbSBrZXkgVGhlIGtleSBjb3JyZXNwb25kaW5nIHRvIHRoZSBnaXZlbiBub2RlCiAqIEBwYXJhbSB2YWx1ZSBUaGUgbm9kZSB0byBiZSB2aXNpdGVkCiAqIEBwYXJhbSBkZXB0aCBPcHRpb25hbCBudW1iZXIgaW5kaWNhdGluZyB0aGUgbWF4aW11bSByZWN1cnNpb24gZGVwdGgKICogQHBhcmFtIG1heFByb3BlcnRpZXMgT3B0aW9uYWwgbWF4aW11bSBudW1iZXIgb2YgcHJvcGVydGllcy9lbGVtZW50cyBpbmNsdWRlZCBpbiBhbnkgc2luZ2xlIG9iamVjdC9hcnJheQogKiBAcGFyYW0gbWVtbyBPcHRpb25hbCBNZW1vIGNsYXNzIGhhbmRsaW5nIGRlY3ljbGluZwogKi8KZnVuY3Rpb24gdmlzaXQoCiAga2V5LAogIHZhbHVlLAogIGRlcHRoID0gK0luZmluaXR5LAogIG1heFByb3BlcnRpZXMgPSArSW5maW5pdHksCiAgbWVtbyA9IG1lbW9CdWlsZGVyKCksCikgewogIGNvbnN0IFttZW1vaXplLCB1bm1lbW9pemVdID0gbWVtbzsKCiAgLy8gR2V0IHRoZSBzaW1wbGUgY2FzZXMgb3V0IG9mIHRoZSB3YXkgZmlyc3QKICBpZiAoCiAgICB2YWx1ZSA9PSBudWxsIHx8IC8vIHRoaXMgbWF0Y2hlcyBudWxsIGFuZCB1bmRlZmluZWQgLT4gZXFlcSBub3QgZXFlcWVxCiAgICAoWydudW1iZXInLCAnYm9vbGVhbicsICdzdHJpbmcnXS5pbmNsdWRlcyh0eXBlb2YgdmFsdWUpICYmICFpc05hTiQxKHZhbHVlKSkKICApIHsKICAgIHJldHVybiB2YWx1ZSA7CiAgfQoKICBjb25zdCBzdHJpbmdpZmllZCA9IHN0cmluZ2lmeVZhbHVlKGtleSwgdmFsdWUpOwoKICAvLyBBbnl0aGluZyB3ZSBjb3VsZCBwb3RlbnRpYWxseSBkaWcgaW50byBtb3JlIChvYmplY3RzIG9yIGFycmF5cykgd2lsbCBoYXZlIGNvbWUgYmFjayBhcyBgIltvYmplY3QgWFhYWF0iYC4KICAvLyBFdmVyeXRoaW5nIGVsc2Ugd2lsbCBoYXZlIGFscmVhZHkgYmVlbiBzZXJpYWxpemVkLCBzbyBpZiB3ZSBkb24ndCBzZWUgdGhhdCBwYXR0ZXJuLCB3ZSdyZSBkb25lLgogIGlmICghc3RyaW5naWZpZWQuc3RhcnRzV2l0aCgnW29iamVjdCAnKSkgewogICAgcmV0dXJuIHN0cmluZ2lmaWVkOwogIH0KCiAgLy8gRnJvbSBoZXJlIG9uLCB3ZSBjYW4gYXNzZXJ0IHRoYXQgYHZhbHVlYCBpcyBlaXRoZXIgYW4gb2JqZWN0IG9yIGFuIGFycmF5LgoKICAvLyBEbyBub3Qgbm9ybWFsaXplIG9iamVjdHMgdGhhdCB3ZSBrbm93IGhhdmUgYWxyZWFkeSBiZWVuIG5vcm1hbGl6ZWQuIEFzIGEgZ2VuZXJhbCBydWxlLCB0aGUKICAvLyAiX19zZW50cnlfc2tpcF9ub3JtYWxpemF0aW9uX18iIHByb3BlcnR5IHNob3VsZCBvbmx5IGJlIHVzZWQgc3BhcmluZ2x5IGFuZCBvbmx5IHNob3VsZCBvbmx5IGJlIHNldCBvbiBvYmplY3RzIHRoYXQKICAvLyBoYXZlIGFscmVhZHkgYmVlbiBub3JtYWxpemVkLgogIGlmICgodmFsdWUgKVsnX19zZW50cnlfc2tpcF9ub3JtYWxpemF0aW9uX18nXSkgewogICAgcmV0dXJuIHZhbHVlIDsKICB9CgogIC8vIFdlIGNhbiBzZXQgYF9fc2VudHJ5X292ZXJyaWRlX25vcm1hbGl6YXRpb25fZGVwdGhfX2Agb24gYW4gb2JqZWN0IHRvIGVuc3VyZSB0aGF0IGZyb20gdGhlcmUKICAvLyBXZSBrZWVwIGEgY2VydGFpbiBhbW91bnQgb2YgZGVwdGguCiAgLy8gVGhpcyBzaG91bGQgYmUgdXNlZCBzcGFyaW5nbHksIGUuZy4gd2UgdXNlIGl0IGZvciB0aGUgcmVkdXggaW50ZWdyYXRpb24gdG8gZW5zdXJlIHdlIGdldCBhIGNlcnRhaW4gYW1vdW50IG9mIHN0YXRlLgogIGNvbnN0IHJlbWFpbmluZ0RlcHRoID0KICAgIHR5cGVvZiAodmFsdWUgKVsnX19zZW50cnlfb3ZlcnJpZGVfbm9ybWFsaXphdGlvbl9kZXB0aF9fJ10gPT09ICdudW1iZXInCiAgICAgID8gKCh2YWx1ZSApWydfX3NlbnRyeV9vdmVycmlkZV9ub3JtYWxpemF0aW9uX2RlcHRoX18nXSApCiAgICAgIDogZGVwdGg7CgogIC8vIFdlJ3JlIGFsc28gZG9uZSBpZiB3ZSd2ZSByZWFjaGVkIHRoZSBtYXggZGVwdGgKICBpZiAocmVtYWluaW5nRGVwdGggPT09IDApIHsKICAgIC8vIEF0IHRoaXMgcG9pbnQgd2Uga25vdyBgc2VyaWFsaXplZGAgaXMgYSBzdHJpbmcgb2YgdGhlIGZvcm0gYCJbb2JqZWN0IFhYWFhdImAuIENsZWFuIGl0IHVwIHNvIGl0J3MganVzdCBgIltYWFhYXSJgLgogICAgcmV0dXJuIHN0cmluZ2lmaWVkLnJlcGxhY2UoJ29iamVjdCAnLCAnJyk7CiAgfQoKICAvLyBJZiB3ZSd2ZSBhbHJlYWR5IHZpc2l0ZWQgdGhpcyBicmFuY2gsIGJhaWwgb3V0LCBhcyBpdCdzIGNpcmN1bGFyIHJlZmVyZW5jZS4gSWYgbm90LCBub3RlIHRoYXQgd2UncmUgc2VlaW5nIGl0IG5vdy4KICBpZiAobWVtb2l6ZSh2YWx1ZSkpIHsKICAgIHJldHVybiAnW0NpcmN1bGFyIH5dJzsKICB9CgogIC8vIElmIHRoZSB2YWx1ZSBoYXMgYSBgdG9KU09OYCBtZXRob2QsIHdlIGNhbGwgaXQgdG8gZXh0cmFjdCBtb3JlIGluZm9ybWF0aW9uCiAgY29uc3QgdmFsdWVXaXRoVG9KU09OID0gdmFsdWUgOwogIGlmICh2YWx1ZVdpdGhUb0pTT04gJiYgdHlwZW9mIHZhbHVlV2l0aFRvSlNPTi50b0pTT04gPT09ICdmdW5jdGlvbicpIHsKICAgIHRyeSB7CiAgICAgIGNvbnN0IGpzb25WYWx1ZSA9IHZhbHVlV2l0aFRvSlNPTi50b0pTT04oKTsKICAgICAgLy8gV2UgbmVlZCB0byBub3JtYWxpemUgdGhlIHJldHVybiB2YWx1ZSBvZiBgLnRvSlNPTigpYCBpbiBjYXNlIGl0IGhhcyBjaXJjdWxhciByZWZlcmVuY2VzCiAgICAgIHJldHVybiB2aXNpdCgnJywganNvblZhbHVlLCByZW1haW5pbmdEZXB0aCAtIDEsIG1heFByb3BlcnRpZXMsIG1lbW8pOwogICAgfSBjYXRjaCAoZXJyKSB7CiAgICAgIC8vIHBhc3MgKFRoZSBidWlsdC1pbiBgdG9KU09OYCBmYWlsZWQsIGJ1dCB3ZSBjYW4gc3RpbGwgdHJ5IHRvIGRvIGl0IG91cnNlbHZlcykKICAgIH0KICB9CgogIC8vIEF0IHRoaXMgcG9pbnQgd2Uga25vdyB3ZSBlaXRoZXIgaGF2ZSBhbiBvYmplY3Qgb3IgYW4gYXJyYXksIHdlIGhhdmVuJ3Qgc2VlbiBpdCBiZWZvcmUsIGFuZCB3ZSdyZSBnb2luZyB0byByZWN1cnNlCiAgLy8gYmVjYXVzZSB3ZSBoYXZlbid0IHlldCByZWFjaGVkIHRoZSBtYXggZGVwdGguIENyZWF0ZSBhbiBhY2N1bXVsYXRvciB0byBob2xkIHRoZSByZXN1bHRzIG9mIHZpc2l0aW5nIGVhY2gKICAvLyBwcm9wZXJ0eS9lbnRyeSwgYW5kIGtlZXAgdHJhY2sgb2YgdGhlIG51bWJlciBvZiBpdGVtcyB3ZSBhZGQgdG8gaXQuCiAgY29uc3Qgbm9ybWFsaXplZCA9IChBcnJheS5pc0FycmF5KHZhbHVlKSA/IFtdIDoge30pIDsKICBsZXQgbnVtQWRkZWQgPSAwOwoKICAvLyBCZWZvcmUgd2UgYmVnaW4sIGNvbnZlcnRgRXJyb3JgIGFuZGBFdmVudGAgaW5zdGFuY2VzIGludG8gcGxhaW4gb2JqZWN0cywgc2luY2Ugc29tZSBvZiBlYWNoIG9mIHRoZWlyIHJlbGV2YW50CiAgLy8gcHJvcGVydGllcyBhcmUgbm9uLWVudW1lcmFibGUgYW5kIG90aGVyd2lzZSB3b3VsZCBnZXQgbWlzc2VkLgogIGNvbnN0IHZpc2l0YWJsZSA9IGNvbnZlcnRUb1BsYWluT2JqZWN0KHZhbHVlICk7CgogIGZvciAoY29uc3QgdmlzaXRLZXkgaW4gdmlzaXRhYmxlKSB7CiAgICAvLyBBdm9pZCBpdGVyYXRpbmcgb3ZlciBmaWVsZHMgaW4gdGhlIHByb3RvdHlwZSBpZiB0aGV5J3ZlIHNvbWVob3cgYmVlbiBleHBvc2VkIHRvIGVudW1lcmF0aW9uLgogICAgaWYgKCFPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwodmlzaXRhYmxlLCB2aXNpdEtleSkpIHsKICAgICAgY29udGludWU7CiAgICB9CgogICAgaWYgKG51bUFkZGVkID49IG1heFByb3BlcnRpZXMpIHsKICAgICAgbm9ybWFsaXplZFt2aXNpdEtleV0gPSAnW01heFByb3BlcnRpZXMgfl0nOwogICAgICBicmVhazsKICAgIH0KCiAgICAvLyBSZWN1cnNpdmVseSB2aXNpdCBhbGwgdGhlIGNoaWxkIG5vZGVzCiAgICBjb25zdCB2aXNpdFZhbHVlID0gdmlzaXRhYmxlW3Zpc2l0S2V5XTsKICAgIG5vcm1hbGl6ZWRbdmlzaXRLZXldID0gdmlzaXQodmlzaXRLZXksIHZpc2l0VmFsdWUsIHJlbWFpbmluZ0RlcHRoIC0gMSwgbWF4UHJvcGVydGllcywgbWVtbyk7CgogICAgbnVtQWRkZWQrKzsKICB9CgogIC8vIE9uY2Ugd2UndmUgdmlzaXRlZCBhbGwgdGhlIGJyYW5jaGVzLCByZW1vdmUgdGhlIHBhcmVudCBmcm9tIG1lbW8gc3RvcmFnZQogIHVubWVtb2l6ZSh2YWx1ZSk7CgogIC8vIFJldHVybiBhY2N1bXVsYXRlZCB2YWx1ZXMKICByZXR1cm4gbm9ybWFsaXplZDsKfQoKLyogZXNsaW50LWRpc2FibGUgY29tcGxleGl0eSAqLwovKioKICogU3RyaW5naWZ5IHRoZSBnaXZlbiB2YWx1ZS4gSGFuZGxlcyB2YXJpb3VzIGtub3duIHNwZWNpYWwgdmFsdWVzIGFuZCB0eXBlcy4KICoKICogTm90IG1lYW50IHRvIGJlIHVzZWQgb24gc2ltcGxlIHByaW1pdGl2ZXMgd2hpY2ggYWxyZWFkeSBoYXZlIGEgc3RyaW5nIHJlcHJlc2VudGF0aW9uLCBhcyBpdCB3aWxsLCBmb3IgZXhhbXBsZSwgdHVybgogKiB0aGUgbnVtYmVyIDEyMzEgaW50byAiW09iamVjdCBOdW1iZXJdIiwgbm9yIG9uIGBudWxsYCwgYXMgaXQgd2lsbCB0aHJvdy4KICoKICogQHBhcmFtIHZhbHVlIFRoZSB2YWx1ZSB0byBzdHJpbmdpZnkKICogQHJldHVybnMgQSBzdHJpbmdpZmllZCByZXByZXNlbnRhdGlvbiBvZiB0aGUgZ2l2ZW4gdmFsdWUKICovCmZ1bmN0aW9uIHN0cmluZ2lmeVZhbHVlKAogIGtleSwKICAvLyB0aGlzIHR5cGUgaXMgYSB0aW55IGJpdCBvZiBhIGNoZWF0LCBzaW5jZSB0aGlzIGZ1bmN0aW9uIGRvZXMgaGFuZGxlIE5hTiAod2hpY2ggaXMgdGVjaG5pY2FsbHkgYSBudW1iZXIpLCBidXQgZm9yCiAgLy8gb3VyIGludGVybmFsIHVzZSwgaXQnbGwgZG8KICB2YWx1ZSwKKSB7CiAgdHJ5IHsKICAgIGlmIChrZXkgPT09ICdkb21haW4nICYmIHZhbHVlICYmIHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcgJiYgKHZhbHVlICkuX2V2ZW50cykgewogICAgICByZXR1cm4gJ1tEb21haW5dJzsKICAgIH0KCiAgICBpZiAoa2V5ID09PSAnZG9tYWluRW1pdHRlcicpIHsKICAgICAgcmV0dXJuICdbRG9tYWluRW1pdHRlcl0nOwogICAgfQoKICAgIC8vIEl0J3Mgc2FmZSB0byB1c2UgYGdsb2JhbGAsIGB3aW5kb3dgLCBhbmQgYGRvY3VtZW50YCBoZXJlIGluIHRoaXMgbWFubmVyLCBhcyB3ZSBhcmUgYXNzZXJ0aW5nIHVzaW5nIGB0eXBlb2ZgIGZpcnN0CiAgICAvLyB3aGljaCB3b24ndCB0aHJvdyBpZiB0aGV5IGFyZSBub3QgcHJlc2VudC4KCiAgICBpZiAodHlwZW9mIGdsb2JhbCAhPT0gJ3VuZGVmaW5lZCcgJiYgdmFsdWUgPT09IGdsb2JhbCkgewogICAgICByZXR1cm4gJ1tHbG9iYWxdJzsKICAgIH0KCiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tcmVzdHJpY3RlZC1nbG9iYWxzCiAgICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgJiYgdmFsdWUgPT09IHdpbmRvdykgewogICAgICByZXR1cm4gJ1tXaW5kb3ddJzsKICAgIH0KCiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tcmVzdHJpY3RlZC1nbG9iYWxzCiAgICBpZiAodHlwZW9mIGRvY3VtZW50ICE9PSAndW5kZWZpbmVkJyAmJiB2YWx1ZSA9PT0gZG9jdW1lbnQpIHsKICAgICAgcmV0dXJuICdbRG9jdW1lbnRdJzsKICAgIH0KCiAgICBpZiAoaXNWdWVWaWV3TW9kZWwodmFsdWUpKSB7CiAgICAgIHJldHVybiAnW1Z1ZVZpZXdNb2RlbF0nOwogICAgfQoKICAgIC8vIFJlYWN0J3MgU3ludGhldGljRXZlbnQgdGhpbmd5CiAgICBpZiAoaXNTeW50aGV0aWNFdmVudCh2YWx1ZSkpIHsKICAgICAgcmV0dXJuICdbU3ludGhldGljRXZlbnRdJzsKICAgIH0KCiAgICBpZiAodHlwZW9mIHZhbHVlID09PSAnbnVtYmVyJyAmJiB2YWx1ZSAhPT0gdmFsdWUpIHsKICAgICAgcmV0dXJuICdbTmFOXSc7CiAgICB9CgogICAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ2Z1bmN0aW9uJykgewogICAgICByZXR1cm4gYFtGdW5jdGlvbjogJHtnZXRGdW5jdGlvbk5hbWUodmFsdWUpfV1gOwogICAgfQoKICAgIGlmICh0eXBlb2YgdmFsdWUgPT09ICdzeW1ib2wnKSB7CiAgICAgIHJldHVybiBgWyR7U3RyaW5nKHZhbHVlKX1dYDsKICAgIH0KCiAgICAvLyBzdHJpbmdpZmllZCBCaWdJbnRzIGFyZSBpbmRpc3Rpbmd1aXNoYWJsZSBmcm9tIHJlZ3VsYXIgbnVtYmVycywgc28gd2UgbmVlZCB0byBsYWJlbCB0aGVtIHRvIGF2b2lkIGNvbmZ1c2lvbgogICAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ2JpZ2ludCcpIHsKICAgICAgcmV0dXJuIGBbQmlnSW50OiAke1N0cmluZyh2YWx1ZSl9XWA7CiAgICB9CgogICAgLy8gTm93IHRoYXQgd2UndmUga25vY2tlZCBvdXQgYWxsIHRoZSBzcGVjaWFsIGNhc2VzIGFuZCB0aGUgcHJpbWl0aXZlcywgYWxsIHdlIGhhdmUgbGVmdCBhcmUgb2JqZWN0cy4gU2ltcGx5IGNhc3RpbmcKICAgIC8vIHRoZW0gdG8gc3RyaW5ncyBtZWFucyB0aGF0IGluc3RhbmNlcyBvZiBjbGFzc2VzIHdoaWNoIGhhdmVuJ3QgZGVmaW5lZCB0aGVpciBgdG9TdHJpbmdUYWdgIHdpbGwganVzdCBjb21lIG91dCBhcwogICAgLy8gYCJbb2JqZWN0IE9iamVjdF0iYC4gSWYgd2UgaW5zdGVhZCBsb29rIGF0IHRoZSBjb25zdHJ1Y3RvcidzIG5hbWUgKHdoaWNoIGlzIHRoZSBzYW1lIGFzIHRoZSBuYW1lIG9mIHRoZSBjbGFzcyksCiAgICAvLyB3ZSBjYW4gbWFrZSBzdXJlIHRoYXQgb25seSBwbGFpbiBvYmplY3RzIGNvbWUgb3V0IHRoYXQgd2F5LgogICAgY29uc3Qgb2JqTmFtZSA9IGdldENvbnN0cnVjdG9yTmFtZSh2YWx1ZSk7CgogICAgLy8gSGFuZGxlIEhUTUwgRWxlbWVudHMKICAgIGlmICgvXkhUTUwoXHcqKUVsZW1lbnQkLy50ZXN0KG9iak5hbWUpKSB7CiAgICAgIHJldHVybiBgW0hUTUxFbGVtZW50OiAke29iak5hbWV9XWA7CiAgICB9CgogICAgcmV0dXJuIGBbb2JqZWN0ICR7b2JqTmFtZX1dYDsKICB9IGNhdGNoIChlcnIpIHsKICAgIHJldHVybiBgKipub24tc2VyaWFsaXphYmxlKiogKCR7ZXJyfSlgOwogIH0KfQovKiBlc2xpbnQtZW5hYmxlIGNvbXBsZXhpdHkgKi8KCmZ1bmN0aW9uIGdldENvbnN0cnVjdG9yTmFtZSh2YWx1ZSkgewogIGNvbnN0IHByb3RvdHlwZSA9IE9iamVjdC5nZXRQcm90b3R5cGVPZih2YWx1ZSk7CgogIHJldHVybiBwcm90b3R5cGUgPyBwcm90b3R5cGUuY29uc3RydWN0b3IubmFtZSA6ICdudWxsIHByb3RvdHlwZSc7Cn0KCi8qKgogKiBOb3JtYWxpemVzIFVSTHMgaW4gZXhjZXB0aW9ucyBhbmQgc3RhY2t0cmFjZXMgdG8gYSBiYXNlIHBhdGggc28gU2VudHJ5IGNhbiBmaW5nZXJwcmludAogKiBhY3Jvc3MgcGxhdGZvcm1zIGFuZCB3b3JraW5nIGRpcmVjdG9yeS4KICoKICogQHBhcmFtIHVybCBUaGUgVVJMIHRvIGJlIG5vcm1hbGl6ZWQuCiAqIEBwYXJhbSBiYXNlUGF0aCBUaGUgYXBwbGljYXRpb24gYmFzZSBwYXRoLgogKiBAcmV0dXJucyBUaGUgbm9ybWFsaXplZCBVUkwuCiAqLwpmdW5jdGlvbiBub3JtYWxpemVVcmxUb0Jhc2UodXJsLCBiYXNlUGF0aCkgewogIGNvbnN0IGVzY2FwZWRCYXNlID0gYmFzZVBhdGgKICAgIC8vIEJhY2tzbGFzaCB0byBmb3J3YXJkCiAgICAucmVwbGFjZSgvXFwvZywgJy8nKQogICAgLy8gRXNjYXBlIFJlZ0V4cCBzcGVjaWFsIGNoYXJhY3RlcnMKICAgIC5yZXBsYWNlKC9bfFxce30oKVtcXV4kKyo/Ll0vZywgJ1xcJCYnKTsKCiAgbGV0IG5ld1VybCA9IHVybDsKICB0cnkgewogICAgbmV3VXJsID0gZGVjb2RlVVJJKHVybCk7CiAgfSBjYXRjaCAoX09vKSB7CiAgICAvLyBTb21ldGltZSB0aGlzIGJyZWFrcwogIH0KICByZXR1cm4gKAogICAgbmV3VXJsCiAgICAgIC5yZXBsYWNlKC9cXC9nLCAnLycpCiAgICAgIC5yZXBsYWNlKC93ZWJwYWNrOlwvPy9nLCAnJykgLy8gUmVtb3ZlIGludGVybWVkaWF0ZSBiYXNlIHBhdGgKICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEBzZW50cnktaW50ZXJuYWwvc2RrL25vLXJlZ2V4cC1jb25zdHJ1Y3RvcgogICAgICAucmVwbGFjZShuZXcgUmVnRXhwKGAoZmlsZTovLyk/Lyoke2VzY2FwZWRCYXNlfS8qYCwgJ2lnJyksICdhcHA6Ly8vJykKICApOwp9CgovLyBTbGlnaHRseSBtb2RpZmllZCAobm8gSUU4IHN1cHBvcnQsIEVTNikgYW5kIHRyYW5zY3JpYmVkIHRvIFR5cGVTY3JpcHQKCi8vIFNwbGl0IGEgZmlsZW5hbWUgaW50byBbcm9vdCwgZGlyLCBiYXNlbmFtZSwgZXh0XSwgdW5peCB2ZXJzaW9uCi8vICdyb290JyBpcyBqdXN0IGEgc2xhc2gsIG9yIG5vdGhpbmcuCmNvbnN0IHNwbGl0UGF0aFJlID0gL14oXFMrOlxcfFwvPykoW1xzXFNdKj8pKCg/OlwuezEsMn18W14vXFxdKz98KShcLlteLi9cXF0qfCkpKD86Wy9cXF0qKSQvOwovKiogSlNEb2MgKi8KZnVuY3Rpb24gc3BsaXRQYXRoKGZpbGVuYW1lKSB7CiAgLy8gVHJ1bmNhdGUgZmlsZXMgbmFtZXMgZ3JlYXRlciB0aGFuIDEwMjQgY2hhcmFjdGVycyB0byBhdm9pZCByZWdleCBkb3MKICAvLyBodHRwczovL2dpdGh1Yi5jb20vZ2V0c2VudHJ5L3NlbnRyeS1qYXZhc2NyaXB0L3B1bGwvODczNyNkaXNjdXNzaW9uX3IxMjg1NzE5MTcyCiAgY29uc3QgdHJ1bmNhdGVkID0gZmlsZW5hbWUubGVuZ3RoID4gMTAyNCA/IGA8dHJ1bmNhdGVkPiR7ZmlsZW5hbWUuc2xpY2UoLTEwMjQpfWAgOiBmaWxlbmFtZTsKICBjb25zdCBwYXJ0cyA9IHNwbGl0UGF0aFJlLmV4ZWModHJ1bmNhdGVkKTsKICByZXR1cm4gcGFydHMgPyBwYXJ0cy5zbGljZSgxKSA6IFtdOwp9CgovKiogSlNEb2MgKi8KZnVuY3Rpb24gZGlybmFtZShwYXRoKSB7CiAgY29uc3QgcmVzdWx0ID0gc3BsaXRQYXRoKHBhdGgpOwogIGNvbnN0IHJvb3QgPSByZXN1bHRbMF07CiAgbGV0IGRpciA9IHJlc3VsdFsxXTsKCiAgaWYgKCFyb290ICYmICFkaXIpIHsKICAgIC8vIE5vIGRpcm5hbWUgd2hhdHNvZXZlcgogICAgcmV0dXJuICcuJzsKICB9CgogIGlmIChkaXIpIHsKICAgIC8vIEl0IGhhcyBhIGRpcm5hbWUsIHN0cmlwIHRyYWlsaW5nIHNsYXNoCiAgICBkaXIgPSBkaXIuc2xpY2UoMCwgZGlyLmxlbmd0aCAtIDEpOwogIH0KCiAgcmV0dXJuIHJvb3QgKyBkaXI7Cn0KCi8qIGVzbGludC1kaXNhYmxlIEB0eXBlc2NyaXB0LWVzbGludC9leHBsaWNpdC1mdW5jdGlvbi1yZXR1cm4tdHlwZSAqLwoKLyoqIFN5bmNQcm9taXNlIGludGVybmFsIHN0YXRlcyAqLwp2YXIgU3RhdGVzOyAoZnVuY3Rpb24gKFN0YXRlcykgewogIC8qKiBQZW5kaW5nICovCiAgY29uc3QgUEVORElORyA9IDA7IFN0YXRlc1tTdGF0ZXNbIlBFTkRJTkciXSA9IFBFTkRJTkddID0gIlBFTkRJTkciOwogIC8qKiBSZXNvbHZlZCAvIE9LICovCiAgY29uc3QgUkVTT0xWRUQgPSAxOyBTdGF0ZXNbU3RhdGVzWyJSRVNPTFZFRCJdID0gUkVTT0xWRURdID0gIlJFU09MVkVEIjsKICAvKiogUmVqZWN0ZWQgLyBFcnJvciAqLwogIGNvbnN0IFJFSkVDVEVEID0gMjsgU3RhdGVzW1N0YXRlc1siUkVKRUNURUQiXSA9IFJFSkVDVEVEXSA9ICJSRUpFQ1RFRCI7Cn0pKFN0YXRlcyB8fCAoU3RhdGVzID0ge30pKTsKCi8vIE92ZXJsb2FkcyBzbyB3ZSBjYW4gY2FsbCByZXNvbHZlZFN5bmNQcm9taXNlIHdpdGhvdXQgYXJndW1lbnRzIGFuZCBnZW5lcmljIGFyZ3VtZW50CgovKioKICogQ3JlYXRlcyBhIHJlc29sdmVkIHN5bmMgcHJvbWlzZS4KICoKICogQHBhcmFtIHZhbHVlIHRoZSB2YWx1ZSB0byByZXNvbHZlIHRoZSBwcm9taXNlIHdpdGgKICogQHJldHVybnMgdGhlIHJlc29sdmVkIHN5bmMgcHJvbWlzZQogKi8KZnVuY3Rpb24gcmVzb2x2ZWRTeW5jUHJvbWlzZSh2YWx1ZSkgewogIHJldHVybiBuZXcgU3luY1Byb21pc2UocmVzb2x2ZSA9PiB7CiAgICByZXNvbHZlKHZhbHVlKTsKICB9KTsKfQoKLyoqCiAqIENyZWF0ZXMgYSByZWplY3RlZCBzeW5jIHByb21pc2UuCiAqCiAqIEBwYXJhbSB2YWx1ZSB0aGUgdmFsdWUgdG8gcmVqZWN0IHRoZSBwcm9taXNlIHdpdGgKICogQHJldHVybnMgdGhlIHJlamVjdGVkIHN5bmMgcHJvbWlzZQogKi8KZnVuY3Rpb24gcmVqZWN0ZWRTeW5jUHJvbWlzZShyZWFzb24pIHsKICByZXR1cm4gbmV3IFN5bmNQcm9taXNlKChfLCByZWplY3QpID0+IHsKICAgIHJlamVjdChyZWFzb24pOwogIH0pOwp9CgovKioKICogVGhlbmFibGUgY2xhc3MgdGhhdCBiZWhhdmVzIGxpa2UgYSBQcm9taXNlIGFuZCBmb2xsb3dzIGl0J3MgaW50ZXJmYWNlCiAqIGJ1dCBpcyBub3QgYXN5bmMgaW50ZXJuYWxseQogKi8KY2xhc3MgU3luY1Byb21pc2UgewoKICAgY29uc3RydWN0b3IoCiAgICBleGVjdXRvciwKICApIHtTeW5jUHJvbWlzZS5wcm90b3R5cGUuX19pbml0LmNhbGwodGhpcyk7U3luY1Byb21pc2UucHJvdG90eXBlLl9faW5pdDIuY2FsbCh0aGlzKTtTeW5jUHJvbWlzZS5wcm90b3R5cGUuX19pbml0My5jYWxsKHRoaXMpO1N5bmNQcm9taXNlLnByb3RvdHlwZS5fX2luaXQ0LmNhbGwodGhpcyk7CiAgICB0aGlzLl9zdGF0ZSA9IFN0YXRlcy5QRU5ESU5HOwogICAgdGhpcy5faGFuZGxlcnMgPSBbXTsKCiAgICB0cnkgewogICAgICBleGVjdXRvcih0aGlzLl9yZXNvbHZlLCB0aGlzLl9yZWplY3QpOwogICAgfSBjYXRjaCAoZSkgewogICAgICB0aGlzLl9yZWplY3QoZSk7CiAgICB9CiAgfQoKICAvKiogSlNEb2MgKi8KICAgdGhlbigKICAgIG9uZnVsZmlsbGVkLAogICAgb25yZWplY3RlZCwKICApIHsKICAgIHJldHVybiBuZXcgU3luY1Byb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4gewogICAgICB0aGlzLl9oYW5kbGVycy5wdXNoKFsKICAgICAgICBmYWxzZSwKICAgICAgICByZXN1bHQgPT4gewogICAgICAgICAgaWYgKCFvbmZ1bGZpbGxlZCkgewogICAgICAgICAgICAvLyBUT0RPOiDCr1xfKOODhClfL8KvCiAgICAgICAgICAgIC8vIFRPRE86IEZJWE1FCiAgICAgICAgICAgIHJlc29sdmUocmVzdWx0ICk7CiAgICAgICAgICB9IGVsc2UgewogICAgICAgICAgICB0cnkgewogICAgICAgICAgICAgIHJlc29sdmUob25mdWxmaWxsZWQocmVzdWx0KSk7CiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHsKICAgICAgICAgICAgICByZWplY3QoZSk7CiAgICAgICAgICAgIH0KICAgICAgICAgIH0KICAgICAgICB9LAogICAgICAgIHJlYXNvbiA9PiB7CiAgICAgICAgICBpZiAoIW9ucmVqZWN0ZWQpIHsKICAgICAgICAgICAgcmVqZWN0KHJlYXNvbik7CiAgICAgICAgICB9IGVsc2UgewogICAgICAgICAgICB0cnkgewogICAgICAgICAgICAgIHJlc29sdmUob25yZWplY3RlZChyZWFzb24pKTsKICAgICAgICAgICAgfSBjYXRjaCAoZSkgewogICAgICAgICAgICAgIHJlamVjdChlKTsKICAgICAgICAgICAgfQogICAgICAgICAgfQogICAgICAgIH0sCiAgICAgIF0pOwogICAgICB0aGlzLl9leGVjdXRlSGFuZGxlcnMoKTsKICAgIH0pOwogIH0KCiAgLyoqIEpTRG9jICovCiAgIGNhdGNoKAogICAgb25yZWplY3RlZCwKICApIHsKICAgIHJldHVybiB0aGlzLnRoZW4odmFsID0+IHZhbCwgb25yZWplY3RlZCk7CiAgfQoKICAvKiogSlNEb2MgKi8KICAgZmluYWxseShvbmZpbmFsbHkpIHsKICAgIHJldHVybiBuZXcgU3luY1Byb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4gewogICAgICBsZXQgdmFsOwogICAgICBsZXQgaXNSZWplY3RlZDsKCiAgICAgIHJldHVybiB0aGlzLnRoZW4oCiAgICAgICAgdmFsdWUgPT4gewogICAgICAgICAgaXNSZWplY3RlZCA9IGZhbHNlOwogICAgICAgICAgdmFsID0gdmFsdWU7CiAgICAgICAgICBpZiAob25maW5hbGx5KSB7CiAgICAgICAgICAgIG9uZmluYWxseSgpOwogICAgICAgICAgfQogICAgICAgIH0sCiAgICAgICAgcmVhc29uID0+IHsKICAgICAgICAgIGlzUmVqZWN0ZWQgPSB0cnVlOwogICAgICAgICAgdmFsID0gcmVhc29uOwogICAgICAgICAgaWYgKG9uZmluYWxseSkgewogICAgICAgICAgICBvbmZpbmFsbHkoKTsKICAgICAgICAgIH0KICAgICAgICB9LAogICAgICApLnRoZW4oKCkgPT4gewogICAgICAgIGlmIChpc1JlamVjdGVkKSB7CiAgICAgICAgICByZWplY3QodmFsKTsKICAgICAgICAgIHJldHVybjsKICAgICAgICB9CgogICAgICAgIHJlc29sdmUodmFsICk7CiAgICAgIH0pOwogICAgfSk7CiAgfQoKICAvKiogSlNEb2MgKi8KICAgIF9faW5pdCgpIHt0aGlzLl9yZXNvbHZlID0gKHZhbHVlKSA9PiB7CiAgICB0aGlzLl9zZXRSZXN1bHQoU3RhdGVzLlJFU09MVkVELCB2YWx1ZSk7CiAgfTt9CgogIC8qKiBKU0RvYyAqLwogICAgX19pbml0MigpIHt0aGlzLl9yZWplY3QgPSAocmVhc29uKSA9PiB7CiAgICB0aGlzLl9zZXRSZXN1bHQoU3RhdGVzLlJFSkVDVEVELCByZWFzb24pOwogIH07fQoKICAvKiogSlNEb2MgKi8KICAgIF9faW5pdDMoKSB7dGhpcy5fc2V0UmVzdWx0ID0gKHN0YXRlLCB2YWx1ZSkgPT4gewogICAgaWYgKHRoaXMuX3N0YXRlICE9PSBTdGF0ZXMuUEVORElORykgewogICAgICByZXR1cm47CiAgICB9CgogICAgaWYgKGlzVGhlbmFibGUodmFsdWUpKSB7CiAgICAgIHZvaWQgKHZhbHVlICkudGhlbih0aGlzLl9yZXNvbHZlLCB0aGlzLl9yZWplY3QpOwogICAgICByZXR1cm47CiAgICB9CgogICAgdGhpcy5fc3RhdGUgPSBzdGF0ZTsKICAgIHRoaXMuX3ZhbHVlID0gdmFsdWU7CgogICAgdGhpcy5fZXhlY3V0ZUhhbmRsZXJzKCk7CiAgfTt9CgogIC8qKiBKU0RvYyAqLwogICAgX19pbml0NCgpIHt0aGlzLl9leGVjdXRlSGFuZGxlcnMgPSAoKSA9PiB7CiAgICBpZiAodGhpcy5fc3RhdGUgPT09IFN0YXRlcy5QRU5ESU5HKSB7CiAgICAgIHJldHVybjsKICAgIH0KCiAgICBjb25zdCBjYWNoZWRIYW5kbGVycyA9IHRoaXMuX2hhbmRsZXJzLnNsaWNlKCk7CiAgICB0aGlzLl9oYW5kbGVycyA9IFtdOwoKICAgIGNhY2hlZEhhbmRsZXJzLmZvckVhY2goaGFuZGxlciA9PiB7CiAgICAgIGlmIChoYW5kbGVyWzBdKSB7CiAgICAgICAgcmV0dXJuOwogICAgICB9CgogICAgICBpZiAodGhpcy5fc3RhdGUgPT09IFN0YXRlcy5SRVNPTFZFRCkgewogICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZmxvYXRpbmctcHJvbWlzZXMKICAgICAgICBoYW5kbGVyWzFdKHRoaXMuX3ZhbHVlICk7CiAgICAgIH0KCiAgICAgIGlmICh0aGlzLl9zdGF0ZSA9PT0gU3RhdGVzLlJFSkVDVEVEKSB7CiAgICAgICAgaGFuZGxlclsyXSh0aGlzLl92YWx1ZSk7CiAgICAgIH0KCiAgICAgIGhhbmRsZXJbMF0gPSB0cnVlOwogICAgfSk7CiAgfTt9Cn0KCi8qKgogKiBDcmVhdGVzIGFuIG5ldyBQcm9taXNlQnVmZmVyIG9iamVjdCB3aXRoIHRoZSBzcGVjaWZpZWQgbGltaXQKICogQHBhcmFtIGxpbWl0IG1heCBudW1iZXIgb2YgcHJvbWlzZXMgdGhhdCBjYW4gYmUgc3RvcmVkIGluIHRoZSBidWZmZXIKICovCmZ1bmN0aW9uIG1ha2VQcm9taXNlQnVmZmVyKGxpbWl0KSB7CiAgY29uc3QgYnVmZmVyID0gW107CgogIGZ1bmN0aW9uIGlzUmVhZHkoKSB7CiAgICByZXR1cm4gbGltaXQgPT09IHVuZGVmaW5lZCB8fCBidWZmZXIubGVuZ3RoIDwgbGltaXQ7CiAgfQoKICAvKioKICAgKiBSZW1vdmUgYSBwcm9taXNlIGZyb20gdGhlIHF1ZXVlLgogICAqCiAgICogQHBhcmFtIHRhc2sgQ2FuIGJlIGFueSBQcm9taXNlTGlrZTxUPgogICAqIEByZXR1cm5zIFJlbW92ZWQgcHJvbWlzZS4KICAgKi8KICBmdW5jdGlvbiByZW1vdmUodGFzaykgewogICAgcmV0dXJuIGJ1ZmZlci5zcGxpY2UoYnVmZmVyLmluZGV4T2YodGFzayksIDEpWzBdOwogIH0KCiAgLyoqCiAgICogQWRkIGEgcHJvbWlzZSAocmVwcmVzZW50aW5nIGFuIGluLWZsaWdodCBhY3Rpb24pIHRvIHRoZSBxdWV1ZSwgYW5kIHNldCBpdCB0byByZW1vdmUgaXRzZWxmIG9uIGZ1bGZpbGxtZW50LgogICAqCiAgICogQHBhcmFtIHRhc2tQcm9kdWNlciBBIGZ1bmN0aW9uIHByb2R1Y2luZyBhbnkgUHJvbWlzZUxpa2U8VD47IEluIHByZXZpb3VzIHZlcnNpb25zIHRoaXMgdXNlZCB0byBiZSBgdGFzazoKICAgKiAgICAgICAgUHJvbWlzZUxpa2U8VD5gLCBidXQgdW5kZXIgdGhhdCBtb2RlbCwgUHJvbWlzZXMgd2VyZSBpbnN0YW50bHkgY3JlYXRlZCBvbiB0aGUgY2FsbC1zaXRlIGFuZCB0aGVpciBleGVjdXRvcgogICAqICAgICAgICBmdW5jdGlvbnMgdGhlcmVmb3JlIHJhbiBpbW1lZGlhdGVseS4gVGh1cywgZXZlbiBpZiB0aGUgYnVmZmVyIHdhcyBmdWxsLCB0aGUgYWN0aW9uIHN0aWxsIGhhcHBlbmVkLiBCeQogICAqICAgICAgICByZXF1aXJpbmcgdGhlIHByb21pc2UgdG8gYmUgd3JhcHBlZCBpbiBhIGZ1bmN0aW9uLCB3ZSBjYW4gZGVmZXIgcHJvbWlzZSBjcmVhdGlvbiB1bnRpbCBhZnRlciB0aGUgYnVmZmVyCiAgICogICAgICAgIGxpbWl0IGNoZWNrLgogICAqIEByZXR1cm5zIFRoZSBvcmlnaW5hbCBwcm9taXNlLgogICAqLwogIGZ1bmN0aW9uIGFkZCh0YXNrUHJvZHVjZXIpIHsKICAgIGlmICghaXNSZWFkeSgpKSB7CiAgICAgIHJldHVybiByZWplY3RlZFN5bmNQcm9taXNlKG5ldyBTZW50cnlFcnJvcignTm90IGFkZGluZyBQcm9taXNlIGJlY2F1c2UgYnVmZmVyIGxpbWl0IHdhcyByZWFjaGVkLicpKTsKICAgIH0KCiAgICAvLyBzdGFydCB0aGUgdGFzayBhbmQgYWRkIGl0cyBwcm9taXNlIHRvIHRoZSBxdWV1ZQogICAgY29uc3QgdGFzayA9IHRhc2tQcm9kdWNlcigpOwogICAgaWYgKGJ1ZmZlci5pbmRleE9mKHRhc2spID09PSAtMSkgewogICAgICBidWZmZXIucHVzaCh0YXNrKTsKICAgIH0KICAgIHZvaWQgdGFzawogICAgICAudGhlbigoKSA9PiByZW1vdmUodGFzaykpCiAgICAgIC8vIFVzZSBgdGhlbihudWxsLCByZWplY3Rpb25IYW5kbGVyKWAgcmF0aGVyIHRoYW4gYGNhdGNoKHJlamVjdGlvbkhhbmRsZXIpYCBzbyB0aGF0IHdlIGNhbiB1c2UgYFByb21pc2VMaWtlYAogICAgICAvLyByYXRoZXIgdGhhbiBgUHJvbWlzZWAuIGBQcm9taXNlTGlrZWAgZG9lc24ndCBoYXZlIGEgYC5jYXRjaGAgbWV0aG9kLCBtYWtpbmcgaXRzIHBvbHlmaWxsIHNtYWxsZXIuIChFUzUgZGlkbid0CiAgICAgIC8vIGhhdmUgcHJvbWlzZXMsIHNvIFRTIGhhcyB0byBwb2x5ZmlsbCB3aGVuIGRvd24tY29tcGlsaW5nLikKICAgICAgLnRoZW4obnVsbCwgKCkgPT4KICAgICAgICByZW1vdmUodGFzaykudGhlbihudWxsLCAoKSA9PiB7CiAgICAgICAgICAvLyBXZSBoYXZlIHRvIGFkZCBhbm90aGVyIGNhdGNoIGhlcmUgYmVjYXVzZSBgcmVtb3ZlKClgIHN0YXJ0cyBhIG5ldyBwcm9taXNlIGNoYWluLgogICAgICAgIH0pLAogICAgICApOwogICAgcmV0dXJuIHRhc2s7CiAgfQoKICAvKioKICAgKiBXYWl0IGZvciBhbGwgcHJvbWlzZXMgaW4gdGhlIHF1ZXVlIHRvIHJlc29sdmUgb3IgZm9yIHRpbWVvdXQgdG8gZXhwaXJlLCB3aGljaGV2ZXIgY29tZXMgZmlyc3QuCiAgICoKICAgKiBAcGFyYW0gdGltZW91dCBUaGUgdGltZSwgaW4gbXMsIGFmdGVyIHdoaWNoIHRvIHJlc29sdmUgdG8gYGZhbHNlYCBpZiB0aGUgcXVldWUgaXMgc3RpbGwgbm9uLWVtcHR5LiBQYXNzaW5nIGAwYCAob3IKICAgKiBub3QgcGFzc2luZyBhbnl0aGluZykgd2lsbCBtYWtlIHRoZSBwcm9taXNlIHdhaXQgYXMgbG9uZyBhcyBpdCB0YWtlcyBmb3IgdGhlIHF1ZXVlIHRvIGRyYWluIGJlZm9yZSByZXNvbHZpbmcgdG8KICAgKiBgdHJ1ZWAuCiAgICogQHJldHVybnMgQSBwcm9taXNlIHdoaWNoIHdpbGwgcmVzb2x2ZSB0byBgdHJ1ZWAgaWYgdGhlIHF1ZXVlIGlzIGFscmVhZHkgZW1wdHkgb3IgZHJhaW5zIGJlZm9yZSB0aGUgdGltZW91dCwgYW5kCiAgICogYGZhbHNlYCBvdGhlcndpc2UKICAgKi8KICBmdW5jdGlvbiBkcmFpbih0aW1lb3V0KSB7CiAgICByZXR1cm4gbmV3IFN5bmNQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHsKICAgICAgbGV0IGNvdW50ZXIgPSBidWZmZXIubGVuZ3RoOwoKICAgICAgaWYgKCFjb3VudGVyKSB7CiAgICAgICAgcmV0dXJuIHJlc29sdmUodHJ1ZSk7CiAgICAgIH0KCiAgICAgIC8vIHdhaXQgZm9yIGB0aW1lb3V0YCBtcyBhbmQgdGhlbiByZXNvbHZlIHRvIGBmYWxzZWAgKGlmIG5vdCBjYW5jZWxsZWQgZmlyc3QpCiAgICAgIGNvbnN0IGNhcHR1cmVkU2V0VGltZW91dCA9IHNldFRpbWVvdXQoKCkgPT4gewogICAgICAgIGlmICh0aW1lb3V0ICYmIHRpbWVvdXQgPiAwKSB7CiAgICAgICAgICByZXNvbHZlKGZhbHNlKTsKICAgICAgICB9CiAgICAgIH0sIHRpbWVvdXQpOwoKICAgICAgLy8gaWYgYWxsIHByb21pc2VzIHJlc29sdmUgaW4gdGltZSwgY2FuY2VsIHRoZSB0aW1lciBhbmQgcmVzb2x2ZSB0byBgdHJ1ZWAKICAgICAgYnVmZmVyLmZvckVhY2goaXRlbSA9PiB7CiAgICAgICAgdm9pZCByZXNvbHZlZFN5bmNQcm9taXNlKGl0ZW0pLnRoZW4oKCkgPT4gewogICAgICAgICAgaWYgKCEtLWNvdW50ZXIpIHsKICAgICAgICAgICAgY2xlYXJUaW1lb3V0KGNhcHR1cmVkU2V0VGltZW91dCk7CiAgICAgICAgICAgIHJlc29sdmUodHJ1ZSk7CiAgICAgICAgICB9CiAgICAgICAgfSwgcmVqZWN0KTsKICAgICAgfSk7CiAgICB9KTsKICB9CgogIHJldHVybiB7CiAgICAkOiBidWZmZXIsCiAgICBhZGQsCiAgICBkcmFpbiwKICB9Owp9Cgpjb25zdCBPTkVfU0VDT05EX0lOX01TID0gMTAwMDsKCi8qKgogKiBBIHBhcnRpYWwgZGVmaW5pdGlvbiBvZiB0aGUgW1BlcmZvcm1hbmNlIFdlYiBBUElde0BsaW5rIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0FQSS9QZXJmb3JtYW5jZX0KICogZm9yIGFjY2Vzc2luZyBhIGhpZ2gtcmVzb2x1dGlvbiBtb25vdG9uaWMgY2xvY2suCiAqLwoKLyoqCiAqIFJldHVybnMgYSB0aW1lc3RhbXAgaW4gc2Vjb25kcyBzaW5jZSB0aGUgVU5JWCBlcG9jaCB1c2luZyB0aGUgRGF0ZSBBUEkuCiAqCiAqIFRPRE8odjgpOiBSZXR1cm4gdHlwZSBzaG91bGQgYmUgcm91bmRlZC4KICovCmZ1bmN0aW9uIGRhdGVUaW1lc3RhbXBJblNlY29uZHMoKSB7CiAgcmV0dXJuIERhdGUubm93KCkgLyBPTkVfU0VDT05EX0lOX01TOwp9CgovKioKICogUmV0dXJucyBhIHdyYXBwZXIgYXJvdW5kIHRoZSBuYXRpdmUgUGVyZm9ybWFuY2UgQVBJIGJyb3dzZXIgaW1wbGVtZW50YXRpb24sIG9yIHVuZGVmaW5lZCBmb3IgYnJvd3NlcnMgdGhhdCBkbyBub3QKICogc3VwcG9ydCB0aGUgQVBJLgogKgogKiBXcmFwcGluZyB0aGUgbmF0aXZlIEFQSSB3b3JrcyBhcm91bmQgZGlmZmVyZW5jZXMgaW4gYmVoYXZpb3IgZnJvbSBkaWZmZXJlbnQgYnJvd3NlcnMuCiAqLwpmdW5jdGlvbiBjcmVhdGVVbml4VGltZXN0YW1wSW5TZWNvbmRzRnVuYygpIHsKICBjb25zdCB7IHBlcmZvcm1hbmNlIH0gPSBHTE9CQUxfT0JKIDsKICBpZiAoIXBlcmZvcm1hbmNlIHx8ICFwZXJmb3JtYW5jZS5ub3cpIHsKICAgIHJldHVybiBkYXRlVGltZXN0YW1wSW5TZWNvbmRzOwogIH0KCiAgLy8gU29tZSBicm93c2VyIGFuZCBlbnZpcm9ubWVudHMgZG9uJ3QgaGF2ZSBhIHRpbWVPcmlnaW4sIHNvIHdlIGZhbGxiYWNrIHRvCiAgLy8gdXNpbmcgRGF0ZS5ub3coKSB0byBjb21wdXRlIHRoZSBzdGFydGluZyB0aW1lLgogIGNvbnN0IGFwcHJveFN0YXJ0aW5nVGltZU9yaWdpbiA9IERhdGUubm93KCkgLSBwZXJmb3JtYW5jZS5ub3coKTsKICBjb25zdCB0aW1lT3JpZ2luID0gcGVyZm9ybWFuY2UudGltZU9yaWdpbiA9PSB1bmRlZmluZWQgPyBhcHByb3hTdGFydGluZ1RpbWVPcmlnaW4gOiBwZXJmb3JtYW5jZS50aW1lT3JpZ2luOwoKICAvLyBwZXJmb3JtYW5jZS5ub3coKSBpcyBhIG1vbm90b25pYyBjbG9jaywgd2hpY2ggbWVhbnMgaXQgc3RhcnRzIGF0IDAgd2hlbiB0aGUgcHJvY2VzcyBiZWdpbnMuIFRvIGdldCB0aGUgY3VycmVudAogIC8vIHdhbGwgY2xvY2sgdGltZSAoYWN0dWFsIFVOSVggdGltZXN0YW1wKSwgd2UgbmVlZCB0byBhZGQgdGhlIHN0YXJ0aW5nIHRpbWUgb3JpZ2luIGFuZCB0aGUgY3VycmVudCB0aW1lIGVsYXBzZWQuCiAgLy8KICAvLyBUT0RPOiBUaGlzIGRvZXMgbm90IGFjY291bnQgZm9yIHRoZSBjYXNlIHdoZXJlIHRoZSBtb25vdG9uaWMgY2xvY2sgdGhhdCBwb3dlcnMgcGVyZm9ybWFuY2Uubm93KCkgZHJpZnRzIGZyb20gdGhlCiAgLy8gd2FsbCBjbG9jayB0aW1lLCB3aGljaCBjYXVzZXMgdGhlIHJldHVybmVkIHRpbWVzdGFtcCB0byBiZSBpbmFjY3VyYXRlLiBXZSBzaG91bGQgaW52ZXN0aWdhdGUgaG93IHRvIGRldGVjdCBhbmQKICAvLyBjb3JyZWN0IGZvciB0aGlzLgogIC8vIFNlZTogaHR0cHM6Ly9naXRodWIuY29tL2dldHNlbnRyeS9zZW50cnktamF2YXNjcmlwdC9pc3N1ZXMvMjU5MAogIC8vIFNlZTogaHR0cHM6Ly9naXRodWIuY29tL21kbi9jb250ZW50L2lzc3Vlcy80NzEzCiAgLy8gU2VlOiBodHRwczovL2Rldi50by9ub2Ftci93aGVuLWEtbWlsbGlzZWNvbmQtaXMtbm90LWEtbWlsbGlzZWNvbmQtM2g2CiAgcmV0dXJuICgpID0+IHsKICAgIHJldHVybiAodGltZU9yaWdpbiArIHBlcmZvcm1hbmNlLm5vdygpKSAvIE9ORV9TRUNPTkRfSU5fTVM7CiAgfTsKfQoKLyoqCiAqIFJldHVybnMgYSB0aW1lc3RhbXAgaW4gc2Vjb25kcyBzaW5jZSB0aGUgVU5JWCBlcG9jaCB1c2luZyBlaXRoZXIgdGhlIFBlcmZvcm1hbmNlIG9yIERhdGUgQVBJcywgZGVwZW5kaW5nIG9uIHRoZQogKiBhdmFpbGFiaWxpdHkgb2YgdGhlIFBlcmZvcm1hbmNlIEFQSS4KICoKICogQlVHOiBOb3RlIHRoYXQgYmVjYXVzZSBvZiBob3cgYnJvd3NlcnMgaW1wbGVtZW50IHRoZSBQZXJmb3JtYW5jZSBBUEksIHRoZSBjbG9jayBtaWdodCBzdG9wIHdoZW4gdGhlIGNvbXB1dGVyIGlzCiAqIGFzbGVlcC4gVGhpcyBjcmVhdGVzIGEgc2tldyBiZXR3ZWVuIGBkYXRlVGltZXN0YW1wSW5TZWNvbmRzYCBhbmQgYHRpbWVzdGFtcEluU2Vjb25kc2AuIFRoZQogKiBza2V3IGNhbiBncm93IHRvIGFyYml0cmFyeSBhbW91bnRzIGxpa2UgZGF5cywgd2Vla3Mgb3IgbW9udGhzLgogKiBTZWUgaHR0cHM6Ly9naXRodWIuY29tL2dldHNlbnRyeS9zZW50cnktamF2YXNjcmlwdC9pc3N1ZXMvMjU5MC4KICovCmNvbnN0IHRpbWVzdGFtcEluU2Vjb25kcyA9IGNyZWF0ZVVuaXhUaW1lc3RhbXBJblNlY29uZHNGdW5jKCk7CgovKioKICogVGhlIG51bWJlciBvZiBtaWxsaXNlY29uZHMgc2luY2UgdGhlIFVOSVggZXBvY2guIFRoaXMgdmFsdWUgaXMgb25seSB1c2FibGUgaW4gYSBicm93c2VyLCBhbmQgb25seSB3aGVuIHRoZQogKiBwZXJmb3JtYW5jZSBBUEkgaXMgYXZhaWxhYmxlLgogKi8KKCgpID0+IHsKICAvLyBVbmZvcnR1bmF0ZWx5IGJyb3dzZXJzIG1heSByZXBvcnQgYW4gaW5hY2N1cmF0ZSB0aW1lIG9yaWdpbiBkYXRhLCB0aHJvdWdoIGVpdGhlciBwZXJmb3JtYW5jZS50aW1lT3JpZ2luIG9yCiAgLy8gcGVyZm9ybWFuY2UudGltaW5nLm5hdmlnYXRpb25TdGFydCwgd2hpY2ggcmVzdWx0cyBpbiBwb29yIHJlc3VsdHMgaW4gcGVyZm9ybWFuY2UgZGF0YS4gV2Ugb25seSB0cmVhdCB0aW1lIG9yaWdpbgogIC8vIGRhdGEgYXMgcmVsaWFibGUgaWYgdGhleSBhcmUgd2l0aGluIGEgcmVhc29uYWJsZSB0aHJlc2hvbGQgb2YgdGhlIGN1cnJlbnQgdGltZS4KCiAgY29uc3QgeyBwZXJmb3JtYW5jZSB9ID0gR0xPQkFMX09CSiA7CiAgaWYgKCFwZXJmb3JtYW5jZSB8fCAhcGVyZm9ybWFuY2Uubm93KSB7CiAgICByZXR1cm4gdW5kZWZpbmVkOwogIH0KCiAgY29uc3QgdGhyZXNob2xkID0gMzYwMCAqIDEwMDA7CiAgY29uc3QgcGVyZm9ybWFuY2VOb3cgPSBwZXJmb3JtYW5jZS5ub3coKTsKICBjb25zdCBkYXRlTm93ID0gRGF0ZS5ub3coKTsKCiAgLy8gaWYgdGltZU9yaWdpbiBpc24ndCBhdmFpbGFibGUgc2V0IGRlbHRhIHRvIHRocmVzaG9sZCBzbyBpdCBpc24ndCB1c2VkCiAgY29uc3QgdGltZU9yaWdpbkRlbHRhID0gcGVyZm9ybWFuY2UudGltZU9yaWdpbgogICAgPyBNYXRoLmFicyhwZXJmb3JtYW5jZS50aW1lT3JpZ2luICsgcGVyZm9ybWFuY2VOb3cgLSBkYXRlTm93KQogICAgOiB0aHJlc2hvbGQ7CiAgY29uc3QgdGltZU9yaWdpbklzUmVsaWFibGUgPSB0aW1lT3JpZ2luRGVsdGEgPCB0aHJlc2hvbGQ7CgogIC8vIFdoaWxlIHBlcmZvcm1hbmNlLnRpbWluZy5uYXZpZ2F0aW9uU3RhcnQgaXMgZGVwcmVjYXRlZCBpbiBmYXZvciBvZiBwZXJmb3JtYW5jZS50aW1lT3JpZ2luLCBwZXJmb3JtYW5jZS50aW1lT3JpZ2luCiAgLy8gaXMgbm90IGFzIHdpZGVseSBzdXBwb3J0ZWQuIE5hbWVseSwgcGVyZm9ybWFuY2UudGltZU9yaWdpbiBpcyB1bmRlZmluZWQgaW4gU2FmYXJpIGFzIG9mIHdyaXRpbmcuCiAgLy8gQWxzbyBhcyBvZiB3cml0aW5nLCBwZXJmb3JtYW5jZS50aW1pbmcgaXMgbm90IGF2YWlsYWJsZSBpbiBXZWIgV29ya2VycyBpbiBtYWluc3RyZWFtIGJyb3dzZXJzLCBzbyBpdCBpcyBub3QgYWx3YXlzCiAgLy8gYSB2YWxpZCBmYWxsYmFjay4gSW4gdGhlIGFic2VuY2Ugb2YgYW4gaW5pdGlhbCB0aW1lIHByb3ZpZGVkIGJ5IHRoZSBicm93c2VyLCBmYWxsYmFjayB0byB0aGUgY3VycmVudCB0aW1lIGZyb20gdGhlCiAgLy8gRGF0ZSBBUEkuCiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGRlcHJlY2F0aW9uL2RlcHJlY2F0aW9uCiAgY29uc3QgbmF2aWdhdGlvblN0YXJ0ID0gcGVyZm9ybWFuY2UudGltaW5nICYmIHBlcmZvcm1hbmNlLnRpbWluZy5uYXZpZ2F0aW9uU3RhcnQ7CiAgY29uc3QgaGFzTmF2aWdhdGlvblN0YXJ0ID0gdHlwZW9mIG5hdmlnYXRpb25TdGFydCA9PT0gJ251bWJlcic7CiAgLy8gaWYgbmF2aWdhdGlvblN0YXJ0IGlzbid0IGF2YWlsYWJsZSBzZXQgZGVsdGEgdG8gdGhyZXNob2xkIHNvIGl0IGlzbid0IHVzZWQKICBjb25zdCBuYXZpZ2F0aW9uU3RhcnREZWx0YSA9IGhhc05hdmlnYXRpb25TdGFydCA/IE1hdGguYWJzKG5hdmlnYXRpb25TdGFydCArIHBlcmZvcm1hbmNlTm93IC0gZGF0ZU5vdykgOiB0aHJlc2hvbGQ7CiAgY29uc3QgbmF2aWdhdGlvblN0YXJ0SXNSZWxpYWJsZSA9IG5hdmlnYXRpb25TdGFydERlbHRhIDwgdGhyZXNob2xkOwoKICBpZiAodGltZU9yaWdpbklzUmVsaWFibGUgfHwgbmF2aWdhdGlvblN0YXJ0SXNSZWxpYWJsZSkgewogICAgLy8gVXNlIHRoZSBtb3JlIHJlbGlhYmxlIHRpbWUgb3JpZ2luCiAgICBpZiAodGltZU9yaWdpbkRlbHRhIDw9IG5hdmlnYXRpb25TdGFydERlbHRhKSB7CiAgICAgIHJldHVybiBwZXJmb3JtYW5jZS50aW1lT3JpZ2luOwogICAgfSBlbHNlIHsKICAgICAgcmV0dXJuIG5hdmlnYXRpb25TdGFydDsKICAgIH0KICB9CiAgcmV0dXJuIGRhdGVOb3c7Cn0pKCk7CgovKioKICogQ3JlYXRlcyBhbiBlbnZlbG9wZS4KICogTWFrZSBzdXJlIHRvIGFsd2F5cyBleHBsaWNpdGx5IHByb3ZpZGUgdGhlIGdlbmVyaWMgdG8gdGhpcyBmdW5jdGlvbgogKiBzbyB0aGF0IHRoZSBlbnZlbG9wZSB0eXBlcyByZXNvbHZlIGNvcnJlY3RseS4KICovCmZ1bmN0aW9uIGNyZWF0ZUVudmVsb3BlKGhlYWRlcnMsIGl0ZW1zID0gW10pIHsKICByZXR1cm4gW2hlYWRlcnMsIGl0ZW1zXSA7Cn0KCi8qKgogKiBDb252ZW5pZW5jZSBmdW5jdGlvbiB0byBsb29wIHRocm91Z2ggdGhlIGl0ZW1zIGFuZCBpdGVtIHR5cGVzIG9mIGFuIGVudmVsb3BlLgogKiAoVGhpcyBmdW5jdGlvbiB3YXMgbW9zdGx5IGNyZWF0ZWQgYmVjYXVzZSB3b3JraW5nIHdpdGggZW52ZWxvcGUgdHlwZXMgaXMgcGFpbmZ1bCBhdCB0aGUgbW9tZW50KQogKgogKiBJZiB0aGUgY2FsbGJhY2sgcmV0dXJucyB0cnVlLCB0aGUgcmVzdCBvZiB0aGUgaXRlbXMgd2lsbCBiZSBza2lwcGVkLgogKi8KZnVuY3Rpb24gZm9yRWFjaEVudmVsb3BlSXRlbSgKICBlbnZlbG9wZSwKICBjYWxsYmFjaywKKSB7CiAgY29uc3QgZW52ZWxvcGVJdGVtcyA9IGVudmVsb3BlWzFdOwoKICBmb3IgKGNvbnN0IGVudmVsb3BlSXRlbSBvZiBlbnZlbG9wZUl0ZW1zKSB7CiAgICBjb25zdCBlbnZlbG9wZUl0ZW1UeXBlID0gZW52ZWxvcGVJdGVtWzBdLnR5cGU7CiAgICBjb25zdCByZXN1bHQgPSBjYWxsYmFjayhlbnZlbG9wZUl0ZW0sIGVudmVsb3BlSXRlbVR5cGUpOwoKICAgIGlmIChyZXN1bHQpIHsKICAgICAgcmV0dXJuIHRydWU7CiAgICB9CiAgfQoKICByZXR1cm4gZmFsc2U7Cn0KCi8qKgogKiBFbmNvZGUgYSBzdHJpbmcgdG8gVVRGOC4KICovCmZ1bmN0aW9uIGVuY29kZVVURjgoaW5wdXQsIHRleHRFbmNvZGVyKSB7CiAgY29uc3QgdXRmOCA9IHRleHRFbmNvZGVyIHx8IG5ldyBUZXh0RW5jb2RlcigpOwogIHJldHVybiB1dGY4LmVuY29kZShpbnB1dCk7Cn0KCi8qKgogKiBTZXJpYWxpemVzIGFuIGVudmVsb3BlLgogKi8KZnVuY3Rpb24gc2VyaWFsaXplRW52ZWxvcGUoZW52ZWxvcGUsIHRleHRFbmNvZGVyKSB7CiAgY29uc3QgW2VudkhlYWRlcnMsIGl0ZW1zXSA9IGVudmVsb3BlOwoKICAvLyBJbml0aWFsbHkgd2UgY29uc3RydWN0IG91ciBlbnZlbG9wZSBhcyBhIHN0cmluZyBhbmQgb25seSBjb252ZXJ0IHRvIGJpbmFyeSBjaHVua3MgaWYgd2UgZW5jb3VudGVyIGJpbmFyeSBkYXRhCiAgbGV0IHBhcnRzID0gSlNPTi5zdHJpbmdpZnkoZW52SGVhZGVycyk7CgogIGZ1bmN0aW9uIGFwcGVuZChuZXh0KSB7CiAgICBpZiAodHlwZW9mIHBhcnRzID09PSAnc3RyaW5nJykgewogICAgICBwYXJ0cyA9IHR5cGVvZiBuZXh0ID09PSAnc3RyaW5nJyA/IHBhcnRzICsgbmV4dCA6IFtlbmNvZGVVVEY4KHBhcnRzLCB0ZXh0RW5jb2RlciksIG5leHRdOwogICAgfSBlbHNlIHsKICAgICAgcGFydHMucHVzaCh0eXBlb2YgbmV4dCA9PT0gJ3N0cmluZycgPyBlbmNvZGVVVEY4KG5leHQsIHRleHRFbmNvZGVyKSA6IG5leHQpOwogICAgfQogIH0KCiAgZm9yIChjb25zdCBpdGVtIG9mIGl0ZW1zKSB7CiAgICBjb25zdCBbaXRlbUhlYWRlcnMsIHBheWxvYWRdID0gaXRlbTsKCiAgICBhcHBlbmQoYFxuJHtKU09OLnN0cmluZ2lmeShpdGVtSGVhZGVycyl9XG5gKTsKCiAgICBpZiAodHlwZW9mIHBheWxvYWQgPT09ICdzdHJpbmcnIHx8IHBheWxvYWQgaW5zdGFuY2VvZiBVaW50OEFycmF5KSB7CiAgICAgIGFwcGVuZChwYXlsb2FkKTsKICAgIH0gZWxzZSB7CiAgICAgIGxldCBzdHJpbmdpZmllZFBheWxvYWQ7CiAgICAgIHRyeSB7CiAgICAgICAgc3RyaW5naWZpZWRQYXlsb2FkID0gSlNPTi5zdHJpbmdpZnkocGF5bG9hZCk7CiAgICAgIH0gY2F0Y2ggKGUpIHsKICAgICAgICAvLyBJbiBjYXNlLCBkZXNwaXRlIGFsbCBvdXIgZWZmb3J0cyB0byBrZWVwIGBwYXlsb2FkYCBjaXJjdWxhci1kZXBlbmRlbmN5LWZyZWUsIGBKU09OLnN0cmluaWZ5KClgIHN0aWxsCiAgICAgICAgLy8gZmFpbHMsIHdlIHRyeSBhZ2FpbiBhZnRlciBub3JtYWxpemluZyBpdCBhZ2FpbiB3aXRoIGluZmluaXRlIG5vcm1hbGl6YXRpb24gZGVwdGguIFRoaXMgb2YgY291cnNlIGhhcyBhCiAgICAgICAgLy8gcGVyZm9ybWFuY2UgaW1wYWN0IGJ1dCBpbiB0aGlzIGNhc2UgYSBwZXJmb3JtYW5jZSBoaXQgaXMgYmV0dGVyIHRoYW4gdGhyb3dpbmcuCiAgICAgICAgc3RyaW5naWZpZWRQYXlsb2FkID0gSlNPTi5zdHJpbmdpZnkobm9ybWFsaXplKHBheWxvYWQpKTsKICAgICAgfQogICAgICBhcHBlbmQoc3RyaW5naWZpZWRQYXlsb2FkKTsKICAgIH0KICB9CgogIHJldHVybiB0eXBlb2YgcGFydHMgPT09ICdzdHJpbmcnID8gcGFydHMgOiBjb25jYXRCdWZmZXJzKHBhcnRzKTsKfQoKZnVuY3Rpb24gY29uY2F0QnVmZmVycyhidWZmZXJzKSB7CiAgY29uc3QgdG90YWxMZW5ndGggPSBidWZmZXJzLnJlZHVjZSgoYWNjLCBidWYpID0+IGFjYyArIGJ1Zi5sZW5ndGgsIDApOwoKICBjb25zdCBtZXJnZWQgPSBuZXcgVWludDhBcnJheSh0b3RhbExlbmd0aCk7CiAgbGV0IG9mZnNldCA9IDA7CiAgZm9yIChjb25zdCBidWZmZXIgb2YgYnVmZmVycykgewogICAgbWVyZ2VkLnNldChidWZmZXIsIG9mZnNldCk7CiAgICBvZmZzZXQgKz0gYnVmZmVyLmxlbmd0aDsKICB9CgogIHJldHVybiBtZXJnZWQ7Cn0KCmNvbnN0IElURU1fVFlQRV9UT19EQVRBX0NBVEVHT1JZX01BUCA9IHsKICBzZXNzaW9uOiAnc2Vzc2lvbicsCiAgc2Vzc2lvbnM6ICdzZXNzaW9uJywKICBhdHRhY2htZW50OiAnYXR0YWNobWVudCcsCiAgdHJhbnNhY3Rpb246ICd0cmFuc2FjdGlvbicsCiAgZXZlbnQ6ICdlcnJvcicsCiAgY2xpZW50X3JlcG9ydDogJ2ludGVybmFsJywKICB1c2VyX3JlcG9ydDogJ2RlZmF1bHQnLAogIHByb2ZpbGU6ICdwcm9maWxlJywKICByZXBsYXlfZXZlbnQ6ICdyZXBsYXknLAogIHJlcGxheV9yZWNvcmRpbmc6ICdyZXBsYXknLAogIGNoZWNrX2luOiAnbW9uaXRvcicsCiAgZmVlZGJhY2s6ICdmZWVkYmFjaycsCiAgLy8gVE9ETzogVGhpcyBpcyBhIHRlbXBvcmFyeSB3b3JrYXJvdW5kIHVudGlsIHdlIGhhdmUgYSBwcm9wZXIgZGF0YSBjYXRlZ29yeSBmb3IgbWV0cmljcwogIHN0YXRzZDogJ3Vua25vd24nLAp9OwoKLyoqCiAqIE1hcHMgdGhlIHR5cGUgb2YgYW4gZW52ZWxvcGUgaXRlbSB0byBhIGRhdGEgY2F0ZWdvcnkuCiAqLwpmdW5jdGlvbiBlbnZlbG9wZUl0ZW1UeXBlVG9EYXRhQ2F0ZWdvcnkodHlwZSkgewogIHJldHVybiBJVEVNX1RZUEVfVE9fREFUQV9DQVRFR09SWV9NQVBbdHlwZV07Cn0KCi8qKiBFeHRyYWN0cyB0aGUgbWluaW1hbCBTREsgaW5mbyBmcm9tIGZyb20gdGhlIG1ldGFkYXRhIG9yIGFuIGV2ZW50cyAqLwpmdW5jdGlvbiBnZXRTZGtNZXRhZGF0YUZvckVudmVsb3BlSGVhZGVyKG1ldGFkYXRhT3JFdmVudCkgewogIGlmICghbWV0YWRhdGFPckV2ZW50IHx8ICFtZXRhZGF0YU9yRXZlbnQuc2RrKSB7CiAgICByZXR1cm47CiAgfQogIGNvbnN0IHsgbmFtZSwgdmVyc2lvbiB9ID0gbWV0YWRhdGFPckV2ZW50LnNkazsKICByZXR1cm4geyBuYW1lLCB2ZXJzaW9uIH07Cn0KCi8qKgogKiBDcmVhdGVzIGV2ZW50IGVudmVsb3BlIGhlYWRlcnMsIGJhc2VkIG9uIGV2ZW50LCBzZGsgaW5mbyBhbmQgdHVubmVsCiAqIE5vdGU6IFRoaXMgZnVuY3Rpb24gd2FzIGV4dHJhY3RlZCBmcm9tIHRoZSBjb3JlIHBhY2thZ2UgdG8gbWFrZSBpdCBhdmFpbGFibGUgaW4gUmVwbGF5CiAqLwpmdW5jdGlvbiBjcmVhdGVFdmVudEVudmVsb3BlSGVhZGVycygKICBldmVudCwKICBzZGtJbmZvLAogIHR1bm5lbCwKICBkc24sCikgewogIGNvbnN0IGR5bmFtaWNTYW1wbGluZ0NvbnRleHQgPSBldmVudC5zZGtQcm9jZXNzaW5nTWV0YWRhdGEgJiYgZXZlbnQuc2RrUHJvY2Vzc2luZ01ldGFkYXRhLmR5bmFtaWNTYW1wbGluZ0NvbnRleHQ7CiAgcmV0dXJuIHsKICAgIGV2ZW50X2lkOiBldmVudC5ldmVudF9pZCAsCiAgICBzZW50X2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksCiAgICAuLi4oc2RrSW5mbyAmJiB7IHNkazogc2RrSW5mbyB9KSwKICAgIC4uLighIXR1bm5lbCAmJiBkc24gJiYgeyBkc246IGRzblRvU3RyaW5nKGRzbikgfSksCiAgICAuLi4oZHluYW1pY1NhbXBsaW5nQ29udGV4dCAmJiB7CiAgICAgIHRyYWNlOiBkcm9wVW5kZWZpbmVkS2V5cyh7IC4uLmR5bmFtaWNTYW1wbGluZ0NvbnRleHQgfSksCiAgICB9KSwKICB9Owp9CgovLyBJbnRlbnRpb25hbGx5IGtlZXBpbmcgdGhlIGtleSBicm9hZCwgYXMgd2UgZG9uJ3Qga25vdyBmb3Igc3VyZSB3aGF0IHJhdGUgbGltaXQgaGVhZGVycyBnZXQgcmV0dXJuZWQgZnJvbSBiYWNrZW5kCgpjb25zdCBERUZBVUxUX1JFVFJZX0FGVEVSID0gNjAgKiAxMDAwOyAvLyA2MCBzZWNvbmRzCgovKioKICogRXh0cmFjdHMgUmV0cnktQWZ0ZXIgdmFsdWUgZnJvbSB0aGUgcmVxdWVzdCBoZWFkZXIgb3IgcmV0dXJucyBkZWZhdWx0IHZhbHVlCiAqIEBwYXJhbSBoZWFkZXIgc3RyaW5nIHJlcHJlc2VudGF0aW9uIG9mICdSZXRyeS1BZnRlcicgaGVhZGVyCiAqIEBwYXJhbSBub3cgY3VycmVudCB1bml4IHRpbWVzdGFtcAogKgogKi8KZnVuY3Rpb24gcGFyc2VSZXRyeUFmdGVySGVhZGVyKGhlYWRlciwgbm93ID0gRGF0ZS5ub3coKSkgewogIGNvbnN0IGhlYWRlckRlbGF5ID0gcGFyc2VJbnQoYCR7aGVhZGVyfWAsIDEwKTsKICBpZiAoIWlzTmFOKGhlYWRlckRlbGF5KSkgewogICAgcmV0dXJuIGhlYWRlckRlbGF5ICogMTAwMDsKICB9CgogIGNvbnN0IGhlYWRlckRhdGUgPSBEYXRlLnBhcnNlKGAke2hlYWRlcn1gKTsKICBpZiAoIWlzTmFOKGhlYWRlckRhdGUpKSB7CiAgICByZXR1cm4gaGVhZGVyRGF0ZSAtIG5vdzsKICB9CgogIHJldHVybiBERUZBVUxUX1JFVFJZX0FGVEVSOwp9CgovKioKICogR2V0cyB0aGUgdGltZSB0aGF0IHRoZSBnaXZlbiBjYXRlZ29yeSBpcyBkaXNhYmxlZCB1bnRpbCBmb3IgcmF0ZSBsaW1pdGluZy4KICogSW4gY2FzZSBubyBjYXRlZ29yeS1zcGVjaWZpYyBsaW1pdCBpcyBzZXQgYnV0IGEgZ2VuZXJhbCByYXRlIGxpbWl0IGFjcm9zcyBhbGwgY2F0ZWdvcmllcyBpcyBhY3RpdmUsCiAqIHRoYXQgdGltZSBpcyByZXR1cm5lZC4KICoKICogQHJldHVybiB0aGUgdGltZSBpbiBtcyB0aGF0IHRoZSBjYXRlZ29yeSBpcyBkaXNhYmxlZCB1bnRpbCBvciAwIGlmIHRoZXJlJ3Mgbm8gYWN0aXZlIHJhdGUgbGltaXQuCiAqLwpmdW5jdGlvbiBkaXNhYmxlZFVudGlsKGxpbWl0cywgY2F0ZWdvcnkpIHsKICByZXR1cm4gbGltaXRzW2NhdGVnb3J5XSB8fCBsaW1pdHMuYWxsIHx8IDA7Cn0KCi8qKgogKiBDaGVja3MgaWYgYSBjYXRlZ29yeSBpcyByYXRlIGxpbWl0ZWQKICovCmZ1bmN0aW9uIGlzUmF0ZUxpbWl0ZWQobGltaXRzLCBjYXRlZ29yeSwgbm93ID0gRGF0ZS5ub3coKSkgewogIHJldHVybiBkaXNhYmxlZFVudGlsKGxpbWl0cywgY2F0ZWdvcnkpID4gbm93Owp9CgovKioKICogVXBkYXRlIHJhdGVsaW1pdHMgZnJvbSBpbmNvbWluZyBoZWFkZXJzLgogKgogKiBAcmV0dXJuIHRoZSB1cGRhdGVkIFJhdGVMaW1pdHMgb2JqZWN0LgogKi8KZnVuY3Rpb24gdXBkYXRlUmF0ZUxpbWl0cygKICBsaW1pdHMsCiAgeyBzdGF0dXNDb2RlLCBoZWFkZXJzIH0sCiAgbm93ID0gRGF0ZS5ub3coKSwKKSB7CiAgY29uc3QgdXBkYXRlZFJhdGVMaW1pdHMgPSB7CiAgICAuLi5saW1pdHMsCiAgfTsKCiAgLy8gIlRoZSBuYW1lIGlzIGNhc2UtaW5zZW5zaXRpdmUuIgogIC8vIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0FQSS9IZWFkZXJzL2dldAogIGNvbnN0IHJhdGVMaW1pdEhlYWRlciA9IGhlYWRlcnMgJiYgaGVhZGVyc1sneC1zZW50cnktcmF0ZS1saW1pdHMnXTsKICBjb25zdCByZXRyeUFmdGVySGVhZGVyID0gaGVhZGVycyAmJiBoZWFkZXJzWydyZXRyeS1hZnRlciddOwoKICBpZiAocmF0ZUxpbWl0SGVhZGVyKSB7CiAgICAvKioKICAgICAqIHJhdGUgbGltaXQgaGVhZGVycyBhcmUgb2YgdGhlIGZvcm0KICAgICAqICAgICA8aGVhZGVyPiw8aGVhZGVyPiwuLgogICAgICogd2hlcmUgZWFjaCA8aGVhZGVyPiBpcyBvZiB0aGUgZm9ybQogICAgICogICAgIDxyZXRyeV9hZnRlcj46IDxjYXRlZ29yaWVzPjogPHNjb3BlPjogPHJlYXNvbl9jb2RlPgogICAgICogd2hlcmUKICAgICAqICAgICA8cmV0cnlfYWZ0ZXI+IGlzIGEgZGVsYXkgaW4gc2Vjb25kcwogICAgICogICAgIDxjYXRlZ29yaWVzPiBpcyB0aGUgZXZlbnQgdHlwZShzKSAoZXJyb3IsIHRyYW5zYWN0aW9uLCBldGMpIGJlaW5nIHJhdGUgbGltaXRlZCBhbmQgaXMgb2YgdGhlIGZvcm0KICAgICAqICAgICAgICAgPGNhdGVnb3J5Pjs8Y2F0ZWdvcnk+Oy4uLgogICAgICogICAgIDxzY29wZT4gaXMgd2hhdCdzIGJlaW5nIGxpbWl0ZWQgKG9yZywgcHJvamVjdCwgb3Iga2V5KSAtIGlnbm9yZWQgYnkgU0RLCiAgICAgKiAgICAgPHJlYXNvbl9jb2RlPiBpcyBhbiBhcmJpdHJhcnkgc3RyaW5nIGxpa2UgIm9yZ19xdW90YSIgLSBpZ25vcmVkIGJ5IFNESwogICAgICovCiAgICBmb3IgKGNvbnN0IGxpbWl0IG9mIHJhdGVMaW1pdEhlYWRlci50cmltKCkuc3BsaXQoJywnKSkgewogICAgICBjb25zdCBbcmV0cnlBZnRlciwgY2F0ZWdvcmllc10gPSBsaW1pdC5zcGxpdCgnOicsIDIpOwogICAgICBjb25zdCBoZWFkZXJEZWxheSA9IHBhcnNlSW50KHJldHJ5QWZ0ZXIsIDEwKTsKICAgICAgY29uc3QgZGVsYXkgPSAoIWlzTmFOKGhlYWRlckRlbGF5KSA/IGhlYWRlckRlbGF5IDogNjApICogMTAwMDsgLy8gNjBzZWMgZGVmYXVsdAogICAgICBpZiAoIWNhdGVnb3JpZXMpIHsKICAgICAgICB1cGRhdGVkUmF0ZUxpbWl0cy5hbGwgPSBub3cgKyBkZWxheTsKICAgICAgfSBlbHNlIHsKICAgICAgICBmb3IgKGNvbnN0IGNhdGVnb3J5IG9mIGNhdGVnb3JpZXMuc3BsaXQoJzsnKSkgewogICAgICAgICAgdXBkYXRlZFJhdGVMaW1pdHNbY2F0ZWdvcnldID0gbm93ICsgZGVsYXk7CiAgICAgICAgfQogICAgICB9CiAgICB9CiAgfSBlbHNlIGlmIChyZXRyeUFmdGVySGVhZGVyKSB7CiAgICB1cGRhdGVkUmF0ZUxpbWl0cy5hbGwgPSBub3cgKyBwYXJzZVJldHJ5QWZ0ZXJIZWFkZXIocmV0cnlBZnRlckhlYWRlciwgbm93KTsKICB9IGVsc2UgaWYgKHN0YXR1c0NvZGUgPT09IDQyOSkgewogICAgdXBkYXRlZFJhdGVMaW1pdHMuYWxsID0gbm93ICsgNjAgKiAxMDAwOwogIH0KCiAgcmV0dXJuIHVwZGF0ZWRSYXRlTGltaXRzOwp9CgovKioKICogQSBub2RlLmpzIHdhdGNoZG9nIHRpbWVyCiAqIEBwYXJhbSBwb2xsSW50ZXJ2YWwgVGhlIGludGVydmFsIHRoYXQgd2UgZXhwZWN0IHRvIGdldCBwb2xsZWQgYXQKICogQHBhcmFtIGFuclRocmVzaG9sZCBUaGUgdGhyZXNob2xkIGZvciB3aGVuIHdlIGNvbnNpZGVyIEFOUgogKiBAcGFyYW0gY2FsbGJhY2sgVGhlIGNhbGxiYWNrIHRvIGNhbGwgZm9yIEFOUgogKiBAcmV0dXJucyBBbiBvYmplY3Qgd2l0aCBgcG9sbGAgYW5kIGBlbmFibGVkYCBmdW5jdGlvbnMge0BsaW5rIFdhdGNoZG9nUmV0dXJufQogKi8KZnVuY3Rpb24gd2F0Y2hkb2dUaW1lcigKICBjcmVhdGVUaW1lciwKICBwb2xsSW50ZXJ2YWwsCiAgYW5yVGhyZXNob2xkLAogIGNhbGxiYWNrLAopIHsKICBjb25zdCB0aW1lciA9IGNyZWF0ZVRpbWVyKCk7CiAgbGV0IHRyaWdnZXJlZCA9IGZhbHNlOwogIGxldCBlbmFibGVkID0gdHJ1ZTsKCiAgc2V0SW50ZXJ2YWwoKCkgPT4gewogICAgY29uc3QgZGlmZk1zID0gdGltZXIuZ2V0VGltZU1zKCk7CgogICAgaWYgKHRyaWdnZXJlZCA9PT0gZmFsc2UgJiYgZGlmZk1zID4gcG9sbEludGVydmFsICsgYW5yVGhyZXNob2xkKSB7CiAgICAgIHRyaWdnZXJlZCA9IHRydWU7CiAgICAgIGlmIChlbmFibGVkKSB7CiAgICAgICAgY2FsbGJhY2soKTsKICAgICAgfQogICAgfQoKICAgIGlmIChkaWZmTXMgPCBwb2xsSW50ZXJ2YWwgKyBhbnJUaHJlc2hvbGQpIHsKICAgICAgdHJpZ2dlcmVkID0gZmFsc2U7CiAgICB9CiAgfSwgMjApOwoKICByZXR1cm4gewogICAgcG9sbDogKCkgPT4gewogICAgICB0aW1lci5yZXNldCgpOwogICAgfSwKICAgIGVuYWJsZWQ6IChzdGF0ZSkgPT4gewogICAgICBlbmFibGVkID0gc3RhdGU7CiAgICB9LAogIH07Cn0KCi8vIHR5cGVzIGNvcGllZCBmcm9tIGluc3BlY3Rvci5kLnRzCgovKioKICogQ29udmVydHMgRGVidWdnZXIuQ2FsbEZyYW1lIHRvIFNlbnRyeSBTdGFja0ZyYW1lCiAqLwpmdW5jdGlvbiBjYWxsRnJhbWVUb1N0YWNrRnJhbWUoCiAgZnJhbWUsCiAgdXJsLAogIGdldE1vZHVsZUZyb21GaWxlbmFtZSwKKSB7CiAgY29uc3QgZmlsZW5hbWUgPSB1cmwgPyB1cmwucmVwbGFjZSgvXmZpbGU6XC9cLy8sICcnKSA6IHVuZGVmaW5lZDsKCiAgLy8gQ2FsbEZyYW1lIHJvdy9jb2wgYXJlIDAgYmFzZWQsIHdoZXJlYXMgU3RhY2tGcmFtZSBhcmUgMSBiYXNlZAogIGNvbnN0IGNvbG5vID0gZnJhbWUubG9jYXRpb24uY29sdW1uTnVtYmVyID8gZnJhbWUubG9jYXRpb24uY29sdW1uTnVtYmVyICsgMSA6IHVuZGVmaW5lZDsKICBjb25zdCBsaW5lbm8gPSBmcmFtZS5sb2NhdGlvbi5saW5lTnVtYmVyID8gZnJhbWUubG9jYXRpb24ubGluZU51bWJlciArIDEgOiB1bmRlZmluZWQ7CgogIHJldHVybiBkcm9wVW5kZWZpbmVkS2V5cyh7CiAgICBmaWxlbmFtZSwKICAgIG1vZHVsZTogZ2V0TW9kdWxlRnJvbUZpbGVuYW1lKGZpbGVuYW1lKSwKICAgIGZ1bmN0aW9uOiBmcmFtZS5mdW5jdGlvbk5hbWUgfHwgJz8nLAogICAgY29sbm8sCiAgICBsaW5lbm8sCiAgICBpbl9hcHA6IGZpbGVuYW1lID8gZmlsZW5hbWVJc0luQXBwKGZpbGVuYW1lKSA6IHVuZGVmaW5lZCwKICB9KTsKfQoKLyoqCiAqIFRoaXMgc2VydmVzIGFzIGEgYnVpbGQgdGltZSBmbGFnIHRoYXQgd2lsbCBiZSB0cnVlIGJ5IGRlZmF1bHQsIGJ1dCBmYWxzZSBpbiBub24tZGVidWcgYnVpbGRzIG9yIGlmIHVzZXJzIHJlcGxhY2UgYF9fU0VOVFJZX0RFQlVHX19gIGluIHRoZWlyIGdlbmVyYXRlZCBjb2RlLgogKgogKiBBVFRFTlRJT046IFRoaXMgY29uc3RhbnQgbXVzdCBuZXZlciBjcm9zcyBwYWNrYWdlIGJvdW5kYXJpZXMgKGkuZS4gYmUgZXhwb3J0ZWQpIHRvIGd1YXJhbnRlZSB0aGF0IGl0IGNhbiBiZSB1c2VkIGZvciB0cmVlIHNoYWtpbmcuCiAqLwpjb25zdCBERUJVR19CVUlMRCA9ICh0eXBlb2YgX19TRU5UUllfREVCVUdfXyA9PT0gJ3VuZGVmaW5lZCcgfHwgX19TRU5UUllfREVCVUdfXyk7CgovKioKICogQ3JlYXRlcyBhIG5ldyBgU2Vzc2lvbmAgb2JqZWN0IGJ5IHNldHRpbmcgY2VydGFpbiBkZWZhdWx0IHBhcmFtZXRlcnMuIElmIG9wdGlvbmFsIEBwYXJhbSBjb250ZXh0CiAqIGlzIHBhc3NlZCwgdGhlIHBhc3NlZCBwcm9wZXJ0aWVzIGFyZSBhcHBsaWVkIHRvIHRoZSBzZXNzaW9uIG9iamVjdC4KICoKICogQHBhcmFtIGNvbnRleHQgKG9wdGlvbmFsKSBhZGRpdGlvbmFsIHByb3BlcnRpZXMgdG8gYmUgYXBwbGllZCB0byB0aGUgcmV0dXJuZWQgc2Vzc2lvbiBvYmplY3QKICoKICogQHJldHVybnMgYSBuZXcgYFNlc3Npb25gIG9iamVjdAogKi8KZnVuY3Rpb24gbWFrZVNlc3Npb24oY29udGV4dCkgewogIC8vIEJvdGggdGltZXN0YW1wIGFuZCBzdGFydGVkIGFyZSBpbiBzZWNvbmRzIHNpbmNlIHRoZSBVTklYIGVwb2NoLgogIGNvbnN0IHN0YXJ0aW5nVGltZSA9IHRpbWVzdGFtcEluU2Vjb25kcygpOwoKICBjb25zdCBzZXNzaW9uID0gewogICAgc2lkOiB1dWlkNCgpLAogICAgaW5pdDogdHJ1ZSwKICAgIHRpbWVzdGFtcDogc3RhcnRpbmdUaW1lLAogICAgc3RhcnRlZDogc3RhcnRpbmdUaW1lLAogICAgZHVyYXRpb246IDAsCiAgICBzdGF0dXM6ICdvaycsCiAgICBlcnJvcnM6IDAsCiAgICBpZ25vcmVEdXJhdGlvbjogZmFsc2UsCiAgICB0b0pTT046ICgpID0+IHNlc3Npb25Ub0pTT04oc2Vzc2lvbiksCiAgfTsKCiAgaWYgKGNvbnRleHQpIHsKICAgIHVwZGF0ZVNlc3Npb24oc2Vzc2lvbiwgY29udGV4dCk7CiAgfQoKICByZXR1cm4gc2Vzc2lvbjsKfQoKLyoqCiAqIFVwZGF0ZXMgYSBzZXNzaW9uIG9iamVjdCB3aXRoIHRoZSBwcm9wZXJ0aWVzIHBhc3NlZCBpbiB0aGUgY29udGV4dC4KICoKICogTm90ZSB0aGF0IHRoaXMgZnVuY3Rpb24gbXV0YXRlcyB0aGUgcGFzc2VkIG9iamVjdCBhbmQgcmV0dXJucyB2b2lkLgogKiAoSGFkIHRvIGRvIHRoaXMgaW5zdGVhZCBvZiByZXR1cm5pbmcgYSBuZXcgYW5kIHVwZGF0ZWQgc2Vzc2lvbiBiZWNhdXNlIGNsb3NpbmcgYW5kIHNlbmRpbmcgYSBzZXNzaW9uCiAqIG1ha2VzIGFuIHVwZGF0ZSB0byB0aGUgc2Vzc2lvbiBhZnRlciBpdCB3YXMgcGFzc2VkIHRvIHRoZSBzZW5kaW5nIGxvZ2ljLgogKiBAc2VlIEJhc2VDbGllbnQuY2FwdHVyZVNlc3Npb24gKQogKgogKiBAcGFyYW0gc2Vzc2lvbiB0aGUgYFNlc3Npb25gIHRvIHVwZGF0ZQogKiBAcGFyYW0gY29udGV4dCB0aGUgYFNlc3Npb25Db250ZXh0YCBob2xkaW5nIHRoZSBwcm9wZXJ0aWVzIHRoYXQgc2hvdWxkIGJlIHVwZGF0ZWQgaW4gQHBhcmFtIHNlc3Npb24KICovCi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBjb21wbGV4aXR5CmZ1bmN0aW9uIHVwZGF0ZVNlc3Npb24oc2Vzc2lvbiwgY29udGV4dCA9IHt9KSB7CiAgaWYgKGNvbnRleHQudXNlcikgewogICAgaWYgKCFzZXNzaW9uLmlwQWRkcmVzcyAmJiBjb250ZXh0LnVzZXIuaXBfYWRkcmVzcykgewogICAgICBzZXNzaW9uLmlwQWRkcmVzcyA9IGNvbnRleHQudXNlci5pcF9hZGRyZXNzOwogICAgfQoKICAgIGlmICghc2Vzc2lvbi5kaWQgJiYgIWNvbnRleHQuZGlkKSB7CiAgICAgIHNlc3Npb24uZGlkID0gY29udGV4dC51c2VyLmlkIHx8IGNvbnRleHQudXNlci5lbWFpbCB8fCBjb250ZXh0LnVzZXIudXNlcm5hbWU7CiAgICB9CiAgfQoKICBzZXNzaW9uLnRpbWVzdGFtcCA9IGNvbnRleHQudGltZXN0YW1wIHx8IHRpbWVzdGFtcEluU2Vjb25kcygpOwoKICBpZiAoY29udGV4dC5hYm5vcm1hbF9tZWNoYW5pc20pIHsKICAgIHNlc3Npb24uYWJub3JtYWxfbWVjaGFuaXNtID0gY29udGV4dC5hYm5vcm1hbF9tZWNoYW5pc207CiAgfQoKICBpZiAoY29udGV4dC5pZ25vcmVEdXJhdGlvbikgewogICAgc2Vzc2lvbi5pZ25vcmVEdXJhdGlvbiA9IGNvbnRleHQuaWdub3JlRHVyYXRpb247CiAgfQogIGlmIChjb250ZXh0LnNpZCkgewogICAgLy8gR29vZCBlbm91Z2ggdXVpZCB2YWxpZGF0aW9uLiDigJQgS2FtaWwKICAgIHNlc3Npb24uc2lkID0gY29udGV4dC5zaWQubGVuZ3RoID09PSAzMiA/IGNvbnRleHQuc2lkIDogdXVpZDQoKTsKICB9CiAgaWYgKGNvbnRleHQuaW5pdCAhPT0gdW5kZWZpbmVkKSB7CiAgICBzZXNzaW9uLmluaXQgPSBjb250ZXh0LmluaXQ7CiAgfQogIGlmICghc2Vzc2lvbi5kaWQgJiYgY29udGV4dC5kaWQpIHsKICAgIHNlc3Npb24uZGlkID0gYCR7Y29udGV4dC5kaWR9YDsKICB9CiAgaWYgKHR5cGVvZiBjb250ZXh0LnN0YXJ0ZWQgPT09ICdudW1iZXInKSB7CiAgICBzZXNzaW9uLnN0YXJ0ZWQgPSBjb250ZXh0LnN0YXJ0ZWQ7CiAgfQogIGlmIChzZXNzaW9uLmlnbm9yZUR1cmF0aW9uKSB7CiAgICBzZXNzaW9uLmR1cmF0aW9uID0gdW5kZWZpbmVkOwogIH0gZWxzZSBpZiAodHlwZW9mIGNvbnRleHQuZHVyYXRpb24gPT09ICdudW1iZXInKSB7CiAgICBzZXNzaW9uLmR1cmF0aW9uID0gY29udGV4dC5kdXJhdGlvbjsKICB9IGVsc2UgewogICAgY29uc3QgZHVyYXRpb24gPSBzZXNzaW9uLnRpbWVzdGFtcCAtIHNlc3Npb24uc3RhcnRlZDsKICAgIHNlc3Npb24uZHVyYXRpb24gPSBkdXJhdGlvbiA+PSAwID8gZHVyYXRpb24gOiAwOwogIH0KICBpZiAoY29udGV4dC5yZWxlYXNlKSB7CiAgICBzZXNzaW9uLnJlbGVhc2UgPSBjb250ZXh0LnJlbGVhc2U7CiAgfQogIGlmIChjb250ZXh0LmVudmlyb25tZW50KSB7CiAgICBzZXNzaW9uLmVudmlyb25tZW50ID0gY29udGV4dC5lbnZpcm9ubWVudDsKICB9CiAgaWYgKCFzZXNzaW9uLmlwQWRkcmVzcyAmJiBjb250ZXh0LmlwQWRkcmVzcykgewogICAgc2Vzc2lvbi5pcEFkZHJlc3MgPSBjb250ZXh0LmlwQWRkcmVzczsKICB9CiAgaWYgKCFzZXNzaW9uLnVzZXJBZ2VudCAmJiBjb250ZXh0LnVzZXJBZ2VudCkgewogICAgc2Vzc2lvbi51c2VyQWdlbnQgPSBjb250ZXh0LnVzZXJBZ2VudDsKICB9CiAgaWYgKHR5cGVvZiBjb250ZXh0LmVycm9ycyA9PT0gJ251bWJlcicpIHsKICAgIHNlc3Npb24uZXJyb3JzID0gY29udGV4dC5lcnJvcnM7CiAgfQogIGlmIChjb250ZXh0LnN0YXR1cykgewogICAgc2Vzc2lvbi5zdGF0dXMgPSBjb250ZXh0LnN0YXR1czsKICB9Cn0KCi8qKgogKiBTZXJpYWxpemVzIGEgcGFzc2VkIHNlc3Npb24gb2JqZWN0IHRvIGEgSlNPTiBvYmplY3Qgd2l0aCBhIHNsaWdodGx5IGRpZmZlcmVudCBzdHJ1Y3R1cmUuCiAqIFRoaXMgaXMgbmVjZXNzYXJ5IGJlY2F1c2UgdGhlIFNlbnRyeSBiYWNrZW5kIHJlcXVpcmVzIGEgc2xpZ2h0bHkgZGlmZmVyZW50IHNjaGVtYSBvZiBhIHNlc3Npb24KICogdGhhbiB0aGUgb25lIHRoZSBKUyBTREtzIHVzZSBpbnRlcm5hbGx5LgogKgogKiBAcGFyYW0gc2Vzc2lvbiB0aGUgc2Vzc2lvbiB0byBiZSBjb252ZXJ0ZWQKICoKICogQHJldHVybnMgYSBKU09OIG9iamVjdCBvZiB0aGUgcGFzc2VkIHNlc3Npb24KICovCmZ1bmN0aW9uIHNlc3Npb25Ub0pTT04oc2Vzc2lvbikgewogIHJldHVybiBkcm9wVW5kZWZpbmVkS2V5cyh7CiAgICBzaWQ6IGAke3Nlc3Npb24uc2lkfWAsCiAgICBpbml0OiBzZXNzaW9uLmluaXQsCiAgICAvLyBNYWtlIHN1cmUgdGhhdCBzZWMgaXMgY29udmVydGVkIHRvIG1zIGZvciBkYXRlIGNvbnN0cnVjdG9yCiAgICBzdGFydGVkOiBuZXcgRGF0ZShzZXNzaW9uLnN0YXJ0ZWQgKiAxMDAwKS50b0lTT1N0cmluZygpLAogICAgdGltZXN0YW1wOiBuZXcgRGF0ZShzZXNzaW9uLnRpbWVzdGFtcCAqIDEwMDApLnRvSVNPU3RyaW5nKCksCiAgICBzdGF0dXM6IHNlc3Npb24uc3RhdHVzLAogICAgZXJyb3JzOiBzZXNzaW9uLmVycm9ycywKICAgIGRpZDogdHlwZW9mIHNlc3Npb24uZGlkID09PSAnbnVtYmVyJyB8fCB0eXBlb2Ygc2Vzc2lvbi5kaWQgPT09ICdzdHJpbmcnID8gYCR7c2Vzc2lvbi5kaWR9YCA6IHVuZGVmaW5lZCwKICAgIGR1cmF0aW9uOiBzZXNzaW9uLmR1cmF0aW9uLAogICAgYWJub3JtYWxfbWVjaGFuaXNtOiBzZXNzaW9uLmFibm9ybWFsX21lY2hhbmlzbSwKICAgIGF0dHJzOiB7CiAgICAgIHJlbGVhc2U6IHNlc3Npb24ucmVsZWFzZSwKICAgICAgZW52aXJvbm1lbnQ6IHNlc3Npb24uZW52aXJvbm1lbnQsCiAgICAgIGlwX2FkZHJlc3M6IHNlc3Npb24uaXBBZGRyZXNzLAogICAgICB1c2VyX2FnZW50OiBzZXNzaW9uLnVzZXJBZ2VudCwKICAgIH0sCiAgfSk7Cn0KCi8qKgogKiBBcHBseSBTZGtJbmZvIChuYW1lLCB2ZXJzaW9uLCBwYWNrYWdlcywgaW50ZWdyYXRpb25zKSB0byB0aGUgY29ycmVzcG9uZGluZyBldmVudCBrZXkuCiAqIE1lcmdlIHdpdGggZXhpc3RpbmcgZGF0YSBpZiBhbnkuCiAqKi8KZnVuY3Rpb24gZW5oYW5jZUV2ZW50V2l0aFNka0luZm8oZXZlbnQsIHNka0luZm8pIHsKICBpZiAoIXNka0luZm8pIHsKICAgIHJldHVybiBldmVudDsKICB9CiAgZXZlbnQuc2RrID0gZXZlbnQuc2RrIHx8IHt9OwogIGV2ZW50LnNkay5uYW1lID0gZXZlbnQuc2RrLm5hbWUgfHwgc2RrSW5mby5uYW1lOwogIGV2ZW50LnNkay52ZXJzaW9uID0gZXZlbnQuc2RrLnZlcnNpb24gfHwgc2RrSW5mby52ZXJzaW9uOwogIGV2ZW50LnNkay5pbnRlZ3JhdGlvbnMgPSBbLi4uKGV2ZW50LnNkay5pbnRlZ3JhdGlvbnMgfHwgW10pLCAuLi4oc2RrSW5mby5pbnRlZ3JhdGlvbnMgfHwgW10pXTsKICBldmVudC5zZGsucGFja2FnZXMgPSBbLi4uKGV2ZW50LnNkay5wYWNrYWdlcyB8fCBbXSksIC4uLihzZGtJbmZvLnBhY2thZ2VzIHx8IFtdKV07CiAgcmV0dXJuIGV2ZW50Owp9CgovKiogQ3JlYXRlcyBhbiBlbnZlbG9wZSBmcm9tIGEgU2Vzc2lvbiAqLwpmdW5jdGlvbiBjcmVhdGVTZXNzaW9uRW52ZWxvcGUoCiAgc2Vzc2lvbiwKICBkc24sCiAgbWV0YWRhdGEsCiAgdHVubmVsLAopIHsKICBjb25zdCBzZGtJbmZvID0gZ2V0U2RrTWV0YWRhdGFGb3JFbnZlbG9wZUhlYWRlcihtZXRhZGF0YSk7CiAgY29uc3QgZW52ZWxvcGVIZWFkZXJzID0gewogICAgc2VudF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLAogICAgLi4uKHNka0luZm8gJiYgeyBzZGs6IHNka0luZm8gfSksCiAgICAuLi4oISF0dW5uZWwgJiYgZHNuICYmIHsgZHNuOiBkc25Ub1N0cmluZyhkc24pIH0pLAogIH07CgogIGNvbnN0IGVudmVsb3BlSXRlbSA9CiAgICAnYWdncmVnYXRlcycgaW4gc2Vzc2lvbiA/IFt7IHR5cGU6ICdzZXNzaW9ucycgfSwgc2Vzc2lvbl0gOiBbeyB0eXBlOiAnc2Vzc2lvbicgfSwgc2Vzc2lvbi50b0pTT04oKV07CgogIHJldHVybiBjcmVhdGVFbnZlbG9wZShlbnZlbG9wZUhlYWRlcnMsIFtlbnZlbG9wZUl0ZW1dKTsKfQoKLyoqCiAqIENyZWF0ZSBhbiBFbnZlbG9wZSBmcm9tIGFuIGV2ZW50LgogKi8KZnVuY3Rpb24gY3JlYXRlRXZlbnRFbnZlbG9wZSgKICBldmVudCwKICBkc24sCiAgbWV0YWRhdGEsCiAgdHVubmVsLAopIHsKICBjb25zdCBzZGtJbmZvID0gZ2V0U2RrTWV0YWRhdGFGb3JFbnZlbG9wZUhlYWRlcihtZXRhZGF0YSk7CgogIC8qCiAgICBOb3RlOiBEdWUgdG8gVFMsIGV2ZW50LnR5cGUgbWF5IGJlIGByZXBsYXlfZXZlbnRgLCB0aGVvcmV0aWNhbGx5LgogICAgSW4gcHJhY3RpY2UsIHdlIG5ldmVyIGNhbGwgYGNyZWF0ZUV2ZW50RW52ZWxvcGVgIHdpdGggYHJlcGxheV9ldmVudGAgdHlwZSwKICAgIGFuZCB3ZSdkIGhhdmUgdG8gYWRqdXQgYSBsb29vdCBvZiB0eXBlcyB0byBtYWtlIHRoaXMgd29yayBwcm9wZXJseS4KICAgIFdlIHdhbnQgdG8gYXZvaWQgY2FzdGluZyB0aGlzIGFyb3VuZCwgYXMgdGhhdCBjb3VsZCBsZWFkIHRvIGJ1Z3MgKGUuZy4gd2hlbiB3ZSBhZGQgYW5vdGhlciB0eXBlKQogICAgU28gdGhlIHNhZmUgY2hvaWNlIGlzIHRvIHJlYWxseSBndWFyZCBhZ2FpbnN0IHRoZSByZXBsYXlfZXZlbnQgdHlwZSBoZXJlLgogICovCiAgY29uc3QgZXZlbnRUeXBlID0gZXZlbnQudHlwZSAmJiBldmVudC50eXBlICE9PSAncmVwbGF5X2V2ZW50JyA/IGV2ZW50LnR5cGUgOiAnZXZlbnQnOwoKICBlbmhhbmNlRXZlbnRXaXRoU2RrSW5mbyhldmVudCwgbWV0YWRhdGEgJiYgbWV0YWRhdGEuc2RrKTsKCiAgY29uc3QgZW52ZWxvcGVIZWFkZXJzID0gY3JlYXRlRXZlbnRFbnZlbG9wZUhlYWRlcnMoZXZlbnQsIHNka0luZm8sIHR1bm5lbCwgZHNuKTsKCiAgLy8gUHJldmVudCB0aGlzIGRhdGEgKHdoaWNoLCBpZiBpdCBleGlzdHMsIHdhcyB1c2VkIGluIGVhcmxpZXIgc3RlcHMgaW4gdGhlIHByb2Nlc3NpbmcgcGlwZWxpbmUpIGZyb20gYmVpbmcgc2VudCB0bwogIC8vIHNlbnRyeS4gKE5vdGU6IE91ciB1c2Ugb2YgdGhpcyBwcm9wZXJ0eSBjb21lcyBhbmQgZ29lcyB3aXRoIHdoYXRldmVyIHdlIG1pZ2h0IGJlIGRlYnVnZ2luZywgd2hhdGV2ZXIgaGFja3Mgd2UgbWF5CiAgLy8gaGF2ZSB0ZW1wb3JhcmlseSBhZGRlZCwgZXRjLiBFdmVuIGlmIHdlIGRvbid0IGhhcHBlbiB0byBiZSB1c2luZyBpdCBhdCBzb21lIHBvaW50IGluIHRoZSBmdXR1cmUsIGxldCdzIG5vdCBnZXQgcmlkCiAgLy8gb2YgdGhpcyBgZGVsZXRlYCwgbGVzdCB3ZSBtaXNzIHB1dHRpbmcgaXQgYmFjayBpbiB0aGUgbmV4dCB0aW1lIHRoZSBwcm9wZXJ0eSBpcyBpbiB1c2UuKQogIGRlbGV0ZSBldmVudC5zZGtQcm9jZXNzaW5nTWV0YWRhdGE7CgogIGNvbnN0IGV2ZW50SXRlbSA9IFt7IHR5cGU6IGV2ZW50VHlwZSB9LCBldmVudF07CiAgcmV0dXJuIGNyZWF0ZUVudmVsb3BlKGVudmVsb3BlSGVhZGVycywgW2V2ZW50SXRlbV0pOwp9Cgpjb25zdCBTRU5UUllfQVBJX1ZFUlNJT04gPSAnNyc7CgovKiogUmV0dXJucyB0aGUgcHJlZml4IHRvIGNvbnN0cnVjdCBTZW50cnkgaW5nZXN0aW9uIEFQSSBlbmRwb2ludHMuICovCmZ1bmN0aW9uIGdldEJhc2VBcGlFbmRwb2ludChkc24pIHsKICBjb25zdCBwcm90b2NvbCA9IGRzbi5wcm90b2NvbCA/IGAke2Rzbi5wcm90b2NvbH06YCA6ICcnOwogIGNvbnN0IHBvcnQgPSBkc24ucG9ydCA/IGA6JHtkc24ucG9ydH1gIDogJyc7CiAgcmV0dXJuIGAke3Byb3RvY29sfS8vJHtkc24uaG9zdH0ke3BvcnR9JHtkc24ucGF0aCA/IGAvJHtkc24ucGF0aH1gIDogJyd9L2FwaS9gOwp9CgovKiogUmV0dXJucyB0aGUgaW5nZXN0IEFQSSBlbmRwb2ludCBmb3IgdGFyZ2V0LiAqLwpmdW5jdGlvbiBfZ2V0SW5nZXN0RW5kcG9pbnQoZHNuKSB7CiAgcmV0dXJuIGAke2dldEJhc2VBcGlFbmRwb2ludChkc24pfSR7ZHNuLnByb2plY3RJZH0vZW52ZWxvcGUvYDsKfQoKLyoqIFJldHVybnMgYSBVUkwtZW5jb2RlZCBzdHJpbmcgd2l0aCBhdXRoIGNvbmZpZyBzdWl0YWJsZSBmb3IgYSBxdWVyeSBzdHJpbmcuICovCmZ1bmN0aW9uIF9lbmNvZGVkQXV0aChkc24sIHNka0luZm8pIHsKICByZXR1cm4gdXJsRW5jb2RlKHsKICAgIC8vIFdlIHNlbmQgb25seSB0aGUgbWluaW11bSBzZXQgb2YgcmVxdWlyZWQgaW5mb3JtYXRpb24uIFNlZQogICAgLy8gaHR0cHM6Ly9naXRodWIuY29tL2dldHNlbnRyeS9zZW50cnktamF2YXNjcmlwdC9pc3N1ZXMvMjU3Mi4KICAgIHNlbnRyeV9rZXk6IGRzbi5wdWJsaWNLZXksCiAgICBzZW50cnlfdmVyc2lvbjogU0VOVFJZX0FQSV9WRVJTSU9OLAogICAgLi4uKHNka0luZm8gJiYgeyBzZW50cnlfY2xpZW50OiBgJHtzZGtJbmZvLm5hbWV9LyR7c2RrSW5mby52ZXJzaW9ufWAgfSksCiAgfSk7Cn0KCi8qKgogKiBSZXR1cm5zIHRoZSBlbnZlbG9wZSBlbmRwb2ludCBVUkwgd2l0aCBhdXRoIGluIHRoZSBxdWVyeSBzdHJpbmcuCiAqCiAqIFNlbmRpbmcgYXV0aCBhcyBwYXJ0IG9mIHRoZSBxdWVyeSBzdHJpbmcgYW5kIG5vdCBhcyBjdXN0b20gSFRUUCBoZWFkZXJzIGF2b2lkcyBDT1JTIHByZWZsaWdodCByZXF1ZXN0cy4KICovCmZ1bmN0aW9uIGdldEVudmVsb3BlRW5kcG9pbnRXaXRoVXJsRW5jb2RlZEF1dGgoCiAgZHNuLAogIC8vIFRPRE8gKHY4KTogUmVtb3ZlIGB0dW5uZWxPck9wdGlvbnNgIGluIGZhdm9yIG9mIGBvcHRpb25zYCwgYW5kIHVzZSB0aGUgc3Vic3RpdHV0ZSBjb2RlIGJlbG93CiAgLy8gb3B0aW9uczogQ2xpZW50T3B0aW9ucyA9IHt9IGFzIENsaWVudE9wdGlvbnMsCiAgdHVubmVsT3JPcHRpb25zID0ge30gLAopIHsKICAvLyBUT0RPICh2OCk6IFVzZSB0aGlzIGNvZGUgaW5zdGVhZAogIC8vIGNvbnN0IHsgdHVubmVsLCBfbWV0YWRhdGEgPSB7fSB9ID0gb3B0aW9uczsKICAvLyByZXR1cm4gdHVubmVsID8gdHVubmVsIDogYCR7X2dldEluZ2VzdEVuZHBvaW50KGRzbil9PyR7X2VuY29kZWRBdXRoKGRzbiwgX21ldGFkYXRhLnNkayl9YDsKCiAgY29uc3QgdHVubmVsID0gdHlwZW9mIHR1bm5lbE9yT3B0aW9ucyA9PT0gJ3N0cmluZycgPyB0dW5uZWxPck9wdGlvbnMgOiB0dW5uZWxPck9wdGlvbnMudHVubmVsOwogIGNvbnN0IHNka0luZm8gPQogICAgdHlwZW9mIHR1bm5lbE9yT3B0aW9ucyA9PT0gJ3N0cmluZycgfHwgIXR1bm5lbE9yT3B0aW9ucy5fbWV0YWRhdGEgPyB1bmRlZmluZWQgOiB0dW5uZWxPck9wdGlvbnMuX21ldGFkYXRhLnNkazsKCiAgcmV0dXJuIHR1bm5lbCA/IHR1bm5lbCA6IGAke19nZXRJbmdlc3RFbmRwb2ludChkc24pfT8ke19lbmNvZGVkQXV0aChkc24sIHNka0luZm8pfWA7Cn0KCmNvbnN0IERFRkFVTFRfVFJBTlNQT1JUX0JVRkZFUl9TSVpFID0gMzA7CgovKioKICogQ3JlYXRlcyBhbiBpbnN0YW5jZSBvZiBhIFNlbnRyeSBgVHJhbnNwb3J0YAogKgogKiBAcGFyYW0gb3B0aW9ucwogKiBAcGFyYW0gbWFrZVJlcXVlc3QKICovCmZ1bmN0aW9uIGNyZWF0ZVRyYW5zcG9ydCgKICBvcHRpb25zLAogIG1ha2VSZXF1ZXN0LAogIGJ1ZmZlciA9IG1ha2VQcm9taXNlQnVmZmVyKAogICAgb3B0aW9ucy5idWZmZXJTaXplIHx8IERFRkFVTFRfVFJBTlNQT1JUX0JVRkZFUl9TSVpFLAogICksCikgewogIGxldCByYXRlTGltaXRzID0ge307CiAgY29uc3QgZmx1c2ggPSAodGltZW91dCkgPT4gYnVmZmVyLmRyYWluKHRpbWVvdXQpOwoKICBmdW5jdGlvbiBzZW5kKGVudmVsb3BlKSB7CiAgICBjb25zdCBmaWx0ZXJlZEVudmVsb3BlSXRlbXMgPSBbXTsKCiAgICAvLyBEcm9wIHJhdGUgbGltaXRlZCBpdGVtcyBmcm9tIGVudmVsb3BlCiAgICBmb3JFYWNoRW52ZWxvcGVJdGVtKGVudmVsb3BlLCAoaXRlbSwgdHlwZSkgPT4gewogICAgICBjb25zdCBlbnZlbG9wZUl0ZW1EYXRhQ2F0ZWdvcnkgPSBlbnZlbG9wZUl0ZW1UeXBlVG9EYXRhQ2F0ZWdvcnkodHlwZSk7CiAgICAgIGlmIChpc1JhdGVMaW1pdGVkKHJhdGVMaW1pdHMsIGVudmVsb3BlSXRlbURhdGFDYXRlZ29yeSkpIHsKICAgICAgICBjb25zdCBldmVudCA9IGdldEV2ZW50Rm9yRW52ZWxvcGVJdGVtKGl0ZW0sIHR5cGUpOwogICAgICAgIG9wdGlvbnMucmVjb3JkRHJvcHBlZEV2ZW50KCdyYXRlbGltaXRfYmFja29mZicsIGVudmVsb3BlSXRlbURhdGFDYXRlZ29yeSwgZXZlbnQpOwogICAgICB9IGVsc2UgewogICAgICAgIGZpbHRlcmVkRW52ZWxvcGVJdGVtcy5wdXNoKGl0ZW0pOwogICAgICB9CiAgICB9KTsKCiAgICAvLyBTa2lwIHNlbmRpbmcgaWYgZW52ZWxvcGUgaXMgZW1wdHkgYWZ0ZXIgZmlsdGVyaW5nIG91dCByYXRlIGxpbWl0ZWQgZXZlbnRzCiAgICBpZiAoZmlsdGVyZWRFbnZlbG9wZUl0ZW1zLmxlbmd0aCA9PT0gMCkgewogICAgICByZXR1cm4gcmVzb2x2ZWRTeW5jUHJvbWlzZSgpOwogICAgfQoKICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55CiAgICBjb25zdCBmaWx0ZXJlZEVudmVsb3BlID0gY3JlYXRlRW52ZWxvcGUoZW52ZWxvcGVbMF0sIGZpbHRlcmVkRW52ZWxvcGVJdGVtcyApOwoKICAgIC8vIENyZWF0ZXMgY2xpZW50IHJlcG9ydCBmb3IgZWFjaCBpdGVtIGluIGFuIGVudmVsb3BlCiAgICBjb25zdCByZWNvcmRFbnZlbG9wZUxvc3MgPSAocmVhc29uKSA9PiB7CiAgICAgIGZvckVhY2hFbnZlbG9wZUl0ZW0oZmlsdGVyZWRFbnZlbG9wZSwgKGl0ZW0sIHR5cGUpID0+IHsKICAgICAgICBjb25zdCBldmVudCA9IGdldEV2ZW50Rm9yRW52ZWxvcGVJdGVtKGl0ZW0sIHR5cGUpOwogICAgICAgIG9wdGlvbnMucmVjb3JkRHJvcHBlZEV2ZW50KHJlYXNvbiwgZW52ZWxvcGVJdGVtVHlwZVRvRGF0YUNhdGVnb3J5KHR5cGUpLCBldmVudCk7CiAgICAgIH0pOwogICAgfTsKCiAgICBjb25zdCByZXF1ZXN0VGFzayA9ICgpID0+CiAgICAgIG1ha2VSZXF1ZXN0KHsgYm9keTogc2VyaWFsaXplRW52ZWxvcGUoZmlsdGVyZWRFbnZlbG9wZSwgb3B0aW9ucy50ZXh0RW5jb2RlcikgfSkudGhlbigKICAgICAgICByZXNwb25zZSA9PiB7CiAgICAgICAgICAvLyBXZSBkb24ndCB3YW50IHRvIHRocm93IG9uIE5PSyByZXNwb25zZXMsIGJ1dCB3ZSB3YW50IHRvIGF0IGxlYXN0IGxvZyB0aGVtCiAgICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzQ29kZSAhPT0gdW5kZWZpbmVkICYmIChyZXNwb25zZS5zdGF0dXNDb2RlIDwgMjAwIHx8IHJlc3BvbnNlLnN0YXR1c0NvZGUgPj0gMzAwKSkgewogICAgICAgICAgICBERUJVR19CVUlMRCAmJiBsb2dnZXIud2FybihgU2VudHJ5IHJlc3BvbmRlZCB3aXRoIHN0YXR1cyBjb2RlICR7cmVzcG9uc2Uuc3RhdHVzQ29kZX0gdG8gc2VudCBldmVudC5gKTsKICAgICAgICAgIH0KCiAgICAgICAgICByYXRlTGltaXRzID0gdXBkYXRlUmF0ZUxpbWl0cyhyYXRlTGltaXRzLCByZXNwb25zZSk7CiAgICAgICAgICByZXR1cm4gcmVzcG9uc2U7CiAgICAgICAgfSwKICAgICAgICBlcnJvciA9PiB7CiAgICAgICAgICByZWNvcmRFbnZlbG9wZUxvc3MoJ25ldHdvcmtfZXJyb3InKTsKICAgICAgICAgIHRocm93IGVycm9yOwogICAgICAgIH0sCiAgICAgICk7CgogICAgcmV0dXJuIGJ1ZmZlci5hZGQocmVxdWVzdFRhc2spLnRoZW4oCiAgICAgIHJlc3VsdCA9PiByZXN1bHQsCiAgICAgIGVycm9yID0+IHsKICAgICAgICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBTZW50cnlFcnJvcikgewogICAgICAgICAgREVCVUdfQlVJTEQgJiYgbG9nZ2VyLmVycm9yKCdTa2lwcGVkIHNlbmRpbmcgZXZlbnQgYmVjYXVzZSBidWZmZXIgaXMgZnVsbC4nKTsKICAgICAgICAgIHJlY29yZEVudmVsb3BlTG9zcygncXVldWVfb3ZlcmZsb3cnKTsKICAgICAgICAgIHJldHVybiByZXNvbHZlZFN5bmNQcm9taXNlKCk7CiAgICAgICAgfSBlbHNlIHsKICAgICAgICAgIHRocm93IGVycm9yOwogICAgICAgIH0KICAgICAgfSwKICAgICk7CiAgfQoKICAvLyBXZSB1c2UgdGhpcyB0byBpZGVudGlmaWZ5IGlmIHRoZSB0cmFuc3BvcnQgaXMgdGhlIGJhc2UgdHJhbnNwb3J0CiAgLy8gVE9ETyAodjgpOiBSZW1vdmUgdGhpcyBhZ2FpbiBhcyB3ZSdsbCBubyBsb25nZXIgbmVlZCBpdAogIHNlbmQuX19zZW50cnlfX2Jhc2VUcmFuc3BvcnRfXyA9IHRydWU7CgogIHJldHVybiB7CiAgICBzZW5kLAogICAgZmx1c2gsCiAgfTsKfQoKZnVuY3Rpb24gZ2V0RXZlbnRGb3JFbnZlbG9wZUl0ZW0oaXRlbSwgdHlwZSkgewogIGlmICh0eXBlICE9PSAnZXZlbnQnICYmIHR5cGUgIT09ICd0cmFuc2FjdGlvbicpIHsKICAgIHJldHVybiB1bmRlZmluZWQ7CiAgfQoKICByZXR1cm4gQXJyYXkuaXNBcnJheShpdGVtKSA/IChpdGVtIClbMV0gOiB1bmRlZmluZWQ7Cn0KCi8qKiBub3JtYWxpemVzIFdpbmRvd3MgcGF0aHMgKi8KZnVuY3Rpb24gbm9ybWFsaXplV2luZG93c1BhdGgocGF0aCkgewogIHJldHVybiBwYXRoCiAgICAucmVwbGFjZSgvXltBLVpdOi8sICcnKSAvLyByZW1vdmUgV2luZG93cy1zdHlsZSBwcmVmaXgKICAgIC5yZXBsYWNlKC9cXC9nLCAnLycpOyAvLyByZXBsYWNlIGFsbCBgXGAgaW5zdGFuY2VzIHdpdGggYC9gCn0KCi8qKiBDcmVhdGVzIGEgZnVuY3Rpb24gdGhhdCBnZXRzIHRoZSBtb2R1bGUgbmFtZSBmcm9tIGEgZmlsZW5hbWUgKi8KZnVuY3Rpb24gY3JlYXRlR2V0TW9kdWxlRnJvbUZpbGVuYW1lKAogIGJhc2VQYXRoID0gcHJvY2Vzcy5hcmd2WzFdID8gZGlybmFtZShwcm9jZXNzLmFyZ3ZbMV0pIDogcHJvY2Vzcy5jd2QoKSwKICBpc1dpbmRvd3MgPSBzZXAgPT09ICdcXCcsCikgewogIGNvbnN0IG5vcm1hbGl6ZWRCYXNlID0gaXNXaW5kb3dzID8gbm9ybWFsaXplV2luZG93c1BhdGgoYmFzZVBhdGgpIDogYmFzZVBhdGg7CgogIHJldHVybiAoZmlsZW5hbWUpID0+IHsKICAgIGlmICghZmlsZW5hbWUpIHsKICAgICAgcmV0dXJuOwogICAgfQoKICAgIGNvbnN0IG5vcm1hbGl6ZWRGaWxlbmFtZSA9IGlzV2luZG93cyA/IG5vcm1hbGl6ZVdpbmRvd3NQYXRoKGZpbGVuYW1lKSA6IGZpbGVuYW1lOwoKICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBwcmVmZXItY29uc3QKICAgIGxldCB7IGRpciwgYmFzZTogZmlsZSwgZXh0IH0gPSBwb3NpeC5wYXJzZShub3JtYWxpemVkRmlsZW5hbWUpOwoKICAgIGlmIChleHQgPT09ICcuanMnIHx8IGV4dCA9PT0gJy5tanMnIHx8IGV4dCA9PT0gJy5janMnKSB7CiAgICAgIGZpbGUgPSBmaWxlLnNsaWNlKDAsIGV4dC5sZW5ndGggKiAtMSk7CiAgICB9CgogICAgaWYgKCFkaXIpIHsKICAgICAgLy8gTm8gZGlybmFtZSB3aGF0c29ldmVyCiAgICAgIGRpciA9ICcuJzsKICAgIH0KCiAgICBjb25zdCBuID0gZGlyLmxhc3RJbmRleE9mKCcvbm9kZV9tb2R1bGVzJyk7CiAgICBpZiAobiA+IC0xKSB7CiAgICAgIHJldHVybiBgJHtkaXIuc2xpY2UobiArIDE0KS5yZXBsYWNlKC9cLy9nLCAnLicpfToke2ZpbGV9YDsKICAgIH0KCiAgICAvLyBMZXQncyBzZWUgaWYgaXQncyBhIHBhcnQgb2YgdGhlIG1haW4gbW9kdWxlCiAgICAvLyBUbyBiZSBhIHBhcnQgb2YgbWFpbiBtb2R1bGUsIGl0IGhhcyB0byBzaGFyZSB0aGUgc2FtZSBiYXNlCiAgICBpZiAoZGlyLnN0YXJ0c1dpdGgobm9ybWFsaXplZEJhc2UpKSB7CiAgICAgIGxldCBtb2R1bGVOYW1lID0gZGlyLnNsaWNlKG5vcm1hbGl6ZWRCYXNlLmxlbmd0aCArIDEpLnJlcGxhY2UoL1wvL2csICcuJyk7CgogICAgICBpZiAobW9kdWxlTmFtZSkgewogICAgICAgIG1vZHVsZU5hbWUgKz0gJzonOwogICAgICB9CiAgICAgIG1vZHVsZU5hbWUgKz0gZmlsZTsKCiAgICAgIHJldHVybiBtb2R1bGVOYW1lOwogICAgfQoKICAgIHJldHVybiBmaWxlOwogIH07Cn0KCmZ1bmN0aW9uIF9udWxsaXNoQ29hbGVzY2UkMihsaHMsIHJoc0ZuKSB7IGlmIChsaHMgIT0gbnVsbCkgeyByZXR1cm4gbGhzOyB9IGVsc2UgeyByZXR1cm4gcmhzRm4oKTsgfSB9LyoqCiAqIFRoaXMgY29kZSB3YXMgb3JpZ2luYWxseSBmb3JrZWQgZnJvbSBodHRwczovL2dpdGh1Yi5jb20vVG9vVGFsbE5hdGUvcHJveHktYWdlbnRzL3RyZWUvYjEzMzI5NWZkMTZmNjQ3NTU3OGI2YjE1YmQ5YjRlMzNlY2IwZDBiNwogKiBXaXRoIHRoZSBmb2xsb3dpbmcgbGljZW5jZToKICoKICogKFRoZSBNSVQgTGljZW5zZSkKICoKICogQ29weXJpZ2h0IChjKSAyMDEzIE5hdGhhbiBSYWpsaWNoIDxuYXRoYW5AdG9vdGFsbG5hdGUubmV0PioKICoKICogUGVybWlzc2lvbiBpcyBoZXJlYnkgZ3JhbnRlZCwgZnJlZSBvZiBjaGFyZ2UsIHRvIGFueSBwZXJzb24gb2J0YWluaW5nCiAqIGEgY29weSBvZiB0aGlzIHNvZnR3YXJlIGFuZCBhc3NvY2lhdGVkIGRvY3VtZW50YXRpb24gZmlsZXMgKHRoZQogKiAnU29mdHdhcmUnKSwgdG8gZGVhbCBpbiB0aGUgU29mdHdhcmUgd2l0aG91dCByZXN0cmljdGlvbiwgaW5jbHVkaW5nCiAqIHdpdGhvdXQgbGltaXRhdGlvbiB0aGUgcmlnaHRzIHRvIHVzZSwgY29weSwgbW9kaWZ5LCBtZXJnZSwgcHVibGlzaCwKICogZGlzdHJpYnV0ZSwgc3VibGljZW5zZSwgYW5kL29yIHNlbGwgY29waWVzIG9mIHRoZSBTb2Z0d2FyZSwgYW5kIHRvCiAqIHBlcm1pdCBwZXJzb25zIHRvIHdob20gdGhlIFNvZnR3YXJlIGlzIGZ1cm5pc2hlZCB0byBkbyBzbywgc3ViamVjdCB0bwogKiB0aGUgZm9sbG93aW5nIGNvbmRpdGlvbnM6KgogKgogKiBUaGUgYWJvdmUgY29weXJpZ2h0IG5vdGljZSBhbmQgdGhpcyBwZXJtaXNzaW9uIG5vdGljZSBzaGFsbCBiZQogKiBpbmNsdWRlZCBpbiBhbGwgY29waWVzIG9yIHN1YnN0YW50aWFsIHBvcnRpb25zIG9mIHRoZSBTb2Z0d2FyZS4qCiAqCiAqIFRIRSBTT0ZUV0FSRSBJUyBQUk9WSURFRCAnQVMgSVMnLCBXSVRIT1VUIFdBUlJBTlRZIE9GIEFOWSBLSU5ELAogKiBFWFBSRVNTIE9SIElNUExJRUQsIElOQ0xVRElORyBCVVQgTk9UIExJTUlURUQgVE8gVEhFIFdBUlJBTlRJRVMgT0YKICogTUVSQ0hBTlRBQklMSVRZLCBGSVRORVNTIEZPUiBBIFBBUlRJQ1VMQVIgUFVSUE9TRSBBTkQgTk9OSU5GUklOR0VNRU5ULgogKiBJTiBOTyBFVkVOVCBTSEFMTCBUSEUgQVVUSE9SUyBPUiBDT1BZUklHSFQgSE9MREVSUyBCRSBMSUFCTEUgRk9SIEFOWQogKiBDTEFJTSwgREFNQUdFUyBPUiBPVEhFUiBMSUFCSUxJVFksIFdIRVRIRVIgSU4gQU4gQUNUSU9OIE9GIENPTlRSQUNULAogKiBUT1JUIE9SIE9USEVSV0lTRSwgQVJJU0lORyBGUk9NLCBPVVQgT0YgT1IgSU4gQ09OTkVDVElPTiBXSVRIIFRIRQogKiBTT0ZUV0FSRSBPUiBUSEUgVVNFIE9SIE9USEVSIERFQUxJTkdTIElOIFRIRSBTT0ZUV0FSRS4KICovCgpjb25zdCBJTlRFUk5BTCA9IFN5bWJvbCgnQWdlbnRCYXNlSW50ZXJuYWxTdGF0ZScpOwoKY2xhc3MgQWdlbnQgZXh0ZW5kcyBodHRwLkFnZW50IHsKCiAgLy8gU2V0IGJ5IGBodHRwLkFnZW50YCAtIG1pc3NpbmcgZnJvbSBgQHR5cGVzL25vZGVgCgogIGNvbnN0cnVjdG9yKG9wdHMpIHsKICAgIHN1cGVyKG9wdHMpOwogICAgdGhpc1tJTlRFUk5BTF0gPSB7fTsKICB9CgogIC8qKgogICAqIERldGVybWluZSB3aGV0aGVyIHRoaXMgaXMgYW4gYGh0dHBgIG9yIGBodHRwc2AgcmVxdWVzdC4KICAgKi8KICBpc1NlY3VyZUVuZHBvaW50KG9wdGlvbnMpIHsKICAgIGlmIChvcHRpb25zKSB7CiAgICAgIC8vIEZpcnN0IGNoZWNrIHRoZSBgc2VjdXJlRW5kcG9pbnRgIHByb3BlcnR5IGV4cGxpY2l0bHksIHNpbmNlIHRoaXMKICAgICAgLy8gbWVhbnMgdGhhdCBhIHBhcmVudCBgQWdlbnRgIGlzICJwYXNzaW5nIHRocm91Z2giIHRvIHRoaXMgaW5zdGFuY2UuCiAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55LCBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tdW5zYWZlLW1lbWJlci1hY2Nlc3MKICAgICAgaWYgKHR5cGVvZiAob3B0aW9ucyApLnNlY3VyZUVuZHBvaW50ID09PSAnYm9vbGVhbicpIHsKICAgICAgICByZXR1cm4gb3B0aW9ucy5zZWN1cmVFbmRwb2ludDsKICAgICAgfQoKICAgICAgLy8gSWYgbm8gZXhwbGljaXQgYHNlY3VyZWAgZW5kcG9pbnQsIGNoZWNrIGlmIGBwcm90b2NvbGAgcHJvcGVydHkgaXMKICAgICAgLy8gc2V0LiBUaGlzIHdpbGwgdXN1YWxseSBiZSB0aGUgY2FzZSBzaW5jZSB1c2luZyBhIGZ1bGwgc3RyaW5nIFVSTAogICAgICAvLyBvciBgVVJMYCBpbnN0YW5jZSBzaG91bGQgYmUgdGhlIG1vc3QgY29tbW9uIHVzYWdlLgogICAgICBpZiAodHlwZW9mIG9wdGlvbnMucHJvdG9jb2wgPT09ICdzdHJpbmcnKSB7CiAgICAgICAgcmV0dXJuIG9wdGlvbnMucHJvdG9jb2wgPT09ICdodHRwczonOwogICAgICB9CiAgICB9CgogICAgLy8gRmluYWxseSwgaWYgbm8gYHByb3RvY29sYCBwcm9wZXJ0eSB3YXMgc2V0LCB0aGVuIGZhbGwgYmFjayB0bwogICAgLy8gY2hlY2tpbmcgdGhlIHN0YWNrIHRyYWNlIG9mIHRoZSBjdXJyZW50IGNhbGwgc3RhY2ssIGFuZCB0cnkgdG8KICAgIC8vIGRldGVjdCB0aGUgImh0dHBzIiBtb2R1bGUuCiAgICBjb25zdCB7IHN0YWNrIH0gPSBuZXcgRXJyb3IoKTsKICAgIGlmICh0eXBlb2Ygc3RhY2sgIT09ICdzdHJpbmcnKSByZXR1cm4gZmFsc2U7CiAgICByZXR1cm4gc3RhY2suc3BsaXQoJ1xuJykuc29tZShsID0+IGwuaW5kZXhPZignKGh0dHBzLmpzOicpICE9PSAtMSB8fCBsLmluZGV4T2YoJ25vZGU6aHR0cHM6JykgIT09IC0xKTsKICB9CgogIGNyZWF0ZVNvY2tldChyZXEsIG9wdGlvbnMsIGNiKSB7CiAgICBjb25zdCBjb25uZWN0T3B0cyA9IHsKICAgICAgLi4ub3B0aW9ucywKICAgICAgc2VjdXJlRW5kcG9pbnQ6IHRoaXMuaXNTZWN1cmVFbmRwb2ludChvcHRpb25zKSwKICAgIH07CiAgICBQcm9taXNlLnJlc29sdmUoKQogICAgICAudGhlbigoKSA9PiB0aGlzLmNvbm5lY3QocmVxLCBjb25uZWN0T3B0cykpCiAgICAgIC50aGVuKHNvY2tldCA9PiB7CiAgICAgICAgaWYgKHNvY2tldCBpbnN0YW5jZW9mIGh0dHAuQWdlbnQpIHsKICAgICAgICAgIC8vIEB0cy1leHBlY3QtZXJyb3IgYGFkZFJlcXVlc3QoKWAgaXNuJ3QgZGVmaW5lZCBpbiBgQHR5cGVzL25vZGVgCiAgICAgICAgICByZXR1cm4gc29ja2V0LmFkZFJlcXVlc3QocmVxLCBjb25uZWN0T3B0cyk7CiAgICAgICAgfQogICAgICAgIHRoaXNbSU5URVJOQUxdLmN1cnJlbnRTb2NrZXQgPSBzb2NrZXQ7CiAgICAgICAgLy8gQHRzLWV4cGVjdC1lcnJvciBgY3JlYXRlU29ja2V0KClgIGlzbid0IGRlZmluZWQgaW4gYEB0eXBlcy9ub2RlYAogICAgICAgIHN1cGVyLmNyZWF0ZVNvY2tldChyZXEsIG9wdGlvbnMsIGNiKTsKICAgICAgfSwgY2IpOwogIH0KCiAgY3JlYXRlQ29ubmVjdGlvbigpIHsKICAgIGNvbnN0IHNvY2tldCA9IHRoaXNbSU5URVJOQUxdLmN1cnJlbnRTb2NrZXQ7CiAgICB0aGlzW0lOVEVSTkFMXS5jdXJyZW50U29ja2V0ID0gdW5kZWZpbmVkOwogICAgaWYgKCFzb2NrZXQpIHsKICAgICAgdGhyb3cgbmV3IEVycm9yKCdObyBzb2NrZXQgd2FzIHJldHVybmVkIGluIHRoZSBgY29ubmVjdCgpYCBmdW5jdGlvbicpOwogICAgfQogICAgcmV0dXJuIHNvY2tldDsKICB9CgogIGdldCBkZWZhdWx0UG9ydCgpIHsKICAgIHJldHVybiBfbnVsbGlzaENvYWxlc2NlJDIodGhpc1tJTlRFUk5BTF0uZGVmYXVsdFBvcnQsICgpID0+ICggKHRoaXMucHJvdG9jb2wgPT09ICdodHRwczonID8gNDQzIDogODApKSk7CiAgfQoKICBzZXQgZGVmYXVsdFBvcnQodikgewogICAgaWYgKHRoaXNbSU5URVJOQUxdKSB7CiAgICAgIHRoaXNbSU5URVJOQUxdLmRlZmF1bHRQb3J0ID0gdjsKICAgIH0KICB9CgogIGdldCBwcm90b2NvbCgpIHsKICAgIHJldHVybiBfbnVsbGlzaENvYWxlc2NlJDIodGhpc1tJTlRFUk5BTF0ucHJvdG9jb2wsICgpID0+ICggKHRoaXMuaXNTZWN1cmVFbmRwb2ludCgpID8gJ2h0dHBzOicgOiAnaHR0cDonKSkpOwogIH0KCiAgc2V0IHByb3RvY29sKHYpIHsKICAgIGlmICh0aGlzW0lOVEVSTkFMXSkgewogICAgICB0aGlzW0lOVEVSTkFMXS5wcm90b2NvbCA9IHY7CiAgICB9CiAgfQp9CgpmdW5jdGlvbiBkZWJ1ZyQxKC4uLmFyZ3MpIHsKICBsb2dnZXIubG9nKCdbaHR0cHMtcHJveHktYWdlbnQ6cGFyc2UtcHJveHktcmVzcG9uc2VdJywgLi4uYXJncyk7Cn0KCmZ1bmN0aW9uIHBhcnNlUHJveHlSZXNwb25zZShzb2NrZXQpIHsKICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4gewogICAgLy8gd2UgbmVlZCB0byBidWZmZXIgYW55IEhUVFAgdHJhZmZpYyB0aGF0IGhhcHBlbnMgd2l0aCB0aGUgcHJveHkgYmVmb3JlIHdlIGdldAogICAgLy8gdGhlIENPTk5FQ1QgcmVzcG9uc2UsIHNvIHRoYXQgaWYgdGhlIHJlc3BvbnNlIGlzIGFueXRoaW5nIG90aGVyIHRoYW4gYW4gIjIwMCIKICAgIC8vIHJlc3BvbnNlIGNvZGUsIHRoZW4gd2UgY2FuIHJlLXBsYXkgdGhlICJkYXRhIiBldmVudHMgb24gdGhlIHNvY2tldCBvbmNlIHRoZQogICAgLy8gSFRUUCBwYXJzZXIgaXMgaG9va2VkIHVwLi4uCiAgICBsZXQgYnVmZmVyc0xlbmd0aCA9IDA7CiAgICBjb25zdCBidWZmZXJzID0gW107CgogICAgZnVuY3Rpb24gcmVhZCgpIHsKICAgICAgY29uc3QgYiA9IHNvY2tldC5yZWFkKCk7CiAgICAgIGlmIChiKSBvbmRhdGEoYik7CiAgICAgIGVsc2Ugc29ja2V0Lm9uY2UoJ3JlYWRhYmxlJywgcmVhZCk7CiAgICB9CgogICAgZnVuY3Rpb24gY2xlYW51cCgpIHsKICAgICAgc29ja2V0LnJlbW92ZUxpc3RlbmVyKCdlbmQnLCBvbmVuZCk7CiAgICAgIHNvY2tldC5yZW1vdmVMaXN0ZW5lcignZXJyb3InLCBvbmVycm9yKTsKICAgICAgc29ja2V0LnJlbW92ZUxpc3RlbmVyKCdyZWFkYWJsZScsIHJlYWQpOwogICAgfQoKICAgIGZ1bmN0aW9uIG9uZW5kKCkgewogICAgICBjbGVhbnVwKCk7CiAgICAgIGRlYnVnJDEoJ29uZW5kJyk7CiAgICAgIHJlamVjdChuZXcgRXJyb3IoJ1Byb3h5IGNvbm5lY3Rpb24gZW5kZWQgYmVmb3JlIHJlY2VpdmluZyBDT05ORUNUIHJlc3BvbnNlJykpOwogICAgfQoKICAgIGZ1bmN0aW9uIG9uZXJyb3IoZXJyKSB7CiAgICAgIGNsZWFudXAoKTsKICAgICAgZGVidWckMSgnb25lcnJvciAlbycsIGVycik7CiAgICAgIHJlamVjdChlcnIpOwogICAgfQoKICAgIGZ1bmN0aW9uIG9uZGF0YShiKSB7CiAgICAgIGJ1ZmZlcnMucHVzaChiKTsKICAgICAgYnVmZmVyc0xlbmd0aCArPSBiLmxlbmd0aDsKCiAgICAgIGNvbnN0IGJ1ZmZlcmVkID0gQnVmZmVyLmNvbmNhdChidWZmZXJzLCBidWZmZXJzTGVuZ3RoKTsKICAgICAgY29uc3QgZW5kT2ZIZWFkZXJzID0gYnVmZmVyZWQuaW5kZXhPZignXHJcblxyXG4nKTsKCiAgICAgIGlmIChlbmRPZkhlYWRlcnMgPT09IC0xKSB7CiAgICAgICAgLy8ga2VlcCBidWZmZXJpbmcKICAgICAgICBkZWJ1ZyQxKCdoYXZlIG5vdCByZWNlaXZlZCBlbmQgb2YgSFRUUCBoZWFkZXJzIHlldC4uLicpOwogICAgICAgIHJlYWQoKTsKICAgICAgICByZXR1cm47CiAgICAgIH0KCiAgICAgIGNvbnN0IGhlYWRlclBhcnRzID0gYnVmZmVyZWQuc2xpY2UoMCwgZW5kT2ZIZWFkZXJzKS50b1N0cmluZygnYXNjaWknKS5zcGxpdCgnXHJcbicpOwogICAgICBjb25zdCBmaXJzdExpbmUgPSBoZWFkZXJQYXJ0cy5zaGlmdCgpOwogICAgICBpZiAoIWZpcnN0TGluZSkgewogICAgICAgIHNvY2tldC5kZXN0cm95KCk7CiAgICAgICAgcmV0dXJuIHJlamVjdChuZXcgRXJyb3IoJ05vIGhlYWRlciByZWNlaXZlZCBmcm9tIHByb3h5IENPTk5FQ1QgcmVzcG9uc2UnKSk7CiAgICAgIH0KICAgICAgY29uc3QgZmlyc3RMaW5lUGFydHMgPSBmaXJzdExpbmUuc3BsaXQoJyAnKTsKICAgICAgY29uc3Qgc3RhdHVzQ29kZSA9ICtmaXJzdExpbmVQYXJ0c1sxXTsKICAgICAgY29uc3Qgc3RhdHVzVGV4dCA9IGZpcnN0TGluZVBhcnRzLnNsaWNlKDIpLmpvaW4oJyAnKTsKICAgICAgY29uc3QgaGVhZGVycyA9IHt9OwogICAgICBmb3IgKGNvbnN0IGhlYWRlciBvZiBoZWFkZXJQYXJ0cykgewogICAgICAgIGlmICghaGVhZGVyKSBjb250aW51ZTsKICAgICAgICBjb25zdCBmaXJzdENvbG9uID0gaGVhZGVyLmluZGV4T2YoJzonKTsKICAgICAgICBpZiAoZmlyc3RDb2xvbiA9PT0gLTEpIHsKICAgICAgICAgIHNvY2tldC5kZXN0cm95KCk7CiAgICAgICAgICByZXR1cm4gcmVqZWN0KG5ldyBFcnJvcihgSW52YWxpZCBoZWFkZXIgZnJvbSBwcm94eSBDT05ORUNUIHJlc3BvbnNlOiAiJHtoZWFkZXJ9ImApKTsKICAgICAgICB9CiAgICAgICAgY29uc3Qga2V5ID0gaGVhZGVyLnNsaWNlKDAsIGZpcnN0Q29sb24pLnRvTG93ZXJDYXNlKCk7CiAgICAgICAgY29uc3QgdmFsdWUgPSBoZWFkZXIuc2xpY2UoZmlyc3RDb2xvbiArIDEpLnRyaW1TdGFydCgpOwogICAgICAgIGNvbnN0IGN1cnJlbnQgPSBoZWFkZXJzW2tleV07CiAgICAgICAgaWYgKHR5cGVvZiBjdXJyZW50ID09PSAnc3RyaW5nJykgewogICAgICAgICAgaGVhZGVyc1trZXldID0gW2N1cnJlbnQsIHZhbHVlXTsKICAgICAgICB9IGVsc2UgaWYgKEFycmF5LmlzQXJyYXkoY3VycmVudCkpIHsKICAgICAgICAgIGN1cnJlbnQucHVzaCh2YWx1ZSk7CiAgICAgICAgfSBlbHNlIHsKICAgICAgICAgIGhlYWRlcnNba2V5XSA9IHZhbHVlOwogICAgICAgIH0KICAgICAgfQogICAgICBkZWJ1ZyQxKCdnb3QgcHJveHkgc2VydmVyIHJlc3BvbnNlOiAlbyAlbycsIGZpcnN0TGluZSwgaGVhZGVycyk7CiAgICAgIGNsZWFudXAoKTsKICAgICAgcmVzb2x2ZSh7CiAgICAgICAgY29ubmVjdDogewogICAgICAgICAgc3RhdHVzQ29kZSwKICAgICAgICAgIHN0YXR1c1RleHQsCiAgICAgICAgICBoZWFkZXJzLAogICAgICAgIH0sCiAgICAgICAgYnVmZmVyZWQsCiAgICAgIH0pOwogICAgfQoKICAgIHNvY2tldC5vbignZXJyb3InLCBvbmVycm9yKTsKICAgIHNvY2tldC5vbignZW5kJywgb25lbmQpOwoKICAgIHJlYWQoKTsKICB9KTsKfQoKZnVuY3Rpb24gX251bGxpc2hDb2FsZXNjZSQxKGxocywgcmhzRm4pIHsgaWYgKGxocyAhPSBudWxsKSB7IHJldHVybiBsaHM7IH0gZWxzZSB7IHJldHVybiByaHNGbigpOyB9IH0gZnVuY3Rpb24gX29wdGlvbmFsQ2hhaW4kMShvcHMpIHsgbGV0IGxhc3RBY2Nlc3NMSFMgPSB1bmRlZmluZWQ7IGxldCB2YWx1ZSA9IG9wc1swXTsgbGV0IGkgPSAxOyB3aGlsZSAoaSA8IG9wcy5sZW5ndGgpIHsgY29uc3Qgb3AgPSBvcHNbaV07IGNvbnN0IGZuID0gb3BzW2kgKyAxXTsgaSArPSAyOyBpZiAoKG9wID09PSAnb3B0aW9uYWxBY2Nlc3MnIHx8IG9wID09PSAnb3B0aW9uYWxDYWxsJykgJiYgdmFsdWUgPT0gbnVsbCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9IGlmIChvcCA9PT0gJ2FjY2VzcycgfHwgb3AgPT09ICdvcHRpb25hbEFjY2VzcycpIHsgbGFzdEFjY2Vzc0xIUyA9IHZhbHVlOyB2YWx1ZSA9IGZuKHZhbHVlKTsgfSBlbHNlIGlmIChvcCA9PT0gJ2NhbGwnIHx8IG9wID09PSAnb3B0aW9uYWxDYWxsJykgeyB2YWx1ZSA9IGZuKCguLi5hcmdzKSA9PiB2YWx1ZS5jYWxsKGxhc3RBY2Nlc3NMSFMsIC4uLmFyZ3MpKTsgbGFzdEFjY2Vzc0xIUyA9IHVuZGVmaW5lZDsgfSB9IHJldHVybiB2YWx1ZTsgfS8qKgogKiBUaGlzIGNvZGUgd2FzIG9yaWdpbmFsbHkgZm9ya2VkIGZyb20gaHR0cHM6Ly9naXRodWIuY29tL1Rvb1RhbGxOYXRlL3Byb3h5LWFnZW50cy90cmVlL2IxMzMyOTVmZDE2ZjY0NzU1NzhiNmIxNWJkOWI0ZTMzZWNiMGQwYjcKICogV2l0aCB0aGUgZm9sbG93aW5nIGxpY2VuY2U6CiAqCiAqIChUaGUgTUlUIExpY2Vuc2UpCiAqCiAqIENvcHlyaWdodCAoYykgMjAxMyBOYXRoYW4gUmFqbGljaCA8bmF0aGFuQHRvb3RhbGxuYXRlLm5ldD4qCiAqCiAqIFBlcm1pc3Npb24gaXMgaGVyZWJ5IGdyYW50ZWQsIGZyZWUgb2YgY2hhcmdlLCB0byBhbnkgcGVyc29uIG9idGFpbmluZwogKiBhIGNvcHkgb2YgdGhpcyBzb2Z0d2FyZSBhbmQgYXNzb2NpYXRlZCBkb2N1bWVudGF0aW9uIGZpbGVzICh0aGUKICogJ1NvZnR3YXJlJyksIHRvIGRlYWwgaW4gdGhlIFNvZnR3YXJlIHdpdGhvdXQgcmVzdHJpY3Rpb24sIGluY2x1ZGluZwogKiB3aXRob3V0IGxpbWl0YXRpb24gdGhlIHJpZ2h0cyB0byB1c2UsIGNvcHksIG1vZGlmeSwgbWVyZ2UsIHB1Ymxpc2gsCiAqIGRpc3RyaWJ1dGUsIHN1YmxpY2Vuc2UsIGFuZC9vciBzZWxsIGNvcGllcyBvZiB0aGUgU29mdHdhcmUsIGFuZCB0bwogKiBwZXJtaXQgcGVyc29ucyB0byB3aG9tIHRoZSBTb2Z0d2FyZSBpcyBmdXJuaXNoZWQgdG8gZG8gc28sIHN1YmplY3QgdG8KICogdGhlIGZvbGxvd2luZyBjb25kaXRpb25zOioKICoKICogVGhlIGFib3ZlIGNvcHlyaWdodCBub3RpY2UgYW5kIHRoaXMgcGVybWlzc2lvbiBub3RpY2Ugc2hhbGwgYmUKICogaW5jbHVkZWQgaW4gYWxsIGNvcGllcyBvciBzdWJzdGFudGlhbCBwb3J0aW9ucyBvZiB0aGUgU29mdHdhcmUuKgogKgogKiBUSEUgU09GVFdBUkUgSVMgUFJPVklERUQgJ0FTIElTJywgV0lUSE9VVCBXQVJSQU5UWSBPRiBBTlkgS0lORCwKICogRVhQUkVTUyBPUiBJTVBMSUVELCBJTkNMVURJTkcgQlVUIE5PVCBMSU1JVEVEIFRPIFRIRSBXQVJSQU5USUVTIE9GCiAqIE1FUkNIQU5UQUJJTElUWSwgRklUTkVTUyBGT1IgQSBQQVJUSUNVTEFSIFBVUlBPU0UgQU5EIE5PTklORlJJTkdFTUVOVC4KICogSU4gTk8gRVZFTlQgU0hBTEwgVEhFIEFVVEhPUlMgT1IgQ09QWVJJR0hUIEhPTERFUlMgQkUgTElBQkxFIEZPUiBBTlkKICogQ0xBSU0sIERBTUFHRVMgT1IgT1RIRVIgTElBQklMSVRZLCBXSEVUSEVSIElOIEFOIEFDVElPTiBPRiBDT05UUkFDVCwKICogVE9SVCBPUiBPVEhFUldJU0UsIEFSSVNJTkcgRlJPTSwgT1VUIE9GIE9SIElOIENPTk5FQ1RJT04gV0lUSCBUSEUKICogU09GVFdBUkUgT1IgVEhFIFVTRSBPUiBPVEhFUiBERUFMSU5HUyBJTiBUSEUgU09GVFdBUkUuCiAqLwoKZnVuY3Rpb24gZGVidWcoLi4uYXJncykgewogIGxvZ2dlci5sb2coJ1todHRwcy1wcm94eS1hZ2VudF0nLCAuLi5hcmdzKTsKfQoKLyoqCiAqIFRoZSBgSHR0cHNQcm94eUFnZW50YCBpbXBsZW1lbnRzIGFuIEhUVFAgQWdlbnQgc3ViY2xhc3MgdGhhdCBjb25uZWN0cyB0bwogKiB0aGUgc3BlY2lmaWVkICJIVFRQKHMpIHByb3h5IHNlcnZlciIgaW4gb3JkZXIgdG8gcHJveHkgSFRUUFMgcmVxdWVzdHMuCiAqCiAqIE91dGdvaW5nIEhUVFAgcmVxdWVzdHMgYXJlIGZpcnN0IHR1bm5lbGVkIHRocm91Z2ggdGhlIHByb3h5IHNlcnZlciB1c2luZyB0aGUKICogYENPTk5FQ1RgIEhUVFAgcmVxdWVzdCBtZXRob2QgdG8gZXN0YWJsaXNoIGEgY29ubmVjdGlvbiB0byB0aGUgcHJveHkgc2VydmVyLAogKiBhbmQgdGhlbiB0aGUgcHJveHkgc2VydmVyIGNvbm5lY3RzIHRvIHRoZSBkZXN0aW5hdGlvbiB0YXJnZXQgYW5kIGlzc3VlcyB0aGUKICogSFRUUCByZXF1ZXN0IGZyb20gdGhlIHByb3h5IHNlcnZlci4KICoKICogYGh0dHBzOmAgcmVxdWVzdHMgaGF2ZSB0aGVpciBzb2NrZXQgY29ubmVjdGlvbiB1cGdyYWRlZCB0byBUTFMgb25jZQogKiB0aGUgY29ubmVjdGlvbiB0byB0aGUgcHJveHkgc2VydmVyIGhhcyBiZWVuIGVzdGFibGlzaGVkLgogKi8KY2xhc3MgSHR0cHNQcm94eUFnZW50IGV4dGVuZHMgQWdlbnQgewogIHN0YXRpYyBfX2luaXRTdGF0aWMoKSB7dGhpcy5wcm90b2NvbHMgPSBbJ2h0dHAnLCAnaHR0cHMnXTsgfQoKICBjb25zdHJ1Y3Rvcihwcm94eSwgb3B0cykgewogICAgc3VwZXIob3B0cyk7CiAgICB0aGlzLm9wdGlvbnMgPSB7fTsKICAgIHRoaXMucHJveHkgPSB0eXBlb2YgcHJveHkgPT09ICdzdHJpbmcnID8gbmV3IFVSTChwcm94eSkgOiBwcm94eTsKICAgIHRoaXMucHJveHlIZWFkZXJzID0gX251bGxpc2hDb2FsZXNjZSQxKF9vcHRpb25hbENoYWluJDEoW29wdHMsICdvcHRpb25hbEFjY2VzcycsIF8yID0+IF8yLmhlYWRlcnNdKSwgKCkgPT4gKCB7fSkpOwogICAgZGVidWcoJ0NyZWF0aW5nIG5ldyBIdHRwc1Byb3h5QWdlbnQgaW5zdGFuY2U6ICVvJywgdGhpcy5wcm94eS5ocmVmKTsKCiAgICAvLyBUcmltIG9mZiB0aGUgYnJhY2tldHMgZnJvbSBJUHY2IGFkZHJlc3NlcwogICAgY29uc3QgaG9zdCA9ICh0aGlzLnByb3h5Lmhvc3RuYW1lIHx8IHRoaXMucHJveHkuaG9zdCkucmVwbGFjZSgvXlxbfFxdJC9nLCAnJyk7CiAgICBjb25zdCBwb3J0ID0gdGhpcy5wcm94eS5wb3J0ID8gcGFyc2VJbnQodGhpcy5wcm94eS5wb3J0LCAxMCkgOiB0aGlzLnByb3h5LnByb3RvY29sID09PSAnaHR0cHM6JyA/IDQ0MyA6IDgwOwogICAgdGhpcy5jb25uZWN0T3B0cyA9IHsKICAgICAgLy8gQXR0ZW1wdCB0byBuZWdvdGlhdGUgaHR0cC8xLjEgZm9yIHByb3h5IHNlcnZlcnMgdGhhdCBzdXBwb3J0IGh0dHAvMgogICAgICBBTFBOUHJvdG9jb2xzOiBbJ2h0dHAvMS4xJ10sCiAgICAgIC4uLihvcHRzID8gb21pdChvcHRzLCAnaGVhZGVycycpIDogbnVsbCksCiAgICAgIGhvc3QsCiAgICAgIHBvcnQsCiAgICB9OwogIH0KCiAgLyoqCiAgICogQ2FsbGVkIHdoZW4gdGhlIG5vZGUtY29yZSBIVFRQIGNsaWVudCBsaWJyYXJ5IGlzIGNyZWF0aW5nIGEKICAgKiBuZXcgSFRUUCByZXF1ZXN0LgogICAqLwogIGFzeW5jIGNvbm5lY3QocmVxLCBvcHRzKSB7CiAgICBjb25zdCB7IHByb3h5IH0gPSB0aGlzOwoKICAgIGlmICghb3B0cy5ob3N0KSB7CiAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ05vICJob3N0IiBwcm92aWRlZCcpOwogICAgfQoKICAgIC8vIENyZWF0ZSBhIHNvY2tldCBjb25uZWN0aW9uIHRvIHRoZSBwcm94eSBzZXJ2ZXIuCiAgICBsZXQgc29ja2V0OwogICAgaWYgKHByb3h5LnByb3RvY29sID09PSAnaHR0cHM6JykgewogICAgICBkZWJ1ZygnQ3JlYXRpbmcgYHRscy5Tb2NrZXRgOiAlbycsIHRoaXMuY29ubmVjdE9wdHMpOwogICAgICBjb25zdCBzZXJ2ZXJuYW1lID0gdGhpcy5jb25uZWN0T3B0cy5zZXJ2ZXJuYW1lIHx8IHRoaXMuY29ubmVjdE9wdHMuaG9zdDsKICAgICAgc29ja2V0ID0gdGxzLmNvbm5lY3QoewogICAgICAgIC4uLnRoaXMuY29ubmVjdE9wdHMsCiAgICAgICAgc2VydmVybmFtZTogc2VydmVybmFtZSAmJiBuZXQuaXNJUChzZXJ2ZXJuYW1lKSA/IHVuZGVmaW5lZCA6IHNlcnZlcm5hbWUsCiAgICAgIH0pOwogICAgfSBlbHNlIHsKICAgICAgZGVidWcoJ0NyZWF0aW5nIGBuZXQuU29ja2V0YDogJW8nLCB0aGlzLmNvbm5lY3RPcHRzKTsKICAgICAgc29ja2V0ID0gbmV0LmNvbm5lY3QodGhpcy5jb25uZWN0T3B0cyk7CiAgICB9CgogICAgY29uc3QgaGVhZGVycyA9CiAgICAgIHR5cGVvZiB0aGlzLnByb3h5SGVhZGVycyA9PT0gJ2Z1bmN0aW9uJyA/IHRoaXMucHJveHlIZWFkZXJzKCkgOiB7IC4uLnRoaXMucHJveHlIZWFkZXJzIH07CiAgICBjb25zdCBob3N0ID0gbmV0LmlzSVB2NihvcHRzLmhvc3QpID8gYFske29wdHMuaG9zdH1dYCA6IG9wdHMuaG9zdDsKICAgIGxldCBwYXlsb2FkID0gYENPTk5FQ1QgJHtob3N0fToke29wdHMucG9ydH0gSFRUUC8xLjFcclxuYDsKCiAgICAvLyBJbmplY3QgdGhlIGBQcm94eS1BdXRob3JpemF0aW9uYCBoZWFkZXIgaWYgbmVjZXNzYXJ5LgogICAgaWYgKHByb3h5LnVzZXJuYW1lIHx8IHByb3h5LnBhc3N3b3JkKSB7CiAgICAgIGNvbnN0IGF1dGggPSBgJHtkZWNvZGVVUklDb21wb25lbnQocHJveHkudXNlcm5hbWUpfToke2RlY29kZVVSSUNvbXBvbmVudChwcm94eS5wYXNzd29yZCl9YDsKICAgICAgaGVhZGVyc1snUHJveHktQXV0aG9yaXphdGlvbiddID0gYEJhc2ljICR7QnVmZmVyLmZyb20oYXV0aCkudG9TdHJpbmcoJ2Jhc2U2NCcpfWA7CiAgICB9CgogICAgaGVhZGVycy5Ib3N0ID0gYCR7aG9zdH06JHtvcHRzLnBvcnR9YDsKCiAgICBpZiAoIWhlYWRlcnNbJ1Byb3h5LUNvbm5lY3Rpb24nXSkgewogICAgICBoZWFkZXJzWydQcm94eS1Db25uZWN0aW9uJ10gPSB0aGlzLmtlZXBBbGl2ZSA/ICdLZWVwLUFsaXZlJyA6ICdjbG9zZSc7CiAgICB9CiAgICBmb3IgKGNvbnN0IG5hbWUgb2YgT2JqZWN0LmtleXMoaGVhZGVycykpIHsKICAgICAgcGF5bG9hZCArPSBgJHtuYW1lfTogJHtoZWFkZXJzW25hbWVdfVxyXG5gOwogICAgfQoKICAgIGNvbnN0IHByb3h5UmVzcG9uc2VQcm9taXNlID0gcGFyc2VQcm94eVJlc3BvbnNlKHNvY2tldCk7CgogICAgc29ja2V0LndyaXRlKGAke3BheWxvYWR9XHJcbmApOwoKICAgIGNvbnN0IHsgY29ubmVjdCwgYnVmZmVyZWQgfSA9IGF3YWl0IHByb3h5UmVzcG9uc2VQcm9taXNlOwogICAgcmVxLmVtaXQoJ3Byb3h5Q29ubmVjdCcsIGNvbm5lY3QpOwogICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9iYW4tdHMtY29tbWVudAogICAgLy8gQHRzLWlnbm9yZSBOb3QgRXZlbnRFbWl0dGVyIGluIE5vZGUgdHlwZXMKICAgIHRoaXMuZW1pdCgncHJveHlDb25uZWN0JywgY29ubmVjdCwgcmVxKTsKCiAgICBpZiAoY29ubmVjdC5zdGF0dXNDb2RlID09PSAyMDApIHsKICAgICAgcmVxLm9uY2UoJ3NvY2tldCcsIHJlc3VtZSk7CgogICAgICBpZiAob3B0cy5zZWN1cmVFbmRwb2ludCkgewogICAgICAgIC8vIFRoZSBwcm94eSBpcyBjb25uZWN0aW5nIHRvIGEgVExTIHNlcnZlciwgc28gdXBncmFkZQogICAgICAgIC8vIHRoaXMgc29ja2V0IGNvbm5lY3Rpb24gdG8gYSBUTFMgY29ubmVjdGlvbi4KICAgICAgICBkZWJ1ZygnVXBncmFkaW5nIHNvY2tldCBjb25uZWN0aW9uIHRvIFRMUycpOwogICAgICAgIGNvbnN0IHNlcnZlcm5hbWUgPSBvcHRzLnNlcnZlcm5hbWUgfHwgb3B0cy5ob3N0OwogICAgICAgIHJldHVybiB0bHMuY29ubmVjdCh7CiAgICAgICAgICAuLi5vbWl0KG9wdHMsICdob3N0JywgJ3BhdGgnLCAncG9ydCcpLAogICAgICAgICAgc29ja2V0LAogICAgICAgICAgc2VydmVybmFtZTogbmV0LmlzSVAoc2VydmVybmFtZSkgPyB1bmRlZmluZWQgOiBzZXJ2ZXJuYW1lLAogICAgICAgIH0pOwogICAgICB9CgogICAgICByZXR1cm4gc29ja2V0OwogICAgfQoKICAgIC8vIFNvbWUgb3RoZXIgc3RhdHVzIGNvZGUgdGhhdCdzIG5vdCAyMDAuLi4gbmVlZCB0byByZS1wbGF5IHRoZSBIVFRQCiAgICAvLyBoZWFkZXIgImRhdGEiIGV2ZW50cyBvbnRvIHRoZSBzb2NrZXQgb25jZSB0aGUgSFRUUCBtYWNoaW5lcnkgaXMKICAgIC8vIGF0dGFjaGVkIHNvIHRoYXQgdGhlIG5vZGUgY29yZSBgaHR0cGAgY2FuIHBhcnNlIGFuZCBoYW5kbGUgdGhlCiAgICAvLyBlcnJvciBzdGF0dXMgY29kZS4KCiAgICAvLyBDbG9zZSB0aGUgb3JpZ2luYWwgc29ja2V0LCBhbmQgYSBuZXcgImZha2UiIHNvY2tldCBpcyByZXR1cm5lZAogICAgLy8gaW5zdGVhZCwgc28gdGhhdCB0aGUgcHJveHkgZG9lc24ndCBnZXQgdGhlIEhUVFAgcmVxdWVzdAogICAgLy8gd3JpdHRlbiB0byBpdCAod2hpY2ggbWF5IGNvbnRhaW4gYEF1dGhvcml6YXRpb25gIGhlYWRlcnMgb3Igb3RoZXIKICAgIC8vIHNlbnNpdGl2ZSBkYXRhKS4KICAgIC8vCiAgICAvLyBTZWU6IGh0dHBzOi8vaGFja2Vyb25lLmNvbS9yZXBvcnRzLzU0MTUwMgogICAgc29ja2V0LmRlc3Ryb3koKTsKCiAgICBjb25zdCBmYWtlU29ja2V0ID0gbmV3IG5ldC5Tb2NrZXQoeyB3cml0YWJsZTogZmFsc2UgfSk7CiAgICBmYWtlU29ja2V0LnJlYWRhYmxlID0gdHJ1ZTsKCiAgICAvLyBOZWVkIHRvIHdhaXQgZm9yIHRoZSAic29ja2V0IiBldmVudCB0byByZS1wbGF5IHRoZSAiZGF0YSIgZXZlbnRzLgogICAgcmVxLm9uY2UoJ3NvY2tldCcsIChzKSA9PiB7CiAgICAgIGRlYnVnKCdSZXBsYXlpbmcgcHJveHkgYnVmZmVyIGZvciBmYWlsZWQgcmVxdWVzdCcpOwogICAgICBhc3NlcnQocy5saXN0ZW5lckNvdW50KCdkYXRhJykgPiAwKTsKCiAgICAgIC8vIFJlcGxheSB0aGUgImJ1ZmZlcmVkIiBCdWZmZXIgb250byB0aGUgZmFrZSBgc29ja2V0YCwgc2luY2UgYXQKICAgICAgLy8gdGhpcyBwb2ludCB0aGUgSFRUUCBtb2R1bGUgbWFjaGluZXJ5IGhhcyBiZWVuIGhvb2tlZCB1cCBmb3IKICAgICAgLy8gdGhlIHVzZXIuCiAgICAgIHMucHVzaChidWZmZXJlZCk7CiAgICAgIHMucHVzaChudWxsKTsKICAgIH0pOwoKICAgIHJldHVybiBmYWtlU29ja2V0OwogIH0KfSBIdHRwc1Byb3h5QWdlbnQuX19pbml0U3RhdGljKCk7CgpmdW5jdGlvbiByZXN1bWUoc29ja2V0KSB7CiAgc29ja2V0LnJlc3VtZSgpOwp9CgpmdW5jdGlvbiBvbWl0KAogIG9iaiwKICAuLi5rZXlzCikKCiB7CiAgY29uc3QgcmV0ID0ge30KCjsKICBsZXQga2V5OwogIGZvciAoa2V5IGluIG9iaikgewogICAgaWYgKCFrZXlzLmluY2x1ZGVzKGtleSkpIHsKICAgICAgcmV0W2tleV0gPSBvYmpba2V5XTsKICAgIH0KICB9CiAgcmV0dXJuIHJldDsKfQoKZnVuY3Rpb24gX251bGxpc2hDb2FsZXNjZShsaHMsIHJoc0ZuKSB7IGlmIChsaHMgIT0gbnVsbCkgeyByZXR1cm4gbGhzOyB9IGVsc2UgeyByZXR1cm4gcmhzRm4oKTsgfSB9Ci8vIEVzdGltYXRlZCBtYXhpbXVtIHNpemUgZm9yIHJlYXNvbmFibGUgc3RhbmRhbG9uZSBldmVudApjb25zdCBHWklQX1RIUkVTSE9MRCA9IDEwMjQgKiAzMjsKCi8qKgogKiBHZXRzIGEgc3RyZWFtIGZyb20gYSBVaW50OEFycmF5IG9yIHN0cmluZwogKiBSZWFkYWJsZS5mcm9tIGlzIGlkZWFsIGJ1dCB3YXMgYWRkZWQgaW4gbm9kZS5qcyB2MTIuMy4wIGFuZCB2MTAuMTcuMAogKi8KZnVuY3Rpb24gc3RyZWFtRnJvbUJvZHkoYm9keSkgewogIHJldHVybiBuZXcgUmVhZGFibGUoewogICAgcmVhZCgpIHsKICAgICAgdGhpcy5wdXNoKGJvZHkpOwogICAgICB0aGlzLnB1c2gobnVsbCk7CiAgICB9LAogIH0pOwp9CgovKioKICogQ3JlYXRlcyBhIFRyYW5zcG9ydCB0aGF0IHVzZXMgbmF0aXZlIHRoZSBuYXRpdmUgJ2h0dHAnIGFuZCAnaHR0cHMnIG1vZHVsZXMgdG8gc2VuZCBldmVudHMgdG8gU2VudHJ5LgogKi8KZnVuY3Rpb24gbWFrZU5vZGVUcmFuc3BvcnQob3B0aW9ucykgewogIGxldCB1cmxTZWdtZW50czsKCiAgdHJ5IHsKICAgIHVybFNlZ21lbnRzID0gbmV3IFVSTChvcHRpb25zLnVybCk7CiAgfSBjYXRjaCAoZSkgewogICAgY29uc29sZVNhbmRib3goKCkgPT4gewogICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tY29uc29sZQogICAgICBjb25zb2xlLndhcm4oCiAgICAgICAgJ1tAc2VudHJ5L25vZGVdOiBJbnZhbGlkIGRzbiBvciB0dW5uZWwgb3B0aW9uLCB3aWxsIG5vdCBzZW5kIGFueSBldmVudHMuIFRoZSB0dW5uZWwgb3B0aW9uIG11c3QgYmUgYSBmdWxsIFVSTCB3aGVuIHVzZWQuJywKICAgICAgKTsKICAgIH0pOwogICAgcmV0dXJuIGNyZWF0ZVRyYW5zcG9ydChvcHRpb25zLCAoKSA9PiBQcm9taXNlLnJlc29sdmUoe30pKTsKICB9CgogIGNvbnN0IGlzSHR0cHMgPSB1cmxTZWdtZW50cy5wcm90b2NvbCA9PT0gJ2h0dHBzOic7CgogIC8vIFByb3h5IHByaW9yaXRpemF0aW9uOiBodHRwID0+IGBvcHRpb25zLnByb3h5YCB8IGBwcm9jZXNzLmVudi5odHRwX3Byb3h5YAogIC8vIFByb3h5IHByaW9yaXRpemF0aW9uOiBodHRwcyA9PiBgb3B0aW9ucy5wcm94eWAgfCBgcHJvY2Vzcy5lbnYuaHR0cHNfcHJveHlgIHwgYHByb2Nlc3MuZW52Lmh0dHBfcHJveHlgCiAgY29uc3QgcHJveHkgPSBhcHBseU5vUHJveHlPcHRpb24oCiAgICB1cmxTZWdtZW50cywKICAgIG9wdGlvbnMucHJveHkgfHwgKGlzSHR0cHMgPyBwcm9jZXNzLmVudi5odHRwc19wcm94eSA6IHVuZGVmaW5lZCkgfHwgcHJvY2Vzcy5lbnYuaHR0cF9wcm94eSwKICApOwoKICBjb25zdCBuYXRpdmVIdHRwTW9kdWxlID0gaXNIdHRwcyA/IGh0dHBzIDogaHR0cDsKICBjb25zdCBrZWVwQWxpdmUgPSBvcHRpb25zLmtlZXBBbGl2ZSA9PT0gdW5kZWZpbmVkID8gZmFsc2UgOiBvcHRpb25zLmtlZXBBbGl2ZTsKCiAgLy8gVE9ETyh2Nyk6IEV2YWx1YXRlIGlmIHdlIGNhbiBzZXQga2VlcEFsaXZlIHRvIHRydWUuIFRoaXMgd291bGQgaW52b2x2ZSB0ZXN0aW5nIGZvciBtZW1vcnkgbGVha3MgaW4gb2xkZXIgbm9kZQogIC8vIHZlcnNpb25zKD49IDgpIGFzIHRoZXkgaGFkIG1lbW9yeSBsZWFrcyB3aGVuIHVzaW5nIGl0OiAjMjU1NQogIGNvbnN0IGFnZW50ID0gcHJveHkKICAgID8gKG5ldyBIdHRwc1Byb3h5QWdlbnQocHJveHkpICkKICAgIDogbmV3IG5hdGl2ZUh0dHBNb2R1bGUuQWdlbnQoeyBrZWVwQWxpdmUsIG1heFNvY2tldHM6IDMwLCB0aW1lb3V0OiAyMDAwIH0pOwoKICBjb25zdCByZXF1ZXN0RXhlY3V0b3IgPSBjcmVhdGVSZXF1ZXN0RXhlY3V0b3Iob3B0aW9ucywgX251bGxpc2hDb2FsZXNjZShvcHRpb25zLmh0dHBNb2R1bGUsICgpID0+ICggbmF0aXZlSHR0cE1vZHVsZSkpLCBhZ2VudCk7CiAgcmV0dXJuIGNyZWF0ZVRyYW5zcG9ydChvcHRpb25zLCByZXF1ZXN0RXhlY3V0b3IpOwp9CgovKioKICogSG9ub3JzIHRoZSBgbm9fcHJveHlgIGVudiB2YXJpYWJsZSB3aXRoIHRoZSBoaWdoZXN0IHByaW9yaXR5IHRvIGFsbG93IGZvciBob3N0cyBleGNsdXNpb24uCiAqCiAqIEBwYXJhbSB0cmFuc3BvcnRVcmwgVGhlIFVSTCB0aGUgdHJhbnNwb3J0IGludGVuZHMgdG8gc2VuZCBldmVudHMgdG8uCiAqIEBwYXJhbSBwcm94eSBUaGUgY2xpZW50IGNvbmZpZ3VyZWQgcHJveHkuCiAqIEByZXR1cm5zIEEgcHJveHkgdGhlIHRyYW5zcG9ydCBzaG91bGQgdXNlLgogKi8KZnVuY3Rpb24gYXBwbHlOb1Byb3h5T3B0aW9uKHRyYW5zcG9ydFVybFNlZ21lbnRzLCBwcm94eSkgewogIGNvbnN0IHsgbm9fcHJveHkgfSA9IHByb2Nlc3MuZW52OwoKICBjb25zdCB1cmxJc0V4ZW1wdEZyb21Qcm94eSA9CiAgICBub19wcm94eSAmJgogICAgbm9fcHJveHkKICAgICAgLnNwbGl0KCcsJykKICAgICAgLnNvbWUoCiAgICAgICAgZXhlbXB0aW9uID0+IHRyYW5zcG9ydFVybFNlZ21lbnRzLmhvc3QuZW5kc1dpdGgoZXhlbXB0aW9uKSB8fCB0cmFuc3BvcnRVcmxTZWdtZW50cy5ob3N0bmFtZS5lbmRzV2l0aChleGVtcHRpb24pLAogICAgICApOwoKICBpZiAodXJsSXNFeGVtcHRGcm9tUHJveHkpIHsKICAgIHJldHVybiB1bmRlZmluZWQ7CiAgfSBlbHNlIHsKICAgIHJldHVybiBwcm94eTsKICB9Cn0KCi8qKgogKiBDcmVhdGVzIGEgUmVxdWVzdEV4ZWN1dG9yIHRvIGJlIHVzZWQgd2l0aCBgY3JlYXRlVHJhbnNwb3J0YC4KICovCmZ1bmN0aW9uIGNyZWF0ZVJlcXVlc3RFeGVjdXRvcigKICBvcHRpb25zLAogIGh0dHBNb2R1bGUsCiAgYWdlbnQsCikgewogIGNvbnN0IHsgaG9zdG5hbWUsIHBhdGhuYW1lLCBwb3J0LCBwcm90b2NvbCwgc2VhcmNoIH0gPSBuZXcgVVJMKG9wdGlvbnMudXJsKTsKICByZXR1cm4gZnVuY3Rpb24gbWFrZVJlcXVlc3QocmVxdWVzdCkgewogICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHsKICAgICAgbGV0IGJvZHkgPSBzdHJlYW1Gcm9tQm9keShyZXF1ZXN0LmJvZHkpOwoKICAgICAgY29uc3QgaGVhZGVycyA9IHsgLi4ub3B0aW9ucy5oZWFkZXJzIH07CgogICAgICBpZiAocmVxdWVzdC5ib2R5Lmxlbmd0aCA+IEdaSVBfVEhSRVNIT0xEKSB7CiAgICAgICAgaGVhZGVyc1snY29udGVudC1lbmNvZGluZyddID0gJ2d6aXAnOwogICAgICAgIGJvZHkgPSBib2R5LnBpcGUoY3JlYXRlR3ppcCgpKTsKICAgICAgfQoKICAgICAgY29uc3QgcmVxID0gaHR0cE1vZHVsZS5yZXF1ZXN0KAogICAgICAgIHsKICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLAogICAgICAgICAgYWdlbnQsCiAgICAgICAgICBoZWFkZXJzLAogICAgICAgICAgaG9zdG5hbWUsCiAgICAgICAgICBwYXRoOiBgJHtwYXRobmFtZX0ke3NlYXJjaH1gLAogICAgICAgICAgcG9ydCwKICAgICAgICAgIHByb3RvY29sLAogICAgICAgICAgY2E6IG9wdGlvbnMuY2FDZXJ0cywKICAgICAgICB9LAogICAgICAgIHJlcyA9PiB7CiAgICAgICAgICByZXMub24oJ2RhdGEnLCAoKSA9PiB7CiAgICAgICAgICAgIC8vIERyYWluIHNvY2tldAogICAgICAgICAgfSk7CgogICAgICAgICAgcmVzLm9uKCdlbmQnLCAoKSA9PiB7CiAgICAgICAgICAgIC8vIERyYWluIHNvY2tldAogICAgICAgICAgfSk7CgogICAgICAgICAgcmVzLnNldEVuY29kaW5nKCd1dGY4Jyk7CgogICAgICAgICAgLy8gIktleS12YWx1ZSBwYWlycyBvZiBoZWFkZXIgbmFtZXMgYW5kIHZhbHVlcy4gSGVhZGVyIG5hbWVzIGFyZSBsb3dlci1jYXNlZC4iCiAgICAgICAgICAvLyBodHRwczovL25vZGVqcy5vcmcvYXBpL2h0dHAuaHRtbCNodHRwX21lc3NhZ2VfaGVhZGVycwogICAgICAgICAgY29uc3QgcmV0cnlBZnRlckhlYWRlciA9IF9udWxsaXNoQ29hbGVzY2UocmVzLmhlYWRlcnNbJ3JldHJ5LWFmdGVyJ10sICgpID0+ICggbnVsbCkpOwogICAgICAgICAgY29uc3QgcmF0ZUxpbWl0c0hlYWRlciA9IF9udWxsaXNoQ29hbGVzY2UocmVzLmhlYWRlcnNbJ3gtc2VudHJ5LXJhdGUtbGltaXRzJ10sICgpID0+ICggbnVsbCkpOwoKICAgICAgICAgIHJlc29sdmUoewogICAgICAgICAgICBzdGF0dXNDb2RlOiByZXMuc3RhdHVzQ29kZSwKICAgICAgICAgICAgaGVhZGVyczogewogICAgICAgICAgICAgICdyZXRyeS1hZnRlcic6IHJldHJ5QWZ0ZXJIZWFkZXIsCiAgICAgICAgICAgICAgJ3gtc2VudHJ5LXJhdGUtbGltaXRzJzogQXJyYXkuaXNBcnJheShyYXRlTGltaXRzSGVhZGVyKSA/IHJhdGVMaW1pdHNIZWFkZXJbMF0gOiByYXRlTGltaXRzSGVhZGVyLAogICAgICAgICAgICB9LAogICAgICAgICAgfSk7CiAgICAgICAgfSwKICAgICAgKTsKCiAgICAgIHJlcS5vbignZXJyb3InLCByZWplY3QpOwogICAgICBib2R5LnBpcGUocmVxKTsKICAgIH0pOwogIH07Cn0KCmZ1bmN0aW9uIF9vcHRpb25hbENoYWluKG9wcykgeyBsZXQgbGFzdEFjY2Vzc0xIUyA9IHVuZGVmaW5lZDsgbGV0IHZhbHVlID0gb3BzWzBdOyBsZXQgaSA9IDE7IHdoaWxlIChpIDwgb3BzLmxlbmd0aCkgeyBjb25zdCBvcCA9IG9wc1tpXTsgY29uc3QgZm4gPSBvcHNbaSArIDFdOyBpICs9IDI7IGlmICgob3AgPT09ICdvcHRpb25hbEFjY2VzcycgfHwgb3AgPT09ICdvcHRpb25hbENhbGwnKSAmJiB2YWx1ZSA9PSBudWxsKSB7IHJldHVybiB1bmRlZmluZWQ7IH0gaWYgKG9wID09PSAnYWNjZXNzJyB8fCBvcCA9PT0gJ29wdGlvbmFsQWNjZXNzJykgeyBsYXN0QWNjZXNzTEhTID0gdmFsdWU7IHZhbHVlID0gZm4odmFsdWUpOyB9IGVsc2UgaWYgKG9wID09PSAnY2FsbCcgfHwgb3AgPT09ICdvcHRpb25hbENhbGwnKSB7IHZhbHVlID0gZm4oKC4uLmFyZ3MpID0+IHZhbHVlLmNhbGwobGFzdEFjY2Vzc0xIUywgLi4uYXJncykpOyBsYXN0QWNjZXNzTEhTID0gdW5kZWZpbmVkOyB9IH0gcmV0dXJuIHZhbHVlOyB9CmNvbnN0IG9wdGlvbnMgPSB3b3JrZXJEYXRhOwpsZXQgc2Vzc2lvbjsKbGV0IGhhc1NlbnRBbnJFdmVudCA9IGZhbHNlOwoKZnVuY3Rpb24gbG9nKG1zZykgewogIGlmIChvcHRpb25zLmRlYnVnKSB7CiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tY29uc29sZQogICAgY29uc29sZS5sb2coYFtBTlIgV29ya2VyXSAke21zZ31gKTsKICB9Cn0KCmNvbnN0IHVybCA9IGdldEVudmVsb3BlRW5kcG9pbnRXaXRoVXJsRW5jb2RlZEF1dGgob3B0aW9ucy5kc24pOwpjb25zdCB0cmFuc3BvcnQgPSBtYWtlTm9kZVRyYW5zcG9ydCh7CiAgdXJsLAogIHJlY29yZERyb3BwZWRFdmVudDogKCkgPT4gewogICAgLy8KICB9LAp9KTsKCmFzeW5jIGZ1bmN0aW9uIHNlbmRBYm5vcm1hbFNlc3Npb24oKSB7CiAgLy8gb2Ygd2UgaGF2ZSBhbiBleGlzdGluZyBzZXNzaW9uIHBhc3NlZCBmcm9tIHRoZSBtYWluIHRocmVhZCwgc2VuZCBpdCBhcyBhYm5vcm1hbAogIGlmIChzZXNzaW9uKSB7CiAgICBsb2coJ1NlbmRpbmcgYWJub3JtYWwgc2Vzc2lvbicpOwogICAgdXBkYXRlU2Vzc2lvbihzZXNzaW9uLCB7IHN0YXR1czogJ2Fibm9ybWFsJywgYWJub3JtYWxfbWVjaGFuaXNtOiAnYW5yX2ZvcmVncm91bmQnIH0pOwoKICAgIGNvbnN0IGVudmVsb3BlID0gY3JlYXRlU2Vzc2lvbkVudmVsb3BlKHNlc3Npb24sIG9wdGlvbnMuZHNuLCBvcHRpb25zLnNka01ldGFkYXRhKTsKICAgIC8vIExvZyB0aGUgZW52ZWxvcGUgc28gdG8gYWlkIGluIHRlc3RpbmcKICAgIGxvZyhKU09OLnN0cmluZ2lmeShlbnZlbG9wZSkpOwoKICAgIGF3YWl0IHRyYW5zcG9ydC5zZW5kKGVudmVsb3BlKTsKCiAgICB0cnkgewogICAgICAvLyBOb3RpZnkgdGhlIG1haW4gcHJvY2VzcyB0aGF0IHRoZSBzZXNzaW9uIGhhcyBlbmRlZCBzbyB0aGUgc2Vzc2lvbiBjYW4gYmUgY2xlYXJlZCBmcm9tIHRoZSBzY29wZQogICAgICBfb3B0aW9uYWxDaGFpbihbcGFyZW50UG9ydCwgJ29wdGlvbmFsQWNjZXNzJywgXzIgPT4gXzIucG9zdE1lc3NhZ2UsICdjYWxsJywgXzMgPT4gXzMoJ3Nlc3Npb24tZW5kZWQnKV0pOwogICAgfSBjYXRjaCAoXykgewogICAgICAvLyBpZ25vcmUKICAgIH0KICB9Cn0KCmxvZygnU3RhcnRlZCcpOwoKZnVuY3Rpb24gcHJlcGFyZVN0YWNrRnJhbWVzKHN0YWNrRnJhbWVzKSB7CiAgaWYgKCFzdGFja0ZyYW1lcykgewogICAgcmV0dXJuIHVuZGVmaW5lZDsKICB9CgogIC8vIFN0cmlwIFNlbnRyeSBmcmFtZXMgYW5kIHJldmVyc2UgdGhlIHN0YWNrIGZyYW1lcyBzbyB0aGV5IGFyZSBpbiB0aGUgY29ycmVjdCBvcmRlcgogIGNvbnN0IHN0cmlwcGVkRnJhbWVzID0gc3RyaXBTZW50cnlGcmFtZXNBbmRSZXZlcnNlKHN0YWNrRnJhbWVzKTsKCiAgLy8gSWYgd2UgaGF2ZSBhbiBhcHAgcm9vdCBwYXRoLCByZXdyaXRlIHRoZSBmaWxlbmFtZXMgdG8gYmUgcmVsYXRpdmUgdG8gdGhlIGFwcCByb290CiAgaWYgKG9wdGlvbnMuYXBwUm9vdFBhdGgpIHsKICAgIGZvciAoY29uc3QgZnJhbWUgb2Ygc3RyaXBwZWRGcmFtZXMpIHsKICAgICAgaWYgKCFmcmFtZS5maWxlbmFtZSkgewogICAgICAgIGNvbnRpbnVlOwogICAgICB9CgogICAgICBmcmFtZS5maWxlbmFtZSA9IG5vcm1hbGl6ZVVybFRvQmFzZShmcmFtZS5maWxlbmFtZSwgb3B0aW9ucy5hcHBSb290UGF0aCk7CiAgICB9CiAgfQoKICByZXR1cm4gc3RyaXBwZWRGcmFtZXM7Cn0KCmFzeW5jIGZ1bmN0aW9uIHNlbmRBbnJFdmVudChmcmFtZXMsIHRyYWNlQ29udGV4dCkgewogIGlmIChoYXNTZW50QW5yRXZlbnQpIHsKICAgIHJldHVybjsKICB9CgogIGhhc1NlbnRBbnJFdmVudCA9IHRydWU7CgogIGF3YWl0IHNlbmRBYm5vcm1hbFNlc3Npb24oKTsKCiAgbG9nKCdTZW5kaW5nIGV2ZW50Jyk7CgogIGNvbnN0IGV2ZW50ID0gewogICAgZXZlbnRfaWQ6IHV1aWQ0KCksCiAgICBjb250ZXh0czogeyAuLi5vcHRpb25zLmNvbnRleHRzLCB0cmFjZTogdHJhY2VDb250ZXh0IH0sCiAgICByZWxlYXNlOiBvcHRpb25zLnJlbGVhc2UsCiAgICBlbnZpcm9ubWVudDogb3B0aW9ucy5lbnZpcm9ubWVudCwKICAgIGRpc3Q6IG9wdGlvbnMuZGlzdCwKICAgIHBsYXRmb3JtOiAnbm9kZScsCiAgICBsZXZlbDogJ2Vycm9yJywKICAgIGV4Y2VwdGlvbjogewogICAgICB2YWx1ZXM6IFsKICAgICAgICB7CiAgICAgICAgICB0eXBlOiAnQXBwbGljYXRpb25Ob3RSZXNwb25kaW5nJywKICAgICAgICAgIHZhbHVlOiBgQXBwbGljYXRpb24gTm90IFJlc3BvbmRpbmcgZm9yIGF0IGxlYXN0ICR7b3B0aW9ucy5hbnJUaHJlc2hvbGR9IG1zYCwKICAgICAgICAgIHN0YWNrdHJhY2U6IHsgZnJhbWVzOiBwcmVwYXJlU3RhY2tGcmFtZXMoZnJhbWVzKSB9LAogICAgICAgICAgLy8gVGhpcyBlbnN1cmVzIHRoZSBVSSBkb2Vzbid0IHNheSAnQ3Jhc2hlZCBpbicgZm9yIHRoZSBzdGFjayB0cmFjZQogICAgICAgICAgbWVjaGFuaXNtOiB7IHR5cGU6ICdBTlInIH0sCiAgICAgICAgfSwKICAgICAgXSwKICAgIH0sCiAgICB0YWdzOiBvcHRpb25zLnN0YXRpY1RhZ3MsCiAgfTsKCiAgY29uc3QgZW52ZWxvcGUgPSBjcmVhdGVFdmVudEVudmVsb3BlKGV2ZW50LCBvcHRpb25zLmRzbiwgb3B0aW9ucy5zZGtNZXRhZGF0YSk7CiAgLy8gTG9nIHRoZSBlbnZlbG9wZSBzbyB0byBhaWQgaW4gdGVzdGluZwogIGxvZyhKU09OLnN0cmluZ2lmeShlbnZlbG9wZSkpOwoKICBhd2FpdCB0cmFuc3BvcnQuc2VuZChlbnZlbG9wZSk7CiAgYXdhaXQgdHJhbnNwb3J0LmZsdXNoKDIwMDApOwoKICAvLyBEZWxheSBmb3IgNSBzZWNvbmRzIHNvIHRoYXQgc3RkaW8gY2FuIGZsdXNoIGluIHRoZSBtYWluIGV2ZW50IGxvb3AgZXZlciByZXN0YXJ0cy4KICAvLyBUaGlzIGlzIG1haW5seSBmb3IgdGhlIGJlbmVmaXQgb2YgbG9nZ2luZy9kZWJ1Z2dpbmcgaXNzdWVzLgogIHNldFRpbWVvdXQoKCkgPT4gewogICAgcHJvY2Vzcy5leGl0KDApOwogIH0sIDUwMDApOwp9CgpsZXQgZGVidWdnZXJQYXVzZTsKCmlmIChvcHRpb25zLmNhcHR1cmVTdGFja1RyYWNlKSB7CiAgbG9nKCdDb25uZWN0aW5nIHRvIGRlYnVnZ2VyJyk7CgogIGNvbnN0IHNlc3Npb24gPSBuZXcgU2Vzc2lvbigpIDsKICBzZXNzaW9uLmNvbm5lY3RUb01haW5UaHJlYWQoKTsKCiAgbG9nKCdDb25uZWN0ZWQgdG8gZGVidWdnZXInKTsKCiAgLy8gQ29sbGVjdCBzY3JpcHRJZCAtPiB1cmwgbWFwIHNvIHdlIGNhbiBsb29rIHVwIHRoZSBmaWxlbmFtZXMgbGF0ZXIKICBjb25zdCBzY3JpcHRzID0gbmV3IE1hcCgpOwoKICBzZXNzaW9uLm9uKCdEZWJ1Z2dlci5zY3JpcHRQYXJzZWQnLCBldmVudCA9PiB7CiAgICBzY3JpcHRzLnNldChldmVudC5wYXJhbXMuc2NyaXB0SWQsIGV2ZW50LnBhcmFtcy51cmwpOwogIH0pOwoKICBzZXNzaW9uLm9uKCdEZWJ1Z2dlci5wYXVzZWQnLCBldmVudCA9PiB7CiAgICBpZiAoZXZlbnQucGFyYW1zLnJlYXNvbiAhPT0gJ290aGVyJykgewogICAgICByZXR1cm47CiAgICB9CgogICAgdHJ5IHsKICAgICAgbG9nKCdEZWJ1Z2dlciBwYXVzZWQnKTsKCiAgICAgIC8vIGNvcHkgdGhlIGZyYW1lcwogICAgICBjb25zdCBjYWxsRnJhbWVzID0gWy4uLmV2ZW50LnBhcmFtcy5jYWxsRnJhbWVzXTsKCiAgICAgIGNvbnN0IGdldE1vZHVsZU5hbWUgPSBvcHRpb25zLmFwcFJvb3RQYXRoID8gY3JlYXRlR2V0TW9kdWxlRnJvbUZpbGVuYW1lKG9wdGlvbnMuYXBwUm9vdFBhdGgpIDogKCkgPT4gdW5kZWZpbmVkOwogICAgICBjb25zdCBzdGFja0ZyYW1lcyA9IGNhbGxGcmFtZXMubWFwKGZyYW1lID0+CiAgICAgICAgY2FsbEZyYW1lVG9TdGFja0ZyYW1lKGZyYW1lLCBzY3JpcHRzLmdldChmcmFtZS5sb2NhdGlvbi5zY3JpcHRJZCksIGdldE1vZHVsZU5hbWUpLAogICAgICApOwoKICAgICAgLy8gRXZhbHVhdGUgYSBzY3JpcHQgaW4gdGhlIGN1cnJlbnRseSBwYXVzZWQgY29udGV4dAogICAgICBzZXNzaW9uLnBvc3QoCiAgICAgICAgJ1J1bnRpbWUuZXZhbHVhdGUnLAogICAgICAgIHsKICAgICAgICAgIC8vIEdyYWIgdGhlIHRyYWNlIGNvbnRleHQgZnJvbSB0aGUgY3VycmVudCBzY29wZQogICAgICAgICAgZXhwcmVzc2lvbjoKICAgICAgICAgICAgJ2NvbnN0IGN0eCA9IF9fU0VOVFJZX18uaHViLmdldFNjb3BlKCkuZ2V0UHJvcGFnYXRpb25Db250ZXh0KCk7IGN0eC50cmFjZUlkICsgIi0iICsgY3R4LnNwYW5JZCArICItIiArIGN0eC5wYXJlbnRTcGFuSWQnLAogICAgICAgICAgLy8gRG9uJ3QgcmUtdHJpZ2dlciB0aGUgZGVidWdnZXIgaWYgdGhpcyBjYXVzZXMgYW4gZXJyb3IKICAgICAgICAgIHNpbGVudDogdHJ1ZSwKICAgICAgICB9LAogICAgICAgIChfLCBwYXJhbSkgPT4gewogICAgICAgICAgY29uc3QgdHJhY2VJZCA9IHBhcmFtICYmIHBhcmFtLnJlc3VsdCA/IChwYXJhbS5yZXN1bHQudmFsdWUgKSA6ICctLSc7CiAgICAgICAgICBjb25zdCBbdHJhY2VfaWQsIHNwYW5faWQsIHBhcmVudF9zcGFuX2lkXSA9IHRyYWNlSWQuc3BsaXQoJy0nKSA7CgogICAgICAgICAgc2Vzc2lvbi5wb3N0KCdEZWJ1Z2dlci5yZXN1bWUnKTsKICAgICAgICAgIHNlc3Npb24ucG9zdCgnRGVidWdnZXIuZGlzYWJsZScpOwoKICAgICAgICAgIGNvbnN0IGNvbnRleHQgPSBfb3B0aW9uYWxDaGFpbihbdHJhY2VfaWQsICdvcHRpb25hbEFjY2VzcycsIF80ID0+IF80Lmxlbmd0aF0pICYmIF9vcHRpb25hbENoYWluKFtzcGFuX2lkLCAnb3B0aW9uYWxBY2Nlc3MnLCBfNSA9PiBfNS5sZW5ndGhdKSA/IHsgdHJhY2VfaWQsIHNwYW5faWQsIHBhcmVudF9zcGFuX2lkIH0gOiB1bmRlZmluZWQ7CiAgICAgICAgICBzZW5kQW5yRXZlbnQoc3RhY2tGcmFtZXMsIGNvbnRleHQpLnRoZW4obnVsbCwgKCkgPT4gewogICAgICAgICAgICBsb2coJ1NlbmRpbmcgQU5SIGV2ZW50IGZhaWxlZC4nKTsKICAgICAgICAgIH0pOwogICAgICAgIH0sCiAgICAgICk7CiAgICB9IGNhdGNoIChlKSB7CiAgICAgIHNlc3Npb24ucG9zdCgnRGVidWdnZXIucmVzdW1lJyk7CiAgICAgIHNlc3Npb24ucG9zdCgnRGVidWdnZXIuZGlzYWJsZScpOwogICAgICB0aHJvdyBlOwogICAgfQogIH0pOwoKICBkZWJ1Z2dlclBhdXNlID0gKCkgPT4gewogICAgdHJ5IHsKICAgICAgc2Vzc2lvbi5wb3N0KCdEZWJ1Z2dlci5lbmFibGUnLCAoKSA9PiB7CiAgICAgICAgc2Vzc2lvbi5wb3N0KCdEZWJ1Z2dlci5wYXVzZScpOwogICAgICB9KTsKICAgIH0gY2F0Y2ggKF8pIHsKICAgICAgLy8KICAgIH0KICB9Owp9CgpmdW5jdGlvbiBjcmVhdGVIclRpbWVyKCkgewogIC8vIFRPRE8gKHY4KTogV2UgY2FuIHVzZSBwcm9jZXNzLmhydGltZS5iaWdpbnQoKSBhZnRlciB3ZSBkcm9wIG5vZGUgdjgKICBsZXQgbGFzdFBvbGwgPSBwcm9jZXNzLmhydGltZSgpOwoKICByZXR1cm4gewogICAgZ2V0VGltZU1zOiAoKSA9PiB7CiAgICAgIGNvbnN0IFtzZWNvbmRzLCBuYW5vU2Vjb25kc10gPSBwcm9jZXNzLmhydGltZShsYXN0UG9sbCk7CiAgICAgIHJldHVybiBNYXRoLmZsb29yKHNlY29uZHMgKiAxZTMgKyBuYW5vU2Vjb25kcyAvIDFlNik7CiAgICB9LAogICAgcmVzZXQ6ICgpID0+IHsKICAgICAgbGFzdFBvbGwgPSBwcm9jZXNzLmhydGltZSgpOwogICAgfSwKICB9Owp9CgpmdW5jdGlvbiB3YXRjaGRvZ1RpbWVvdXQoKSB7CiAgbG9nKCdXYXRjaGRvZyB0aW1lb3V0Jyk7CgogIGlmIChkZWJ1Z2dlclBhdXNlKSB7CiAgICBsb2coJ1BhdXNpbmcgZGVidWdnZXIgdG8gY2FwdHVyZSBzdGFjayB0cmFjZScpOwogICAgZGVidWdnZXJQYXVzZSgpOwogIH0gZWxzZSB7CiAgICBsb2coJ0NhcHR1cmluZyBldmVudCB3aXRob3V0IGEgc3RhY2sgdHJhY2UnKTsKICAgIHNlbmRBbnJFdmVudCgpLnRoZW4obnVsbCwgKCkgPT4gewogICAgICBsb2coJ1NlbmRpbmcgQU5SIGV2ZW50IGZhaWxlZCBvbiB3YXRjaGRvZyB0aW1lb3V0LicpOwogICAgfSk7CiAgfQp9Cgpjb25zdCB7IHBvbGwgfSA9IHdhdGNoZG9nVGltZXIoY3JlYXRlSHJUaW1lciwgb3B0aW9ucy5wb2xsSW50ZXJ2YWwsIG9wdGlvbnMuYW5yVGhyZXNob2xkLCB3YXRjaGRvZ1RpbWVvdXQpOwoKX29wdGlvbmFsQ2hhaW4oW3BhcmVudFBvcnQsICdvcHRpb25hbEFjY2VzcycsIF82ID0+IF82Lm9uLCAnY2FsbCcsIF83ID0+IF83KCdtZXNzYWdlJywgKG1zZykgPT4gewogIGlmIChtc2cuc2Vzc2lvbikgewogICAgc2Vzc2lvbiA9IG1ha2VTZXNzaW9uKG1zZy5zZXNzaW9uKTsKICB9CgogIHBvbGwoKTsKfSldKTs=";

// node_modules/@sentry/node/esm/integrations/anr/index.js
var DEFAULT_INTERVAL = 50;
var DEFAULT_HANG_THRESHOLD = 5e3;
function log(message, ...args) {
  logger.log(`[ANR] ${message}`, ...args);
}
function getWorkerThreads() {
  return dynamicRequire(module, "worker_threads");
}
async function getContexts(client) {
  let event = { message: "ANR" };
  const eventHint = {};
  for (const processor of client.getEventProcessors()) {
    if (event === null)
      break;
    event = await processor(event, eventHint);
  }
  return _optionalChain([event, "optionalAccess", (_2) => _2.contexts]) || {};
}
var INTEGRATION_NAME13 = "Anr";
var _anrIntegration = (options = {}) => {
  return {
    name: INTEGRATION_NAME13,
    // TODO v8: Remove this
    setupOnce() {
    },
    // eslint-disable-line @typescript-eslint/no-empty-function
    setup(client) {
      if (NODE_VERSION.major < 16 || NODE_VERSION.major === 16 && NODE_VERSION.minor < 17) {
        throw new Error("ANR detection requires Node 16.17.0 or later");
      }
      setImmediate(() => _startWorker(client, options));
    }
  };
};
var anrIntegration = defineIntegration(_anrIntegration);
var Anr = convertIntegrationFnToClass(INTEGRATION_NAME13, anrIntegration);
async function _startWorker(client, _options) {
  const contexts = await getContexts(client);
  const dsn = client.getDsn();
  if (!dsn) {
    return;
  }
  _optionalChainDelete([contexts, "access", (_3) => _3.app, "optionalAccess", (_4) => delete _4.app_memory]);
  _optionalChainDelete([contexts, "access", (_5) => _5.device, "optionalAccess", (_6) => delete _6.free_memory]);
  const initOptions = client.getOptions();
  const sdkMetadata = client.getSdkMetadata() || {};
  if (sdkMetadata.sdk) {
    sdkMetadata.sdk.integrations = initOptions.integrations.map((i2) => i2.name);
  }
  const options = {
    debug: logger.isEnabled(),
    dsn,
    environment: initOptions.environment || "production",
    release: initOptions.release,
    dist: initOptions.dist,
    sdkMetadata,
    appRootPath: _options.appRootPath,
    pollInterval: _options.pollInterval || DEFAULT_INTERVAL,
    anrThreshold: _options.anrThreshold || DEFAULT_HANG_THRESHOLD,
    captureStackTrace: !!_options.captureStackTrace,
    staticTags: _options.staticTags || {},
    contexts
  };
  if (options.captureStackTrace) {
    const inspector = require("inspector");
    if (!inspector.url()) {
      inspector.open(0);
    }
  }
  const { Worker } = getWorkerThreads();
  const worker = new Worker(new import_url7.URL(`data:application/javascript;base64,${base64WorkerScript}`), {
    workerData: options
  });
  process.on("exit", () => {
    worker.terminate();
  });
  const timer = setInterval(() => {
    try {
      const currentSession = getCurrentScope().getSession();
      const session = currentSession ? { ...currentSession, toJSON: void 0 } : void 0;
      worker.postMessage({ session });
    } catch (_) {
    }
  }, options.pollInterval);
  timer.unref();
  worker.on("message", (msg) => {
    if (msg === "session-ended") {
      log("ANR event sent from ANR worker. Clearing session in this thread.");
      getCurrentScope().setSession(void 0);
    }
  });
  worker.once("error", (err) => {
    clearInterval(timer);
    log("ANR worker error", err);
  });
  worker.once("exit", (code) => {
    clearInterval(timer);
    log("ANR worker exit", code);
  });
  worker.unref();
}

// node_modules/@sentry/node/esm/integrations/index.js
var integrations_exports2 = {};
__export(integrations_exports2, {
  Anr: () => Anr,
  Console: () => Console,
  Context: () => Context,
  ContextLines: () => ContextLines,
  Hapi: () => Hapi,
  Http: () => Http,
  LocalVariables: () => LocalVariables,
  Modules: () => Modules,
  OnUncaughtException: () => OnUncaughtException,
  OnUnhandledRejection: () => OnUnhandledRejection,
  RequestData: () => RequestData,
  Spotlight: () => Spotlight,
  Undici: () => Undici
});

// node_modules/@sentry/node/esm/integrations/hapi/index.js
function isResponseObject(response) {
  return response && response.statusCode !== void 0;
}
function isBoomObject(response) {
  return response && response.isBoom !== void 0;
}
function isErrorEvent2(event) {
  return event && event.error !== void 0;
}
function sendErrorToSentry(errorData) {
  captureException(errorData, {
    mechanism: {
      type: "hapi",
      handled: false,
      data: {
        function: "hapiErrorPlugin"
      }
    }
  });
}
var hapiErrorPlugin = {
  name: "SentryHapiErrorPlugin",
  version: SDK_VERSION,
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  register: async function(serverArg) {
    const server = serverArg;
    server.events.on("request", (request, event) => {
      const transaction = getActiveTransaction();
      if (request.response && isBoomObject(request.response)) {
        sendErrorToSentry(request.response);
      } else if (isErrorEvent2(event)) {
        sendErrorToSentry(event.error);
      }
      if (transaction) {
        transaction.setStatus("internal_error");
        transaction.end();
      }
    });
  }
};
var hapiTracingPlugin = {
  name: "SentryHapiTracingPlugin",
  version: SDK_VERSION,
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  register: async function(serverArg) {
    const server = serverArg;
    server.ext("onPreHandler", (request, h2) => {
      const transaction = continueTrace(
        {
          sentryTrace: request.headers["sentry-trace"] || void 0,
          baggage: request.headers["baggage"] || void 0
        },
        (transactionContext) => {
          return startTransaction({
            ...transactionContext,
            op: "hapi.request",
            name: request.route.path,
            description: `${request.route.method} ${request.path}`
          });
        }
      );
      getCurrentScope().setSpan(transaction);
      return h2.continue;
    });
    server.ext("onPreResponse", (request, h2) => {
      const transaction = getActiveTransaction();
      if (request.response && isResponseObject(request.response) && transaction) {
        const response = request.response;
        response.header("sentry-trace", spanToTraceHeader(transaction));
        const dynamicSamplingContext = dynamicSamplingContextToSentryBaggageHeader(
          getDynamicSamplingContextFromSpan(transaction)
        );
        if (dynamicSamplingContext) {
          response.header("baggage", dynamicSamplingContext);
        }
      }
      return h2.continue;
    });
    server.ext("onPostHandler", (request, h2) => {
      const transaction = getActiveTransaction();
      if (transaction) {
        if (request.response && isResponseObject(request.response)) {
          setHttpStatus(transaction, request.response.statusCode);
        }
        transaction.end();
      }
      return h2.continue;
    });
  }
};
var INTEGRATION_NAME14 = "Hapi";
var _hapiIntegration = (options = {}) => {
  const server = options.server;
  return {
    name: INTEGRATION_NAME14,
    setupOnce() {
      if (!server) {
        return;
      }
      fill(server, "start", (originalStart) => {
        return async function() {
          await this.register(hapiTracingPlugin);
          await this.register(hapiErrorPlugin);
          const result = originalStart.apply(this);
          return result;
        };
      });
    }
  };
};
var hapiIntegration = defineIntegration(_hapiIntegration);
var Hapi = convertIntegrationFnToClass(INTEGRATION_NAME14, hapiIntegration);

// node_modules/@sentry/node/esm/tracing/integrations.js
var integrations_exports3 = {};
__export(integrations_exports3, {
  Apollo: () => Apollo,
  Express: () => Express,
  GraphQL: () => GraphQL,
  Mongo: () => Mongo,
  Mysql: () => Mysql,
  Postgres: () => Postgres,
  Prisma: () => Prisma
});

// node_modules/@sentry/node/esm/index.js
var getModuleFromFilename = createGetModuleFromFilename();
var Integrations2 = {
  // eslint-disable-next-line deprecation/deprecation
  ...Integrations,
  ...integrations_exports2,
  ...integrations_exports3
};

// src/logForwarder.ts
var forwardLogs = async (data) => {
  if (!data.logs.length)
    return;
  console.log("[Sentry Lambda Exension] Forwarding logs to sentry");
  const outcomes = {};
  const recordDroppedEvent = (reason, category) => {
    const key = `${reason}:${category}`;
    outcomes[key] = outcomes[key] + 1 || 1;
  };
  const transport = makeNodeTransport({
    url: data.logs[0].options.url,
    recordDroppedEvent
  });
  for (const log2 of data.logs) {
    await transport.send(log2.envelope);
  }
  await transport.flush(2e3);
};

// src/index.ts
console.log("[Sentry Lambda Exension] Executing extension code...");
var main = async () => {
  const logAggregator = new LogAggregator();
  const lambdaContext = new LambdaContext();
  const onLogReceived = (log2) => {
    console.log("[Sentry Lambda Exension] Log received", lambdaContext.getRequestId());
    logAggregator.addLog(log2, lambdaContext.getRequestId());
  };
  console.log("[Sentry Lambda Exension] Listening for logs...");
  listenForLog(onLogReceived);
  const extensionApiService = new ExtensionAPIService({
    extensionName: "sentry-lambda-extension"
  });
  const extensionId = await extensionApiService.register([EventTypes.Invoke, EventTypes.Shutdown]);
  console.log(`[Sentry Lambda Exension] Registered with extension API service ${extensionId}. Listening for events...`);
  while (true) {
    const event = await extensionApiService.next();
    const lastContext = lambdaContext.getContext();
    lambdaContext.updateContext(event);
    if (lastContext !== void 0) {
      await forwardLogs({
        context: lastContext,
        logs: logAggregator.getLogs(lastContext.requestId)
      });
      logAggregator.deleteLogs(lastContext.requestId);
    }
  }
};
main().catch((error) => console.error(error));
/*! Bundled license information:

web-streams-polyfill/dist/ponyfill.es2018.js:
  (**
   * @license
   * web-streams-polyfill v3.3.2
   * Copyright 2024 Mattias Buelens, Diwank Singh Tomer and other contributors.
   * This code is released under the MIT license.
   * SPDX-License-Identifier: MIT
   *)

fetch-blob/index.js:
  (*! fetch-blob. MIT License. Jimmy Wärting <https://jimmy.warting.se/opensource> *)

formdata-polyfill/esm.min.js:
  (*! formdata-polyfill. MIT License. Jimmy Wärting <https://jimmy.warting.se/opensource> *)

node-domexception/index.js:
  (*! node-domexception. MIT License. Jimmy Wärting <https://jimmy.warting.se/opensource> *)

@sentry/node/esm/integrations/anr/worker-script.js:
  (*! @sentry/node 7.100.1 (424a9c1) | https://github.com/getsentry/sentry-javascript *)
*/
